package com.example.ui.screens

import android.util.Base64
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.AlternateEmail
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.UserPresenceStatus
import com.example.data.model.UserRole
import com.example.data.repository.SavedAccountsStore
import com.example.ui.components.BitmapMemoryCache
import com.example.ui.components.RoleBadge
import com.example.ui.components.UserAvatar
import com.example.ui.components.UserPresenceIndicator
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UserProfileSheet(
    displayName: String,
    handle: String,
    avatarBase64: String,
    avatarColorIndex: Int,
    keyFingerprint: String,
    safetyNumber: String? = null,
    role: UserRole = UserRole.USER,
    presenceStatus: UserPresenceStatus? = null,
    isSelf: Boolean = false,
    isMuted: Boolean = false,
    savedAccountsCount: Int = 1,
    onDismiss: () -> Unit,
    onMessageAction: (() -> Unit)? = null,
    onAudioCall: (() -> Unit)? = null,
    onVideoCall: (() -> Unit)? = null,
    onEditProfile: (() -> Unit)? = null,
    onEditAvatar: (() -> Unit)? = null,
    onSwitchAccount: (() -> Unit)? = null,
    onOpenFullSecurity: (() -> Unit)? = null,
    onCopied: (String) -> Unit = {}
) {
    val clipboard = LocalClipboardManager.current
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val scrollState = rememberScrollState()

    var showAvatarViewer by remember { mutableStateOf(false) }
    var usernameCopied by remember { mutableStateOf(false) }
    var keyCopied by remember { mutableStateOf(false) }
    var safetyCopied by remember { mutableStateOf(false) }

    LaunchedEffect(usernameCopied) {
        if (usernameCopied) {
            delay(2000L)
            usernameCopied = false
        }
    }
    LaunchedEffect(keyCopied) {
        if (keyCopied) {
            delay(2000L)
            keyCopied = false
        }
    }
    LaunchedEffect(safetyCopied) {
        if (safetyCopied) {
            delay(2000L)
            safetyCopied = false
        }
    }

    val resolvedName = displayName.trim().ifBlank { "Пользователь SpoX" }
    val normalizedHandle = remember(handle) {
        val trimmed = handle.trim()
        when {
            trimmed.isBlank() -> ""
            trimmed.startsWith("@") -> trimmed
            else -> "@$trimmed"
        }
    }
    val formattedFingerprint = remember(keyFingerprint) {
        formatEncryptionCodeForDisplay(keyFingerprint)
    }

    val primaryGlow = MaterialTheme.colorScheme.primary.copy(alpha = 0.22f)
    val secondaryGlow = MaterialTheme.colorScheme.secondary.copy(alpha = 0.16f)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(scrollState)
                .navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 8.dp)
                .testTag("user_profile_sheet"),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Hero Header: Avatar (tappable to view), Display Name, Role, Presence
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = MaterialTheme.colorScheme.surfaceContainer,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.7f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .drawBehind {
                            drawCircle(
                                brush = Brush.radialGradient(
                                    colors = listOf(primaryGlow, Color.Transparent),
                                    center = Offset(size.width * 0.5f, size.height * 0.26f),
                                    radius = (size.width * 0.62f).coerceAtLeast(1f)
                                )
                            )
                            drawCircle(
                                brush = Brush.radialGradient(
                                    colors = listOf(secondaryGlow, Color.Transparent),
                                    center = Offset(size.width * 0.85f, size.height * 0.15f),
                                    radius = (size.width * 0.42f).coerceAtLeast(1f)
                                )
                            )
                        }
                        .padding(horizontal = 18.dp, vertical = 20.dp)
                ) {
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .size(48.dp)
                            .testTag("user_profile_close_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Close,
                            contentDescription = "Закрыть профиль"
                        )
                    }

                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .clip(CircleShape)
                                .clickable { showAvatarViewer = true }
                                .padding(4.dp)
                                .testTag("user_profile_avatar_button")
                        ) {
                            UserAvatar(
                                name = resolvedName,
                                avatarBase64 = avatarBase64,
                                colorIndex = avatarColorIndex,
                                size = 104.dp,
                                presenceStatus = if (isSelf) null else presenceStatus
                            )
                            Surface(
                                shape = CircleShape,
                                color = MaterialTheme.colorScheme.surfaceContainerHigh,
                                shadowElevation = 3.dp,
                                border = BorderStroke(
                                    1.dp,
                                    MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.7f)
                                ),
                                modifier = Modifier
                                    .align(Alignment.BottomStart)
                                    .size(32.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Filled.ZoomIn,
                                        contentDescription = "Посмотреть фото профиля",
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = if (avatarBase64.isNotBlank()) "Нажмите на аватар для просмотра" else "Просмотр аватара",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = resolvedName,
                                style = MaterialTheme.typography.headlineSmall,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier
                                    .weight(1f, fill = false)
                                    .testTag("user_profile_name_text")
                            )
                            if (role != UserRole.USER) {
                                Spacer(modifier = Modifier.width(8.dp))
                                RoleBadge(role = role, compact = true)
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        when {
                            isSelf -> {
                                Surface(
                                    shape = RoundedCornerShape(50),
                                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.14f)
                                ) {
                                    Text(
                                        text = "Ваш профиль",
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.SemiBold,
                                        color = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                    )
                                }
                            }
                            presenceStatus != null -> {
                                UserPresenceIndicator(status = presenceStatus, compact = false)
                            }
                        }

                        val hasQuickActions = onMessageAction != null || onAudioCall != null || onVideoCall != null || onEditProfile != null
                        if (hasQuickActions) {
                            Spacer(modifier = Modifier.height(16.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally)
                            ) {
                                if (onMessageAction != null) {
                                    FilledTonalButton(
                                        onClick = {
                                            onDismiss()
                                            onMessageAction()
                                        },
                                        shape = RoundedCornerShape(14.dp),
                                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp),
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(48.dp)
                                            .testTag("user_profile_message_button")
                                    ) {
                                        Icon(
                                            imageVector = Icons.AutoMirrored.Filled.Chat,
                                            contentDescription = null,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Написать", maxLines = 1)
                                    }
                                }
                                if (onAudioCall != null) {
                                    FilledTonalButton(
                                        onClick = {
                                            onDismiss()
                                            onAudioCall()
                                        },
                                        enabled = !isMuted,
                                        shape = RoundedCornerShape(14.dp),
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp),
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(48.dp)
                                            .testTag("user_profile_audio_call_button")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Filled.Call,
                                            contentDescription = null,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Звонок", maxLines = 1)
                                    }
                                }
                                if (onVideoCall != null) {
                                    FilledTonalButton(
                                        onClick = {
                                            onDismiss()
                                            onVideoCall()
                                        },
                                        enabled = !isMuted,
                                        shape = RoundedCornerShape(14.dp),
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp),
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(48.dp)
                                            .testTag("user_profile_video_call_button")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Filled.Videocam,
                                            contentDescription = null,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Видео", maxLines = 1)
                                    }
                                }
                                if (onEditProfile != null) {
                                    Button(
                                        onClick = {
                                            onDismiss()
                                            onEditProfile()
                                        },
                                        shape = RoundedCornerShape(14.dp),
                                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(48.dp)
                                            .testTag("user_profile_edit_button")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Filled.Edit,
                                            contentDescription = null,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("Редактировать профиль", maxLines = 1)
                                    }
                                }
                            }
                        }

                        if (isSelf && onSwitchAccount != null) {
                            Spacer(modifier = Modifier.height(10.dp))
                            FilledTonalButton(
                                onClick = {
                                    onDismiss()
                                    onSwitchAccount()
                                },
                                shape = RoundedCornerShape(14.dp),
                                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .testTag("user_profile_switch_account_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.SwapHoriz,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Сменить аккаунт ($savedAccountsCount/${SavedAccountsStore.MAX_ACCOUNTS})",
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }
            }

            // Username Card (with copy capability)
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = MaterialTheme.colorScheme.surfaceContainer,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                modifier = Modifier
                    .fillMaxWidth()
                    .let { base ->
                        if (normalizedHandle.isNotBlank()) {
                            base.clickable {
                                clipboard.setText(AnnotatedString(normalizedHandle))
                                usernameCopied = true
                                onCopied("Юзернейм $normalizedHandle скопирован")
                            }
                        } else {
                            base
                        }
                    }
                    .testTag("user_profile_username_card")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.14f),
                        modifier = Modifier.size(40.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Filled.AlternateEmail,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Юзернейм",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = if (normalizedHandle.isNotBlank()) normalizedHandle else "Юзернейм не задан",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = if (normalizedHandle.isNotBlank()) FontWeight.SemiBold else FontWeight.Normal,
                            fontStyle = if (normalizedHandle.isBlank()) FontStyle.Italic else FontStyle.Normal,
                            color = if (normalizedHandle.isNotBlank()) {
                                MaterialTheme.colorScheme.primary
                            } else {
                                MaterialTheme.colorScheme.onSurfaceVariant
                            },
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.testTag("user_profile_username_text")
                        )
                    }
                    if (normalizedHandle.isNotBlank()) {
                        IconButton(
                            onClick = {
                                clipboard.setText(AnnotatedString(normalizedHandle))
                                usernameCopied = true
                                onCopied("Юзернейм $normalizedHandle скопирован")
                            },
                            modifier = Modifier
                                .size(48.dp)
                                .testTag("user_profile_copy_username_button")
                        ) {
                            AnimatedContent(
                                targetState = usernameCopied,
                                transitionSpec = { fadeIn(tween(180)) togetherWith fadeOut(tween(180)) },
                                label = "username_copy_icon"
                            ) { copied ->
                                Icon(
                                    imageVector = if (copied) Icons.Filled.Check else Icons.Filled.ContentCopy,
                                    contentDescription = "Скопировать юзернейм",
                                    tint = if (copied) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }
                }
            }

            // Encryption Code Card
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.28f),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.35f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("user_profile_encryption_card")
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.16f),
                            modifier = Modifier.size(40.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Filled.Key,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Код шифрования",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "Отпечаток ключа ECDH P-256 • SHA-256",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Surface(
                            shape = RoundedCornerShape(50),
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.16f)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Lock,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(12.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "E2EE",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary,
                                    maxLines = 1,
                                    softWrap = false
                                )
                            }
                        }
                    }

                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.85f),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.65f))
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(start = 12.dp, top = 8.dp, bottom = 8.dp, end = 4.dp)
                        ) {
                            Text(
                                text = formattedFingerprint.ifBlank { "Ключ шифрования недоступен" },
                                style = MaterialTheme.typography.bodyMedium,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Medium,
                                color = if (formattedFingerprint.isNotBlank()) {
                                    MaterialTheme.colorScheme.primary
                                } else {
                                    MaterialTheme.colorScheme.onSurfaceVariant
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("user_profile_encryption_code_text")
                            )
                            if (keyFingerprint.isNotBlank()) {
                                IconButton(
                                    onClick = {
                                        clipboard.setText(AnnotatedString(keyFingerprint))
                                        keyCopied = true
                                        onCopied("Код шифрования скопирован")
                                    },
                                    modifier = Modifier
                                        .size(48.dp)
                                        .testTag("user_profile_copy_encryption_button")
                                ) {
                                    AnimatedContent(
                                        targetState = keyCopied,
                                        transitionSpec = { fadeIn(tween(180)) togetherWith fadeOut(tween(180)) },
                                        label = "key_copy_icon"
                                    ) { copied ->
                                        Icon(
                                            imageVector = if (copied) Icons.Filled.Check else Icons.Filled.ContentCopy,
                                            contentDescription = "Скопировать код шифрования",
                                            tint = if (copied) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.primary
                                        )
                                    }
                                }
                            }
                        }
                    }

                    if (!safetyNumber.isNullOrBlank()) {
                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.45f))
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Общий код безопасности чата",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = safetyNumber,
                                    style = MaterialTheme.typography.titleSmall,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.testTag("user_profile_safety_number_text")
                                )
                            }
                            IconButton(
                                onClick = {
                                    clipboard.setText(AnnotatedString(safetyNumber))
                                    safetyCopied = true
                                    onCopied("Код безопасности чата скопирован")
                                },
                                modifier = Modifier
                                    .size(48.dp)
                                    .testTag("user_profile_copy_safety_button")
                            ) {
                                AnimatedContent(
                                    targetState = safetyCopied,
                                    transitionSpec = { fadeIn(tween(180)) togetherWith fadeOut(tween(180)) },
                                    label = "safety_copy_icon"
                                ) { copied ->
                                    Icon(
                                        imageVector = if (copied) Icons.Filled.Check else Icons.Filled.ContentCopy,
                                        contentDescription = "Скопировать код безопасности чата",
                                        tint = if (copied) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.primary
                                    )
                                }
                            }
                        }
                    }

                    if (onOpenFullSecurity != null) {
                        TextButton(
                            onClick = {
                                onDismiss()
                                onOpenFullSecurity()
                            },
                            modifier = Modifier
                                .align(Alignment.End)
                                .testTag("user_profile_verify_e2ee_button")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.VerifiedUser,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Проверить ключи чата")
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
        }
    }

    if (showAvatarViewer) {
        AvatarViewerDialog(
            displayName = resolvedName,
            handle = normalizedHandle,
            avatarBase64 = avatarBase64,
            avatarColorIndex = avatarColorIndex,
            onEditAvatar = onEditAvatar?.let { editCallback ->
                {
                    showAvatarViewer = false
                    editCallback()
                }
            },
            onDismiss = { showAvatarViewer = false }
        )
    }
}

@Composable
fun AvatarViewerDialog(
    displayName: String,
    handle: String = "",
    avatarBase64: String,
    avatarColorIndex: Int = 0,
    onEditAvatar: (() -> Unit)? = null,
    onDismiss: () -> Unit
) {
    val fullBitmap by produceState<ImageBitmap?>(initialValue = null, key1 = avatarBase64) {
        if (avatarBase64.isBlank()) {
            value = null
        } else {
            val bytes = runCatching { Base64.decode(avatarBase64, Base64.DEFAULT) }.getOrNull()
            value = if (bytes != null && bytes.isNotEmpty()) {
                BitmapMemoryCache.decodeFullImage(bytes, maxDimensionPx = 1400)
            } else {
                null
            }
        }
    }

    var scale by remember { mutableFloatStateOf(1f) }
    var offsetX by remember { mutableFloatStateOf(0f) }
    var offsetY by remember { mutableFloatStateOf(0f) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        BackHandler(onBack = onDismiss)
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.94f))
                .statusBarsPadding()
                .navigationBarsPadding()
                .testTag("avatar_viewer_dialog")
        ) {
            // Top bar
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.TopCenter)
                    .padding(horizontal = 12.dp, vertical = 10.dp)
            ) {
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .padding(start = 6.dp)
                ) {
                    Text(
                        text = displayName.ifBlank { "Аватар" },
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = Color.White,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (handle.isNotBlank()) {
                        Text(
                            text = handle,
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.White.copy(alpha = 0.72f),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
                if (onEditAvatar != null) {
                    OutlinedButton(
                        onClick = onEditAvatar,
                        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.35f)),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .height(42.dp)
                            .testTag("avatar_viewer_edit_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.PhotoLibrary,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Изменить", maxLines = 1)
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                }
                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("avatar_viewer_close_button")
                ) {
                    Surface(
                        shape = CircleShape,
                        color = Color.White.copy(alpha = 0.14f),
                        modifier = Modifier.size(38.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Filled.Close,
                                contentDescription = "Закрыть просмотр аватара",
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }

            // Center image / fallback avatar
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 20.dp, vertical = 76.dp)
                    .pointerInput(Unit) {
                        detectTapGestures(
                            onDoubleTap = {
                                if (scale > 1.05f) {
                                    scale = 1f
                                    offsetX = 0f
                                    offsetY = 0f
                                } else {
                                    scale = 2.1f
                                }
                            },
                            onTap = {
                                if (scale <= 1.02f) onDismiss()
                            }
                        )
                    }
            ) {
                val bmp = fullBitmap
                if (bmp != null) {
                    Image(
                        bitmap = bmp,
                        contentDescription = "Фото профиля $displayName",
                        contentScale = ContentScale.Fit,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(20.dp))
                            .pointerInput(Unit) {
                                detectTransformGestures { _, pan, zoom, _ ->
                                    val nextScale = (scale * zoom).coerceIn(1f, 3.2f)
                                    scale = nextScale
                                    if (nextScale > 1.02f) {
                                        offsetX = (offsetX + pan.x).coerceIn(-420f, 420f)
                                        offsetY = (offsetY + pan.y).coerceIn(-420f, 420f)
                                    } else {
                                        offsetX = 0f
                                        offsetY = 0f
                                    }
                                }
                            }
                            .graphicsLayer {
                                scaleX = scale
                                scaleY = scale
                                translationX = offsetX
                                translationY = offsetY
                            }
                    )
                } else {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        UserAvatar(
                            name = displayName,
                            avatarBase64 = avatarBase64,
                            colorIndex = avatarColorIndex,
                            size = 200.dp
                        )
                        Text(
                            text = if (avatarBase64.isBlank()) {
                                "Фото профиля не установлено"
                            } else {
                                "Загрузка изображения..."
                            },
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color.White.copy(alpha = 0.78f)
                        )
                    }
                }
            }

            if (fullBitmap != null) {
                Text(
                    text = "Двойное нажатие или сведение пальцев для масштаба",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.White.copy(alpha = 0.58f),
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 18.dp)
                )
            }
        }
    }
}

private fun formatEncryptionCodeForDisplay(raw: String): String {
    val clean = raw.trim()
    if (clean.isBlank()) return ""
    if (clean.contains(":") || clean.contains(" ") || clean.contains("-")) return clean
    return clean.chunked(4).joinToString(" ")
}
