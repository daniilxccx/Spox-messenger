package com.example.ui.theme

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.os.Build
import android.view.Window
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import com.example.data.model.AppThemeMode
import com.example.data.model.AppVisualTheme
import com.example.data.model.ChatAppearanceConfig

@Immutable
data class SpoXPresenceColors(
    val online: Color,
    val recent: Color,
    val offline: Color
)

val LocalPresenceColors = staticCompositionLocalOf {
    SpoXPresenceColors(
        online = DarkPresenceOnline,
        recent = DarkPresenceRecent,
        offline = DarkPresenceOffline
    )
}

val LocalChatAppearance = staticCompositionLocalOf {
    ChatAppearanceConfig()
}

private val CipherDarkColorScheme = darkColorScheme(
    primary = DarkPrimary,
    onPrimary = DarkOnPrimary,
    primaryContainer = DarkPrimaryContainer,
    onPrimaryContainer = DarkOnPrimaryContainer,
    secondary = DarkSecondary,
    onSecondary = DarkOnSecondary,
    secondaryContainer = DarkSecondaryContainer,
    onSecondaryContainer = DarkOnSecondaryContainer,
    tertiary = DarkTertiary,
    onTertiary = DarkOnTertiary,
    tertiaryContainer = DarkTertiaryContainer,
    onTertiaryContainer = DarkOnTertiaryContainer,
    background = DarkBackground,
    onBackground = DarkOnBackground,
    surface = DarkSurface,
    onSurface = DarkOnSurface,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = DarkOnSurfaceVariant,
    surfaceContainerLow = DarkSurfaceContainerLow,
    surfaceContainer = DarkSurfaceContainer,
    surfaceContainerHigh = DarkSurfaceContainerHigh,
    outline = DarkOutline,
    outlineVariant = DarkOutlineVariant,
    error = DarkError,
    onError = DarkOnError
)

private val CipherLightColorScheme = lightColorScheme(
    primary = LightPrimary,
    onPrimary = LightOnPrimary,
    primaryContainer = LightPrimaryContainer,
    onPrimaryContainer = LightOnPrimaryContainer,
    secondary = LightSecondary,
    onSecondary = LightOnSecondary,
    secondaryContainer = LightSecondaryContainer,
    onSecondaryContainer = LightOnSecondaryContainer,
    tertiary = LightTertiary,
    onTertiary = LightOnTertiary,
    tertiaryContainer = LightTertiaryContainer,
    onTertiaryContainer = LightOnTertiaryContainer,
    background = LightBackground,
    onBackground = LightOnBackground,
    surface = LightSurface,
    onSurface = LightOnSurface,
    surfaceVariant = LightSurfaceVariant,
    onSurfaceVariant = LightOnSurfaceVariant,
    surfaceContainerLow = LightSurfaceContainerLow,
    surfaceContainer = LightSurfaceContainer,
    surfaceContainerHigh = LightSurfaceContainerHigh,
    outline = LightOutline,
    outlineVariant = LightOutlineVariant,
    error = LightError,
    onError = LightOnError
)

private fun buildDynamicThemeColorScheme(
    visualTheme: AppVisualTheme,
    isDark: Boolean,
    liquidGlass: Boolean
): ColorScheme {
    val base = if (visualTheme == AppVisualTheme.SPOX_CYBER) {
        if (isDark) CipherDarkColorScheme else CipherLightColorScheme
    } else if (isDark) {
        val bg = visualTheme.darkBackground
        val surf = visualTheme.darkSurface
        val pri = visualTheme.darkPrimary
        val sec = visualTheme.darkSecondary
        val ter = visualTheme.darkTertiary
        val isMono = visualTheme == AppVisualTheme.MONO_SLATE
        val onPri = if (isMono) Color(0xFF0A0A0C) else lerp(bg, Color.Black, 0.45f)
        val priContainer = if (isMono) Color(0xFF27272F) else lerp(surf, pri, 0.26f)
        val onPriContainer = if (isMono) Color(0xFFF8FAFC) else lerp(pri, Color.White, 0.65f)
        val secContainer = if (isMono) Color(0xFF1F242D) else lerp(surf, sec, 0.24f)
        val onSecContainer = if (isMono) Color(0xFFE2E8F0) else lerp(sec, Color.White, 0.65f)
        val terContainer = lerp(surf, ter, 0.24f)
        val onTerContainer = lerp(ter, Color.White, 0.65f)

        darkColorScheme(
            primary = pri,
            onPrimary = onPri,
            primaryContainer = priContainer,
            onPrimaryContainer = onPriContainer,
            secondary = sec,
            onSecondary = lerp(bg, Color.Black, 0.4f),
            secondaryContainer = secContainer,
            onSecondaryContainer = onSecContainer,
            tertiary = ter,
            onTertiary = lerp(bg, Color.Black, 0.4f),
            tertiaryContainer = terContainer,
            onTertiaryContainer = onTerContainer,
            background = bg,
            onBackground = Color(0xFFF1F5F9),
            surface = surf,
            onSurface = Color(0xFFE2E8F0),
            surfaceVariant = lerp(surf, pri, 0.08f),
            onSurfaceVariant = Color(0xFF94A3B8),
            surfaceContainerLow = lerp(bg, surf, 0.65f),
            surfaceContainer = lerp(surf, pri, 0.06f),
            surfaceContainerHigh = lerp(surf, pri, 0.13f),
            outline = lerp(surf, Color.White, 0.18f),
            outlineVariant = lerp(surf, Color.White, 0.10f),
            error = DarkError,
            onError = DarkOnError
        )
    } else {
        val bg = visualTheme.lightBackground
        val pri = visualTheme.lightPrimary
        val sec = visualTheme.lightSecondary
        val ter = visualTheme.darkTertiary
        val priContainer = lerp(Color.White, pri, 0.16f)
        val onPriContainer = lerp(pri, Color.Black, 0.45f)
        val secContainer = lerp(Color.White, sec, 0.16f)
        val onSecContainer = lerp(sec, Color.Black, 0.45f)

        lightColorScheme(
            primary = pri,
            onPrimary = Color.White,
            primaryContainer = priContainer,
            onPrimaryContainer = onPriContainer,
            secondary = sec,
            onSecondary = Color.White,
            secondaryContainer = secContainer,
            onSecondaryContainer = onSecContainer,
            tertiary = ter,
            onTertiary = Color.White,
            tertiaryContainer = lerp(Color.White, ter, 0.16f),
            onTertiaryContainer = lerp(ter, Color.Black, 0.45f),
            background = bg,
            onBackground = Color(0xFF0F172A),
            surface = Color.White,
            onSurface = Color(0xFF1E293B),
            surfaceVariant = lerp(bg, pri, 0.08f),
            onSurfaceVariant = Color(0xFF64748B),
            surfaceContainerLow = lerp(Color.White, bg, 0.45f),
            surfaceContainer = lerp(bg, pri, 0.06f),
            surfaceContainerHigh = lerp(bg, pri, 0.12f),
            outline = Color(0xFFCBD5E1),
            outlineVariant = Color(0xFFE2E8F0),
            error = LightError,
            onError = LightOnError
        )
    }
    return if (liquidGlass) applyLiquidGlassColorScheme(base, isDark) else base
}

private fun applyLiquidGlassColorScheme(base: ColorScheme, isDark: Boolean): ColorScheme {
    val glassOutline = if (isDark) {
        Color.White.copy(alpha = 0.24f)
    } else {
        lerp(Color.White, base.outline, 0.42f).copy(alpha = 0.72f)
    }
    val glassOutlineVariant = if (isDark) {
        Color.White.copy(alpha = 0.12f)
    } else {
        lerp(Color.White, base.outlineVariant, 0.45f).copy(alpha = 0.56f)
    }
    return base.copy(
        surface = base.surface.copy(alpha = if (isDark) 0.62f else 0.72f),
        surfaceVariant = base.surfaceVariant.copy(alpha = if (isDark) 0.58f else 0.68f),
        surfaceContainerLowest = base.surface.copy(alpha = if (isDark) 0.52f else 0.62f),
        surfaceContainerLow = base.surfaceContainerLow.copy(alpha = if (isDark) 0.60f else 0.68f),
        surfaceContainer = base.surfaceContainer.copy(alpha = if (isDark) 0.66f else 0.74f),
        surfaceContainerHigh = base.surfaceContainerHigh.copy(alpha = if (isDark) 0.72f else 0.80f),
        surfaceContainerHighest = base.surfaceContainerHigh.copy(alpha = if (isDark) 0.78f else 0.86f),
        primaryContainer = base.primaryContainer.copy(alpha = if (isDark) 0.64f else 0.72f),
        secondaryContainer = base.secondaryContainer.copy(alpha = if (isDark) 0.62f else 0.70f),
        tertiaryContainer = base.tertiaryContainer.copy(alpha = if (isDark) 0.62f else 0.70f),
        outline = glassOutline,
        outlineVariant = glassOutlineVariant
    )
}

@Composable
fun LiquidGlassBackdrop(modifier: Modifier = Modifier) {
    val appearance = LocalChatAppearance.current
    val isDark = when (appearance.themeMode) {
        AppThemeMode.DARK -> true
        AppThemeMode.LIGHT -> false
        AppThemeMode.SYSTEM -> isSystemInDarkTheme()
    }
    val backgroundColor = MaterialTheme.colorScheme.background
    val primaryGlow = MaterialTheme.colorScheme.primary.copy(alpha = if (isDark) 0.13f else 0.09f)
    val secondaryGlow = MaterialTheme.colorScheme.secondary.copy(alpha = if (isDark) 0.10f else 0.07f)
    val tertiaryGlow = MaterialTheme.colorScheme.tertiary.copy(alpha = if (isDark) 0.08f else 0.05f)

    Box(modifier = modifier) {
        val blurModifier = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            Modifier.blur(26.dp)
        } else {
            Modifier
        }
        Box(
            modifier = Modifier
                .fillMaxSize()
                .then(blurModifier)
                .drawWithCache {
                    val topRightCenter = Offset(size.width * 0.84f, size.height * 0.10f)
                    val topRightRadius = (size.maxDimension * 0.48f).coerceAtLeast(1f)
                    val midLeftCenter = Offset(size.width * 0.12f, size.height * 0.42f)
                    val midLeftRadius = (size.maxDimension * 0.44f).coerceAtLeast(1f)
                    val bottomRightCenter = Offset(size.width * 0.76f, size.height * 0.86f)
                    val bottomRightRadius = (size.maxDimension * 0.48f).coerceAtLeast(1f)

                    val baseMesh = Brush.verticalGradient(
                        colors = listOf(
                            backgroundColor,
                            lerp(backgroundColor, primaryGlow.copy(alpha = 1f), if (isDark) 0.05f else 0.03f),
                            backgroundColor
                        )
                    )
                    val topRightOrb = Brush.radialGradient(
                        colors = listOf(primaryGlow, Color.Transparent),
                        center = topRightCenter,
                        radius = topRightRadius
                    )
                    val midLeftOrb = Brush.radialGradient(
                        colors = listOf(secondaryGlow, Color.Transparent),
                        center = midLeftCenter,
                        radius = midLeftRadius
                    )
                    val bottomRightOrb = Brush.radialGradient(
                        colors = listOf(tertiaryGlow, Color.Transparent),
                        center = bottomRightCenter,
                        radius = bottomRightRadius
                    )

                    onDrawBehind {
                        drawRect(brush = baseMesh)
                        drawCircle(brush = topRightOrb, radius = topRightRadius, center = topRightCenter)
                        drawCircle(brush = midLeftOrb, radius = midLeftRadius, center = midLeftCenter)
                        drawCircle(brush = bottomRightOrb, radius = bottomRightRadius, center = bottomRightCenter)
                    }
                }
        )
    }
}

val CipherShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun CipherChatTheme(
    themeMode: AppThemeMode = AppThemeMode.DARK,
    appearanceConfig: ChatAppearanceConfig = ChatAppearanceConfig(themeMode = themeMode),
    content: @Composable () -> Unit
) {
    val isDark = when (appearanceConfig.themeMode) {
        AppThemeMode.DARK -> true
        AppThemeMode.LIGHT -> false
        AppThemeMode.SYSTEM -> isSystemInDarkTheme()
    }

    val colorScheme = buildDynamicThemeColorScheme(
        visualTheme = appearanceConfig.visualTheme,
        isDark = isDark,
        liquidGlass = appearanceConfig.liquidGlassEnabled && !appearanceConfig.resourceSavingMode
    )
    val presenceColors = if (isDark) {
        SpoXPresenceColors(
            online = DarkPresenceOnline,
            recent = DarkPresenceRecent,
            offline = DarkPresenceOffline
        )
    } else {
        SpoXPresenceColors(
            online = LightPresenceOnline,
            recent = LightPresenceRecent,
            offline = LightPresenceOffline
        )
    }

    val view = LocalView.current
    if (!view.isInEditMode) {
        LaunchedEffect(view, isDark) {
            val window = view.context.findActivityWindow() ?: return@LaunchedEffect
            runCatching {
                val controller = WindowCompat.getInsetsController(window, view)
                controller.isAppearanceLightStatusBars = !isDark
                controller.isAppearanceLightNavigationBars = !isDark
            }
        }
    }

    CompositionLocalProvider(
        LocalPresenceColors provides presenceColors,
        LocalChatAppearance provides appearanceConfig
    ) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = Typography,
            shapes = CipherShapes,
            content = content
        )
    }
}

private tailrec fun Context.findActivityWindow(): Window? = when (this) {
    is Activity -> window
    is ContextWrapper -> baseContext.findActivityWindow()
    else -> null
}
