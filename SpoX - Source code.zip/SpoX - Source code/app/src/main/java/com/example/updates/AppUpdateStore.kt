package com.example.updates

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.example.BuildConfig
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

class AppUpdateStore(
    context: Context,
    private val currentVersionProvider: () -> String = { BuildConfig.VERSION_NAME },
    private val currentVersionCodeProvider: () -> Int = { BuildConfig.VERSION_CODE },
    private val fetcher: suspend () -> Result<GitHubUpdateService.FetchOutcome> = {
        GitHubUpdateService.fetchReleases()
    }
) {
    private val appContext = context.applicationContext
    private val prefs = appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    private val checkMutex = Mutex()

    private val _state = MutableStateFlow(
        AppUpdateState(
            currentVersion = currentVersionProvider(),
            currentVersionCode = currentVersionCodeProvider(),
            autoCheckEnabled = prefs.getBoolean(KEY_AUTO_CHECK, true),
            skippedTag = prefs.getString(KEY_SKIPPED_TAG, null),
            lastCheckedAtMs = prefs.getLong(KEY_LAST_CHECK_MS, 0L).takeIf { it > 0L }
        )
    )
    val state: StateFlow<AppUpdateState> = _state.asStateFlow()

    suspend fun checkForUpdates(force: Boolean = false): AppUpdateState {
        val currentState = _state.value
        val now = System.currentTimeMillis()
        if (!force && currentState.lastCheckedAtMs != null &&
            currentState.status != UpdateCheckStatus.IDLE &&
            (now - currentState.lastCheckedAtMs) < AUTO_CHECK_COOLDOWN_MS
        ) {
            return currentState
        }

        return checkMutex.withLock {
            val latestBefore = _state.value
            val checkNow = System.currentTimeMillis()
            if (!force && latestBefore.lastCheckedAtMs != null &&
                latestBefore.status != UpdateCheckStatus.IDLE &&
                (checkNow - latestBefore.lastCheckedAtMs) < AUTO_CHECK_COOLDOWN_MS
            ) {
                return@withLock latestBefore
            }

            _state.value = latestBefore.copy(
                status = UpdateCheckStatus.CHECKING,
                errorMessage = null
            )

            val result = fetcher()
            val finishedAt = System.currentTimeMillis()
            prefs.edit().putLong(KEY_LAST_CHECK_MS, finishedAt).apply()

            val nextState = result.fold(
                onSuccess = { outcome ->
                    val candidate = GitHubUpdateService.selectBestCandidateRelease(outcome.releases)
                    if (candidate == null) {
                        _state.value.copy(
                            status = UpdateCheckStatus.NO_RELEASES,
                            latestRelease = null,
                            recentReleases = emptyList(),
                            lastCheckedAtMs = finishedAt,
                            errorMessage = null
                        )
                    } else {
                        val isNewer = GitHubUpdateService.compareVersions(
                            candidate = candidate.versionName,
                            current = currentVersionProvider()
                        ) > 0
                        _state.value.copy(
                            status = if (isNewer) UpdateCheckStatus.UPDATE_AVAILABLE else UpdateCheckStatus.UP_TO_DATE,
                            latestRelease = candidate,
                            recentReleases = outcome.releases,
                            lastCheckedAtMs = finishedAt,
                            errorMessage = null
                        )
                    }
                },
                onFailure = { error ->
                    _state.value.copy(
                        status = UpdateCheckStatus.ERROR,
                        lastCheckedAtMs = finishedAt,
                        errorMessage = error.localizedMessage ?: "Не удалось проверить обновления на GitHub"
                    )
                }
            )
            _state.value = nextState
            nextState
        }
    }

    fun setAutoCheckEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_AUTO_CHECK, enabled).apply()
        _state.value = _state.value.copy(autoCheckEnabled = enabled)
    }

    fun skipVersion(tagName: String) {
        prefs.edit().putString(KEY_SKIPPED_TAG, tagName).apply()
        _state.value = _state.value.copy(skippedTag = tagName)
    }

    fun clearSkippedVersion() {
        prefs.edit().remove(KEY_SKIPPED_TAG).apply()
        _state.value = _state.value.copy(skippedTag = null)
    }

    fun openTrustedReleaseUrl(context: Context, url: String): Boolean {
        if (!GitHubUpdateService.isTrustedGitHubUrl(url)) return false
        return runCatching {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            true
        }.getOrDefault(false)
    }

    companion object {
        private const val PREFS_NAME = "spox_updates_prefs"
        private const val KEY_AUTO_CHECK = "auto_check_enabled"
        private const val KEY_SKIPPED_TAG = "skipped_tag"
        private const val KEY_LAST_CHECK_MS = "last_checked_ms"
        private const val AUTO_CHECK_COOLDOWN_MS = 10 * 60 * 1000L

        @Volatile
        private var instance: AppUpdateStore? = null

        fun getInstance(context: Context): AppUpdateStore {
            return instance ?: synchronized(this) {
                instance ?: AppUpdateStore(context.applicationContext).also { instance = it }
            }
        }
    }
}
