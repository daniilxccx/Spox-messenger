package com.example.notifications

import android.content.Context
import android.util.Log
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.example.R
import com.example.data.model.CallSession
import com.example.data.model.Conversation
import com.google.firebase.Firebase
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await
import java.util.concurrent.TimeUnit

class MessagePushWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        if (FirebaseApp.getApps(applicationContext).isEmpty()) {
            runCatching { FirebaseApp.initializeApp(applicationContext) }
        }
        val uid = runCatching { Firebase.auth.currentUser?.uid }.getOrNull() ?: return Result.success()
        if (!SpoXNotificationHelper.hasNotificationPermission(applicationContext)) {
            return Result.success()
        }

        val checkMessages = NotificationPreferences.isMessagePushEnabled(applicationContext)
        val checkCalls = NotificationPreferences.isCallPushEnabled(applicationContext)
        if (!checkMessages && !checkCalls) {
            return Result.success()
        }

        return runCatching {
            val dbId = applicationContext.getString(R.string.firestore_database_id)
            val db = FirebaseFirestore.getInstance(dbId)

            if (checkMessages) {
                val convSnapshot = db.collection("conversations")
                    .whereArrayContains("memberUids", uid)
                    .get()
                    .await()

                val conversations = convSnapshot.toObjects(Conversation::class.java)
                conversations.forEach { conv ->
                    val unread = conv.unreadCountFor(uid)
                    if (unread <= 0) return@forEach
                    if (conv.lastMessageSenderId.isBlank() || conv.lastMessageSenderId == uid) return@forEach
                    if (ActiveChatTracker.isActivelyViewingChat(conv.id)) return@forEach

                    val msgTimeMs = (conv.updatedAt ?: conv.createdAt)?.toDate()?.time ?: 0L
                    val lastNotifiedMs = NotificationPreferences.getLastNotifiedMs(
                        context = applicationContext,
                        uid = uid,
                        chatId = conv.id
                    )

                    if (msgTimeMs > lastNotifiedMs) {
                        val peerUid = conv.memberUids.firstOrNull { it != uid }
                        val peerName = peerUid?.let { conv.memberNames[it] }.orEmpty()
                        val chatTitle = if (conv.isGroup) {
                            conv.title.ifBlank { "Групповой чат" }
                        } else {
                            peerName.ifBlank { conv.title.ifBlank { "SpoX" } }
                        }
                        val senderName = conv.memberNames[conv.lastMessageSenderId]
                            ?.ifBlank { chatTitle }
                            ?: chatTitle
                        val body = when (conv.lastMessageType) {
                            "voice" -> "Голосовое сообщение"
                            "image" -> "Зашифрованное фото"
                            "file" -> "Зашифрованный файл"
                            "call_event" -> conv.lastMessagePreview.ifBlank { "Событие звонка" }
                            else -> conv.lastMessagePreview.ifBlank { "Новое зашифрованное сообщение" }
                        }

                        NotificationPreferences.markChatNotified(
                            context = applicationContext,
                            uid = uid,
                            chatId = conv.id,
                            messageTimeMs = msgTimeMs
                        )
                        SpoXNotificationHelper.showMessageNotification(
                            context = applicationContext,
                            chatId = conv.id,
                            chatTitle = chatTitle,
                            body = body,
                            unreadCount = unread,
                            senderName = senderName
                        )
                    }
                }
            }

            if (checkCalls) {
                val callsSnapshot = db.collection("calls")
                    .whereArrayContains("memberUids", uid)
                    .get()
                    .await()
                val calls = callsSnapshot.toObjects(CallSession::class.java)
                calls.forEach { call ->
                    val isIncomingRinging = call.status == "ringing" &&
                        call.callerId != uid &&
                        uid !in call.activeParticipantUids
                    if (isIncomingRinging && !ActiveChatTracker.isAppInForeground) {
                        SpoXNotificationHelper.showIncomingCallNotification(
                            context = applicationContext,
                            callId = call.id,
                            callerName = call.callerName,
                            conversationTitle = call.conversationTitle,
                            isGroupCall = call.isGroupCall,
                            callType = call.callType
                        )
                    }
                }
            }

            Result.success()
        }.getOrElse { error ->
            Log.w(TAG, "Background message push sync failed: ${error.message}")
            Result.retry()
        }
    }

    companion object {
        private const val TAG = "MessagePushWorker"
        private const val PERIODIC_WORK_NAME = "spox_message_push_periodic"
        private const val IMMEDIATE_WORK_NAME = "spox_message_push_immediate"

        fun schedulePeriodicSync(context: Context) {
            val constraints = Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .build()

            val request = PeriodicWorkRequestBuilder<MessagePushWorker>(15, TimeUnit.MINUTES)
                .setConstraints(constraints)
                .build()

            runCatching {
                WorkManager.getInstance(context.applicationContext).enqueueUniquePeriodicWork(
                    PERIODIC_WORK_NAME,
                    ExistingPeriodicWorkPolicy.KEEP,
                    request
                )
            }
        }

        fun triggerBackgroundCheck(context: Context, delaySeconds: Long = 8L) {
            val constraints = Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .build()

            val request = OneTimeWorkRequestBuilder<MessagePushWorker>()
                .setInitialDelay(delaySeconds, TimeUnit.SECONDS)
                .setConstraints(constraints)
                .build()

            runCatching {
                WorkManager.getInstance(context.applicationContext).enqueueUniqueWork(
                    IMMEDIATE_WORK_NAME,
                    ExistingWorkPolicy.REPLACE,
                    request
                )
            }
        }

        fun cancelAll(context: Context) {
            runCatching {
                WorkManager.getInstance(context.applicationContext).cancelUniqueWork(PERIODIC_WORK_NAME)
                WorkManager.getInstance(context.applicationContext).cancelUniqueWork(IMMEDIATE_WORK_NAME)
            }
        }
    }
}
