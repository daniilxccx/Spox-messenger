package com.example.notifications

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.test.core.app.ApplicationProvider
import com.example.ui.call.IncomingCallActivity
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class SpoXNotificationHelperTest {

    private lateinit var context: Context

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
    }

    @Test
    fun incomingCallNotificationHasLockScreenFullScreenIntentAndCallStyleActions() {
        val notification = SpoXNotificationHelper.buildIncomingCallNotification(
            context = context,
            callId = "call_test_42",
            callerName = "Алиса",
            conversationTitle = "Алиса",
            isGroupCall = false,
            callType = "audio"
        )

        assertEquals(Notification.CATEGORY_CALL, notification.category)
        assertEquals(Notification.VISIBILITY_PUBLIC, notification.visibility)
        assertTrue((notification.flags and Notification.FLAG_ONGOING_EVENT) != 0)
        assertNotNull(notification.fullScreenIntent)

        val fsShadow = shadowOf(notification.fullScreenIntent)
        val fsIntent: Intent = fsShadow.savedIntent
        assertEquals(IncomingCallActivity::class.java.name, fsIntent.component?.className)
        assertEquals("call_test_42", fsIntent.getStringExtra(SpoXNotificationHelper.EXTRA_OPEN_CALL_ID))
        assertFalse(fsIntent.getBooleanExtra(SpoXNotificationHelper.EXTRA_AUTO_ANSWER, true))

        @Suppress("DEPRECATION")
        val answerPi = notification.extras.getParcelable<PendingIntent>(NotificationCompat.EXTRA_ANSWER_INTENT)
        @Suppress("DEPRECATION")
        val declinePi = notification.extras.getParcelable<PendingIntent>(NotificationCompat.EXTRA_DECLINE_INTENT)
        assertNotNull(answerPi)
        assertNotNull(declinePi)

        val answerIntent = shadowOf(answerPi).savedIntent
        assertEquals(IncomingCallActivity::class.java.name, answerIntent.component?.className)
        assertEquals("call_test_42", answerIntent.getStringExtra(SpoXNotificationHelper.EXTRA_OPEN_CALL_ID))
        assertTrue(answerIntent.getBooleanExtra(SpoXNotificationHelper.EXTRA_AUTO_ANSWER, false))

        val declineIntent = shadowOf(declinePi).savedIntent
        assertEquals(CallActionReceiver::class.java.name, declineIntent.component?.className)
        assertEquals(SpoXNotificationHelper.ACTION_DECLINE_CALL, declineIntent.action)
        assertEquals("call_test_42", declineIntent.getStringExtra(SpoXNotificationHelper.EXTRA_OPEN_CALL_ID))
    }

    @Test
    fun callsChannelConfiguredForLockScreenVisibilityAndHighImportance() {
        SpoXNotificationHelper.ensureChannels(context)
        val manager = context.getSystemService(NotificationManager::class.java)
        val channel = manager.getNotificationChannel(SpoXNotificationHelper.CHANNEL_CALLS)
        assertNotNull(channel)
        assertEquals(NotificationManager.IMPORTANCE_HIGH, channel.importance)
        assertEquals(Notification.VISIBILITY_PUBLIC, channel.lockscreenVisibility)

        val ongoingChannel = manager.getNotificationChannel(SpoXNotificationHelper.CHANNEL_ONGOING_CALL)
        assertNotNull(ongoingChannel)
        assertEquals(NotificationManager.IMPORTANCE_DEFAULT, ongoingChannel.importance)
        assertEquals(null, ongoingChannel.sound)
    }

    @Test
    fun ongoingCallNotificationHasChronometerAndMuteAndHangUpActions() {
        val notification = SpoXNotificationHelper.buildOngoingCallNotification(
            context = context,
            callId = "call_game_99",
            title = "Максим",
            startedAtMs = 1_700_000_000_000L,
            isMuted = false
        )

        assertEquals(Notification.CATEGORY_CALL, notification.category)
        assertEquals(Notification.VISIBILITY_PUBLIC, notification.visibility)
        assertTrue(notification.extras.getBoolean(Notification.EXTRA_SHOW_CHRONOMETER))

        @Suppress("DEPRECATION")
        val hangUpPi = notification.extras.getParcelable<PendingIntent>(NotificationCompat.EXTRA_HANG_UP_INTENT)
        assertNotNull(hangUpPi)
        val hangUpIntent = shadowOf(hangUpPi).savedIntent
        assertEquals(CallActionReceiver::class.java.name, hangUpIntent.component?.className)
        assertEquals(SpoXNotificationHelper.ACTION_END_CALL, hangUpIntent.action)
        assertEquals("call_game_99", hangUpIntent.getStringExtra(SpoXNotificationHelper.EXTRA_OPEN_CALL_ID))

        assertTrue(notification.actions.isNotEmpty())
        val actionActions = notification.actions.mapNotNull { shadowOf(it.actionIntent).savedIntent.action }
        assertTrue(SpoXNotificationHelper.ACTION_TOGGLE_MUTE_CALL in actionActions)
    }
}
