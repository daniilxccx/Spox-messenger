package com.example.plugins

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class SpoxLuaEngineAndStoreTest {

    private lateinit var appContext: Context

    @Before
    fun setUp() {
        appContext = ApplicationProvider.getApplicationContext()
        File(appContext.filesDir, "spox_plugins.json").delete()
    }

    @Test
    fun templatePlugin_extractsMetadataAndRunsCommandAndTransform() {
        val meta = SpoxLuaEngine.extractMetadata(BuiltInPlugins.SPOX_PLUGIN_TEMPLATE_LUA).getOrThrow()
        assertEquals("my_custom_plugin", meta.id)
        assertEquals("Мой первый плагин", meta.name)
        assertEquals(listOf("/hello"), meta.commands)

        val sandboxCmd = SpoxLuaEngine.runSandboxTest(BuiltInPlugins.SPOX_PLUGIN_TEMPLATE_LUA, "/hello SpoX")
        assertTrue(sandboxCmd.success)
        val outcome = sandboxCmd.commandOutcome
        assertTrue(outcome is PluginCommandOutcome.HandledSend)
        assertTrue((outcome as PluginCommandOutcome.HandledSend).text.contains("Привет, SpoX!"))
        assertTrue(sandboxCmd.logs.any { it.contains("/hello") })

        val sandboxMsg = SpoxLuaEngine.runSandboxTest(BuiltInPlugins.SPOX_PLUGIN_TEMPLATE_LUA, "Привет :wave:")
        assertTrue(sandboxMsg.success)
        assertEquals("Привет 👋", sandboxMsg.transformedSendText)
    }

    @Test
    fun builtInQuickMacros_handlesCommandsAndSendSubstitutions() {
        val quickMacros = BuiltInPlugins.defaultPlugins().first { it.id == "builtin_quick_macros" }
        val ctx = PluginHookContext(chatId = "c1", chatTitle = "Dev", senderName = "Alex")

        val shrug = SpoxLuaEngine.executeCommand(
            quickMacros.sourceCode, "/shrug", "ок", "/shrug ок", ctx
        ).getOrThrow().first
        assertEquals(PluginCommandOutcome.HandledSend("ок ¯\\_(ツ)_/¯"), shrug)

        val reversed = SpoxLuaEngine.executeCommand(
            quickMacros.sourceCode, "/reverse", "SpoX", "/reverse SpoX", ctx
        ).getOrThrow().first
        assertEquals(PluginCommandOutcome.HandledSend("XopS"), reversed)

        val roll = SpoxLuaEngine.executeCommand(
            quickMacros.sourceCode, "/roll", "20", "/roll 20", ctx
        ).getOrThrow().first
        assertTrue(roll is PluginCommandOutcome.HandledSend && roll.text.contains("1–20"))

        val coin = SpoxLuaEngine.executeCommand(
            quickMacros.sourceCode, "/coin", "", "/coin", ctx
        ).getOrThrow().first
        assertTrue(
            coin is PluginCommandOutcome.HandledSend &&
                (coin.text.contains("Орёл") || coin.text.contains("Решка"))
        )

        val transformed = SpoxLuaEngine.executeOnSendMessage(
            quickMacros.sourceCode, "Статус :shield: -> :check:", ctx
        ).getOrThrow()
        assertTrue(transformed is OutgoingTransformResult.Proceed)
        assertEquals("Статус 🛡️ → ✅", (transformed as OutgoingTransformResult.Proceed).text)
    }

    @Test
    fun builtInSmartCalc_evaluatesExpressionsAndHandlesDivisionByZero() {
        val calc = BuiltInPlugins.defaultPlugins().first { it.id == "builtin_smart_calc" }
        val ctx = PluginHookContext(chatId = "c1", chatTitle = "Math", senderName = "User")

        val arith = SpoxLuaEngine.executeCommand(
            calc.sourceCode, "/calc", "(2 + 3) * 4", "/calc (2 + 3) * 4", ctx
        ).getOrThrow().first
        assertTrue(arith is PluginCommandOutcome.HandledSend)
        assertTrue((arith as PluginCommandOutcome.HandledSend).text.contains("= 20"))

        val sqrtExpr = SpoxLuaEngine.executeCommand(
            calc.sourceCode, "/calc", "sqrt(144) + 5", "/calc sqrt(144) + 5", ctx
        ).getOrThrow().first
        assertTrue(sqrtExpr is PluginCommandOutcome.HandledSend)
        assertTrue((sqrtExpr as PluginCommandOutcome.HandledSend).text.contains("= 17"))

        val divZero = SpoxLuaEngine.executeCommand(
            calc.sourceCode, "/calc", "10 / 0", "/calc 10 / 0", ctx
        ).getOrThrow().first
        assertTrue(divZero is PluginCommandOutcome.HandledLocal)
        assertTrue((divZero as PluginCommandOutcome.HandledLocal).message.contains("Деление на ноль"))
    }

    @Test
    fun builtInTypography_formatsQuotesDashesAndEllipsis() {
        val typo = BuiltInPlugins.defaultPlugins().first { it.id == "builtin_typography" }
        val ctx = PluginHookContext()

        val result = SpoxLuaEngine.executeOnSendMessage(
            typo.sourceCode,
            "\"Привет\" -- тест...",
            ctx
        ).getOrThrow()

        assertTrue(result is OutgoingTransformResult.Proceed)
        assertEquals("«Привет» — тест…", (result as OutgoingTransformResult.Proceed).text)
    }

    @Test
    fun builtInMessageInspector_handlesHashUpperStatsAndLongRender() {
        val inspector = BuiltInPlugins.defaultPlugins().first { it.id == "builtin_message_inspector" }
        val ctx = PluginHookContext()

        val hashRes = SpoxLuaEngine.executeCommand(
            inspector.sourceCode, "/hash", "spox", "/hash spox", ctx
        ).getOrThrow().first
        assertTrue(hashRes is PluginCommandOutcome.HandledSend && hashRes.text.contains("SHA-256 ["))

        val upperRes = SpoxLuaEngine.executeCommand(
            inspector.sourceCode, "/upper", "привет", "/upper привет", ctx
        ).getOrThrow().first
        assertEquals(PluginCommandOutcome.HandledSend("ПРИВЕТ"), upperRes)

        val statsRes = SpoxLuaEngine.executeCommand(
            inspector.sourceCode, "/stats", "раз два три", "/stats раз два три", ctx
        ).getOrThrow().first
        assertTrue(statsRes is PluginCommandOutcome.HandledLocal)
        assertTrue((statsRes as PluginCommandOutcome.HandledLocal).message.contains("Слов: 3"))

        val longText = "Очень длинное сообщение для проверки автоматического подсчёта слов и символов в плагине SpoX Lua."
        assertTrue(longText.length >= 80)
        val rendered = SpoxLuaEngine.executeOnRenderMessage(inspector.sourceCode, longText, ctx).getOrThrow()
        assertTrue(rendered.contains("〔") && rendered.contains("сл."))
    }

    @Test
    fun sandboxProtectsAgainstInfiniteLoopsAndSupportsClosures() {
        val infiniteLua = """
            plugin = { id = "inf_loop", name = "Loop", version = "1.0" }
            function on_command(ctx)
                while true do
                    local x = 1 + 1
                end
            end
        """.trimIndent()

        val res = SpoxLuaEngine.executeCommand(infiniteLua, "/loop", "", "/loop", PluginHookContext())
        assertTrue(res.isFailure)
        assertNotNull(res.exceptionOrNull()?.message)

        val closureLua = """
            plugin = { id = "closure_test", name = "Closure", version = "1.0", commands = { "/inc" } }
            local function make_adder(base)
                return function(x) return base + x end
            end
            function on_command(ctx)
                local add10 = make_adder(10)
                return { action = "send", text = tostring(add10(tonumber(ctx.args) or 0)) }
            end
        """.trimIndent()

        val closureRes = SpoxLuaEngine.executeCommand(
            closureLua, "/inc", "7", "/inc 7", PluginHookContext()
        ).getOrThrow().first
        assertEquals(PluginCommandOutcome.HandledSend("17"), closureRes)
    }

    @Test
    fun pluginStore_seedsPersistsTogglesInstallsAndResets() {
        val store = PluginStore(appContext)
        val initial = store.plugins.value
        assertEquals(4, initial.size)
        assertTrue(initial.first { it.id == "builtin_quick_macros" }.enabled)
        assertFalse(initial.first { it.id == "builtin_typography" }.enabled)

        // Toggle typography on & confirm outgoing hook picks it up
        store.setPluginEnabled("builtin_typography", true)
        val transformed = store.transformOutgoingMessage("\"Привет\"...", PluginHookContext())
        assertTrue(transformed is OutgoingTransformResult.Proceed)
        assertEquals("«Привет»…", (transformed as OutgoingTransformResult.Proceed).text)

        // Install custom plugin from template
        val installed = store.installOrUpdateFromSource(BuiltInPlugins.SPOX_PLUGIN_TEMPLATE_LUA).getOrThrow()
        assertEquals("my_custom_plugin", installed.id)
        assertFalse(installed.isBuiltIn)

        // Reload new PluginStore instance -> persisted on disk
        val reloaded = PluginStore(appContext)
        assertEquals(5, reloaded.plugins.value.size)
        assertTrue(reloaded.plugins.value.first { it.id == "builtin_typography" }.enabled)
        assertNotNull(reloaded.plugins.value.firstOrNull { it.id == "my_custom_plugin" })

        val cmdOutcome = reloaded.dispatchCommand("/hello Мир", PluginHookContext(chatTitle = "Чат"))
        assertTrue(cmdOutcome is PluginCommandOutcome.HandledSend)
        assertTrue((cmdOutcome as PluginCommandOutcome.HandledSend).text.contains("Привет, Мир!"))

        // Built-in cannot be deleted, custom can
        assertFalse(reloaded.deleteCustomPlugin("builtin_quick_macros"))
        assertTrue(reloaded.deleteCustomPlugin("my_custom_plugin"))
        assertEquals(4, reloaded.plugins.value.size)

        // Modifying built-in sets isModifiedBuiltIn and reset restores original code
        val modifiedBuiltIn = """
            -- @id builtin_smart_calc
            -- @name Изменённый calc
            -- @version 9.9
            plugin = { id = "builtin_smart_calc", name = "Изменённый calc", version = "9.9", commands = { "/calc" } }
            function on_command(ctx) return { action = "send", text = "override" } end
        """.trimIndent()
        val updatedCalc = reloaded.installOrUpdateFromSource(modifiedBuiltIn, overrideId = "builtin_smart_calc").getOrThrow()
        assertTrue(updatedCalc.isBuiltIn)
        assertTrue(updatedCalc.isModifiedBuiltIn)
        assertTrue(reloaded.resetBuiltInPlugin("builtin_smart_calc"))
        val restoredCalc = reloaded.plugins.value.first { it.id == "builtin_smart_calc" }
        assertFalse(restoredCalc.isModifiedBuiltIn)
        assertEquals("Калькулятор (/calc)", restoredCalc.name)
    }
}
