package com.example.updates

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class GitHubUpdateServiceAndStoreTest {

    private lateinit var appContext: Context

    @Before
    fun setUp() {
        appContext = ApplicationProvider.getApplicationContext()
        appContext.getSharedPreferences("spox_updates_prefs", Context.MODE_PRIVATE)
            .edit()
            .clear()
            .commit()
    }

    @Test
    fun compareVersions_handlesSemVerPrefixesAndPrereleases() {
        assertTrue(GitHubUpdateService.compareVersions("v1.2", "1.1") > 0)
        assertTrue(GitHubUpdateService.compareVersions("1.1.1", "1.1") > 0)
        assertTrue(GitHubUpdateService.compareVersions("2.0.0", "1.9.9") > 0)
        assertEquals(0, GitHubUpdateService.compareVersions("v1.1.0", "1.1"))
        assertTrue(GitHubUpdateService.compareVersions("1.0.9", "1.1") < 0)
        assertTrue(GitHubUpdateService.compareVersions("1.2.0", "1.2.0-beta") > 0)
    }

    @Test
    fun parseReleasesListJson_parsesApkAssetFiltersDraftsAndRejectsUntrustedUrls() {
        val sampleJson = """
            [
              {
                "tag_name": "v1.3-draft",
                "name": "Draft",
                "draft": true,
                "prerelease": false,
                "html_url": "https://github.com/daniilxccx/Spox-messenger/releases/tag/v1.3-draft",
                "assets": []
              },
              {
                "tag_name": "v1.2.0",
                "name": "SpoX 1.2.0 — Плагины и Liquid Glass",
                "body": "- Добавлены плагины на Lua\n- Исправления UI",
                "draft": false,
                "prerelease": false,
                "published_at": "2026-11-23T12:00:00Z",
                "html_url": "https://github.com/daniilxccx/Spox-messenger/releases/tag/v1.2.0",
                "assets": [
                  {
                    "name": "evil.apk",
                    "browser_download_url": "http://untrusted.example.com/evil.apk",
                    "size": 12345,
                    "download_count": 1,
                    "content_type": "application/vnd.android.package-archive"
                  },
                  {
                    "name": "SpoX.apk",
                    "browser_download_url": "https://github.com/daniilxccx/Spox-messenger/releases/download/v1.2.0/SpoX.apk",
                    "size": 15728640,
                    "download_count": 42,
                    "content_type": "application/vnd.android.package-archive"
                  }
                ]
              }
            ]
        """.trimIndent()

        val releases = GitHubUpdateService.parseReleasesListJson(sampleJson)
        assertEquals(1, releases.size)
        val latest = releases.first()
        assertEquals("v1.2.0", latest.tagName)
        assertEquals("1.2.0", latest.versionName)
        assertNotNull(latest.apkAsset)
        assertEquals("SpoX.apk", latest.apkAsset?.name)
        assertEquals(1, latest.allAssets.size)
        assertEquals("15.0 МБ", GitHubUpdateService.formatBytes(latest.apkAsset!!.sizeBytes))

        assertTrue(GitHubUpdateService.isTrustedGitHubUrl("https://github.com/daniilxccx/Spox-messenger/releases"))
        assertTrue(GitHubUpdateService.isTrustedGitHubUrl("https://objects.githubusercontent.com/github-production-release-asset/123"))
        assertFalse(GitHubUpdateService.isTrustedGitHubUrl("http://github.com/daniilxccx/Spox-messenger/releases"))
        assertFalse(GitHubUpdateService.isTrustedGitHubUrl("https://evil.example.org/SpoX.apk"))
    }

    @Test
    fun appUpdateStore_detectsUpdateSkipsVersionAndHandlesStates() = runTest {
        val newerRelease = GitHubReleaseInfo(
            tagName = "v1.2",
            versionName = "1.2",
            title = "SpoX 1.2",
            changelog = "Система обновлений",
            htmlUrl = "https://github.com/daniilxccx/Spox-messenger/releases/tag/v1.2",
            publishedAtIso = "2026-11-23T12:00:00Z",
            isPrerelease = false,
            isDraft = false,
            apkAsset = GitHubReleaseAsset(
                name = "SpoX.apk",
                downloadUrl = "https://github.com/daniilxccx/Spox-messenger/releases/download/v1.2/SpoX.apk",
                sizeBytes = 10_485_760L,
                downloadCount = 7,
                contentType = "application/vnd.android.package-archive"
            ),
            allAssets = emptyList()
        )

        var fetchCount = 0
        val store = AppUpdateStore(
            context = appContext,
            currentVersionProvider = { "1.1" },
            currentVersionCodeProvider = { 5 },
            fetcher = {
                fetchCount++
                Result.success(GitHubUpdateService.FetchOutcome(listOf(newerRelease)))
            }
        )

        val state = store.checkForUpdates(force = true)
        assertEquals(UpdateCheckStatus.UPDATE_AVAILABLE, state.status)
        assertTrue(state.isUpdateAvailable)
        assertTrue(state.shouldShowBanner)
        assertEquals(1, fetchCount)

        // Auto-check throttled right after check when force = false
        store.checkForUpdates(force = false)
        assertEquals(1, fetchCount)

        // Skipping version hides banner and persists
        store.skipVersion("v1.2")
        assertFalse(store.state.value.shouldShowBanner)
        assertTrue(store.state.value.isUpdateAvailable)

        store.setAutoCheckEnabled(false)
        val reloaded = AppUpdateStore(appContext, currentVersionProvider = { "1.1" })
        assertFalse(reloaded.state.value.autoCheckEnabled)
        assertEquals("v1.2", reloaded.state.value.skippedTag)

        // Up-to-date when current >= remote
        val upToDateStore = AppUpdateStore(
            context = appContext,
            currentVersionProvider = { "1.2" },
            fetcher = { Result.success(GitHubUpdateService.FetchOutcome(listOf(newerRelease))) }
        )
        val upState = upToDateStore.checkForUpdates(force = true)
        assertEquals(UpdateCheckStatus.UP_TO_DATE, upState.status)
        assertFalse(upState.isUpdateAvailable)

        // Empty releases -> NO_RELEASES
        val emptyStore = AppUpdateStore(
            context = appContext,
            currentVersionProvider = { "1.1" },
            fetcher = { Result.success(GitHubUpdateService.FetchOutcome(emptyList())) }
        )
        val emptyState = emptyStore.checkForUpdates(force = true)
        assertEquals(UpdateCheckStatus.NO_RELEASES, emptyState.status)
        assertNull(emptyState.latestRelease)

        // Error case
        val errorStore = AppUpdateStore(
            context = appContext,
            currentVersionProvider = { "1.1" },
            fetcher = { Result.failure(IllegalStateException("Нет соединения")) }
        )
        val errState = errorStore.checkForUpdates(force = true)
        assertEquals(UpdateCheckStatus.ERROR, errState.status)
        assertEquals("Нет соединения", errState.errorMessage)
    }
}
