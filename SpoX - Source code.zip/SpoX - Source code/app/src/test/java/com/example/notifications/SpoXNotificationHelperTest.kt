package com.example.notifications

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.util.Base64
import androidx.core.app.NotificationCompat
import androidx.test.core.app.ApplicationProvider
import com.example.ui.call.IncomingCallActivity
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import java.io.ByteArrayOutputStream

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class SpoXNotificationHelperTest {

    private lateinit var context: Context

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
    }

    @Test
    fun messageNotificationContainsSenderRoleMessageTextAndCircularAvatar() {
        val sampleBmp = Bitmap.createBitmap(16, 16, Bitmap.Config.ARGB_8888).apply {
            eraseColor(0xFF00AAFF.toInt())
        }
        val baos = ByteArrayOutputStream()
        sampleBmp.compress(Bitmap.CompressFormat.PNG, 100, baos)
        val avatarB64 = Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP)

        val notification = SpoXNotificationHelper.buildMessageNotification(
            context = context,
            chatId = "chat_dm_1",
            chatTitle = "Артём",
            body = "Привет! Встреча переносится на 18:30.",
            unreadCount = 1,
            senderName = "Артём",
            senderRole = "developer",
            senderAvatarBase64 = avatarB64,
            senderAvatarColorIndex = 2,
            isGroup = false,
            timestampMs = 1_700_000_123_000L
        )

        assertEquals(Notification.CATEGORY_MESSAGE, notification.category)
        val title = notification.extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = notification.extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        val subText = notification.extras.getCharSequence(Notification.EXTRA_SUB_TEXT)?.toString().orEmpty()

        assertTrue("Expected sender name in title, got: $title", title.contains("Артём"))
        assertTrue("Expected developer role in title, got: $title", title.contains("Разработчик"))
        assertEquals("Привет! Встреча переносится на 18:30.", text)
        assertEquals("Разработчик", subText)

        @Suppress("DEPRECATION")
        val largeIcon = notification.getLargeIcon()
        assertNotNull(largeIcon)

        val messagingStyle = NotificationCompat.MessagingStyle.extractMessagingStyleFromNotification(notification)
        assertNotNull(messagingStyle)
        assertFalse(messagingStyle!!.isGroupConversation)
        assertEquals(1, messagingStyle.messages.size)
        val msg = messagingStyle.messages.first()
        assertEquals("Привет! Встреча переносится на 18:30.", msg.text.toString())
        assertTrue(msg.person?.name?.toString().orEmpty().contains("Артём"))
        assertTrue(msg.person?.name?.toString().orEmpty().contains("Разработчик"))
        assertNotNull(msg.person?.icon)
    }

    @Test
    fun groupMessageNotificationShowsGroupTitleCustomRoleUnreadCountAndInitialsAvatar() {
        val notification = SpoXNotificationHelper.buildMessageNotification(
            context = context,
            chatId = "chat_grp_7",
            chatTitle = "Команда дизайна",
            body = "Макет обновлён в Figma",
            unreadCount = 4,
            senderName = "Елена Смирнова",
            senderRole = "user",
            customRoleName = "Арт-директор",
            customRoleBadge = "ART",
            senderAvatarBase64 = "",
            senderAvatarColorIndex = 5,
            isGroup = true,
            timestampMs = 1_700_000_200_000L
        )

        val title = notification.extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = notification.extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        val subText = notification.extras.getCharSequence(Notification.EXTRA_SUB_TEXT)?.toString().orEmpty()

        assertTrue(title.contains("Команда дизайна"))
        assertTrue(title.contains("Елена Смирнова"))
        assertTrue(title.contains("Арт-директор"))
        assertEquals("Макет обновлён в Figma", text)
        assertTrue(subText.contains("Арт-директор"))
        assertTrue(subText.contains("4"))

        @Suppress("DEPRECATION")
        assertNotNull(notification.getLargeIcon())

        val messagingStyle = NotificationCompat.MessagingStyle.extractMessagingStyleFromNotification(notification)
        assertNotNull(messagingStyle)
        assertTrue(messagingStyle!!.isGroupConversation)
        assertEquals("Команда дизайна", messagingStyle.conversationTitle?.toString())
        assertEquals("Елена Смирнова • Арт-директор", messagingStyle.messages.first().person?.name?.toString())
    }

    @Test
    fun createCircularAvatarBitmapHandlesFallbackAndBase64() {
        val initialsAvatar = SpoXNotificationHelper.createCircularAvatarBitmap(
            name = "Иван Петров",
            avatarBase64 = "",
            colorIndex = 3
        )
        assertEquals(128, initialsAvatar.width)
        assertEquals(128, initialsAvatar.height)
    }

    @Test
    fun incomingCallNotificationHasLockScreenFullScreenIntentAndCallStyleActions() {
        val notification = SpoXNotificationHelper.buildIncomingCallNotification(
            context = context,
            callId = "call_test_42",
            callerName = "Алиса",
            conversationTitle = "Алиса",
            isGroupCall = false,
            callType = "audio",
            callerRole = "tester"
        )

        assertEquals(Notification.CATEGORY_CALL, notification.category)
        assertEquals(Notification.VISIBILITY_PUBLIC, notification.visibility)
        assertTrue((notification.flags and Notification.FLAG_ONGOING_EVENT) != 0)
        assertNotNull(notification.fullScreenIntent)
        @Suppress("DEPRECATION")
        assertNotNull(notification.getLargeIcon())
        val title = notification.extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        assertTrue(title.contains("Алиса"))
        assertTrue(title.contains("Тестировщик"))

        val fsShadow = shadowOf(notification.fullScreenIntent)
        val fsIntent: Intent = fsShadow.savedIntent
        assertEquals(IncomingCallActivity::class.java.name, fsIntent.component?.className)
        assertEquals("call_test_42", fsIntent.getStringExtra(SpoXNotificationHelper.EXTRA_OPEN_CALL_ID))
        assertFalse(fsIntent.getBooleanExtra(SpoXNotificationHelper.EXTRA_AUTO_ANSWER, true))

        @Suppress("DEPRECATION")
        val answerPi = notification.extras.getParcelable<PendingIntent>(NotificationCompat.EXTRA_ANSWER_INTENT)
        @Suppress("DEPRECATION")
        val declinePi = notification.extras.getParcelable<PendingIntent>(NotificationCompat.EXTRA_DECLINE_INTENT)
        assertNotNull(answerPi)
        assertNotNull(declinePi)

        val answerIntent = shadowOf(answerPi).savedIntent
        assertEquals(IncomingCallActivity::class.java.name, answerIntent.component?.className)
        assertEquals("call_test_42", answerIntent.getStringExtra(SpoXNotificationHelper.EXTRA_OPEN_CALL_ID))
        assertTrue(answerIntent.getBooleanExtra(SpoXNotificationHelper.EXTRA_AUTO_ANSWER, false))

        val declineIntent = shadowOf(declinePi).savedIntent
        assertEquals(CallActionReceiver::class.java.name, declineIntent.component?.className)
        assertEquals(SpoXNotificationHelper.ACTION_DECLINE_CALL, declineIntent.action)
        assertEquals("call_test_42", declineIntent.getStringExtra(SpoXNotificationHelper.EXTRA_OPEN_CALL_ID))
    }

    @Test
    fun callsChannelConfiguredForLockScreenVisibilityAndHighImportance() {
        SpoXNotificationHelper.ensureChannels(context)
        val manager = context.getSystemService(NotificationManager::class.java)
        val channel = manager.getNotificationChannel(SpoXNotificationHelper.CHANNEL_CALLS)
        assertNotNull(channel)
        assertEquals(NotificationManager.IMPORTANCE_HIGH, channel.importance)
        assertEquals(Notification.VISIBILITY_PUBLIC, channel.lockscreenVisibility)

        val ongoingChannel = manager.getNotificationChannel(SpoXNotificationHelper.CHANNEL_ONGOING_CALL)
        assertNotNull(ongoingChannel)
        assertEquals(NotificationManager.IMPORTANCE_DEFAULT, ongoingChannel.importance)
        assertEquals(null, ongoingChannel.sound)
    }

    @Test
    fun ongoingCallNotificationHasChronometerAndMuteAndHangUpActions() {
        val notification = SpoXNotificationHelper.buildOngoingCallNotification(
            context = context,
            callId = "call_game_99",
            title = "Максим",
            startedAtMs = 1_700_000_000_000L,
            isMuted = false
        )

        assertEquals(Notification.CATEGORY_CALL, notification.category)
        assertEquals(Notification.VISIBILITY_PUBLIC, notification.visibility)
        assertTrue(notification.extras.getBoolean(Notification.EXTRA_SHOW_CHRONOMETER))

        @Suppress("DEPRECATION")
        val hangUpPi = notification.extras.getParcelable<PendingIntent>(NotificationCompat.EXTRA_HANG_UP_INTENT)
        assertNotNull(hangUpPi)
        val hangUpIntent = shadowOf(hangUpPi).savedIntent
        assertEquals(CallActionReceiver::class.java.name, hangUpIntent.component?.className)
        assertEquals(SpoXNotificationHelper.ACTION_END_CALL, hangUpIntent.action)
        assertEquals("call_game_99", hangUpIntent.getStringExtra(SpoXNotificationHelper.EXTRA_OPEN_CALL_ID))

        assertTrue(notification.actions.isNotEmpty())
        val actionActions = notification.actions.mapNotNull { shadowOf(it.actionIntent).savedIntent.action }
        assertTrue(SpoXNotificationHelper.ACTION_TOGGLE_MUTE_CALL in actionActions)
    }
}
