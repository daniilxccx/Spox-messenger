package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.crypto.CryptoManager
import com.example.data.model.Conversation
import com.example.data.model.DeletedAccountRecord
import com.example.data.model.EncryptedMediaChunk
import com.example.data.model.EncryptedMessage
import com.example.data.model.ForwardOriginInfo
import com.example.data.model.ModerationStatus
import com.example.data.model.PublicUserProfile
import com.example.data.model.ReplyQuoteInfo
import com.example.data.model.RoleCodeRecord
import com.example.data.model.UserPrivateProfile
import com.example.data.model.UserRole
import com.example.media.FileAttachmentHelper
import com.google.firebase.Firebase
import com.google.firebase.Timestamp
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import android.util.Log
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.io.File
import java.security.SecureRandom
import java.util.UUID
import kotlin.math.abs

class ChatRepository(
    private val db: FirebaseFirestore,
    private val crypto: CryptoManager = CryptoManager()
) {
    constructor(context: Context, crypto: CryptoManager = CryptoManager(context)) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        ),
        crypto
    )

    private val auth = Firebase.auth

    fun isCurrentUser(uid: String): Boolean = auth.currentUser?.uid == uid

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("Пользователь должен быть авторизован.")
    }

    private fun requireMatchingUserId(uid: String): String {
        val current = auth.currentUser?.uid
            ?: throw CancellationException("Пользователь вышел из аккаунта.")
        if (current != uid) {
            throw CancellationException("Активный аккаунт изменился.")
        }
        return current
    }

    suspend fun checkUserNeedsRegistrationSetup(uid: String): Boolean {
        val deletedSnap = runCatching { db.collection("deleted_accounts").document(uid).get().await() }.getOrNull()
        if (deletedSnap?.exists() == true) return false
        val existingPriv = db.collection("users").document(uid).get().await()
        return !existingPriv.exists()
    }

    private fun sanitizeHandleOrDefault(raw: String?, fallback: String): String {
        if (raw == null) return fallback
        if (raw.isEmpty()) return ""
        return if (raw.length in 3..33 && Regex("^@[a-zA-Z0-9_.]+$").matches(raw)) raw else fallback
    }

    suspend fun checkRegistrationAndSyncSignedInUserProfile(
        uid: String,
        email: String,
        displayName: String,
        preferredTheme: String = "dark"
    ): Boolean {
        requireMatchingUserId(uid)
        val safeEmail = email.ifBlank { "$uid@cipherchat.local" }.take(254)
        val trimmedName = displayName.trim()
        val safeName = trimmedName.ifBlank { safeEmail.substringBefore("@") }.take(60)
        val safeTheme = if (preferredTheme in VALID_THEMES) preferredTheme else "dark"
        val sanitizedHandlePart = safeEmail.substringBefore("@")
            .lowercase()
            .replace(Regex("[^a-z0-9_.]"), "_")
            .take(32)
            .let { if (it.length < 2) "user_${uid.take(6)}" else it }
        val cleanHandle = "@$sanitizedHandlePart"

        val privateRef = db.collection("users").document(uid)
        val publicRef = db.collection("users_public").document(uid)
        val deletedRef = db.collection("deleted_accounts").document(uid)

        try {
            val deletedSnap = runCatching { deletedRef.get().await() }.getOrNull()
            if (deletedSnap?.exists() == true) {
                return false
            }

            requireMatchingUserId(uid)
            val existingPriv = privateRef.get().await()
            if (!existingPriv.exists()) {
                return true
            }
            if (existingPriv.getString("moderationStatus") == ModerationStatus.BANNED.wireValue) {
                return false
            }

            val (publicKeyB64, fingerprint, emailHash) = withContext(Dispatchers.Default) {
                val pub = crypto.getPublicKeyBase64()
                val fp = crypto.getKeyFingerprint(pub)
                val hash = crypto.sha256Hex(safeEmail.trim().lowercase())
                Triple(pub, fp, hash)
            }
            val colorIndex = abs(uid.hashCode() % 8).toLong()

            requireMatchingUserId(uid)
            val privRole = UserRole.fromWire(existingPriv.getString("role")).wireValue
            val resolvedName = existingPriv.getString("displayName")
                ?.trim()
                ?.takeIf { it.isNotEmpty() && it.length <= 60 }
                ?: safeName
            val resolvedHandle = sanitizeHandleOrDefault(existingPriv.getString("handle"), cleanHandle)
            val resolvedAvatar = existingPriv.getString("avatarBase64")
                ?.takeIf { it.length <= 120_000 }
                ?: ""

            val privCanUpdate = existingPriv.getString("userId") == uid &&
                (existingPriv.getString("email")?.length ?: 0) in 3..254 &&
                existingPriv.getTimestamp("createdAt") != null

            if (privCanUpdate) {
                val privUpdates = mutableMapOf<String, Any>()
                if (existingPriv.getString("keyFingerprint") != fingerprint) {
                    privUpdates["keyFingerprint"] = fingerprint
                }
                if (existingPriv.getString("displayName").isNullOrBlank() ||
                    (existingPriv.getString("displayName")?.length ?: 0) > 60
                ) {
                    privUpdates["displayName"] = resolvedName
                }
                if (!existingPriv.contains("handle") ||
                    existingPriv.getString("handle") != resolvedHandle
                ) {
                    privUpdates["handle"] = resolvedHandle
                }
                if (!existingPriv.contains("avatarBase64") ||
                    existingPriv.getString("avatarBase64") == null ||
                    (existingPriv.getString("avatarBase64")?.length ?: 0) > 120_000
                ) {
                    privUpdates["avatarBase64"] = resolvedAvatar
                }
                if (existingPriv.getString("preferredTheme") !in VALID_THEMES) {
                    privUpdates["preferredTheme"] = safeTheme
                }
                if (!existingPriv.contains("role")) {
                    privUpdates["role"] = UserRole.USER.wireValue
                }
                if (privUpdates.isNotEmpty()) {
                    privUpdates["updatedAt"] = FieldValue.serverTimestamp()
                    privateRef.update(privUpdates).await()
                }
            }

            requireMatchingUserId(uid)
            val existingPub = publicRef.get().await()
            if (existingPub.exists()) {
                val pubUpdates = mutableMapOf<String, Any>(
                    "isOnline" to true,
                    "lastSeenAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                if (existingPub.getString("displayName").isNullOrBlank() ||
                    (existingPub.getString("displayName")?.length ?: 0) > 60
                ) {
                    pubUpdates["displayName"] = resolvedName
                }
                if (!existingPub.contains("handle") ||
                    sanitizeHandleOrDefault(existingPub.getString("handle"), resolvedHandle) != existingPub.getString("handle")
                ) {
                    pubUpdates["handle"] = resolvedHandle
                }
                if (!existingPub.contains("avatarBase64") ||
                    existingPub.getString("avatarBase64") == null ||
                    (existingPub.getString("avatarBase64")?.length ?: 0) > 120_000
                ) {
                    pubUpdates["avatarBase64"] = resolvedAvatar
                }
                if (existingPub.getString("emailHash") != emailHash) {
                    pubUpdates["emailHash"] = emailHash
                }
                if (existingPub.getString("publicKeyBase64") != publicKeyB64) {
                    pubUpdates["publicKeyBase64"] = publicKeyB64
                }
                if (existingPub.getString("keyFingerprint") != fingerprint) {
                    pubUpdates["keyFingerprint"] = fingerprint
                }
                val existingColor = existingPub.getLong("avatarColorIndex")
                if (existingColor == null || existingColor !in 0L..20L) {
                    pubUpdates["avatarColorIndex"] = colorIndex
                }
                if (!existingPub.contains("isDiscoverable")) {
                    pubUpdates["isDiscoverable"] = true
                }
                val pubRole = existingPub.getString("role")
                val canSyncRole = if (pubRole == null) {
                    privRole == UserRole.USER.wireValue ||
                        (privRole in listOf(UserRole.TESTER.wireValue, UserRole.DEVELOPER.wireValue) &&
                            existingPriv.getString("role") == privRole)
                } else {
                    pubRole != privRole &&
                        privRole in listOf(UserRole.TESTER.wireValue, UserRole.DEVELOPER.wireValue) &&
                        existingPriv.getString("role") == privRole
                }
                if (canSyncRole) {
                    pubUpdates["role"] = privRole
                }
                publicRef.update(pubUpdates).await()
            } else {
                val createRole = if (existingPriv.getString("role") == privRole) {
                    privRole
                } else {
                    UserRole.USER.wireValue
                }
                publicRef.set(
                    mapOf(
                        "userId" to uid,
                        "displayName" to resolvedName,
                        "handle" to resolvedHandle,
                        "avatarBase64" to resolvedAvatar,
                        "emailHash" to emailHash,
                        "publicKeyBase64" to publicKeyB64,
                        "keyFingerprint" to fingerprint,
                        "avatarColorIndex" to colorIndex,
                        "isDiscoverable" to true,
                        "isOnline" to true,
                        "lastSeenAt" to FieldValue.serverTimestamp(),
                        "role" to createRole,
                        "moderationStatus" to ModerationStatus.ACTIVE.wireValue,
                        "mutedUntilEpochMs" to 0L,
                        "moderationReason" to "",
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            return false
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            if (auth.currentUser?.uid == uid) {
                handleFirestoreError(e, OperationType.WRITE, privateRef.path)
            }
            throw e
        }
    }

    suspend fun syncSignedInUserProfile(
        uid: String,
        email: String,
        displayName: String,
        preferredTheme: String = "dark",
        rawUsername: String? = null,
        avatarBase64: String = ""
    ) {
        requireMatchingUserId(uid)
        val safeEmail = email.ifBlank { "$uid@cipherchat.local" }.take(254)
        val trimmedName = displayName.trim()
        val safeName = if (rawUsername != null) {
            if (trimmedName.isEmpty() || trimmedName.length > 60) {
                throw IllegalArgumentException("Имя должно содержать от 1 до 60 символов")
            }
            trimmedName
        } else {
            trimmedName.ifBlank { safeEmail.substringBefore("@") }.take(60)
        }
        val cleanHandle = if (rawUsername != null) {
            val trimmedUser = rawUsername.trim().removePrefix("@")
            if (trimmedUser.isEmpty()) {
                ""
            } else {
                if (!Regex("^[a-zA-Z0-9_.]{2,32}$").matches(trimmedUser)) {
                    throw IllegalArgumentException("Юзернейм: 2–32 символа (латиница, цифры, _ и .)")
                }
                "@$trimmedUser"
            }
        } else {
            val sanitizedHandlePart = safeEmail.substringBefore("@")
                .lowercase()
                .replace(Regex("[^a-z0-9_.]"), "_")
                .take(32)
                .let { if (it.length < 2) "user_${uid.take(6)}" else it }
            "@$sanitizedHandlePart"
        }
        if (avatarBase64.length > 120_000) {
            throw IllegalArgumentException("Аватар превышает допустимый размер")
        }
        val safeTheme = if (preferredTheme in VALID_THEMES) preferredTheme else "dark"

        val (publicKeyB64, fingerprint, emailHash) = withContext(Dispatchers.Default) {
            val pub = crypto.getPublicKeyBase64()
            val fp = crypto.getKeyFingerprint(pub)
            val hash = crypto.sha256Hex(safeEmail.trim().lowercase())
            Triple(pub, fp, hash)
        }
        val colorIndex = abs(uid.hashCode() % 8).toLong()

        val privateRef = db.collection("users").document(uid)
        val publicRef = db.collection("users_public").document(uid)
        val deletedRef = db.collection("deleted_accounts").document(uid)

        try {
            val deletedSnap = runCatching { deletedRef.get().await() }.getOrNull()
            if (deletedSnap?.exists() == true) {
                return
            }

            requireMatchingUserId(uid)
            val existingPriv = privateRef.get().await()
            val privRole: String
            if (existingPriv.exists()) {
                if (existingPriv.getString("moderationStatus") == ModerationStatus.BANNED.wireValue) {
                    return
                }
                privRole = UserRole.fromWire(existingPriv.getString("role")).wireValue
                val privUpdates = mutableMapOf<String, Any>(
                    "keyFingerprint" to fingerprint,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                if (rawUsername != null) {
                    privUpdates["displayName"] = safeName
                    privUpdates["handle"] = cleanHandle
                    privUpdates["avatarBase64"] = avatarBase64
                } else {
                    if (existingPriv.getString("displayName").isNullOrBlank()) {
                        privUpdates["displayName"] = safeName
                    }
                    if (!existingPriv.contains("handle") || existingPriv.getString("handle") == null) {
                        privUpdates["handle"] = cleanHandle
                    }
                    if (!existingPriv.contains("avatarBase64") || existingPriv.getString("avatarBase64") == null) {
                        privUpdates["avatarBase64"] = ""
                    }
                }
                if (existingPriv.getString("preferredTheme") !in VALID_THEMES) {
                    privUpdates["preferredTheme"] = safeTheme
                }
                if (!existingPriv.contains("role")) {
                    privUpdates["role"] = UserRole.USER.wireValue
                }
                if (existingPriv.getTimestamp("createdAt") != null && existingPriv.getString("userId") == uid) {
                    privateRef.update(privUpdates).await()
                }
            } else {
                privRole = UserRole.USER.wireValue
                privateRef.set(
                    mapOf(
                        "userId" to uid,
                        "email" to safeEmail,
                        "displayName" to safeName,
                        "handle" to cleanHandle,
                        "avatarBase64" to avatarBase64,
                        "preferredTheme" to safeTheme,
                        "keyFingerprint" to fingerprint,
                        "role" to UserRole.USER.wireValue,
                        "redeemedCodeHash" to "",
                        "moderationStatus" to ModerationStatus.ACTIVE.wireValue,
                        "mutedUntilEpochMs" to 0L,
                        "moderationReason" to "",
                        "moderatedBy" to "",
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }

            requireMatchingUserId(uid)
            val existingPub = publicRef.get().await()
            if (existingPub.exists()) {
                val pubUpdates = mutableMapOf<String, Any>(
                    "emailHash" to emailHash,
                    "publicKeyBase64" to publicKeyB64,
                    "keyFingerprint" to fingerprint,
                    "isOnline" to true,
                    "lastSeenAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                if (rawUsername != null) {
                    pubUpdates["displayName"] = safeName
                    pubUpdates["handle"] = cleanHandle
                    pubUpdates["avatarBase64"] = avatarBase64
                } else {
                    if (existingPub.getString("displayName").isNullOrBlank()) {
                        pubUpdates["displayName"] = safeName
                    }
                    if (!existingPub.contains("handle") || existingPub.getString("handle") == null) {
                        pubUpdates["handle"] = cleanHandle
                    }
                    if (!existingPub.contains("avatarBase64") || existingPub.getString("avatarBase64") == null) {
                        pubUpdates["avatarBase64"] = ""
                    }
                }
                if (!existingPub.contains("avatarColorIndex")) {
                    pubUpdates["avatarColorIndex"] = colorIndex
                }
                if (!existingPub.contains("isDiscoverable")) {
                    pubUpdates["isDiscoverable"] = true
                }
                val pubRole = existingPub.getString("role")
                val canSyncRole = if (pubRole == null) {
                    privRole == UserRole.USER.wireValue ||
                        (privRole in listOf(UserRole.TESTER.wireValue, UserRole.DEVELOPER.wireValue) &&
                            existingPriv.exists() && existingPriv.getString("role") == privRole)
                } else {
                    pubRole != privRole &&
                        privRole in listOf(UserRole.TESTER.wireValue, UserRole.DEVELOPER.wireValue) &&
                        existingPriv.exists() && existingPriv.getString("role") == privRole
                }
                if (canSyncRole) {
                    pubUpdates["role"] = privRole
                }
                publicRef.update(pubUpdates).await()
            } else {
                val createRole = if (existingPriv.exists() && existingPriv.getString("role") == privRole) {
                    privRole
                } else {
                    UserRole.USER.wireValue
                }
                publicRef.set(
                    mapOf(
                        "userId" to uid,
                        "displayName" to safeName,
                        "handle" to cleanHandle,
                        "avatarBase64" to avatarBase64,
                        "emailHash" to emailHash,
                        "publicKeyBase64" to publicKeyB64,
                        "keyFingerprint" to fingerprint,
                        "avatarColorIndex" to colorIndex,
                        "isDiscoverable" to true,
                        "isOnline" to true,
                        "lastSeenAt" to FieldValue.serverTimestamp(),
                        "role" to createRole,
                        "moderationStatus" to ModerationStatus.ACTIVE.wireValue,
                        "mutedUntilEpochMs" to 0L,
                        "moderationReason" to "",
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            if (auth.currentUser?.uid == uid) {
                handleFirestoreError(e, OperationType.WRITE, privateRef.path)
            }
            throw e
        }
    }

    suspend fun updateFcmToken(uid: String, token: String) {
        val currentUid = auth.currentUser?.uid ?: return
        if (uid != currentUid || token.isBlank()) return
        val privateRef = db.collection("users").document(uid)
        runCatching {
            val snap = privateRef.get().await()
            if (snap.exists() && snap.getString("moderationStatus") != ModerationStatus.BANNED.wireValue) {
                privateRef.update(
                    mapOf(
                        "fcmToken" to token.take(512),
                        "fcmUpdatedAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
        }.onFailure { err ->
            Log.w("ChatRepository", "Unable to sync FCM token: ${err.message}")
        }
    }

    suspend fun updateUserProfile(
        uid: String,
        displayName: String,
        rawUsername: String,
        avatarBase64: String
    ) {
        requireUserId()
        val cleanName = displayName.trim()
        if (cleanName.isEmpty() || cleanName.length > 60) {
            throw IllegalArgumentException("Никнейм должен содержать от 1 до 60 символов")
        }

        val trimmedUser = rawUsername.trim().removePrefix("@")
        val cleanHandle = if (trimmedUser.isEmpty()) {
            ""
        } else {
            if (!Regex("^[a-zA-Z0-9_.]{2,32}$").matches(trimmedUser)) {
                throw IllegalArgumentException("Юзернейм: 2–32 символа (латиница, цифры, _ и .)")
            }
            "@$trimmedUser"
        }

        if (avatarBase64.length > 120_000) {
            throw IllegalArgumentException("Аватар превышает допустимый размер")
        }

        val privateRef = db.collection("users").document(uid)
        val publicRef = db.collection("users_public").document(uid)
        try {
            val updates = mapOf(
                "displayName" to cleanName,
                "handle" to cleanHandle,
                "avatarBase64" to avatarBase64,
                "updatedAt" to FieldValue.serverTimestamp()
            )
            privateRef.update(updates).await()
            publicRef.update(updates).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, privateRef.path)
            throw e
        }
    }

    suspend fun updateThemePreferenceOnProfile(uid: String, themeWire: String) {
        requireUserId()
        val ref = db.collection("users").document(uid)
        try {
            val snap = ref.get().await()
            if (snap.exists()) {
                ref.update(
                    mapOf(
                        "preferredTheme" to themeWire,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, ref.path)
        }
    }

    suspend fun updateDiscoverability(uid: String, discoverable: Boolean) {
        requireUserId()
        val ref = db.collection("users_public").document(uid)
        try {
            ref.update(
                mapOf(
                    "isDiscoverable" to discoverable,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, ref.path)
            throw e
        }
    }

    suspend fun updatePresence(uid: String, isOnline: Boolean) {
        val currentUid = auth.currentUser?.uid ?: return
        if (currentUid != uid) return
        val publicRef = db.collection("users_public").document(uid)
        runCatching {
            val deletedSnap = db.collection("deleted_accounts").document(uid).get().await()
            if (deletedSnap.exists()) return
            val pubSnap = publicRef.get().await()
            if (!pubSnap.exists()) return
            if (pubSnap.getString("moderationStatus") == ModerationStatus.BANNED.wireValue) return
            publicRef.update(
                mapOf(
                    "isOnline" to isOnline,
                    "lastSeenAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        }.onFailure { e ->
            if (e is CancellationException) throw e
            Log.w("ChatRepository", "Presence update skipped for $uid: ${e.message}")
        }
    }

    fun observePrivateProfile(userId: String): Flow<UserPrivateProfile?> = flow {
        val docRef = db.collection("users").document(userId)
        emitAll(
            docRef.snapshots()
                .map { it.toObject(UserPrivateProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
                .catch { error ->
                    logStreamError(error, OperationType.GET, docRef.path, userId)
                    throw error
                }
        )
    }

    fun observeDeletedAccount(userId: String): Flow<DeletedAccountRecord?> = flow {
        val docRef = db.collection("deleted_accounts").document(userId)
        emitAll(
            docRef.snapshots()
                .map { it.toObject(DeletedAccountRecord::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
                .catch { error ->
                    logStreamError(error, OperationType.GET, docRef.path, userId)
                    throw error
                }
        )
    }

    suspend fun getPublicProfile(userId: String): PublicUserProfile? {
        requireUserId()
        return runCatching {
            db.collection("users_public").document(userId).get().await()
                .toObject(PublicUserProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
        }.getOrNull()
    }

    suspend fun getPublicProfiles(userIds: List<String>): List<PublicUserProfile> {
        requireUserId()
        return userIds.distinct().mapNotNull { uid ->
            runCatching {
                db.collection("users_public").document(uid).get().await()
                    .toObject(PublicUserProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
            }.getOrNull()
        }
    }

    suspend fun getOrSyncCurrentPublicProfile(
        uid: String,
        email: String,
        displayName: String,
        preferredTheme: String = "dark"
    ): PublicUserProfile {
        val existing = getPublicProfile(uid)
        if (existing != null && existing.publicKeyBase64.isNotBlank()) {
            return existing
        }
        syncSignedInUserProfile(uid, email, displayName, preferredTheme)
        return getPublicProfile(uid)
            ?: throw IllegalStateException("Профиль пользователя недоступен или заблокирован")
    }

    fun observeAllUsersForAdmin(): Flow<List<UserPrivateProfile>> = flow {
        val uid = requireUserId()
        val path = "users"
        emitAll(
            db.collection(path)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(UserPrivateProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedWith(
                            compareBy<UserPrivateProfile> { it.userId != uid }
                                .thenBy { it.displayName.lowercase() }
                        )
                }
                .catch { error ->
                    logStreamError(error, OperationType.LIST, path, uid)
                    throw error
                }
        )
    }

    suspend fun moderateUserAccount(
        targetUid: String,
        status: ModerationStatus,
        durationMillis: Long? = null,
        reason: String = ""
    ) {
        val adminUid = requireUserId()
        require(targetUid != adminUid) { "Нельзя применить санкцию к самому себе" }
        val cleanReason = reason.trim().take(240)
        val mutedUntil = when {
            status != ModerationStatus.MUTED -> 0L
            durationMillis == null || durationMillis <= 0L -> 0L
            else -> System.currentTimeMillis() + durationMillis
        }

        val privateRef = db.collection("users").document(targetUid)
        val publicRef = db.collection("users_public").document(targetUid)

        try {
            val pubSnap = publicRef.get().await()
            val batch = db.batch()
            batch.update(
                privateRef,
                mapOf(
                    "moderationStatus" to status.wireValue,
                    "mutedUntilEpochMs" to mutedUntil,
                    "moderationReason" to cleanReason,
                    "moderatedBy" to adminUid,
                    "moderatedAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            if (pubSnap.exists()) {
                batch.update(
                    publicRef,
                    mapOf(
                        "moderationStatus" to status.wireValue,
                        "mutedUntilEpochMs" to mutedUntil,
                        "moderationReason" to cleanReason,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            }
            batch.commit().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, privateRef.path)
            throw e
        }
    }

    suspend fun deleteUserAccountByAdmin(
        targetUid: String,
        reason: String = ""
    ) {
        val adminUid = requireUserId()
        require(targetUid != adminUid) { "Нельзя удалить собственный аккаунт администратора" }
        val cleanReason = reason.trim().ifBlank { "Аккаунт удалён администратором" }.take(240)
        val privateRef = db.collection("users").document(targetUid)
        val publicRef = db.collection("users_public").document(targetUid)
        val deletedRef = db.collection("deleted_accounts").document(targetUid)

        try {
            val batch = db.batch()
            batch.set(
                deletedRef,
                mapOf(
                    "userId" to targetUid,
                    "deletedBy" to adminUid,
                    "reason" to cleanReason,
                    "deletedAt" to FieldValue.serverTimestamp()
                )
            )
            batch.delete(privateRef)
            batch.delete(publicRef)
            batch.commit().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, privateRef.path)
            throw e
        }
    }

    fun observeRoleCodes(): Flow<List<RoleCodeRecord>> = flow {
        val uid = requireUserId()
        val path = "role_codes"
        emitAll(
            db.collection(path)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(RoleCodeRecord::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                }
                .catch { error ->
                    logStreamError(error, OperationType.LIST, path, uid)
                    throw error
                }
        )
    }

    suspend fun generateRoleCode(targetRole: UserRole): Pair<String, RoleCodeRecord> {
        val uid = requireUserId()
        require(targetRole == UserRole.DEVELOPER || targetRole == UserRole.TESTER) {
            "Код можно выпустить только для роли Разработчик или Тестировщик"
        }
        val prefix = if (targetRole == UserRole.DEVELOPER) "SPOX-DEV" else "SPOX-TST"
        val alphabet = "23456789ABCDEFGHJKLMNPQRSTUVWXYZ"
        val rnd = SecureRandom()
        fun block(len: Int): String = buildString(len) {
            repeat(len) { append(alphabet[rnd.nextInt(alphabet.length)]) }
        }
        val b1 = block(4)
        val b2 = block(4)
        val plainCode = "$prefix-$b1-$b2"
        val codeHash = crypto.sha256Hex(plainCode)
        val codePreview = "$prefix-••••-$b2"
        val docRef = db.collection("role_codes").document(codeHash)

        val payload = mapOf(
            "codeHash" to codeHash,
            "codePreview" to codePreview,
            "targetRole" to targetRole.wireValue,
            "createdBy" to uid,
            "isUsed" to false,
            "usedBy" to "",
            "createdAt" to FieldValue.serverTimestamp()
        )
        try {
            docRef.set(payload).await()
            val record = RoleCodeRecord(
                id = codeHash,
                codeHash = codeHash,
                codePreview = codePreview,
                targetRole = targetRole.wireValue,
                createdBy = uid,
                isUsed = false,
                usedBy = ""
            )
            return plainCode to record
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            throw e
        }
    }

    suspend fun redeemRoleCode(rawCode: String): UserRole {
        val uid = requireUserId()
        val normalized = rawCode.trim().uppercase()
        if (normalized.length < 6) {
            throw IllegalArgumentException("Введите корректный код активации")
        }

        val codeHash = crypto.sha256Hex(normalized)
        val codeRef = db.collection("role_codes").document(codeHash)
        val privateRef = db.collection("users").document(uid)
        val publicRef = db.collection("users_public").document(uid)

        return try {
            val snap = codeRef.get().await()
            if (snap.exists()) {
                val existing = snap.toObject(RoleCodeRecord::class.java)
                    ?: throw IllegalStateException("Не удалось прочитать код")
                if (existing.isUsed) {
                    throw IllegalStateException("Этот код уже был использован")
                }
                val targetRole = UserRole.fromWire(existing.targetRole)
                if (targetRole == UserRole.USER) {
                    throw IllegalStateException("Недопустимый тип кода")
                }
                val batch = db.batch()
                batch.update(
                    codeRef,
                    mapOf(
                        "isUsed" to true,
                        "usedBy" to uid,
                        "usedAt" to FieldValue.serverTimestamp()
                    )
                )
                batch.update(
                    privateRef,
                    mapOf(
                        "role" to targetRole.wireValue,
                        "redeemedCodeHash" to codeHash,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
                batch.update(
                    publicRef,
                    mapOf(
                        "role" to targetRole.wireValue,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
                batch.commit().await()
                targetRole
            } else {
                // Single-use bootstrap developer code path (verified by SHA-256 hash in Firestore rules)
                val suffix = normalized.takeLast(4)
                val preview = "SPOX-DEV-••••-$suffix".take(40)
                val batch = db.batch()
                batch.set(
                    codeRef,
                    mapOf(
                        "codeHash" to codeHash,
                        "codePreview" to preview,
                        "targetRole" to UserRole.DEVELOPER.wireValue,
                        "createdBy" to uid,
                        "isUsed" to true,
                        "usedBy" to uid,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "usedAt" to FieldValue.serverTimestamp()
                    )
                )
                batch.update(
                    privateRef,
                    mapOf(
                        "role" to UserRole.DEVELOPER.wireValue,
                        "redeemedCodeHash" to codeHash,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
                batch.update(
                    publicRef,
                    mapOf(
                        "role" to UserRole.DEVELOPER.wireValue,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
                batch.commit().await()
                UserRole.DEVELOPER
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: FirebaseFirestoreException) {
            handleFirestoreError(e, OperationType.UPDATE, codeRef.path)
            if (e.code == FirebaseFirestoreException.Code.PERMISSION_DENIED) {
                throw IllegalStateException("Неверный или уже использованный код доступа")
            }
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, codeRef.path)
            throw e
        }
    }

    suspend fun deleteRoleCode(codeHash: String) {
        requireUserId()
        val docRef = db.collection("role_codes").document(codeHash)
        try {
            docRef.delete().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path)
            throw e
        }
    }

    fun observeDiscoverableUsers(): Flow<List<PublicUserProfile>> = flow {
        val uid = requireUserId()
        val path = "users_public"
        emitAll(
            db.collection(path)
                .whereEqualTo("isDiscoverable", true)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(PublicUserProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .filter { !it.isBanned() }
                        .sortedBy { it.displayName.lowercase() }
                }
                .catch { error ->
                    logStreamError(error, OperationType.LIST, path, uid)
                    throw error
                }
        )
    }

    fun observePublicProfilesByIds(userIds: List<String>): Flow<Map<String, PublicUserProfile>> {
        val distinctIds = userIds.filter { it.isNotBlank() }.distinct().take(100)
        if (distinctIds.isEmpty()) return flowOf(emptyMap())
        val perUserFlows: List<Flow<Pair<String, PublicUserProfile?>>> = distinctIds.map { targetUid ->
            db.collection("users_public").document(targetUid)
                .snapshots()
                .map { snap ->
                    targetUid to snap.toObject(
                        PublicUserProfile::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    )
                }
                .catch { error ->
                    if (error is CancellationException &&
                        generateSequence(error as Throwable) { it.cause }
                            .filterIsInstance<FirebaseFirestoreException>()
                            .firstOrNull() == null
                    ) {
                        throw error
                    }
                    emit(targetUid to null)
                }
        }
        return combine(perUserFlows) { entries ->
            buildMap {
                entries.forEach { (id, profile) ->
                    if (profile != null && !profile.isBanned()) {
                        put(id, profile)
                    }
                }
            }
        }
    }

    fun computeEmailHash(rawQuery: String): String? {
        val trimmed = rawQuery.trim().lowercase()
        val atIndex = trimmed.indexOf('@')
        if (atIndex <= 0) return null
        val domainPart = trimmed.substring(atIndex + 1)
        if (!domainPart.contains('.') || domainPart.endsWith('.')) return null
        return crypto.sha256Hex(trimmed)
    }

    fun filterAndRankUsers(
        users: List<PublicUserProfile>,
        rawQuery: String,
        excludeUid: String? = null
    ): List<PublicUserProfile> {
        val trimmed = rawQuery.trim()
        val eligible = if (excludeUid.isNullOrBlank()) {
            users
        } else {
            users.filter { it.userId != excludeUid }
        }
        if (trimmed.isEmpty()) {
            return eligible.sortedBy { it.displayName.lowercase() }
        }

        val q = trimmed.lowercase()
        val emailHash = computeEmailHash(trimmed)
        val startsWithAt = q.startsWith("@")
        val qHandle = q.removePrefix("@")

        return eligible.mapNotNull { user ->
            val score = computeMatchScore(user, q, qHandle, startsWithAt, emailHash)
            if (score != null) user to score else null
        }
            .sortedWith(compareBy<Pair<PublicUserProfile, Int>> { it.second }.thenBy { it.first.displayName.lowercase() })
            .map { it.first }
    }

    private fun computeMatchScore(
        user: PublicUserProfile,
        q: String,
        qHandle: String,
        startsWithAt: Boolean,
        emailHash: String?
    ): Int? {
        if (emailHash != null && user.emailHash.equals(emailHash, ignoreCase = true)) {
            return 0
        }

        val handleClean = user.handle.trim().removePrefix("@").lowercase()
        val nameClean = user.displayName.trim().lowercase()

        if (startsWithAt) {
            if (handleClean.isEmpty()) return null
            if (qHandle.isEmpty()) return 3
            return when {
                handleClean == qHandle -> 1
                handleClean.startsWith(qHandle) -> 2
                handleClean.contains(qHandle) -> 3
                else -> null
            }
        }

        return when {
            qHandle.isNotEmpty() && handleClean == qHandle -> 1
            nameClean == q -> 2
            qHandle.isNotEmpty() && handleClean.startsWith(qHandle) -> 3
            nameClean.startsWith(q) || nameClean.split(' ').any { it.startsWith(q) } -> 4
            qHandle.isNotEmpty() && handleClean.contains(qHandle) -> 5
            nameClean.contains(q) -> 6
            else -> null
        }
    }

    suspend fun findUserByEmail(email: String): PublicUserProfile? {
        requireUserId()
        val hash = crypto.sha256Hex(email.trim().lowercase())
        val path = "users_public"
        return try {
            val snap = db.collection(path)
                .whereEqualTo("isDiscoverable", true)
                .whereEqualTo("emailHash", hash)
                .get()
                .await()
            snap.toObjects(PublicUserProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                .firstOrNull()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.LIST, path)
            throw e
        }
    }

    suspend fun searchUsers(
        query: String,
        excludeUid: String? = auth.currentUser?.uid
    ): List<PublicUserProfile> {
        requireUserId()
        val trimmed = query.trim()
        if (trimmed.isEmpty()) return emptyList()

        val path = "users_public"
        val emailHash = computeEmailHash(trimmed)

        return try {
            val discoverableSnap = db.collection(path)
                .whereEqualTo("isDiscoverable", true)
                .get()
                .await()
            val allDiscoverable = discoverableSnap.toObjects(
                PublicUserProfile::class.java,
                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
            ).filter { !it.isBanned() }

            val emailMatches = if (emailHash != null) {
                db.collection(path)
                    .whereEqualTo("isDiscoverable", true)
                    .whereEqualTo("emailHash", emailHash)
                    .get()
                    .await()
                    .toObjects(PublicUserProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .filter { !it.isBanned() }
            } else {
                emptyList()
            }

            val merged = (emailMatches + allDiscoverable).distinctBy { it.userId }
            filterAndRankUsers(merged, trimmed, excludeUid)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.LIST, path)
            throw e
        }
    }

    fun observeConversations(userId: String): Flow<List<Conversation>> = flow {
        val path = "conversations"
        emitAll(
            db.collection(path)
                .whereArrayContains("memberUids", userId)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(Conversation::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.updatedAt ?: it.createdAt ?: Timestamp(0, 0) }
                }
                .catch { error ->
                    logStreamError(error, OperationType.LIST, path, userId)
                    throw error
                }
        )
    }

    fun observeConversation(chatId: String, userId: String): Flow<Conversation?> = flow {
        val docRef = db.collection("conversations").document(chatId)
        emitAll(
            docRef.snapshots()
                .map { it.toObject(Conversation::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
                .catch { error ->
                    logStreamError(error, OperationType.GET, docRef.path, userId)
                    throw error
                }
        )
    }

    fun observeMessages(chatId: String, userId: String): Flow<List<EncryptedMessage>> = flow {
        val path = "conversations/$chatId/messages"
        emitAll(
            db.collection("conversations").document(chatId).collection("messages")
                .whereArrayContains("memberUids", userId)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(EncryptedMessage::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedBy { it.createdAt ?: Timestamp(0, 0) }
                }
                .catch { error ->
                    logStreamError(error, OperationType.LIST, path, userId)
                    throw error
                }
        )
    }

    suspend fun getConversationById(chatId: String): Conversation? {
        requireUserId()
        if (chatId.isBlank()) return null
        return runCatching {
            db.collection("conversations").document(chatId).get().await()
                .toObject(Conversation::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
        }.getOrNull()
    }

    suspend fun getOrCreateSavedMessagesChat(currentUser: PublicUserProfile): String {
        val uid = requireUserId()
        val savedId = Conversation.savedConversationId(uid)
        val docRef = db.collection("conversations").document(savedId)
        try {
            val freshMe = getPublicProfile(uid) ?: currentUser
            val myPubKey = freshMe.publicKeyBase64.ifBlank { crypto.getPublicKeyBase64() }
            val myDisplayName = freshMe.displayName.ifBlank { freshMe.handle.ifBlank { "Вы" } }.take(60)

            val existing = docRef.get().await()
            if (existing.exists()) {
                val conv = existing.toObject(Conversation::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                if (conv != null) {
                    val myEnvelope = conv.memberKeyEnvelopes[uid].orEmpty()
                    val canUnwrap = myEnvelope.isNotBlank() && crypto.unwrapRoomKey(myEnvelope) != null
                    if (!canUnwrap) {
                        val newKey = crypto.generateRoomKey()
                        val newEnvelope = crypto.wrapRoomKeyForMember(newKey, myPubKey)
                        docRef.update(
                            mapOf(
                                "memberNames" to mapOf(uid to myDisplayName),
                                "memberKeyEnvelopes" to mapOf(uid to newEnvelope),
                                "updatedAt" to FieldValue.serverTimestamp()
                            )
                        ).await()
                    }
                }
                return existing.id
            }

            val roomKey = crypto.generateRoomKey()
            val myEnvelope = crypto.wrapRoomKeyForMember(roomKey, myPubKey)
            val nowMs = System.currentTimeMillis()
            val payload = mapOf(
                "title" to "Избранное",
                "isGroup" to false,
                "createdBy" to uid,
                "memberUids" to listOf(uid),
                "memberNames" to mapOf(uid to myDisplayName),
                "memberKeyEnvelopes" to mapOf(uid to myEnvelope),
                "lastMessagePreview" to "",
                "lastMessageType" to "none",
                "lastMessageSenderId" to "",
                "activeCallId" to "",
                "unreadCounts" to mapOf(uid to 0L),
                "lastReadAtMillis" to mapOf(uid to nowMs),
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            docRef.set(payload).await()
            return docRef.id
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            throw e
        }
    }

    suspend fun getOrCreateDirectChat(
        currentUser: PublicUserProfile,
        peer: PublicUserProfile
    ): String {
        val uid = requireUserId()
        if (peer.userId == uid) {
            return getOrCreateSavedMessagesChat(currentUser)
        }
        val sortedUids = listOf(currentUser.userId, peer.userId).distinct().sorted()
        val deterministicId = "dm_${sortedUids[0].take(20)}_${sortedUids[1].take(20)}"
        val docRef = db.collection("conversations").document(deterministicId)
        try {
            val freshMe = getPublicProfile(currentUser.userId) ?: currentUser
            val freshPeer = getPublicProfile(peer.userId) ?: peer
            if (freshMe.publicKeyBase64.isBlank()) {
                throw IllegalStateException("Ваш ключ шифрования ещё инициализируется, повторите через секунду.")
            }
            if (freshPeer.publicKeyBase64.isBlank()) {
                throw IllegalStateException("У собеседника отсутствует публичный ключ E2EE.")
            }

            suspend fun ensureKeysAndReturn(conv: Conversation, docId: String): String {
                val myEnvelope = conv.memberKeyEnvelopes[freshMe.userId].orEmpty()
                val peerEnvelope = conv.memberKeyEnvelopes[freshPeer.userId].orEmpty()
                val canUnwrapMine = myEnvelope.isNotBlank() && crypto.unwrapRoomKey(myEnvelope) != null
                if (!canUnwrapMine || peerEnvelope.isBlank()) {
                    val refreshedMembers = listOf(freshMe, freshPeer).distinctBy { it.userId }
                    val newKey = crypto.generateRoomKey()
                    val newEnvelopes = refreshedMembers.associate { m ->
                        m.userId to crypto.wrapRoomKeyForMember(newKey, m.publicKeyBase64)
                    }
                    val newNames = refreshedMembers.associate { m ->
                        m.userId to m.displayName.ifBlank { m.handle.ifBlank { "Участник" } }.take(60)
                    }
                    docRef.update(
                        mapOf(
                            "memberNames" to newNames,
                            "memberKeyEnvelopes" to newEnvelopes
                        )
                    ).await()
                }
                return docId
            }

            val existing = docRef.get().await()
            if (existing.exists()) {
                val conv = existing.toObject(Conversation::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                if (conv != null) {
                    return ensureKeysAndReturn(conv, existing.id)
                }
                return existing.id
            }

            val roomKey = crypto.generateRoomKey()
            val members = listOf(freshMe, freshPeer).distinctBy { it.userId }
            val memberUids = members.map { it.userId }
            val memberNames = members.associate { m ->
                m.userId to m.displayName.ifBlank { m.handle.ifBlank { "Участник" } }.take(60)
            }
            val memberEnvelopes = members.associate { member ->
                member.userId to crypto.wrapRoomKeyForMember(roomKey, member.publicKeyBase64)
            }
            val nowMs = System.currentTimeMillis()
            val unreadMap = memberUids.associateWith { 0L }
            val readMap = memberUids.associateWith { nowMs }
            val safeTitle = freshPeer.displayName.ifBlank { freshPeer.handle.ifBlank { "Чат SpoX" } }.take(80)

            val payload = mapOf(
                "title" to safeTitle,
                "isGroup" to false,
                "createdBy" to uid,
                "memberUids" to memberUids,
                "memberNames" to memberNames,
                "memberKeyEnvelopes" to memberEnvelopes,
                "lastMessagePreview" to "",
                "lastMessageType" to "none",
                "lastMessageSenderId" to "",
                "activeCallId" to "",
                "unreadCounts" to unreadMap,
                "lastReadAtMillis" to readMap,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            try {
                docRef.set(payload).await()
                return docRef.id
            } catch (writeErr: FirebaseFirestoreException) {
                if (writeErr.code == FirebaseFirestoreException.Code.ALREADY_EXISTS ||
                    writeErr.code == FirebaseFirestoreException.Code.PERMISSION_DENIED
                ) {
                    val concurrentSnap = runCatching { docRef.get().await() }.getOrNull()
                    if (concurrentSnap != null && concurrentSnap.exists()) {
                        val conv = concurrentSnap.toObject(
                            Conversation::class.java,
                            DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                        )
                        if (conv != null && freshMe.userId in conv.memberUids) {
                            return ensureKeysAndReturn(conv, concurrentSnap.id)
                        }
                    }
                }
                throw writeErr
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            throw e
        }
    }

    suspend fun repairRoomKey(conversation: Conversation, currentUserId: String): ByteArray {
        requireUserId()
        val profiles = getPublicProfiles(conversation.memberUids)
        val byId = profiles.associateBy { it.userId }
        val newRoomKey = crypto.generateRoomKey()
        val updatedEnvelopes = conversation.memberKeyEnvelopes.toMutableMap()
        val updatedNames = conversation.memberNames.toMutableMap()

        conversation.memberUids.forEach { memberUid ->
            val profile = byId[memberUid]
            if (profile != null && profile.publicKeyBase64.isNotBlank()) {
                updatedEnvelopes[memberUid] = crypto.wrapRoomKeyForMember(newRoomKey, profile.publicKeyBase64)
                if (profile.displayName.isNotBlank()) {
                    updatedNames[memberUid] = profile.displayName.take(60)
                }
            }
        }
        if (updatedEnvelopes[currentUserId].isNullOrBlank()) {
            updatedEnvelopes[currentUserId] = crypto.wrapRoomKeyForMember(newRoomKey, crypto.getPublicKeyBase64())
        }

        val docRef = db.collection("conversations").document(conversation.id)
        docRef.update(
            mapOf(
                "memberNames" to updatedNames,
                "memberKeyEnvelopes" to updatedEnvelopes
            )
        ).await()
        return newRoomKey
    }

    suspend fun createGroupChat(
        title: String,
        creator: PublicUserProfile,
        selectedMembers: List<PublicUserProfile>,
        description: String = ""
    ): String {
        val uid = requireUserId()
        val allMembers = (listOf(creator) + selectedMembers).distinctBy { it.userId }.take(50)
        val roomKey = crypto.generateRoomKey()
        val memberUids = allMembers.map { it.userId }
        val memberNames = allMembers.associate { m ->
            m.userId to m.displayName.ifBlank { m.handle.ifBlank { "Участник" } }.take(60)
        }
        val memberEnvelopes = allMembers.associate { member ->
            member.userId to crypto.wrapRoomKeyForMember(roomKey, member.publicKeyBase64)
        }
        val nowMs = System.currentTimeMillis()
        val unreadMap = memberUids.associateWith { 0L }
        val readMap = memberUids.associateWith { nowMs }

        val chatId = "grp_${UUID.randomUUID().toString().replace("-", "").take(24)}"
        val docRef = db.collection("conversations").document(chatId)
        val safeTitle = title.trim().ifBlank { "Новая группа" }.take(80)
        val safeDescription = description.trim().take(300)

        val payload = mapOf(
            "title" to safeTitle,
            "description" to safeDescription,
            "isGroup" to true,
            "createdBy" to uid,
            "memberUids" to memberUids,
            "memberNames" to memberNames,
            "memberKeyEnvelopes" to memberEnvelopes,
            "lastMessagePreview" to "",
            "lastMessageType" to "none",
            "lastMessageSenderId" to "",
            "activeCallId" to "",
            "unreadCounts" to unreadMap,
            "lastReadAtMillis" to readMap,
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        try {
            docRef.set(payload).await()
            return chatId
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            throw e
        }
    }

    suspend fun updateGroupSettings(
        conversation: Conversation,
        newTitle: String,
        newDescription: String
    ) {
        requireUserId()
        if (!conversation.isGroup) return
        val safeTitle = newTitle.trim().take(80)
        require(safeTitle.isNotBlank()) { "Название группы не может быть пустым" }
        val safeDesc = newDescription.trim().take(300)

        val docRef = db.collection("conversations").document(conversation.id)
        try {
            docRef.update(
                mapOf(
                    "title" to safeTitle,
                    "description" to safeDesc,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            throw e
        }
    }

    suspend fun addMembersToGroup(
        conversation: Conversation,
        newMembers: List<PublicUserProfile>,
        existingRoomKey: ByteArray
    ): List<PublicUserProfile> {
        requireUserId()
        if (!conversation.isGroup) return emptyList()
        val uniqueNewIds = newMembers.map { it.userId }
            .filter { it.isNotBlank() && it !in conversation.memberUids }
            .distinct()
        if (uniqueNewIds.isEmpty()) return emptyList()
        if (conversation.memberUids.size + uniqueNewIds.size > 50) {
            throw IllegalStateException("Достигнут лимит участников группы (50).")
        }

        val freshProfiles = getPublicProfiles(uniqueNewIds).associateBy { it.userId }
        val resolvedNew = newMembers
            .distinctBy { it.userId }
            .filter { it.userId in uniqueNewIds }
            .map { freshProfiles[it.userId] ?: it }
            .filter { !it.isBanned() && it.publicKeyBase64.isNotBlank() }

        if (resolvedNew.isEmpty()) {
            throw IllegalStateException("Не удалось получить ключи E2EE выбранных пользователей.")
        }

        val updatedUids = (conversation.memberUids + resolvedNew.map { it.userId }).distinct()
        val updatedNames = conversation.memberNames.toMutableMap()
        val updatedEnvelopes = conversation.memberKeyEnvelopes.toMutableMap()
        val updatedUnread = conversation.unreadCounts.toMutableMap()
        val updatedRead = conversation.lastReadAtMillis.toMutableMap()
        val nowMs = System.currentTimeMillis()

        resolvedNew.forEach { member ->
            updatedNames[member.userId] = member.displayName.ifBlank { member.handle.ifBlank { "Участник" } }.take(60)
            updatedEnvelopes[member.userId] = crypto.wrapRoomKeyForMember(existingRoomKey, member.publicKeyBase64)
            updatedUnread[member.userId] = 0L
            updatedRead[member.userId] = nowMs
        }

        val docRef = db.collection("conversations").document(conversation.id)
        try {
            docRef.update(
                mapOf(
                    "memberUids" to updatedUids,
                    "memberNames" to updatedNames,
                    "memberKeyEnvelopes" to updatedEnvelopes,
                    "unreadCounts" to updatedUnread,
                    "lastReadAtMillis" to updatedRead,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            return resolvedNew
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            throw e
        }
    }

    suspend fun addMemberToGroup(
        conversation: Conversation,
        newMember: PublicUserProfile,
        existingRoomKey: ByteArray
    ) {
        addMembersToGroup(conversation, listOf(newMember), existingRoomKey)
    }

    suspend fun removeMemberFromGroup(
        conversation: Conversation,
        targetUid: String
    ): ByteArray {
        val uid = requireUserId()
        if (!conversation.isGroup) throw IllegalStateException("Нельзя удалить участника из личного чата")
        if (conversation.createdBy != uid) {
            throw IllegalStateException("Только создатель группы может удалять других участников")
        }
        if (targetUid == conversation.createdBy) {
            throw IllegalStateException("Создателя группы нельзя удалить — вы можете удалить группу целиком")
        }
        if (targetUid !in conversation.memberUids) {
            throw IllegalStateException("Пользователь не состоит в этой группе")
        }
        return removeUidAndRotateKey(conversation, targetUid, actingUid = uid)
    }

    suspend fun leaveGroupChat(
        conversation: Conversation,
        userId: String
    ) {
        val uid = requireUserId()
        if (uid != userId) throw IllegalStateException("Несоответствие пользователя")
        if (!conversation.isGroup) throw IllegalStateException("Личный чат можно только удалить")
        if (conversation.createdBy == uid) {
            throw IllegalStateException("Создатель не может покинуть группу — используйте «Удалить группу»")
        }
        if (uid !in conversation.memberUids) return
        removeUidAndRotateKey(conversation, uid, actingUid = uid)
    }

    private suspend fun removeUidAndRotateKey(
        conversation: Conversation,
        uidToRemove: String,
        actingUid: String
    ): ByteArray {
        val remainingUids = conversation.memberUids.filter { it != uidToRemove && it.isNotBlank() }.distinct()
        if (remainingUids.isEmpty()) {
            throw IllegalStateException("В группе должен оставаться хотя бы создатель")
        }

        val profilesById = getPublicProfiles(remainingUids).associateBy { it.userId }
        val newRoomKey = crypto.generateRoomKey()
        val updatedNames = mutableMapOf<String, String>()
        val updatedEnvelopes = mutableMapOf<String, String>()
        val updatedUnread = mutableMapOf<String, Long>()
        val updatedRead = mutableMapOf<String, Long>()

        remainingUids.forEach { memberUid ->
            val profile = profilesById[memberUid]
            val name = profile?.displayName?.ifBlank { null }
                ?: conversation.memberNames[memberUid]?.ifBlank { null }
                ?: "Участник"
            updatedNames[memberUid] = name.take(60)
            updatedUnread[memberUid] = conversation.unreadCounts[memberUid] ?: 0L
            updatedRead[memberUid] = conversation.lastReadAtMillis[memberUid] ?: System.currentTimeMillis()

            val pubKey = profile?.publicKeyBase64?.ifBlank { null }
                ?: if (memberUid == actingUid) crypto.getPublicKeyBase64() else null
            if (!pubKey.isNullOrBlank()) {
                updatedEnvelopes[memberUid] = crypto.wrapRoomKeyForMember(newRoomKey, pubKey)
            } else {
                conversation.memberKeyEnvelopes[memberUid]?.let { existingEnv ->
                    updatedEnvelopes[memberUid] = existingEnv
                }
            }
        }

        val docRef = db.collection("conversations").document(conversation.id)
        try {
            docRef.update(
                mapOf(
                    "memberUids" to remainingUids,
                    "memberNames" to updatedNames,
                    "memberKeyEnvelopes" to updatedEnvelopes,
                    "unreadCounts" to updatedUnread,
                    "lastReadAtMillis" to updatedRead,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            return newRoomKey
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            throw e
        }
    }

    suspend fun deleteConversation(conversation: Conversation) {
        val uid = requireUserId()
        val canDelete = conversation.createdBy == uid || (!conversation.isGroup && uid in conversation.memberUids)
        if (!canDelete) {
            throw IllegalStateException("Удалить группу целиком может только её создатель")
        }
        val docRef = db.collection("conversations").document(conversation.id)
        try {
            val messagesSnap = docRef.collection("messages")
                .whereArrayContains("memberUids", uid)
                .get()
                .await()
            val docs = messagesSnap.documents
            docs.filter { it.getString("messageType") == "file" }.forEach { msgDoc ->
                runCatching {
                    val chunksSnap = msgDoc.reference.collection("chunks")
                        .whereArrayContains("memberUids", uid)
                        .get()
                        .await()
                    val chunkDocs = chunksSnap.documents
                    var cIdx = 0
                    while (cIdx < chunkDocs.size) {
                        val cBatch = db.batch()
                        chunkDocs.subList(cIdx, minOf(cIdx + 400, chunkDocs.size)).forEach {
                            cBatch.delete(it.reference)
                        }
                        cBatch.commit().await()
                        cIdx += 400
                    }
                }
            }
            var index = 0
            while (index < docs.size) {
                val batch = db.batch()
                val slice = docs.subList(index, minOf(index + 400, docs.size))
                slice.forEach { batch.delete(it.reference) }
                batch.commit().await()
                index += 400
            }
            if (conversation.activeCallId.isNotBlank()) {
                runCatching {
                    db.collection("calls").document(conversation.activeCallId).update(
                        mapOf(
                            "status" to "ended",
                            "activeParticipantUids" to emptyList<String>(),
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    ).await()
                }
            }
            docRef.delete().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path)
            throw e
        }
    }

    suspend fun createGroupFromDirectChat(
        creator: PublicUserProfile,
        peer: PublicUserProfile?,
        additionalMembers: List<PublicUserProfile>,
        title: String
    ): String {
        val allPeers = (listOfNotNull(peer) + additionalMembers)
            .filter { it.userId != creator.userId }
            .distinctBy { it.userId }
        val resolvedTitle = title.trim().ifBlank {
            listOfNotNull(peer?.displayName?.takeIf { it.isNotBlank() }, additionalMembers.firstOrNull()?.displayName)
                .joinToString(", ")
                .ifBlank { "Групповой чат" }
        }.take(80)
        return createGroupChat(
            title = resolvedTitle,
            creator = creator,
            selectedMembers = allPeers
        )
    }

    suspend fun sendEncryptedMessage(
        conversation: Conversation,
        senderName: String,
        messageType: String,
        ivBase64: String,
        encryptedPayload: String,
        encryptedPreviewLabel: String,
        customMessageId: String? = null
    ) {
        val uid = requireUserId()
        val msgId = customMessageId?.takeIf { it.isNotBlank() }
            ?: "msg_${UUID.randomUUID().toString().replace("-", "").take(24)}"
        val chatRef = db.collection("conversations").document(conversation.id)
        val msgRef = chatRef.collection("messages").document(msgId)

        val msgPayload = mapOf(
            "conversationId" to conversation.id,
            "senderId" to uid,
            "senderName" to senderName.ifBlank { "Участник" }.take(60),
            "memberUids" to conversation.memberUids,
            "messageType" to messageType,
            "ivBase64" to ivBase64,
            "encryptedPayload" to encryptedPayload,
            "keyVersion" to 1L,
            "isDeleted" to false,
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        try {
            msgRef.set(msgPayload).await()
            val nowMs = System.currentTimeMillis()
            val chatUpdates = mutableMapOf<String, Any>(
                "lastMessagePreview" to encryptedPreviewLabel.take(300),
                "lastMessageType" to messageType,
                "lastMessageSenderId" to uid,
                "unreadCounts.$uid" to 0L,
                "lastReadAtMillis.$uid" to nowMs,
                "updatedAt" to FieldValue.serverTimestamp()
            )
            conversation.memberUids.forEach { memberUid ->
                if (memberUid != uid) {
                    chatUpdates["unreadCounts.$memberUid"] = FieldValue.increment(1L)
                }
            }
            chatRef.update(chatUpdates).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, msgRef.path)
            throw e
        }
    }

    suspend fun sendChunkedMediaMessage(
        conversation: Conversation,
        senderName: String,
        roomKey: ByteArray,
        sourceFile: File,
        fileName: String,
        mimeType: String,
        sizeBytes: Long,
        encryptedPreviewLabel: String,
        replyTo: ReplyQuoteInfo? = null,
        forwardedFrom: ForwardOriginInfo? = null,
        onChunkProgress: (uploadedChunks: Int, totalChunks: Int) -> Unit = { _, _ -> }
    ) {
        val uid = requireUserId()
        val msgId = "msg_${UUID.randomUUID().toString().replace("-", "").take(24)}"
        val chatRef = db.collection("conversations").document(conversation.id)
        val msgRef = chatRef.collection("messages").document(msgId)
        val chunkSize = FileAttachmentHelper.MEDIA_CHUNK_SIZE_BYTES
        val totalChunks = ((sizeBytes + chunkSize - 1L) / chunkSize).toInt().coerceAtLeast(1)
        val createdChunkRefs = mutableListOf<com.google.firebase.firestore.DocumentReference>()

        try {
            withContext(Dispatchers.IO) {
                sourceFile.inputStream().use { input ->
                    val buffer = ByteArray(chunkSize)
                    for (chunkIndex in 0 until totalChunks) {
                        var offset = 0
                        while (offset < chunkSize) {
                            val read = input.read(buffer, offset, chunkSize - offset)
                            if (read <= 0) break
                            offset += read
                        }
                        if (offset <= 0) break
                        val chunkBytes = if (offset == buffer.size) buffer else buffer.copyOf(offset)
                        val blob = crypto.encryptMediaChunk(roomKey, chunkBytes)
                        val chunkDocId = "chunk_${chunkIndex.toString().padStart(4, '0')}"
                        val chunkRef = msgRef.collection("chunks").document(chunkDocId)
                        val chunkData = mapOf(
                            "conversationId" to conversation.id,
                            "messageId" to msgId,
                            "senderId" to uid,
                            "memberUids" to conversation.memberUids,
                            "chunkIndex" to chunkIndex.toLong(),
                            "ivBase64" to blob.ivBase64,
                            "encryptedPayload" to blob.ciphertextBase64,
                            "createdAt" to FieldValue.serverTimestamp()
                        )
                        chunkRef.set(chunkData).await()
                        createdChunkRefs.add(chunkRef)
                        onChunkProgress(chunkIndex + 1, totalChunks)
                    }
                }
            }

            val manifestBlob = crypto.encryptChunkedFileManifest(
                roomKey = roomKey,
                fileName = fileName,
                mimeType = mimeType,
                sizeBytes = sizeBytes,
                chunkCount = createdChunkRefs.size,
                replyTo = replyTo,
                forwardedFrom = forwardedFrom
            )
            sendEncryptedMessage(
                conversation = conversation,
                senderName = senderName,
                messageType = "file",
                ivBase64 = manifestBlob.ivBase64,
                encryptedPayload = manifestBlob.ciphertextBase64,
                encryptedPreviewLabel = encryptedPreviewLabel,
                customMessageId = msgId
            )
        } catch (e: CancellationException) {
            createdChunkRefs.forEach { ref -> runCatching { ref.delete().await() } }
            throw e
        } catch (e: Exception) {
            createdChunkRefs.forEach { ref -> runCatching { ref.delete().await() } }
            handleFirestoreError(e, OperationType.CREATE, msgRef.path)
            throw e
        }
    }

    suspend fun downloadAndDecryptChunkedMedia(
        chatId: String,
        messageId: String,
        roomKey: ByteArray,
        targetFile: File,
        expectedChunkCount: Int,
        onChunkProgress: (completedChunks: Int, totalChunks: Int) -> Unit = { _, _ -> }
    ): File {
        val uid = requireUserId()
        val msgRef = db.collection("conversations").document(chatId)
            .collection("messages").document(messageId)
        val snap = try {
            msgRef.collection("chunks")
                .whereArrayContains("memberUids", uid)
                .get()
                .await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.LIST, "${msgRef.path}/chunks")
            throw e
        }

        val chunks = snap.toObjects(EncryptedMediaChunk::class.java)
            .sortedBy { it.chunkIndex }
        if (chunks.isEmpty()) {
            throw IllegalStateException("Зашифрованные фрагменты медиафайла не найдены")
        }
        val total = maxOf(expectedChunkCount, chunks.size)

        withContext(Dispatchers.IO) {
            targetFile.parentFile?.mkdirs()
            val tempFile = File(targetFile.parentFile, "${targetFile.name}.part")
            runCatching { tempFile.delete() }
            try {
                tempFile.outputStream().use { output ->
                    chunks.forEachIndexed { idx, chunk ->
                        val plain = crypto.decryptMediaChunk(roomKey, chunk.ivBase64, chunk.encryptedPayload)
                            ?: throw IllegalStateException("Не удалось расшифровать фрагмент #${chunk.chunkIndex + 1}")
                        output.write(plain)
                        onChunkProgress(idx + 1, total)
                    }
                    output.flush()
                }
                if (targetFile.exists()) targetFile.delete()
                if (!tempFile.renameTo(targetFile)) {
                    tempFile.copyTo(targetFile, overwrite = true)
                    tempFile.delete()
                }
            } catch (t: Throwable) {
                runCatching { tempFile.delete() }
                throw t
            }
        }
        return targetFile
    }

    suspend fun markConversationAsRead(
        conversation: Conversation,
        userId: String,
        readAtMillis: Long = System.currentTimeMillis()
    ) {
        val uid = auth.currentUser?.uid ?: return
        if (uid != userId || uid !in conversation.memberUids) return
        val currentUnread = conversation.unreadCountFor(uid)
        val currentCursor = conversation.lastReadAtMillis[uid] ?: 0L
        val convUpdatedMs = conversation.updatedAt?.toDate()?.time ?: 0L
        val targetCursor = maxOf(readAtMillis, convUpdatedMs)
        if (currentUnread == 0 && currentCursor >= targetCursor) return
        val effectiveCursor = maxOf(currentCursor, targetCursor, System.currentTimeMillis())
        runCatching {
            db.collection("conversations").document(conversation.id)
                .update(
                    mapOf(
                        "unreadCounts.$uid" to 0L,
                        "lastReadAtMillis.$uid" to effectiveCursor
                    )
                )
                .await()
        }
    }

    suspend fun softDeleteMessage(conversationId: String, messageId: String, roomKey: ByteArray) {
        requireUserId()
        val msgRef = db.collection("conversations").document(conversationId)
            .collection("messages").document(messageId)
        val encryptedMarker = crypto.encryptText(roomKey, "Сообщение удалено")
        try {
            msgRef.update(
                mapOf(
                    "isDeleted" to true,
                    "ivBase64" to encryptedMarker.ivBase64,
                    "encryptedPayload" to encryptedMarker.ciphertextBase64,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, msgRef.path)
            throw e
        }
    }

    private fun logStreamError(
        error: Throwable,
        operationType: OperationType,
        path: String,
        uid: String
    ) {
        val firestoreError = generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreError == null && error is CancellationException) return
        val exceptionToLog = firestoreError ?: (error as? Exception)
        if (exceptionToLog != null && auth.currentUser?.uid == uid) {
            handleFirestoreError(exceptionToLog, operationType, path)
        }
    }

    private companion object {
        val VALID_THEMES = setOf("dark", "light", "system")
    }
}
