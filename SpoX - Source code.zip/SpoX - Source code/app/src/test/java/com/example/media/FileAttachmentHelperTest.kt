package com.example.media

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class FileAttachmentHelperTest {

    @Test
    fun isUnsafeExecutableFile_blocksAndroidPackagesAndScripts() {
        assertTrue(FileAttachmentHelper.isUnsafeExecutableFile("app-release.apk", "application/octet-stream"))
        assertTrue(FileAttachmentHelper.isUnsafeExecutableFile("split.APKS ", "application/octet-stream"))
        assertTrue(FileAttachmentHelper.isUnsafeExecutableFile("bundle.aab", "application/octet-stream"))
        assertTrue(FileAttachmentHelper.isUnsafeExecutableFile("classes.dex", "application/octet-stream"))
        assertTrue(FileAttachmentHelper.isUnsafeExecutableFile("libpayload.so", "application/octet-stream"))
        assertTrue(FileAttachmentHelper.isUnsafeExecutableFile("payload.jar", "application/octet-stream"))
        assertTrue(FileAttachmentHelper.isUnsafeExecutableFile("installer.exe", "application/octet-stream"))
        assertTrue(FileAttachmentHelper.isUnsafeExecutableFile("run.sh", "text/plain"))
        assertTrue(FileAttachmentHelper.isUnsafeExecutableFile("file.bin", "application/vnd.android.package-archive"))
        assertTrue(FileAttachmentHelper.isUnsafeExecutableFile("archive.zip", "application/java-archive"))
    }

    @Test
    fun isUnsafeExecutableFile_allowsSafeDocumentsAndMedia() {
        assertFalse(FileAttachmentHelper.isUnsafeExecutableFile("contract.pdf", "application/pdf"))
        assertFalse(FileAttachmentHelper.isUnsafeExecutableFile("photo.jpg", "image/jpeg"))
        assertFalse(FileAttachmentHelper.isUnsafeExecutableFile("voice.m4a", "audio/mp4"))
        assertFalse(FileAttachmentHelper.isUnsafeExecutableFile("notes.txt", "text/plain"))
        assertFalse(FileAttachmentHelper.isUnsafeExecutableFile("report.docx", "application/vnd.openxmlformats-officedocument.wordprocessingml.document"))
    }

    @Test
    fun classifyMediaKind_mapsCommonExtensionsAndMimesCorrectly() {
        assertEquals(MediaKind.PHOTO, FileAttachmentHelper.classifyMediaKind("image/png", "pic.png"))
        assertEquals(MediaKind.VIDEO, FileAttachmentHelper.classifyMediaKind("application/octet-stream", "clip.mp4"))
        assertEquals(MediaKind.VIDEO, FileAttachmentHelper.classifyMediaKind("application/octet-stream", "movie.mkv"))
        assertEquals(MediaKind.VIDEO, FileAttachmentHelper.classifyMediaKind("application/octet-stream", "stream.ts"))
        assertEquals(MediaKind.VIDEO, FileAttachmentHelper.classifyMediaKind("application/octet-stream", "capture.avi"))
        assertEquals(MediaKind.VIDEO, FileAttachmentHelper.classifyMediaKind("application/octet-stream", "flash.flv"))
        assertEquals(MediaKind.VIDEO, FileAttachmentHelper.classifyMediaKind("application/octet-stream", "clip.webm"))
        assertEquals(MediaKind.VIDEO, FileAttachmentHelper.classifyMediaKind("application/octet-stream", "dvd.vob"))
        assertEquals(MediaKind.VIDEO, FileAttachmentHelper.classifyMediaKind("application/octet-stream", "clip.ogv"))
        assertEquals(MediaKind.AUDIO, FileAttachmentHelper.classifyMediaKind("audio/mpeg", "track.mp3"))
        assertEquals(MediaKind.AUDIO, FileAttachmentHelper.classifyMediaKind("application/octet-stream", "lossless.flac"))
        assertEquals(MediaKind.AUDIO, FileAttachmentHelper.classifyMediaKind("application/octet-stream", "voice.opus"))
        assertEquals(MediaKind.AUDIO, FileAttachmentHelper.classifyMediaKind("application/octet-stream", "track.mka"))
        assertEquals(MediaKind.AUDIO, FileAttachmentHelper.classifyMediaKind("application/octet-stream", "record.amr"))
        assertEquals(MediaKind.FILE, FileAttachmentHelper.classifyMediaKind("application/pdf", "spec.pdf"))
    }

    @Test
    fun maxAllowedUploadBytes_enforcesIncreased25MbMediaAnd10MbDocumentLimits() {
        assertEquals(25L * 1024L * 1024L, FileAttachmentHelper.maxAllowedUploadBytes(MediaKind.VIDEO))
        assertEquals(25L * 1024L * 1024L, FileAttachmentHelper.maxAllowedUploadBytes(MediaKind.AUDIO))
        assertEquals(25L * 1024L * 1024L, FileAttachmentHelper.maxAllowedUploadBytes(MediaKind.VOICE))
        assertEquals(10L * 1024L * 1024L, FileAttachmentHelper.maxAllowedUploadBytes(MediaKind.FILE))
        assertEquals(FileAttachmentHelper.MAX_RAW_BYTES.toLong(), FileAttachmentHelper.maxAllowedUploadBytes(MediaKind.PHOTO))
    }

    @Test
    fun formatBadge_andDurationFormatting_returnCleanLabels() {
        assertEquals("MKV", FileAttachmentHelper.formatBadge("sample_video.mkv", "application/octet-stream"))
        assertEquals("FLAC", FileAttachmentHelper.formatBadge("lossless.flac", "audio/flac"))
        assertEquals("MKV", FileAttachmentHelper.formatBadge("noext", "video/x-matroska"))
        assertEquals("MOV", FileAttachmentHelper.formatBadge("noext", "video/quicktime"))

        assertEquals("00:00", SpoxMediaEngine.formatMediaDuration(0L))
        assertEquals("03:45", SpoxMediaEngine.formatMediaDuration(225_000L))
        assertEquals("1:05:09", SpoxMediaEngine.formatMediaDuration(3_909_000L))
    }
}
