package com.example.ui.screens

import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.Modifier
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import com.example.data.model.AppThemeMode
import com.example.data.model.ChatAppearanceConfig
import com.example.ui.theme.CipherChatTheme
import com.example.updates.AppUpdateState
import com.example.updates.GitHubReleaseAsset
import com.example.updates.GitHubReleaseInfo
import com.example.updates.UpdateCheckStatus
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class AppUpdateSheetUiTest {

    @get:Rule
    val composeRule = createComposeRule()

    private val sampleRelease = GitHubReleaseInfo(
        tagName = "v1.2",
        versionName = "1.2",
        title = "SpoX 1.2 — Обновление",
        changelog = "• Новая система плагинов Lua\n• Автопроверка обновлений GitHub",
        htmlUrl = "https://github.com/daniilxccx/Spox-messenger/releases/tag/v1.2",
        publishedAtIso = "2026-11-23T12:00:00Z",
        isPrerelease = false,
        isDraft = false,
        apkAsset = GitHubReleaseAsset(
            name = "SpoX.apk",
            downloadUrl = "https://github.com/daniilxccx/Spox-messenger/releases/download/v1.2/SpoX.apk",
            sizeBytes = 12_582_912L,
            downloadCount = 15,
            contentType = "application/vnd.android.package-archive"
        ),
        allAssets = emptyList()
    )

    @Test
    fun appUpdateContent_displaysReleaseAndTriggersActions() {
        var checkClicks = 0
        var downloadedRelease: GitHubReleaseInfo? = null
        var openedUrl: String? = null
        var skippedTag: String? = null
        var autoCheckToggled: Boolean? = null

        composeRule.setContent {
            val state = AppUpdateState(
                currentVersion = "1.1",
                currentVersionCode = 5,
                status = UpdateCheckStatus.UPDATE_AVAILABLE,
                latestRelease = sampleRelease,
                recentReleases = listOf(sampleRelease),
                autoCheckEnabled = true
            )
            CipherChatTheme(themeMode = AppThemeMode.DARK, appearanceConfig = ChatAppearanceConfig()) {
                AppUpdateContent(
                    state = state,
                    onCheckNow = { checkClicks++ },
                    onDownloadApk = { downloadedRelease = it },
                    onOpenReleasePage = { openedUrl = it },
                    onOpenAllReleases = { openedUrl = "all_releases" },
                    onCopyUrl = {},
                    onToggleAutoCheck = { autoCheckToggled = it },
                    onSkipVersion = { skippedTag = it },
                    onClearSkippedVersion = {},
                    modifier = Modifier.verticalScroll(rememberScrollState())
                )
            }
        }

        composeRule.waitForIdle()
        composeRule.onNodeWithText("Обновления SpoX").assertIsDisplayed()
        composeRule.onNodeWithTag("update_status_title").assertIsDisplayed()
        composeRule.onNodeWithText("Доступно обновление: v1.2").assertIsDisplayed()

        composeRule.onNodeWithTag("check_updates_now_button").performScrollTo().performClick()
        assertEquals(1, checkClicks)

        composeRule.onNodeWithTag("download_update_apk_button").performScrollTo().performClick()
        assertEquals("v1.2", downloadedRelease?.tagName)

        composeRule.onNodeWithTag("skip_update_version_button").performScrollTo().performClick()
        assertEquals("v1.2", skippedTag)

        composeRule.onNodeWithTag("auto_check_updates_switch").performScrollTo().performClick()
        assertEquals(false, autoCheckToggled)

        composeRule.onNodeWithTag("open_all_github_releases_button").performScrollTo().performClick()
        assertEquals("all_releases", openedUrl)
    }

    @Test
    fun updateBanner_opensUpdatesOrDismissesVersion() {
        var opened = false
        var dismissed = false

        composeRule.setContent {
            CipherChatTheme(themeMode = AppThemeMode.DARK, appearanceConfig = ChatAppearanceConfig()) {
                UpdateAvailableBanner(
                    release = sampleRelease,
                    currentVersion = "1.1",
                    onOpenUpdates = { opened = true },
                    onDismissVersion = { dismissed = true }
                )
            }
        }

        composeRule.waitForIdle()
        composeRule.onNodeWithTag("update_available_banner").assertIsDisplayed()
        composeRule.onNodeWithText("Доступна версия 1.2").assertIsDisplayed()

        composeRule.onNodeWithTag("update_banner_open_button").performClick()
        assertTrue(opened)

        composeRule.onNodeWithTag("update_banner_dismiss_button").performClick()
        assertTrue(dismissed)
    }
}
