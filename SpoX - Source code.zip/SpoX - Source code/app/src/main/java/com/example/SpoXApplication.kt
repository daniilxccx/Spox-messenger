package com.example

import android.app.Application
import android.util.Log
import androidx.work.Configuration
import com.example.ui.components.BitmapMemoryCache

class SpoXApplication : Application(), Configuration.Provider {

    override val workManagerConfiguration: Configuration
        get() = Configuration.Builder()
            .setMinimumLoggingLevel(if (BuildConfig.DEBUG) Log.INFO else Log.ERROR)
            .build()

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        BitmapMemoryCache.trimOnMemoryPressure(level)
    }

    override fun onLowMemory() {
        super.onLowMemory()
        BitmapMemoryCache.clearAllCaches()
    }
}
