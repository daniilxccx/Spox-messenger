package com.example.notifications

import android.content.Context

object ActiveChatTracker {
    @Volatile
    var isAppInForeground: Boolean = false

    @Volatile
    var activeChatId: String? = null

    fun isActivelyViewingChat(chatId: String): Boolean =
        isAppInForeground && !chatId.isBlank() && activeChatId == chatId
}

object NotificationPreferences {

    private const val PREFS_NAME = "spox_notification_prefs"
    private const val KEY_MESSAGES_ENABLED = "push_messages_enabled"
    private const val KEY_CALLS_ENABLED = "push_calls_enabled"
    private const val KEY_FCM_TOKEN = "fcm_token"
    private const val KEY_NOTIFIED_MS_PREFIX = "last_notified_ms_"

    private fun prefs(context: Context) =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun isMessagePushEnabled(context: Context): Boolean =
        runCatching { prefs(context).getBoolean(KEY_MESSAGES_ENABLED, true) }.getOrDefault(true)

    fun setMessagePushEnabled(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(KEY_MESSAGES_ENABLED, enabled).apply()
    }

    fun isCallPushEnabled(context: Context): Boolean =
        runCatching { prefs(context).getBoolean(KEY_CALLS_ENABLED, true) }.getOrDefault(true)

    fun setCallPushEnabled(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(KEY_CALLS_ENABLED, enabled).apply()
    }

    fun getFcmToken(context: Context): String =
        runCatching { prefs(context).getString(KEY_FCM_TOKEN, "") }.getOrNull().orEmpty()

    fun saveFcmToken(context: Context, token: String) {
        if (token.isBlank()) return
        prefs(context).edit().putString(KEY_FCM_TOKEN, token).apply()
    }

    fun getLastNotifiedMs(context: Context, uid: String, chatId: String): Long =
        runCatching { prefs(context).getLong(notifiedKey(uid, chatId), 0L) }.getOrDefault(0L)

    fun markChatNotified(context: Context, uid: String, chatId: String, messageTimeMs: Long) {
        if (uid.isBlank() || chatId.isBlank() || messageTimeMs <= 0L) return
        val existing = getLastNotifiedMs(context, uid, chatId)
        if (messageTimeMs > existing) {
            prefs(context).edit().putLong(notifiedKey(uid, chatId), messageTimeMs).apply()
        }
    }

    private fun notifiedKey(uid: String, chatId: String): String =
        "${KEY_NOTIFIED_MS_PREFIX}${uid}_$chatId"
}
