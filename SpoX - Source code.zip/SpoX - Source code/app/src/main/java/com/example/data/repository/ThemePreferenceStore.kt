package com.example.data.repository

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.datastore.core.handlers.ReplaceFileCorruptionHandler
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.data.model.AppThemeMode
import com.example.data.model.AppVisualTheme
import com.example.data.model.ChatAppearanceConfig
import com.example.data.model.ChatWallpaperPreset
import com.example.data.model.OutgoingBubbleStyle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

private val Context.themeDataStore by preferencesDataStore(
    name = "cipherchat_prefs",
    corruptionHandler = ReplaceFileCorruptionHandler { emptyPreferences() }
)

class ThemePreferenceStore(context: Context) {
    private val appContext = context.applicationContext
    private val themeKey = stringPreferencesKey("preferred_theme")
    private val visualThemeKey = stringPreferencesKey("visual_theme")
    private val wallpaperPresetKey = stringPreferencesKey("chat_wallpaper_preset")
    private val customWallpaperPathKey = stringPreferencesKey("custom_wallpaper_path")
    private val customWallpaperVersionKey = longPreferencesKey("custom_wallpaper_version")
    private val outgoingBubbleStyleKey = stringPreferencesKey("outgoing_bubble_style")
    private val showStoriesKey = booleanPreferencesKey("show_stories")
    private val showFoldersKey = booleanPreferencesKey("show_folders")

    private val safePrefsFlow = appContext.themeDataStore.data.catch { error ->
        if (error is IOException) {
            emit(emptyPreferences())
        } else {
            throw error
        }
    }

    val themeMode: Flow<AppThemeMode> = safePrefsFlow.map { prefs ->
        AppThemeMode.fromWire(prefs[themeKey])
    }

    val appearanceConfig: Flow<ChatAppearanceConfig> = safePrefsFlow.map { prefs ->
        ChatAppearanceConfig(
            themeMode = AppThemeMode.fromWire(prefs[themeKey]),
            visualTheme = AppVisualTheme.fromWire(prefs[visualThemeKey]),
            wallpaperPreset = ChatWallpaperPreset.fromWire(prefs[wallpaperPresetKey]),
            customWallpaperPath = prefs[customWallpaperPathKey].orEmpty(),
            customWallpaperVersion = prefs[customWallpaperVersionKey] ?: 0L,
            outgoingBubbleStyle = OutgoingBubbleStyle.fromWire(prefs[outgoingBubbleStyleKey]),
            showStories = prefs[showStoriesKey] ?: true,
            showFolders = prefs[showFoldersKey] ?: true
        )
    }

    suspend fun setThemeMode(mode: AppThemeMode) {
        appContext.themeDataStore.edit { prefs ->
            prefs[themeKey] = mode.wireValue
        }
    }

    suspend fun setVisualTheme(theme: AppVisualTheme) {
        appContext.themeDataStore.edit { prefs ->
            prefs[visualThemeKey] = theme.wireValue
        }
    }

    suspend fun setWallpaperPreset(preset: ChatWallpaperPreset) {
        appContext.themeDataStore.edit { prefs ->
            prefs[wallpaperPresetKey] = preset.wireValue
        }
    }

    suspend fun setOutgoingBubbleStyle(style: OutgoingBubbleStyle) {
        appContext.themeDataStore.edit { prefs ->
            prefs[outgoingBubbleStyleKey] = style.wireValue
        }
    }

    suspend fun setShowStories(visible: Boolean) {
        appContext.themeDataStore.edit { prefs ->
            prefs[showStoriesKey] = visible
        }
    }

    suspend fun setShowFolders(visible: Boolean) {
        appContext.themeDataStore.edit { prefs ->
            prefs[showFoldersKey] = visible
        }
    }

    suspend fun saveCustomWallpaperFromUri(uri: Uri): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val resolver = appContext.contentResolver
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            resolver.openInputStream(uri)?.use { stream ->
                BitmapFactory.decodeStream(stream, null, bounds)
            } ?: throw IllegalStateException("Не удалось прочитать выбранное изображение")

            val maxDim = 1440
            var sampleSize = 1
            while (bounds.outWidth / sampleSize > maxDim * 2 || bounds.outHeight / sampleSize > maxDim * 2) {
                sampleSize *= 2
            }

            val decodeOpts = BitmapFactory.Options().apply { inSampleSize = sampleSize }
            val decoded = resolver.openInputStream(uri)?.use { stream ->
                BitmapFactory.decodeStream(stream, null, decodeOpts)
            } ?: throw IllegalStateException("Не удалось декодировать изображение")

            val scaled = if (decoded.width > maxDim || decoded.height > maxDim) {
                val ratio = minOf(maxDim.toFloat() / decoded.width, maxDim.toFloat() / decoded.height)
                val targetW = (decoded.width * ratio).toInt().coerceAtLeast(1)
                val targetH = (decoded.height * ratio).toInt().coerceAtLeast(1)
                Bitmap.createScaledBitmap(decoded, targetW, targetH, true).also {
                    if (it !== decoded) decoded.recycle()
                }
            } else {
                decoded
            }

            val targetFile = File(appContext.filesDir, "custom_chat_wallpaper.jpg")
            FileOutputStream(targetFile).use { out ->
                scaled.compress(Bitmap.CompressFormat.JPEG, 88, out)
            }
            scaled.recycle()

            val path = targetFile.absolutePath
            appContext.themeDataStore.edit { prefs ->
                prefs[customWallpaperPathKey] = path
                prefs[customWallpaperVersionKey] = System.currentTimeMillis()
                prefs[wallpaperPresetKey] = ChatWallpaperPreset.CUSTOM_IMAGE.wireValue
            }
            path
        }
    }

    suspend fun resetCustomization() {
        appContext.themeDataStore.edit { prefs ->
            prefs[visualThemeKey] = AppVisualTheme.SPOX_CYBER.wireValue
            prefs[wallpaperPresetKey] = ChatWallpaperPreset.THEME_DEFAULT.wireValue
            prefs[outgoingBubbleStyleKey] = OutgoingBubbleStyle.THEME_AUTO.wireValue
            prefs[showStoriesKey] = true
            prefs[showFoldersKey] = true
        }
    }
}
