package com.example.security

import android.content.Context
import android.content.ContextWrapper
import android.os.Build
import android.util.Base64
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.security.MessageDigest
import java.security.SecureRandom

enum class BiometricCapability {
    READY,
    NO_HARDWARE,
    HARDWARE_UNAVAILABLE,
    NONE_ENROLLED
}

class AppLockManager(context: Context) {

    private val prefs = context.applicationContext.getSharedPreferences(
        PREFS_NAME,
        Context.MODE_PRIVATE
    )
    private val secureRandom = SecureRandom()

    fun isPinEnabled(uid: String): Boolean {
        if (uid.isBlank()) return false
        return runCatching {
            val salt = prefs.getString(saltKey(uid), null)
            val hash = prefs.getString(hashKey(uid), null)
            !salt.isNullOrBlank() && !hash.isNullOrBlank()
        }.getOrDefault(false)
    }

    fun isBiometricEnabled(uid: String): Boolean {
        if (uid.isBlank()) return false
        return runCatching { prefs.getBoolean(bioKey(uid), false) }.getOrDefault(false)
    }

    fun hasAnyLockEnabled(uid: String): Boolean =
        isPinEnabled(uid) || isBiometricEnabled(uid)

    fun setPin(uid: String, pin: String) {
        require(uid.isNotBlank()) { "User ID must not be blank" }
        require(pin.length == PIN_LENGTH && pin.all { it.isDigit() }) {
            "PIN must be exactly $PIN_LENGTH digits"
        }
        val salt = ByteArray(16).also { secureRandom.nextBytes(it) }
        val digest = computeSaltedHash(salt, pin)
        prefs.edit()
            .putString(saltKey(uid), Base64.encodeToString(salt, Base64.NO_WRAP))
            .putString(hashKey(uid), Base64.encodeToString(digest, Base64.NO_WRAP))
            .apply()
    }

    fun verifyPin(uid: String, pin: String): Boolean {
        if (uid.isBlank() || pin.length != PIN_LENGTH || !pin.all { it.isDigit() }) {
            return false
        }
        val saltB64 = prefs.getString(saltKey(uid), null) ?: return false
        val hashB64 = prefs.getString(hashKey(uid), null) ?: return false
        return try {
            val salt = Base64.decode(saltB64, Base64.NO_WRAP)
            val expected = Base64.decode(hashB64, Base64.NO_WRAP)
            val actual = computeSaltedHash(salt, pin)
            MessageDigest.isEqual(expected, actual)
        } catch (_: Exception) {
            false
        }
    }

    fun disablePin(uid: String) {
        if (uid.isBlank()) return
        prefs.edit()
            .remove(saltKey(uid))
            .remove(hashKey(uid))
            .apply()
    }

    fun setBiometricEnabled(uid: String, enabled: Boolean) {
        if (uid.isBlank()) return
        prefs.edit()
            .putBoolean(bioKey(uid), enabled)
            .apply()
    }

    fun clearAllForUser(uid: String) {
        if (uid.isBlank()) return
        prefs.edit()
            .remove(saltKey(uid))
            .remove(hashKey(uid))
            .remove(bioKey(uid))
            .apply()
    }

    suspend fun loadUserLockStateAsync(uid: String): Pair<Boolean, Boolean> = withContext(Dispatchers.IO) {
        isPinEnabled(uid) to isBiometricEnabled(uid)
    }

    suspend fun getBiometricCapabilityAsync(context: Context): BiometricCapability = withContext(Dispatchers.IO) {
        getBiometricCapability(context.applicationContext)
    }

    fun getBiometricCapability(context: Context): BiometricCapability {
        return runCatching {
            val manager = BiometricManager.from(context)
            val result = manager.canAuthenticate(
                BiometricManager.Authenticators.BIOMETRIC_STRONG or
                    BiometricManager.Authenticators.BIOMETRIC_WEAK
            )
            when (result) {
                BiometricManager.BIOMETRIC_SUCCESS -> BiometricCapability.READY
                BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE,
                BiometricManager.BIOMETRIC_ERROR_UNSUPPORTED -> BiometricCapability.NO_HARDWARE
                BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED -> BiometricCapability.NONE_ENROLLED
                else -> BiometricCapability.HARDWARE_UNAVAILABLE
            }
        }.getOrDefault(BiometricCapability.HARDWARE_UNAVAILABLE)
    }

    fun showBiometricPrompt(
        activity: FragmentActivity,
        title: String,
        subtitle: String,
        hasPinFallback: Boolean,
        negativeButtonText: String = if (hasPinFallback) "Ввести PIN-код" else "Отмена",
        onSuccess: () -> Unit,
        onFallbackOrCancel: () -> Unit = {},
        onError: (String) -> Unit = {}
    ) {
        val executor = ContextCompat.getMainExecutor(activity)
        val prompt = BiometricPrompt(
            activity,
            executor,
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    super.onAuthenticationSucceeded(result)
                    onSuccess()
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    super.onAuthenticationError(errorCode, errString)
                    when (errorCode) {
                        BiometricPrompt.ERROR_NEGATIVE_BUTTON,
                        BiometricPrompt.ERROR_USER_CANCELED,
                        BiometricPrompt.ERROR_CANCELED -> onFallbackOrCancel()
                        else -> onError(errString.toString().ifBlank { "Ошибка биометрической проверки" })
                    }
                }
            }
        )

        val useDeviceCredentialFallback = !hasPinFallback &&
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.R &&
            BiometricManager.from(activity).canAuthenticate(
                BiometricManager.Authenticators.BIOMETRIC_STRONG or
                    BiometricManager.Authenticators.DEVICE_CREDENTIAL
            ) == BiometricManager.BIOMETRIC_SUCCESS

        val builder = BiometricPrompt.PromptInfo.Builder()
            .setTitle(title)
            .setSubtitle(subtitle)

        if (useDeviceCredentialFallback) {
            builder.setAllowedAuthenticators(
                BiometricManager.Authenticators.BIOMETRIC_STRONG or
                    BiometricManager.Authenticators.DEVICE_CREDENTIAL
            )
        } else {
            builder.setAllowedAuthenticators(
                BiometricManager.Authenticators.BIOMETRIC_STRONG or
                    BiometricManager.Authenticators.BIOMETRIC_WEAK
            )
            builder.setNegativeButtonText(negativeButtonText)
        }

        try {
            prompt.authenticate(builder.build())
        } catch (e: Exception) {
            onError(e.localizedMessage ?: "Биометрия недоступна на этом устройстве")
        }
    }

    private fun computeSaltedHash(salt: ByteArray, pin: String): ByteArray {
        val md = MessageDigest.getInstance("SHA-256")
        md.update(salt)
        md.update(pin.toByteArray(Charsets.UTF_8))
        return md.digest()
    }

    private fun saltKey(uid: String) = "pin_salt_$uid"
    private fun hashKey(uid: String) = "pin_hash_$uid"
    private fun bioKey(uid: String) = "bio_enabled_$uid"

    companion object {
        const val PIN_LENGTH = 4
        private const val PREFS_NAME = "spox_app_lock_prefs"
    }
}

tailrec fun Context.findFragmentActivity(): FragmentActivity? = when (this) {
    is FragmentActivity -> this
    is ContextWrapper -> baseContext.findFragmentActivity()
    else -> null
}
