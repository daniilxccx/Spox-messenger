package com.example.notifications

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import com.example.data.model.AppThemeMode
import com.example.data.model.UserRole
import com.example.ui.components.InAppMessageAlertBanner
import com.example.ui.theme.CipherChatTheme
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class NotificationBannerUiTest {

    @get:Rule
    val composeRule = createComposeRule()

    @Test
    fun inAppBanner_displaysSenderNameRoleGroupAndDecryptedMessageText() {
        composeRule.setContent {
            CipherChatTheme(themeMode = AppThemeMode.DARK) {
                InAppMessageAlertBanner(
                    title = "Релиз 1.1",
                    body = "Сборка проверена, можно отправлять уведомления!",
                    unreadCount = 2,
                    senderName = "Мария Волкова",
                    senderRole = UserRole.TESTER,
                    avatarColorIndex = 1,
                    isGroup = true,
                    onOpen = {},
                    onDismiss = {}
                )
            }
        }

        composeRule.onNodeWithTag("in_app_message_alert_banner").assertIsDisplayed()
        composeRule.onNodeWithText("МВ", useUnmergedTree = true).assertIsDisplayed()
        composeRule.onNodeWithText("Мария Волкова", useUnmergedTree = true).assertIsDisplayed()
        composeRule.onNodeWithTag("role_badge_tester", useUnmergedTree = true).assertIsDisplayed()
        composeRule.onNodeWithText("TESTER", useUnmergedTree = true).assertIsDisplayed()
        composeRule.onNodeWithText("в чате «Релиз 1.1»", useUnmergedTree = true).assertIsDisplayed()
        composeRule.onNodeWithText("Сборка проверена, можно отправлять уведомления!", useUnmergedTree = true).assertIsDisplayed()
        composeRule.onNodeWithText("2", useUnmergedTree = true).assertIsDisplayed()
    }

    @Test
    fun inAppBanner_displaysCustomRoleAndStandardUserRole() {
        composeRule.setContent {
            CipherChatTheme(themeMode = AppThemeMode.LIGHT) {
                InAppMessageAlertBanner(
                    title = "Сергей",
                    body = "Обычное сообщение от пользователя",
                    unreadCount = 1,
                    senderName = "Сергей",
                    senderRole = UserRole.USER,
                    avatarColorIndex = 4,
                    isGroup = false,
                    onOpen = {},
                    onDismiss = {}
                )
            }
        }

        composeRule.onNodeWithText("С", useUnmergedTree = true).assertIsDisplayed()
        composeRule.onNodeWithText("Сергей", useUnmergedTree = true).assertIsDisplayed()
        composeRule.onNodeWithTag("role_badge_user", useUnmergedTree = true).assertIsDisplayed()
        composeRule.onNodeWithText("Пользователь", useUnmergedTree = true).assertIsDisplayed()
        composeRule.onNodeWithText("Обычное сообщение от пользователя", useUnmergedTree = true).assertIsDisplayed()
    }
}
