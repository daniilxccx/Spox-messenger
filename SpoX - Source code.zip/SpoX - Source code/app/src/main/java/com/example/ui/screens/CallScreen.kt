package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeDown
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.VideocamOff
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.CallParticipant
import com.example.data.model.CallSession
import com.example.notifications.SpoXNotificationHelper
import com.example.ui.components.UserAvatar
import com.example.ui.theme.isLiquidGlassActive
import com.example.ui.theme.liquidGlassSurface
import com.example.ui.viewmodel.CallRoomUiState
import com.example.ui.viewmodel.CallViewModel
import com.example.ui.viewmodel.UiState
import kotlinx.coroutines.delay

@Composable
fun CallScreen(
    viewModel: CallViewModel,
    currentUserId: String,
    isInPictureInPicture: Boolean = false,
    onMinimizeCall: (() -> Unit)? = null,
    onCallClosed: () -> Unit
) {
    val context = LocalContext.current

    val uiState by viewModel.callUiState.collectAsStateWithLifecycle()
    val isMuted by viewModel.isMuted.collectAsStateWithLifecycle()
    val isCameraOn by viewModel.isCameraOn.collectAsStateWithLifecycle()
    val isSpeakerOn by viewModel.isSpeakerOn.collectAsStateWithLifecycle()
    val elapsedSeconds by viewModel.elapsedSeconds.collectAsStateWithLifecycle()
    val localAudioLevel by viewModel.localAudioLevel.collectAsStateWithLifecycle()
    val isBgServiceActive by viewModel.isBackgroundServiceActive.collectAsStateWithLifecycle()

    var hasMicPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
                PackageManager.PERMISSION_GRANTED
        )
    }
    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) ==
                PackageManager.PERMISSION_GRANTED
        )
    }

    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasMicPermission = granted
    }

    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasCameraPermission = granted
        if (granted) {
            viewModel.toggleCamera(context, true)
        } else {
            viewModel.setCameraEnabled(context, false)
        }
    }

    val callData = (uiState as? UiState.Success<CallRoomUiState>)?.data
    val call = callData?.call
    val isIncomingAwaitingAnswer = callData?.isIncomingAwaitingAnswer == true
    val isCallJoinedAndLive = call != null && call.status != "ended" && !isIncomingAwaitingAnswer

    BackHandler {
        if (!isIncomingAwaitingAnswer && onMinimizeCall != null) {
            // Minimizing keeps OngoingCallService running cleanly for gaming / multitasking
            onMinimizeCall()
        } else {
            viewModel.endOrLeaveCall(context, onCallClosed)
        }
    }

    LaunchedEffect(isCallJoinedAndLive, hasMicPermission, call?.id) {
        if (isCallJoinedAndLive) {
            if (!hasMicPermission) {
                runCatching { micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO) }
            } else {
                viewModel.attachOngoingCallService(context)
            }
        }
    }

    LaunchedEffect(call?.status) {
        if (call?.status == "ended") {
            delay(350L)
            onCallClosed()
        }
    }

    val accentColor = MaterialTheme.colorScheme.primary
    val secondaryGlow = MaterialTheme.colorScheme.secondary

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF0A1626),
                        Color(0xFF070D17),
                        Color(0xFF04070D)
                    )
                )
            )
    ) {
        // Ambient reactive upper aura glow
        Box(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .offset(y = (-80).dp)
                .size(340.dp)
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            accentColor.copy(alpha = 0.22f),
                            secondaryGlow.copy(alpha = 0.08f),
                            Color.Transparent
                        )
                    )
                )
        )

        if (isInPictureInPicture && callData != null && call != null) {
            PictureInPictureCallOverlay(
                callData = callData,
                currentUserId = currentUserId,
                elapsedSeconds = elapsedSeconds,
                isMuted = isMuted,
                localAudioLevel = localAudioLevel
            )
            return@Box
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
        ) {
            when (uiState) {
                is UiState.Loading -> {
                    Column(
                        modifier = Modifier.align(Alignment.Center),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        CircularProgressIndicator(color = accentColor)
                        Text(
                            text = "Подключение к защищённому каналу...",
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color.White.copy(alpha = 0.8f)
                        )
                    }
                }

                is UiState.Error -> {
                    Text(
                        text = (uiState as UiState.Error).message,
                        color = MaterialTheme.colorScheme.error,
                        modifier = Modifier
                            .align(Alignment.Center)
                            .padding(24.dp)
                    )
                }

                is UiState.Success -> {
                    val data = callData ?: CallRoomUiState(null, emptyList())
                    AnimatedContent(
                        targetState = data.isIncomingAwaitingAnswer,
                        transitionSpec = {
                            fadeIn(tween(260)) togetherWith fadeOut(tween(220))
                        },
                        label = "call_stage_transition"
                    ) { awaitingAnswer ->
                        if (awaitingAnswer && data.call != null) {
                            IncomingRingingStage(
                                call = data.call,
                                callerAvatarBase64 = data.participantAvatars[data.call.callerId].orEmpty(),
                                callerDisplayName = data.participantNames[data.call.callerId]
                                    ?.ifBlank { null }
                                    ?: data.call.callerName.ifBlank { "Абонент SpoX" },
                                onDecline = {
                                    SpoXNotificationHelper.cancelCallNotification(
                                        context.applicationContext,
                                        data.call.id
                                    )
                                    viewModel.endOrLeaveCall(context, onCallClosed)
                                },
                                onAnswer = {
                                    SpoXNotificationHelper.cancelCallNotification(
                                        context.applicationContext,
                                        data.call.id
                                    )
                                    viewModel.acceptIncomingCall()
                                }
                            )
                        } else {
                            ActiveCallStage(
                                callData = data,
                                currentUserId = currentUserId,
                                elapsedSeconds = elapsedSeconds,
                                hasMicPermission = hasMicPermission,
                                hasCameraPermission = hasCameraPermission,
                                isMuted = isMuted,
                                isCameraOn = isCameraOn,
                                isSpeakerOn = isSpeakerOn,
                                isBackgroundOptimized = isBgServiceActive,
                                localAudioLevel = localAudioLevel,
                                onMinimize = onMinimizeCall,
                                onRequestMicPermission = {
                                    micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                },
                                onToggleMute = { viewModel.toggleMute(context) },
                                onToggleCamera = {
                                    if (hasCameraPermission) {
                                        viewModel.toggleCamera(context, true)
                                    } else {
                                        cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                                    }
                                },
                                onToggleSpeaker = { viewModel.toggleSpeaker(context) },
                                onEndCall = {
                                    data.call?.id?.let { id ->
                                        SpoXNotificationHelper.cancelCallNotification(
                                            context.applicationContext,
                                            id
                                        )
                                    }
                                    viewModel.endOrLeaveCall(context, onCallClosed)
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PictureInPictureCallOverlay(
    callData: CallRoomUiState,
    currentUserId: String,
    elapsedSeconds: Long,
    isMuted: Boolean,
    localAudioLevel: Int
) {
    val call = callData.call ?: return
    val peer = callData.participants.firstOrNull { it.userId != currentUserId }
    val peerUid = peer?.userId ?: call.memberUids.firstOrNull { it != currentUserId }.orEmpty()
    val peerName = callData.participantNames[peerUid]?.ifBlank { null }
        ?: peer?.displayName?.ifBlank { null }
        ?: call.conversationTitle.ifBlank { "Звонок" }
    val peerAvatar = callData.participantAvatars[peerUid].orEmpty()
    val peerSpeaking = peer != null && !peer.isMuted && peer.audioLevel >= 14

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Surface(
            shape = CircleShape,
            color = Color.White.copy(alpha = 0.08f),
            border = BorderStroke(
                width = if (peerSpeaking) 2.5.dp else 1.5.dp,
                color = if (peerSpeaking) Color(0xFF34D399) else MaterialTheme.colorScheme.primary
            ),
            modifier = Modifier.size(56.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                UserAvatar(
                    name = peerName,
                    avatarBase64 = peerAvatar,
                    size = 50.dp
                )
            }
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = peerName,
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.SemiBold,
            color = Color.White,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Text(
            text = if (isMuted) "Мик. выкл • ${formatCallTimer(elapsedSeconds)}" else formatCallTimer(elapsedSeconds),
            style = MaterialTheme.typography.labelSmall,
            color = if (localAudioLevel >= 14 && !isMuted) Color(0xFF34D399) else Color(0xFF6EE7B7)
        )
    }
}

@Composable
private fun IncomingRingingStage(
    call: CallSession,
    callerAvatarBase64: String,
    callerDisplayName: String,
    onDecline: () -> Unit,
    onAnswer: () -> Unit
) {
    val isResourceSaving = com.example.ui.theme.LocalChatAppearance.current.resourceSavingMode
    val ring1Scale: Float
    val ring1Alpha: Float
    val ring2Scale: Float
    val ring2Alpha: Float
    val answerPulse: Float
    if (isResourceSaving) {
        ring1Scale = 1.16f
        ring1Alpha = 0.22f
        ring2Scale = 1f
        ring2Alpha = 0f
        answerPulse = 1f
    } else {
        val infiniteTransition = rememberInfiniteTransition(label = "incoming_ring_pulse")
        val aRing1Scale by infiniteTransition.animateFloat(
            initialValue = 1.0f,
            targetValue = 1.48f,
            animationSpec = infiniteRepeatable(
                animation = tween(1800, easing = FastOutSlowInEasing),
                repeatMode = RepeatMode.Restart
            ),
            label = "ring1_scale"
        )
        val aRing1Alpha by infiniteTransition.animateFloat(
            initialValue = 0.45f,
            targetValue = 0f,
            animationSpec = infiniteRepeatable(
                animation = tween(1800, easing = LinearEasing),
                repeatMode = RepeatMode.Restart
            ),
            label = "ring1_alpha"
        )
        val aRing2Scale by infiniteTransition.animateFloat(
            initialValue = 1.0f,
            targetValue = 1.48f,
            animationSpec = infiniteRepeatable(
                animation = tween(1800, delayMillis = 650, easing = FastOutSlowInEasing),
                repeatMode = RepeatMode.Restart
            ),
            label = "ring2_scale"
        )
        val aRing2Alpha by infiniteTransition.animateFloat(
            initialValue = 0.35f,
            targetValue = 0f,
            animationSpec = infiniteRepeatable(
                animation = tween(1800, delayMillis = 650, easing = LinearEasing),
                repeatMode = RepeatMode.Restart
            ),
            label = "ring2_alpha"
        )

        val aAnswerPulse by infiniteTransition.animateFloat(
            initialValue = 1.0f,
            targetValue = 1.08f,
            animationSpec = infiniteRepeatable(
                animation = tween(900, easing = FastOutSlowInEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "answer_pulse"
        )
        ring1Scale = aRing1Scale
        ring1Alpha = aRing1Alpha
        ring2Scale = aRing2Scale
        ring2Alpha = aRing2Alpha
        answerPulse = aAnswerPulse
    }

    val isVideo = call.callType == "video"
    val callKindLabel = when {
        call.isGroupCall && isVideo -> "Входящий групповой видеозвонок"
        call.isGroupCall -> "Входящий групповой звонок"
        isVideo -> "Входящий видеозвонок"
        else -> "Входящий аудиозвонок"
    }

    val glassActive = isLiquidGlassActive()
    Column(
        modifier = Modifier
            .fillMaxSize()
            .widthIn(max = 560.dp)
            .padding(horizontal = 24.dp, vertical = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            val pillShape = RoundedCornerShape(50)
            Surface(
                shape = pillShape,
                color = if (glassActive) Color.Transparent else Color.White.copy(alpha = 0.08f),
                border = if (glassActive) null else BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.38f)),
                modifier = if (glassActive) {
                    Modifier.liquidGlassSurface(
                        shape = pillShape,
                        tintColor = Color(0xFF101928),
                        accentGlow = MaterialTheme.colorScheme.primary,
                        tintAlpha = 0.42f
                    )
                } else {
                    Modifier
                }
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Filled.Shield,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "SpoX • Зашифровано E2EE",
                        style = MaterialTheme.typography.labelMedium,
                        color = Color.White
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Surface(
                shape = RoundedCornerShape(50),
                color = Color(0xFF10B981).copy(alpha = 0.16f),
                border = BorderStroke(1.dp, Color(0xFF10B981).copy(alpha = 0.45f))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = if (isVideo) Icons.Filled.Videocam else Icons.Filled.Call,
                        contentDescription = null,
                        tint = Color(0xFF34D399),
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = callKindLabel,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFF6EE7B7),
                        modifier = Modifier.testTag("call_status_text")
                    )
                }
            }
        }

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier.size(210.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(132.dp)
                        .scale(ring1Scale)
                        .alpha(ring1Alpha)
                        .border(2.dp, MaterialTheme.colorScheme.primary, CircleShape)
                )
                Box(
                    modifier = Modifier
                        .size(132.dp)
                        .scale(ring2Scale)
                        .alpha(ring2Alpha)
                        .border(2.dp, Color(0xFF34D399), CircleShape)
                )
                Surface(
                    shape = CircleShape,
                    color = Color.White.copy(alpha = 0.08f),
                    border = BorderStroke(2.dp, Color.White.copy(alpha = 0.25f)),
                    modifier = Modifier.size(132.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        UserAvatar(
                            name = callerDisplayName,
                            avatarBase64 = callerAvatarBase64,
                            size = 122.dp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            Text(
                text = callerDisplayName,
                style = MaterialTheme.typography.headlineLarge,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                textAlign = TextAlign.Center,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )

            if (call.isGroupCall && call.conversationTitle.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Чат: ${call.conversationTitle}",
                    style = MaterialTheme.typography.titleMedium,
                    color = Color.White.copy(alpha = 0.72f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Ожидает вашего ответа...",
                style = MaterialTheme.typography.bodyMedium,
                color = Color.White.copy(alpha = 0.65f)
            )
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 18.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                IconButton(
                    onClick = onDecline,
                    colors = IconButtonDefaults.iconButtonColors(
                        containerColor = Color(0xFFE11D48),
                        contentColor = Color.White
                    ),
                    modifier = Modifier
                        .size(76.dp)
                        .testTag("call_decline_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.CallEnd,
                        contentDescription = "Отклонить звонок",
                        modifier = Modifier.size(32.dp)
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "Отклонить",
                    style = MaterialTheme.typography.labelLarge,
                    color = Color.White.copy(alpha = 0.88f)
                )
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Box(contentAlignment = Alignment.Center) {
                    Box(
                        modifier = Modifier
                            .size(86.dp)
                            .scale(answerPulse)
                            .background(Color(0xFF10B981).copy(alpha = 0.24f), CircleShape)
                    )
                    IconButton(
                        onClick = onAnswer,
                        colors = IconButtonDefaults.iconButtonColors(
                            containerColor = Color(0xFF10B981),
                            contentColor = Color.White
                        ),
                        modifier = Modifier
                            .size(76.dp)
                            .testTag("call_answer_button")
                    ) {
                        Icon(
                            imageVector = if (isVideo) Icons.Filled.Videocam else Icons.Filled.Call,
                            contentDescription = "Ответить на звонок",
                            modifier = Modifier.size(32.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "Ответить",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.SemiBold,
                    color = Color(0xFF6EE7B7)
                )
            }
        }
    }
}

@Composable
private fun ActiveCallStage(
    callData: CallRoomUiState,
    currentUserId: String,
    elapsedSeconds: Long,
    hasMicPermission: Boolean,
    hasCameraPermission: Boolean,
    isMuted: Boolean,
    isCameraOn: Boolean,
    isSpeakerOn: Boolean,
    isBackgroundOptimized: Boolean,
    localAudioLevel: Int,
    onMinimize: (() -> Unit)?,
    onRequestMicPermission: () -> Unit,
    onToggleMute: () -> Unit,
    onToggleCamera: () -> Unit,
    onToggleSpeaker: () -> Unit,
    onEndCall: () -> Unit
) {
    val call = callData.call
    val participants = callData.participants
    val isOneOnOneLayout = call?.isGroupCall != true && participants.size <= 2
    val glassActive = isLiquidGlassActive()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .widthIn(max = 680.dp)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Top header bar with Minimize (Background/Game Mode) & E2EE pill
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            if (onMinimize != null) {
                val minPillShape = RoundedCornerShape(50)
                Surface(
                    shape = minPillShape,
                    color = if (glassActive) Color.Transparent else Color.White.copy(alpha = 0.08f),
                    border = if (glassActive) null else BorderStroke(1.dp, Color.White.copy(alpha = 0.16f)),
                    modifier = Modifier
                        .then(
                            if (glassActive) {
                                Modifier.liquidGlassSurface(
                                    shape = minPillShape,
                                    tintColor = Color(0xFF101928),
                                    tintAlpha = 0.42f
                                )
                            } else {
                                Modifier
                            }
                        )
                        .clickable(onClick = onMinimize)
                        .testTag("call_minimize_button")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Filled.KeyboardArrowDown,
                            contentDescription = "Свернуть звонок в фоновый режим",
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Свернуть",
                            style = MaterialTheme.typography.labelMedium,
                            color = Color.White
                        )
                    }
                }
            } else {
                Spacer(modifier = Modifier.width(12.dp))
            }

            val e2eePillShape = RoundedCornerShape(50)
            Surface(
                shape = e2eePillShape,
                color = if (glassActive) Color.Transparent else Color.White.copy(alpha = 0.08f),
                border = if (glassActive) null else BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.35f)),
                modifier = if (glassActive) {
                    Modifier.liquidGlassSurface(
                        shape = e2eePillShape,
                        tintColor = Color(0xFF101928),
                        accentGlow = MaterialTheme.colorScheme.primary,
                        tintAlpha = 0.42f
                    )
                } else {
                    Modifier
                }
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Filled.Lock,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(5.dp))
                    Text(
                        text = if (call?.isGroupCall == true) "Группа E2EE" else "Звонок E2EE",
                        style = MaterialTheme.typography.labelMedium,
                        color = Color.White
                    )
                    if (isBackgroundOptimized) {
                        Spacer(modifier = Modifier.width(7.dp))
                        Box(
                            modifier = Modifier
                                .size(7.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF34D399))
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Фон OK",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF6EE7B7)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.width(12.dp))
        }

        Spacer(modifier = Modifier.height(12.dp))

        Text(
            text = call?.conversationTitle?.ifBlank { "Звонок" } ?: "Звонок",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            color = Color.White,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )

        Spacer(modifier = Modifier.height(6.dp))

        val statusText = when (call?.status) {
            "ringing" -> "Вызов... (${participants.size} в комнате)"
            "active" -> "Идёт разговор • ${formatCallTimer(elapsedSeconds)}"
            "ended" -> "Звонок завершён"
            else -> "Подключение..."
        }
        Surface(
            shape = RoundedCornerShape(50),
            color = if (call?.status == "active") {
                Color(0xFF10B981).copy(alpha = 0.14f)
            } else {
                MaterialTheme.colorScheme.primary.copy(alpha = 0.14f)
            }
        ) {
            Text(
                text = statusText,
                style = MaterialTheme.typography.labelLarge,
                color = if (call?.status == "active") Color(0xFF6EE7B7) else MaterialTheme.colorScheme.primary,
                modifier = Modifier
                    .padding(horizontal = 12.dp, vertical = 4.dp)
                    .testTag("call_status_text")
            )
        }

        if (!hasMicPermission) {
            Spacer(modifier = Modifier.height(10.dp))
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = Color(0xFFFB7185).copy(alpha = 0.22f),
                border = BorderStroke(1.dp, Color(0xFFFB7185).copy(alpha = 0.65f)),
                modifier = Modifier
                    .clickable(onClick = onRequestMicPermission)
                    .testTag("grant_call_mic_permission")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Filled.MicOff,
                        contentDescription = null,
                        tint = Color(0xFFFDA4AF),
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Собеседник вас не слышит — нажмите, чтобы разрешить микрофон",
                        style = MaterialTheme.typography.labelMedium,
                        color = Color.White
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        if (isOneOnOneLayout) {
            OneOnOneCallStage(
                call = call,
                participants = participants,
                callData = callData,
                currentUserId = currentUserId,
                isLocalMuted = isMuted,
                localCameraActive = isCameraOn && hasCameraPermission,
                localAudioLevel = localAudioLevel,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            )
        } else {
            val columns = when {
                participants.size <= 1 -> 1
                participants.size <= 4 -> 2
                else -> 3
            }
            LazyVerticalGrid(
                columns = GridCells.Fixed(columns),
                contentPadding = PaddingValues(4.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                items(participants, key = { it.userId }) { participant ->
                    val isMe = participant.userId == currentUserId
                    val avatarB64 = callData.participantAvatars[participant.userId].orEmpty()
                    val liveName = callData.participantNames[participant.userId]?.ifBlank { null }
                        ?: participant.displayName
                    ParticipantCallTile(
                        participant = participant.copy(displayName = liveName),
                        avatarBase64 = avatarB64,
                        isLocalUser = isMe,
                        localCameraActive = isMe && isCameraOn && hasCameraPermission,
                        audioLevel = if (isMe) localAudioLevel else participant.audioLevel.toInt(),
                        isGroupCall = true
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        val dockShape = RoundedCornerShape(30.dp)
        Surface(
            shape = dockShape,
            color = if (glassActive) Color.Transparent else Color(0xFF101928).copy(alpha = 0.92f),
            border = if (glassActive) null else BorderStroke(1.dp, Color.White.copy(alpha = 0.12f)),
            modifier = if (glassActive) {
                Modifier.liquidGlassSurface(
                    shape = dockShape,
                    tintColor = Color(0xFF0E1A2D),
                    isHighlighted = true,
                    tintAlpha = 0.50f
                )
            } else {
                Modifier
            }
        ) {
            Row(
                modifier = Modifier
                    .padding(horizontal = 18.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(18.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                DockActionButton(
                    icon = if (isMuted) Icons.Filled.MicOff else Icons.Filled.Mic,
                    label = if (isMuted) "Без звука" else "Микрофон",
                    contentDescription = if (isMuted) "Включить микрофон" else "Выключить микрофон",
                    containerColor = if (isMuted) Color.White else Color.White.copy(alpha = 0.12f),
                    contentColor = if (isMuted) Color(0xFF0F172A) else Color.White,
                    testTag = "call_mute_button",
                    onClick = onToggleMute
                )

                DockActionButton(
                    icon = if (isCameraOn && hasCameraPermission) Icons.Filled.Videocam else Icons.Filled.VideocamOff,
                    label = "Камера",
                    contentDescription = "Камера",
                    containerColor = if (isCameraOn && hasCameraPermission) {
                        MaterialTheme.colorScheme.primary
                    } else {
                        Color.White.copy(alpha = 0.12f)
                    },
                    contentColor = if (isCameraOn && hasCameraPermission) {
                        MaterialTheme.colorScheme.onPrimary
                    } else {
                        Color.White
                    },
                    testTag = "call_camera_button",
                    onClick = onToggleCamera
                )

                DockActionButton(
                    icon = if (isSpeakerOn) {
                        Icons.AutoMirrored.Filled.VolumeUp
                    } else {
                        Icons.AutoMirrored.Filled.VolumeDown
                    },
                    label = if (isSpeakerOn) "Динамик" else "Гарнитура",
                    contentDescription = "Громкая связь",
                    containerColor = if (isSpeakerOn) Color.White else Color.White.copy(alpha = 0.12f),
                    contentColor = if (isSpeakerOn) Color(0xFF0F172A) else Color.White,
                    testTag = "call_speaker_button",
                    onClick = onToggleSpeaker
                )

                DockActionButton(
                    icon = Icons.Filled.CallEnd,
                    label = "Сбросить",
                    contentDescription = "Завершить звонок",
                    containerColor = Color(0xFFE11D48),
                    contentColor = Color.White,
                    buttonSize = 58.dp,
                    testTag = "call_end_button",
                    onClick = onEndCall
                )
            }
        }
        Spacer(modifier = Modifier.height(6.dp))
    }
}

@Composable
private fun OneOnOneCallStage(
    call: CallSession?,
    participants: List<CallParticipant>,
    callData: CallRoomUiState,
    currentUserId: String,
    isLocalMuted: Boolean,
    localCameraActive: Boolean,
    localAudioLevel: Int,
    modifier: Modifier = Modifier
) {
    val peerParticipant = participants.firstOrNull { it.userId != currentUserId }
    val localParticipant = participants.firstOrNull { it.userId == currentUserId }

    val peerUid = peerParticipant?.userId
        ?: call?.memberUids?.firstOrNull { it != currentUserId }.orEmpty()
    val peerName = peerParticipant?.userId?.let { callData.participantNames[it]?.ifBlank { null } }
        ?: peerParticipant?.displayName?.ifBlank { null }
        ?: callData.participantNames[peerUid]?.ifBlank { null }
        ?: call?.conversationTitle?.ifBlank { null }
        ?: "Собеседник"
    val peerAvatar = callData.participantAvatars[peerUid].orEmpty()
    val peerLevel = peerParticipant?.audioLevel?.toInt() ?: 0
    val peerMuted = peerParticipant?.isMuted == true
    val peerSpeaking = peerParticipant != null && !peerMuted && peerLevel >= 14

    val speakingScale by animateFloatAsState(
        targetValue = if (peerSpeaking) (1.06f + (peerLevel / 100f) * 0.14f) else 1f,
        animationSpec = tween(220),
        label = "peer_speaking_scale"
    )

    val glassActive = isLiquidGlassActive()
    val stageShape = RoundedCornerShape(28.dp)
    Surface(
        shape = stageShape,
        color = if (glassActive) Color.Transparent else Color(0xFF0F1929),
        border = if (glassActive) null else BorderStroke(
            width = if (peerSpeaking) 2.dp else 1.dp,
            color = if (peerSpeaking) MaterialTheme.colorScheme.primary else Color.White.copy(alpha = 0.12f)
        ),
        modifier = modifier.then(
            if (glassActive) {
                Modifier.liquidGlassSurface(
                    shape = stageShape,
                    tintColor = Color(0xFF0F1929),
                    isHighlighted = peerSpeaking,
                    tintAlpha = 0.48f
                )
            } else {
                Modifier
            }
        )
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            Box(
                modifier = Modifier
                    .align(Alignment.Center)
                    .size(260.dp)
                    .scale(speakingScale)
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                if (peerSpeaking) {
                                    MaterialTheme.colorScheme.primary.copy(alpha = 0.24f)
                                } else {
                                    Color.White.copy(alpha = 0.05f)
                                },
                                Color.Transparent
                            )
                        )
                    )
            )

            Column(
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(horizontal = 20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(contentAlignment = Alignment.Center) {
                    if (peerSpeaking) {
                        Box(
                            modifier = Modifier
                                .size(134.dp)
                                .scale(speakingScale)
                                .border(2.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.6f), CircleShape)
                        )
                    }
                    Surface(
                        shape = CircleShape,
                        color = Color.White.copy(alpha = 0.08f),
                        border = BorderStroke(2.dp, Color.White.copy(alpha = 0.18f)),
                        modifier = Modifier.size(120.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            UserAvatar(
                                name = peerName,
                                avatarBase64 = peerAvatar,
                                size = 110.dp
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = peerName,
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.SemiBold,
                    color = Color.White,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(8.dp))

                when {
                    peerParticipant == null -> {
                        Text(
                            text = if (call?.status == "ringing") "Гудки... Ожидание собеседника" else "Подключение...",
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color.White.copy(alpha = 0.68f)
                        )
                    }
                    peerMuted -> {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Filled.MicOff,
                                contentDescription = "Микрофон собеседника выключен",
                                tint = Color(0xFFFB7185),
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Микрофон выключен",
                                style = MaterialTheme.typography.labelMedium,
                                color = Color(0xFFFDA4AF)
                            )
                        }
                    }
                    else -> {
                        AudioEqualizerBars(
                            level = peerLevel,
                            activeColor = MaterialTheme.colorScheme.primary
                        )
                    }
                }

                if (peerParticipant?.isCameraOn == true) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Surface(
                        shape = RoundedCornerShape(50),
                        color = MaterialTheme.colorScheme.secondary.copy(alpha = 0.18f)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                Icons.Filled.Videocam,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.secondary,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Камера включена",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.secondary
                            )
                        }
                    }
                }
            }

            val localDisplayName = localParticipant?.userId?.let { callData.participantNames[it]?.ifBlank { null } }
                ?: localParticipant?.displayName
                ?: "Вы"
            val localAvatar = callData.participantAvatars[currentUserId].orEmpty()

            Surface(
                shape = RoundedCornerShape(20.dp),
                color = Color(0xFF172438),
                border = BorderStroke(
                    width = if (!isLocalMuted && localAudioLevel >= 16) 2.dp else 1.dp,
                    color = if (!isLocalMuted && localAudioLevel >= 16) {
                        Color(0xFF34D399)
                    } else {
                        Color.White.copy(alpha = 0.2f)
                    }
                ),
                shadowElevation = 6.dp,
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(14.dp)
                    .width(108.dp)
                    .height(148.dp)
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    if (localCameraActive) {
                        CameraPreviewBox(modifier = Modifier.fillMaxSize())
                    } else {
                        Column(
                            modifier = Modifier.align(Alignment.Center),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            UserAvatar(
                                name = localDisplayName,
                                avatarBase64 = localAvatar,
                                size = 54.dp
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            AudioEqualizerBars(
                                level = if (isLocalMuted) 0 else localAudioLevel,
                                activeColor = Color(0xFF34D399),
                                compact = true
                            )
                        }
                    }

                    Surface(
                        shape = RoundedCornerShape(50),
                        color = Color.Black.copy(alpha = 0.58f),
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(bottom = 8.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Вы",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.SemiBold,
                                color = Color.White
                            )
                            if (isLocalMuted) {
                                Spacer(modifier = Modifier.width(4.dp))
                                Icon(
                                    imageVector = Icons.Filled.MicOff,
                                    contentDescription = "Ваш микрофон выключен",
                                    tint = Color(0xFFFB7185),
                                    modifier = Modifier.size(11.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DockActionButton(
    icon: ImageVector,
    label: String,
    contentDescription: String,
    containerColor: Color,
    contentColor: Color,
    testTag: String,
    buttonSize: androidx.compose.ui.unit.Dp = 54.dp,
    onClick: () -> Unit
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        IconButton(
            onClick = onClick,
            colors = IconButtonDefaults.iconButtonColors(
                containerColor = containerColor,
                contentColor = contentColor
            ),
            modifier = Modifier
                .size(buttonSize)
                .testTag(testTag)
        ) {
            Icon(imageVector = icon, contentDescription = contentDescription)
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = Color.White.copy(alpha = 0.78f),
            maxLines = 1
        )
    }
}

@Composable
private fun AudioEqualizerBars(
    level: Int,
    activeColor: Color,
    compact: Boolean = false
) {
    val clamped = level.coerceIn(0, 100) / 100f
    val weights = listOf(0.45f, 0.78f, 1.0f, 0.72f, 0.42f)
    val maxHeight = if (compact) 14f else 22f
    val minHeight = if (compact) 4f else 5f
    val barWidth = if (compact) 3.dp else 4.dp

    Row(
        horizontalArrangement = Arrangement.spacedBy(if (compact) 3.dp else 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.height((maxHeight + 2).dp)
    ) {
        weights.forEach { weight ->
            val targetH = (minHeight + (maxHeight - minHeight) * clamped * weight).dp
            val animH by animateDpAsState(targetValue = targetH, label = "eq_bar")
            Box(
                modifier = Modifier
                    .width(barWidth)
                    .height(animH)
                    .clip(RoundedCornerShape(50))
                    .background(
                        if (clamped > 0.1f) activeColor else Color.White.copy(alpha = 0.25f)
                    )
            )
        }
    }
}

@Composable
private fun ParticipantCallTile(
    participant: CallParticipant,
    avatarBase64: String,
    isLocalUser: Boolean,
    localCameraActive: Boolean,
    audioLevel: Int,
    isGroupCall: Boolean
) {
    val activeSpeaking = !participant.isMuted && audioLevel >= 16
    val ringSize by animateDpAsState(
        targetValue = if (activeSpeaking) 3.dp else 1.dp,
        label = "speaking_ring"
    )

    val glassActive = isLiquidGlassActive()
    val tileShape = RoundedCornerShape(24.dp)
    Surface(
        shape = tileShape,
        color = if (glassActive) Color.Transparent else Color(0xFF131E30),
        border = if (glassActive) null else BorderStroke(
            width = ringSize,
            color = if (activeSpeaking) MaterialTheme.colorScheme.primary else Color.White.copy(alpha = 0.12f)
        ),
        modifier = Modifier
            .fillMaxWidth()
            .height(if (isGroupCall) 204.dp else 320.dp)
            .then(
                if (glassActive) {
                    Modifier.liquidGlassSurface(
                        shape = tileShape,
                        tintColor = Color(0xFF131E30),
                        isHighlighted = activeSpeaking,
                        tintAlpha = 0.48f
                    )
                } else {
                    Modifier
                }
            )
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            if (localCameraActive) {
                CameraPreviewBox(modifier = Modifier.fillMaxSize())
            } else {
                Column(
                    modifier = Modifier.align(Alignment.Center),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    UserAvatar(
                        name = participant.displayName,
                        avatarBase64 = avatarBase64,
                        size = if (isGroupCall) 68.dp else 96.dp
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    if (!participant.isMuted) {
                        AudioEqualizerBars(
                            level = audioLevel,
                            activeColor = MaterialTheme.colorScheme.primary,
                            compact = true
                        )
                    }
                    if (participant.isCameraOn && !isLocalUser) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Filled.Groups,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.secondary,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Видео включено",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.secondary
                            )
                        }
                    }
                }
            }

            Surface(
                shape = RoundedCornerShape(50),
                color = Color.Black.copy(alpha = 0.55f),
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(12.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (isLocalUser) "${participant.displayName} (Вы)" else participant.displayName,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Medium,
                        color = Color.White,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (participant.isMuted) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Icon(
                            imageVector = Icons.Filled.MicOff,
                            contentDescription = "Микрофон выключен",
                            tint = Color(0xFFFB7185),
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun CameraPreviewBox(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val previewView = remember { PreviewView(context) }

    DisposableEffect(lifecycleOwner) {
        val providerFuture = ProcessCameraProvider.getInstance(context)
        val executor = ContextCompat.getMainExecutor(context)
        providerFuture.addListener({
            runCatching {
                val cameraProvider = providerFuture.get()
                val preview = Preview.Builder().build().also {
                    it.surfaceProvider = previewView.surfaceProvider
                }
                cameraProvider.unbindAll()
                cameraProvider.bindToLifecycle(
                    lifecycleOwner,
                    CameraSelector.DEFAULT_FRONT_CAMERA,
                    preview
                )
            }
        }, executor)

        onDispose {
            runCatching { providerFuture.get().unbindAll() }
        }
    }

    AndroidView(
        factory = { previewView },
        modifier = modifier.clip(RoundedCornerShape(20.dp))
    )
}

private fun formatCallTimer(totalSeconds: Long): String {
    val mins = totalSeconds / 60L
    val secs = totalSeconds % 60L
    return "%02d:%02d".format(mins, secs)
}
