package com.example.media

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Base64
import androidx.core.content.FileProvider
import java.io.ByteArrayOutputStream
import java.io.File
import kotlin.math.max
import kotlin.math.min

enum class MediaKind(val label: String) {
    PHOTO("Фото"),
    VIDEO("Видео"),
    AUDIO("Музыка"),
    FILE("Файл"),
    VOICE("Голосовое")
}

data class PreparedAttachment(
    val fileName: String,
    val mimeType: String,
    val bytes: ByteArray = ByteArray(0),
    val isImage: Boolean,
    val mediaKind: MediaKind = if (isImage) MediaKind.PHOTO else MediaKind.FILE,
    val stagedFile: File? = null,
    val sizeBytes: Long = bytes.size.toLong()
) {
    val isChunked: Boolean
        get() = stagedFile != null
}

object FileAttachmentHelper {
    const val MAX_RAW_BYTES = 600 * 1024 // Single-doc E2EE limit
    const val MAX_MEDIA_UPLOAD_BYTES = 25L * 1024L * 1024L // 25 MB for video & audio
    const val MAX_DOC_UPLOAD_BYTES = 10L * 1024L * 1024L // 10 MB for general files
    const val MEDIA_CHUNK_SIZE_BYTES = 480 * 1024 // ~640 KB Base64 per Firestore chunk
    const val MAX_AVATAR_BASE64_LENGTH = 110_000

    val SUPPORTED_VIDEO_EXTENSIONS = setOf(
        "mp4", "m4v", "mkv", "mov", "webm", "avi", "3gp", "3g2",
        "ts", "m2ts", "mts", "flv", "f4v", "wmv", "vob", "ogv", "mpg", "mpeg", "divx", "asf", "rmvb"
    )

    val SUPPORTED_AUDIO_EXTENSIONS = setOf(
        "mp3", "wav", "ogg", "oga", "m4a", "flac", "aac", "opus",
        "amr", "awb", "mka", "aiff", "aif", "wma", "ac3", "eac3", "alac", "mid", "midi"
    )

    val SUPPORTED_VIDEO_BADGES = listOf("MP4", "MKV", "WEBM", "MOV", "AVI", "FLV", "TS", "3GP", "M4V", "OGV", "MPG")
    val SUPPORTED_AUDIO_BADGES = listOf("MP3", "FLAC", "OPUS", "OGG", "M4A", "WAV", "AAC", "AMR", "MKA")

    fun classifyMediaKind(mimeType: String, fileName: String): MediaKind {
        val lowerMime = mimeType.lowercase()
        val ext = fileName.trim().substringAfterLast('.', "").lowercase()
        return when {
            lowerMime.startsWith("image/") || ext in setOf("jpg", "jpeg", "png", "webp", "gif", "heic", "avif", "bmp") -> MediaKind.PHOTO
            lowerMime.startsWith("video/") ||
                lowerMime == "application/x-matroska" ||
                ext in SUPPORTED_VIDEO_EXTENSIONS -> MediaKind.VIDEO
            lowerMime.startsWith("audio/") ||
                lowerMime == "application/ogg" ||
                ext in SUPPORTED_AUDIO_EXTENSIONS -> MediaKind.AUDIO
            else -> MediaKind.FILE
        }
    }

    fun formatBadge(fileName: String, mimeType: String = ""): String {
        val trimmed = fileName.trim()
        val dotIndex = trimmed.lastIndexOf('.')
        if (dotIndex in 0 until trimmed.lastIndex) {
            val cleanExt = trimmed.substring(dotIndex + 1).trim().uppercase()
            if (cleanExt.length in 1..5 && cleanExt.all { it.isLetterOrDigit() }) {
                return cleanExt
            }
        }
        val sub = mimeType.substringAfter('/', "").substringBefore(';').trim().uppercase()
        return when {
            sub == "X-MATROSKA" -> "MKV"
            sub == "QUICKTIME" -> "MOV"
            sub == "MPEG" -> "MP3"
            sub == "MP4" -> "MP4"
            sub.isNotBlank() && sub != "OCTET-STREAM" -> sub.take(5)
            else -> "MEDIA"
        }
    }

    data class UriMetadata(
        val fileName: String,
        val mimeType: String,
        val sizeBytes: Long,
        val mediaKind: MediaKind
    )

    fun resolveUriMetadata(context: Context, uri: Uri): UriMetadata {
        val resolver = context.contentResolver
        val mimeType = resolver.getType(uri) ?: "application/octet-stream"
        var fileName = uri.lastPathSegment?.substringAfterLast('/') ?: "media_file"
        var sizeBytes = 0L
        runCatching {
            resolver.query(
                uri,
                arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE),
                null,
                null,
                null
            )?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (nameIdx >= 0) {
                        val name = cursor.getString(nameIdx)
                        if (!name.isNullOrBlank()) fileName = name
                    }
                    val sizeIdx = cursor.getColumnIndex(OpenableColumns.SIZE)
                    if (sizeIdx >= 0 && !cursor.isNull(sizeIdx)) {
                        sizeBytes = cursor.getLong(sizeIdx).coerceAtLeast(0L)
                    }
                }
            }
        }
        val kind = classifyMediaKind(mimeType, fileName)
        return UriMetadata(
            fileName = fileName,
            mimeType = mimeType,
            sizeBytes = sizeBytes,
            mediaKind = kind
        )
    }

    fun prepareAvatarBase64(context: Context, uri: Uri): Result<String> {
        return runCatching {
            val resolver = context.contentResolver
            val rawBytes = resolver.openInputStream(uri)?.use { it.readBytes() }
                ?: error("Не удалось прочитать выбранное изображение")
            val original = BitmapFactory.decodeByteArray(rawBytes, 0, rawBytes.size)
                ?: error("Выбранный файл не является изображением")

            val side = min(original.width, original.height).coerceAtLeast(1)
            val cropX = ((original.width - side) / 2).coerceAtLeast(0)
            val cropY = ((original.height - side) / 2).coerceAtLeast(0)
            val squareBitmap = if (original.width == original.height) {
                original
            } else {
                Bitmap.createBitmap(original, cropX, cropY, side, side)
            }
            val targetSize = 256
            val scaledBitmap = if (squareBitmap.width != targetSize || squareBitmap.height != targetSize) {
                Bitmap.createScaledBitmap(squareBitmap, targetSize, targetSize, true)
            } else {
                squareBitmap
            }

            var quality = 82
            var encoded: String
            do {
                val baos = ByteArrayOutputStream()
                scaledBitmap.compress(Bitmap.CompressFormat.JPEG, quality, baos)
                encoded = Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP)
                quality -= 10
            } while (encoded.length > MAX_AVATAR_BASE64_LENGTH && quality >= 30)

            if (scaledBitmap != squareBitmap) scaledBitmap.recycle()
            if (squareBitmap != original) squareBitmap.recycle()
            original.recycle()

            if (encoded.length > MAX_AVATAR_BASE64_LENGTH) {
                error("Изображение слишком большое для аватара")
            }
            encoded
        }
    }

    fun maxAllowedUploadBytes(kind: MediaKind): Long = when (kind) {
        MediaKind.VIDEO, MediaKind.AUDIO, MediaKind.VOICE -> MAX_MEDIA_UPLOAD_BYTES
        MediaKind.PHOTO -> MAX_RAW_BYTES.toLong()
        MediaKind.FILE -> MAX_DOC_UPLOAD_BYTES
    }

    fun readAndPrepareUri(context: Context, uri: Uri, forceImageCompression: Boolean): Result<PreparedAttachment> {
        return runCatching {
            val resolver = context.contentResolver
            val meta = resolveUriMetadata(context, uri)
            val mimeType = meta.mimeType
            val fileName = meta.fileName
            val isImage = forceImageCompression || mimeType.startsWith("image/")
            val kind = if (isImage) MediaKind.PHOTO else meta.mediaKind
            val maxLimit = maxAllowedUploadBytes(kind)

            if (isImage) {
                val rawBytes = resolver.openInputStream(uri)?.use { stream ->
                    readBoundedBytes(stream, 20L * 1024L * 1024L)
                } ?: error("Не удалось прочитать выбранное изображение")
                val compressed = compressImageIfNeeded(rawBytes)
                if (compressed.size > MAX_RAW_BYTES) {
                    error("Изображение слишком большое даже после сжатия (лимит 600 КБ)")
                }
                PreparedAttachment(
                    fileName = if (fileName.endsWith(".jpg", true) || fileName.endsWith(".jpeg", true)) {
                        fileName
                    } else {
                        "${fileName.substringBeforeLast('.')}.jpg"
                    },
                    mimeType = "image/jpeg",
                    bytes = compressed,
                    isImage = true,
                    mediaKind = MediaKind.PHOTO,
                    sizeBytes = compressed.size.toLong()
                )
            } else {
                if (isUnsafeExecutableFile(fileName, mimeType)) {
                    error("Отправка исполняемых файлов запрещена политикой безопасности")
                }
                if (meta.sizeBytes > maxLimit) {
                    error("Файл превышает лимит ${formatSize(maxLimit)} (${formatSize(meta.sizeBytes)})")
                }

                val stagingDir = File(context.cacheDir, "upload_staging").apply { mkdirs() }
                val safeName = fileName.replace(Regex("[^a-zA-Z0-9._\\-а-яА-ЯёЁ]"), "_")
                val stagingFile = File(stagingDir, "${System.currentTimeMillis()}_$safeName")

                var totalCopied = 0L
                val buffer = ByteArray(64 * 1024)
                val input = resolver.openInputStream(uri) ?: error("Не удалось прочитать выбранный файл")
                try {
                    input.use { inStream ->
                        stagingFile.outputStream().use { outStream ->
                            while (true) {
                                val read = inStream.read(buffer)
                                if (read <= 0) break
                                totalCopied += read
                                if (totalCopied > maxLimit) {
                                    error("Файл превышает лимит ${formatSize(maxLimit)} для защищённой передачи")
                                }
                                outStream.write(buffer, 0, read)
                            }
                        }
                    }
                } catch (t: Throwable) {
                    runCatching { stagingFile.delete() }
                    throw t
                }

                if (totalCopied <= MAX_RAW_BYTES) {
                    val bytes = stagingFile.readBytes()
                    runCatching { stagingFile.delete() }
                    PreparedAttachment(
                        fileName = fileName,
                        mimeType = mimeType,
                        bytes = bytes,
                        isImage = false,
                        mediaKind = kind,
                        stagedFile = null,
                        sizeBytes = bytes.size.toLong()
                    )
                } else {
                    PreparedAttachment(
                        fileName = fileName,
                        mimeType = mimeType,
                        bytes = ByteArray(0),
                        isImage = false,
                        mediaKind = kind,
                        stagedFile = stagingFile,
                        sizeBytes = totalCopied
                    )
                }
            }
        }
    }

    private fun readBoundedBytes(stream: java.io.InputStream, maxBytes: Long): ByteArray {
        val out = ByteArrayOutputStream()
        val buf = ByteArray(32 * 1024)
        var total = 0L
        while (true) {
            val read = stream.read(buf)
            if (read <= 0) break
            total += read
            if (total > maxBytes) {
                error("Файл слишком велик (более ${formatSize(maxBytes)})")
            }
            out.write(buf, 0, read)
        }
        return out.toByteArray()
    }

    private val BLOCKED_EXECUTABLE_EXTENSIONS = setOf(
        "apk", "apks", "xapk", "aab", "dex", "jar", "so",
        "exe", "msi", "bat", "cmd", "sh", "vbs", "ps1"
    )

    fun isUnsafeExecutableFile(fileName: String, mimeType: String): Boolean {
        val ext = fileName.trim().substringAfterLast('.', "").lowercase()
        val lowerMime = mimeType.trim().lowercase()
        return ext in BLOCKED_EXECUTABLE_EXTENSIONS ||
            lowerMime == "application/vnd.android.package-archive" ||
            lowerMime == "application/java-archive"
    }

    fun openDecryptedFile(context: Context, fileName: String, mimeType: String, bytes: ByteArray): Boolean {
        if (isUnsafeExecutableFile(fileName, mimeType)) return false
        return runCatching {
            val dir = File(context.cacheDir, "decrypted").apply { mkdirs() }
            val safeName = fileName.replace(Regex("[^a-zA-Z0-9._\\-а-яА-ЯёЁ]"), "_")
            val file = File(dir, safeName)
            file.writeBytes(bytes)
            val contentUri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(contentUri, mimeType)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(Intent.createChooser(intent, "Открыть файл"))
            true
        }.getOrDefault(false)
    }

    fun cacheDecryptedFile(context: Context, fileName: String, bytes: ByteArray): File? {
        return runCatching {
            val dir = File(context.cacheDir, "decrypted").apply { mkdirs() }
            val safeName = fileName.replace(Regex("[^a-zA-Z0-9._\\-а-яА-ЯёЁ]"), "_")
            File(dir, safeName).apply { writeBytes(bytes) }
        }.getOrNull()
    }

    fun writeDecryptedMediaToCache(
        context: Context,
        cacheKey: String,
        fileName: String,
        bytes: ByteArray
    ): File? {
        return runCatching {
            val file = mediaPlaybackCacheFile(context, cacheKey, fileName)
            if (!file.exists() || file.length() != bytes.size.toLong()) {
                file.writeBytes(bytes)
            }
            file
        }.getOrNull()
    }

    fun mediaPlaybackCacheFile(context: Context, cacheKey: String, fileName: String): File {
        val dir = File(context.cacheDir, "media_playback").apply { mkdirs() }
        val safeKey = cacheKey.replace(Regex("[^a-zA-Z0-9_-]"), "_").take(32).ifBlank { "media" }
        val safeName = fileName.replace(Regex("[^a-zA-Z0-9._\\-а-яА-ЯёЁ]"), "_")
        return File(dir, "${safeKey}_$safeName")
    }

    fun getCachedMediaFileIfReady(
        context: Context,
        cacheKey: String,
        fileName: String,
        expectedSizeBytes: Long
    ): File? {
        val file = mediaPlaybackCacheFile(context, cacheKey, fileName)
        return if (file.exists() && expectedSizeBytes > 0L && file.length() == expectedSizeBytes) {
            file
        } else {
            null
        }
    }

    fun openCachedFileWithSystem(context: Context, file: File, fileName: String, mimeType: String): Boolean {
        if (isUnsafeExecutableFile(fileName, mimeType)) return false
        return runCatching {
            val contentUri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(contentUri, mimeType)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(Intent.createChooser(intent, "Открыть файл"))
            true
        }.getOrDefault(false)
    }

    fun formatSize(bytes: Long): String {
        return when {
            bytes < 1024 -> "$bytes Б"
            bytes < 1024 * 1024 -> "${bytes / 1024} КБ"
            else -> String.format("%.1f МБ", bytes / (1024f * 1024f))
        }
    }

    private fun resolveFileName(context: Context, uri: Uri): String {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0) {
                    val name = cursor.getString(idx)
                    if (!name.isNullOrBlank()) return name
                }
            }
        }
        return uri.lastPathSegment?.substringAfterLast('/') ?: "document.bin"
    }

    private fun compressImageIfNeeded(rawBytes: ByteArray): ByteArray {
        val original = BitmapFactory.decodeByteArray(rawBytes, 0, rawBytes.size) ?: return rawBytes
        val maxSide = 1280
        val scale = max(original.width, original.height).toFloat() / maxSide
        val targetBitmap = if (scale > 1f) {
            Bitmap.createScaledBitmap(
                original,
                (original.width / scale).toInt().coerceAtLeast(1),
                (original.height / scale).toInt().coerceAtLeast(1),
                true
            )
        } else {
            original
        }
        var quality = 80
        var outBytes: ByteArray
        do {
            val baos = ByteArrayOutputStream()
            targetBitmap.compress(Bitmap.CompressFormat.JPEG, quality, baos)
            outBytes = baos.toByteArray()
            quality -= 12
        } while (outBytes.size > MAX_RAW_BYTES && quality >= 30)
        if (targetBitmap != original) targetBitmap.recycle()
        original.recycle()
        return outBytes
    }
}
