package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AddIcCall
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material.icons.filled.GroupAdd
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.PersonSearch
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.SystemUpdate
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.VideoFile
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.AppThemeMode
import com.example.data.model.AppVisualTheme
import com.example.data.model.ChatAppearanceConfig
import com.example.data.model.ChatWallpaperPreset
import com.example.data.model.Conversation
import com.example.data.model.CustomRolePermission
import com.example.data.model.ModerationStatus
import com.example.data.model.OutgoingBubbleStyle
import com.example.data.model.PublicUserProfile
import com.example.data.model.UserPresenceStatus
import com.example.data.model.UserRole
import com.example.data.repository.SavedAccount
import com.example.data.repository.SavedAccountsStore
import com.example.media.LocalSpoxAudioPlayer
import com.example.media.SpoxVideoRequest
import com.example.notifications.MessagePushWorker
import com.example.plugins.PluginStore
import com.example.security.AppLockManager
import com.example.security.BiometricCapability
import com.example.ui.auth.signOutUser
import com.example.ui.components.BitmapMemoryCache
import com.example.ui.components.ChatWallpaperBackground
import com.example.ui.components.CipherLoadingStateView
import com.example.ui.components.CustomRoleBadge
import com.example.ui.components.EncryptionBadge
import com.example.ui.components.IncomingOrActiveCallBanner
import com.example.ui.components.MainBottomTab
import com.example.ui.components.ModerationStatusChip
import com.example.ui.components.ReadReceiptIcon
import com.example.ui.components.RoleBadge
import com.example.ui.components.SavedMessagesAvatar
import com.example.ui.components.SpoXBottomNavigationBar
import com.example.ui.components.TopNetworkStatusHeaderContent
import com.example.ui.components.UnreadCountBadge
import com.example.ui.components.UserAvatar
import com.example.ui.components.UserPresenceIndicator
import com.example.ui.components.smoothAppear
import com.example.ui.media.SpoxMediaHubTab
import com.example.ui.media.SpoxVideoPlayerDialog
import com.example.updates.AppUpdateStore
import com.example.ui.theme.ApplyLiquidGlassWindowBlur
import com.example.ui.theme.LocalChatAppearance
import com.example.ui.theme.isLiquidGlassActive
import com.example.ui.theme.liquidGlassDialogContainerColor
import com.example.ui.theme.liquidGlassEdgeScrim
import com.example.ui.theme.liquidGlassMenuContainerColor
import com.example.ui.theme.liquidGlassSheetContainerColor
import com.example.ui.theme.liquidGlassSheetScrimColor
import com.example.ui.theme.liquidGlassSurface
import com.example.ui.viewmodel.ChatListViewModel
import com.example.ui.viewmodel.UiState
import com.example.util.TimeFormatters
import com.google.firebase.Timestamp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private enum class ChatFilter(val label: String) {
    ALL("Все"),
    DIRECT("Личные"),
    GROUPS("Группы"),
    PEOPLE("Люди"),
    PLAYER("Плеер")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatListScreen(
    viewModel: ChatListViewModel,
    currentUserId: String,
    userEmail: String,
    userDisplayName: String,
    keyFingerprint: String,
    themeMode: AppThemeMode,
    appearanceConfig: ChatAppearanceConfig,
    isPinEnabled: Boolean,
    isBiometricEnabled: Boolean,
    biometricCapability: BiometricCapability,
    appLockManager: AppLockManager,
    onSetPin: (String) -> Unit,
    onDisablePin: () -> Unit,
    onSetBiometricEnabled: (Boolean) -> Unit,
    onLockAppNow: () -> Unit,
    onChangeThemeMode: (AppThemeMode) -> Unit,
    onSelectVisualTheme: (AppVisualTheme) -> Unit,
    onSelectWallpaperPreset: (ChatWallpaperPreset) -> Unit,
    onPickCustomWallpaperUri: (android.net.Uri) -> Unit,
    onSelectOutgoingBubbleStyle: (OutgoingBubbleStyle) -> Unit,
    onSetShowStories: (Boolean) -> Unit = {},
    onSetShowFolders: (Boolean) -> Unit = {},
    onSetLiquidGlassEnabled: (Boolean) -> Unit = {},
    onSetResourceSavingMode: (Boolean) -> Unit = {},
    onSetSmoothStoriesAppearance: (Boolean) -> Unit = {},
    onSetSmoothChatsAppearance: (Boolean) -> Unit = {},
    onSetSmoothChatsPanelAppearance: (Boolean) -> Unit = {},
    onSetSmoothChatMessagesAppearance: (Boolean) -> Unit = {},
    onResetCustomization: () -> Unit,
    onOpenChat: (String) -> Unit,
    onOpenGroupSettings: (String) -> Unit = {},
    onOpenCall: (String) -> Unit,
    savedAccounts: List<SavedAccount> = emptyList(),
    isSwitchingAccount: Boolean = false,
    onSwitchAccount: (SavedAccount, onDone: () -> Unit, onError: (String) -> Unit) -> Unit = { _, onDone, _ -> onDone() },
    onAddAccount: (onDone: () -> Unit, onError: (String) -> Unit) -> Unit = { onDone, _ -> onDone() },
    onRemoveSavedAccount: (String) -> Unit = {},
    onSignOutTriggered: () -> Unit = {}
) {
    val conversationsState by viewModel.conversationsState.collectAsStateWithLifecycle()
    val directoryUsers by viewModel.directoryUsers.collectAsStateWithLifecycle()
    val chatPeersMap by viewModel.chatPeersMap.collectAsStateWithLifecycle()
    val privateProfile by viewModel.privateProfile.collectAsStateWithLifecycle()
    val activeCalls by viewModel.activeCalls.collectAsStateWithLifecycle()
    val callHistory by viewModel.callHistory.collectAsStateWithLifecycle()
    val actionMessage by viewModel.actionMessage.collectAsStateWithLifecycle()
    val isBusy by viewModel.isBusy.collectAsStateWithLifecycle()
    val peopleSearchQuery by viewModel.peopleSearchQuery.collectAsStateWithLifecycle()
    val peopleSearchResults by viewModel.peopleSearchResults.collectAsStateWithLifecycle()
    val isSearchingPeople by viewModel.isSearchingPeople.collectAsStateWithLifecycle()
    val peopleSearchError by viewModel.peopleSearchError.collectAsStateWithLifecycle()
    val roleCodes by viewModel.roleCodes.collectAsStateWithLifecycle()
    val allUsersForAdmin by viewModel.allUsersForAdmin.collectAsStateWithLifecycle()
    val customRoles by viewModel.customRoles.collectAsStateWithLifecycle()
    val lastGeneratedRoleCode by viewModel.lastGeneratedRoleCode.collectAsStateWithLifecycle()
    val topStatusUiState by viewModel.topStatusUiState.collectAsStateWithLifecycle()

    val isDeveloper = UserRole.fromWire(privateProfile?.role) == UserRole.DEVELOPER
    val canMuteUsers = isDeveloper || (privateProfile?.hasPermission(CustomRolePermission.MODERATE_MUTE) == true)
    val canBanUsers = isDeveloper || (privateProfile?.hasPermission(CustomRolePermission.MODERATE_BAN) == true)
    val canIssueTesterCodes = isDeveloper || (privateProfile?.hasPermission(CustomRolePermission.ISSUE_TESTER_CODES) == true)
    val canOpenModerationPanel = isDeveloper || canMuteUsers || canBanUsers ||
        (privateProfile?.hasPermission(CustomRolePermission.VIEW_MODERATION) == true)

    val snackbarHostState = remember { SnackbarHostState() }
    var selectedBottomTab by rememberSaveable { mutableStateOf(MainBottomTab.CHATS) }
    var searchQuery by remember { mutableStateOf("") }
    val pagerState = rememberPagerState(
        initialPage = ChatFilter.ALL.ordinal,
        pageCount = { ChatFilter.entries.size }
    )
    var showNewChatSheet by remember { mutableStateOf(false) }
    var showStartCallSheet by remember { mutableStateOf(false) }
    var showNewGroupSheet by remember { mutableStateOf(false) }
    var showFindPeopleDialog by remember { mutableStateOf(false) }
    var activeSettingsSection by remember { mutableStateOf<ProfileSettingsSection?>(null) }
    var showMainMoreMenu by remember { mutableStateOf(false) }
    var showMessengerEditorSheet by remember { mutableStateOf(false) }
    var showPluginsSheet by remember { mutableStateOf(false) }
    var showUpdatesSheet by remember { mutableStateOf(false) }
    var showOwnProfileSheet by remember { mutableStateOf(false) }
    var showAccountSwitcherSheet by remember { mutableStateOf(false) }
    var inspectedPeerWithConvId by remember { mutableStateOf<Pair<PublicUserProfile, String?>?>(null) }
    var showAdminSheet by remember { mutableStateOf(false) }
    var showCustomRolesSheet by remember { mutableStateOf(false) }
    var selectedConvForActions by remember { mutableStateOf<Conversation?>(null) }
    var pendingDeleteConv by remember { mutableStateOf<Conversation?>(null) }
    var pendingLeaveConv by remember { mutableStateOf<Conversation?>(null) }
    var presenceNowMs by remember { mutableLongStateOf(System.currentTimeMillis()) }

    BackHandler(enabled = selectedBottomTab != MainBottomTab.CHATS) {
        selectedBottomTab = MainBottomTab.CHATS
    }

    LaunchedEffect(appearanceConfig.showFolders) {
        if (!appearanceConfig.showFolders && pagerState.currentPage != ChatFilter.ALL.ordinal) {
            pagerState.animateScrollToPage(ChatFilter.ALL.ordinal)
        }
    }

    val isResourceSaving = appearanceConfig.resourceSavingMode
    LaunchedEffect(isResourceSaving) {
        while (true) {
            delay(if (isResourceSaving) 90_000L else 30_000L)
            presenceNowMs = System.currentTimeMillis()
        }
    }

    LaunchedEffect(actionMessage) {
        actionMessage?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearMessage()
        }
    }

    val context = LocalContext.current
    val pluginStore = remember(context) { PluginStore.getInstance(context) }
    val installedPlugins by pluginStore.plugins.collectAsStateWithLifecycle()
    val updateStore = remember(context) { AppUpdateStore.getInstance(context) }
    val updateState by updateStore.state.collectAsStateWithLifecycle()
    LaunchedEffect(updateStore) {
        if (updateStore.state.value.autoCheckEnabled) {
            updateStore.checkForUpdates(force = false)
        }
    }
    val scope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }
    val audioPlayer = LocalSpoxAudioPlayer.current
    val audioUiState = audioPlayer?.uiState?.collectAsStateWithLifecycle()?.value
    val isAudioMiniBarVisible = audioUiState?.activeTrack != null
    var activeVideoRequest by remember { mutableStateOf<SpoxVideoRequest?>(null) }

    val density = LocalDensity.current
    val isLiquidGlass = isLiquidGlassActive()
    val primaryGlowColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.13f)
    val secondaryGlowColor = MaterialTheme.colorScheme.secondary.copy(alpha = 0.10f)
    var floatingHeaderHeightPx by remember { mutableIntStateOf(0) }
    val floatingHeaderHeightDp = with(density) { floatingHeaderHeightPx.toDp() }
    val statusBarTopDp = with(density) { WindowInsets.statusBars.getTop(density).toDp() }
    val navBarBottomDp = with(density) { WindowInsets.navigationBars.getBottom(density).toDp() }
    val myAvatar = privateProfile?.avatarBase64.orEmpty()
    val myColor = (directoryUsers.firstOrNull { it.userId == currentUserId }?.avatarColorIndex ?: 0L).toInt()
    val currentUserRole = UserRole.fromWire(privateProfile?.role)

    val brandBadgeContent: @Composable () -> Unit = {
        TopNetworkStatusHeaderContent(
            topStatus = topStatusUiState,
            isLiquidGlass = isLiquidGlass,
            badgeContent = {
                Spacer(modifier = Modifier.width(7.dp))
                EncryptionBadge(label = "E2EE")
                if (currentUserRole != UserRole.USER) {
                    Spacer(modifier = Modifier.width(5.dp))
                    RoleBadge(role = currentUserRole, compact = true)
                }
                if (privateProfile?.hasCustomRole() == true) {
                    Spacer(modifier = Modifier.width(5.dp))
                    CustomRoleBadge(
                        name = privateProfile?.customRoleName.orEmpty(),
                        badgeText = privateProfile?.customRoleBadge.orEmpty(),
                        colorHex = privateProfile?.customRoleColorHex.orEmpty(),
                        compact = true,
                        isPriority = privateProfile?.hasPermission(CustomRolePermission.PRIORITY_BADGE) == true
                    )
                }
            }
        )
    }

    val topActionsContent: @Composable () -> Unit = {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(if (isLiquidGlass) 4.dp else 0.dp)
        ) {
            IconButton(
                onClick = {
                    val next = if (themeMode == AppThemeMode.LIGHT) AppThemeMode.DARK else AppThemeMode.LIGHT
                    onChangeThemeMode(next)
                    viewModel.syncThemePreference(next)
                },
                modifier = Modifier.testTag("quick_theme_toggle_button")
            ) {
                if (isLiquidGlass) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(38.dp)
                            .liquidGlassSurface(shape = CircleShape)
                    ) {
                        Icon(
                            imageVector = if (themeMode == AppThemeMode.LIGHT) Icons.Filled.DarkMode else Icons.Filled.LightMode,
                            contentDescription = "Переключить тему",
                            modifier = Modifier.size(18.dp)
                        )
                    }
                } else {
                    Surface(
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.7f),
                        modifier = Modifier.size(34.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = if (themeMode == AppThemeMode.LIGHT) Icons.Filled.DarkMode else Icons.Filled.LightMode,
                                contentDescription = "Переключить тему",
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }
            IconButton(
                onClick = { showNewGroupSheet = true },
                modifier = Modifier.testTag("create_group_top_button")
            ) {
                if (isLiquidGlass) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(38.dp)
                            .liquidGlassSurface(shape = CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.GroupAdd,
                            contentDescription = "Создать групповой чат",
                            modifier = Modifier.size(18.dp)
                        )
                    }
                } else {
                    Surface(
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.7f),
                        modifier = Modifier.size(34.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Filled.GroupAdd,
                                contentDescription = "Создать групповой чат",
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }
            if (canOpenModerationPanel) {
                IconButton(
                    onClick = { showAdminSheet = true },
                    modifier = Modifier.testTag("open_admin_panel_button")
                ) {
                    if (isLiquidGlass) {
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .size(38.dp)
                                .liquidGlassSurface(
                                    shape = CircleShape,
                                    tintColor = MaterialTheme.colorScheme.primaryContainer,
                                    isHighlighted = true
                                )
                        ) {
                            Icon(
                                imageVector = Icons.Filled.AdminPanelSettings,
                                contentDescription = "Панель модерации",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    } else {
                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.14f),
                            modifier = Modifier.size(34.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Filled.AdminPanelSettings,
                                    contentDescription = "Панель модерации",
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }
            }
            Box {
                IconButton(
                    onClick = { showMainMoreMenu = true },
                    modifier = Modifier.testTag("main_more_menu_button")
                ) {
                    if (isLiquidGlass) {
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .size(38.dp)
                                .liquidGlassSurface(shape = CircleShape)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.MoreVert,
                                contentDescription = "Меню",
                                modifier = Modifier.size(19.dp)
                            )
                        }
                    } else {
                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.78f),
                            modifier = Modifier.size(34.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Filled.MoreVert,
                                    contentDescription = "Меню",
                                    modifier = Modifier.size(19.dp)
                                )
                            }
                        }
                    }
                }
                DropdownMenu(
                    expanded = showMainMoreMenu,
                    onDismissRequest = { showMainMoreMenu = false },
                    shape = RoundedCornerShape(18.dp),
                    containerColor = liquidGlassMenuContainerColor(),
                    modifier = Modifier.testTag("main_more_menu")
                ) {
                    DropdownMenuItem(
                        text = {
                            Column {
                                Text(
                                    text = "Мой профиль",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = "Аватар, @юзернейм, код шифрования",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        },
                        leadingIcon = {
                            UserAvatar(
                                name = userDisplayName,
                                avatarBase64 = myAvatar,
                                colorIndex = myColor,
                                size = 34.dp
                            )
                        },
                        onClick = {
                            showMainMoreMenu = false
                            showOwnProfileSheet = true
                        },
                        modifier = Modifier.testTag("menu_view_profile")
                    )
                    HorizontalDivider(
                        color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.45f)
                    )
                    DropdownMenuItem(
                        text = {
                            Column {
                                Text(
                                    text = "Аккаунты (${savedAccounts.size.coerceAtLeast(1)}/${SavedAccountsStore.MAX_ACCOUNTS})",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = "Сменить или добавить аккаунт",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        },
                        leadingIcon = {
                            Surface(
                                shape = CircleShape,
                                color = MaterialTheme.colorScheme.tertiary.copy(alpha = 0.16f),
                                modifier = Modifier.size(34.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Filled.SwapHoriz,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.tertiary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        },
                        onClick = {
                            showMainMoreMenu = false
                            showAccountSwitcherSheet = true
                        },
                        modifier = Modifier.testTag("menu_switch_accounts")
                    )
                    HorizontalDivider(
                        color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.45f)
                    )
                    DropdownMenuItem(
                        text = {
                            Column {
                                Text(
                                    text = "Настройки",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = "Уведомления, приватность, ресурсы, PIN",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        },
                        leadingIcon = {
                            Surface(
                                shape = CircleShape,
                                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.14f),
                                modifier = Modifier.size(34.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Filled.Settings,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        },
                        onClick = {
                            showMainMoreMenu = false
                            selectedBottomTab = MainBottomTab.SETTINGS
                        },
                        modifier = Modifier.testTag("menu_open_settings")
                    )
                    if (isDeveloper) {
                        HorizontalDivider(
                            color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.45f)
                        )
                        DropdownMenuItem(
                            text = {
                                Column {
                                    Text(
                                        text = "Кастомные роли (${customRoles.size})",
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Text(
                                        text = "Создание ролей, прав и выдача",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            },
                            leadingIcon = {
                                Surface(
                                    shape = CircleShape,
                                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.14f),
                                    modifier = Modifier.size(34.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = Icons.Filled.AutoAwesome,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                            },
                            onClick = {
                                showMainMoreMenu = false
                                showCustomRolesSheet = true
                            },
                            modifier = Modifier.testTag("menu_custom_roles")
                        )
                    }
                    HorizontalDivider(
                        color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.45f)
                    )
                    DropdownMenuItem(
                        text = {
                            Column {
                                Text(
                                    text = "Редактировать мессенджер",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = "Скрыть или показать истории и папки",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        },
                        leadingIcon = {
                            Surface(
                                shape = CircleShape,
                                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.14f),
                                modifier = Modifier.size(34.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Filled.Tune,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        },
                        onClick = {
                            showMainMoreMenu = false
                            showMessengerEditorSheet = true
                        },
                        modifier = Modifier.testTag("menu_edit_messenger")
                    )
                    HorizontalDivider(
                        color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.45f)
                    )
                    DropdownMenuItem(
                        text = {
                            Column {
                                Text(
                                    text = "Кастомизация",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = "Темы, обои, Liquid Glass, папки",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        },
                        leadingIcon = {
                            Surface(
                                shape = CircleShape,
                                color = MaterialTheme.colorScheme.secondary.copy(alpha = 0.16f),
                                modifier = Modifier.size(34.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Filled.Palette,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.secondary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        },
                        onClick = {
                            showMainMoreMenu = false
                            activeSettingsSection = ProfileSettingsSection.CUSTOMIZATION
                        },
                        modifier = Modifier.testTag("menu_open_customization")
                    )
                    HorizontalDivider(
                        color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.45f)
                    )
                    DropdownMenuItem(
                        text = {
                            val activePluginCount = installedPlugins.count { it.enabled }
                            Column {
                                Text(
                                    text = "Плагины (.lua)",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = "$activePluginCount вкл. • скрипты и шаблон",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        },
                        leadingIcon = {
                            Surface(
                                shape = CircleShape,
                                color = MaterialTheme.colorScheme.tertiary.copy(alpha = 0.16f),
                                modifier = Modifier.size(34.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Filled.Extension,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.tertiary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        },
                        onClick = {
                            showMainMoreMenu = false
                            showPluginsSheet = true
                        },
                        modifier = Modifier.testTag("menu_plugins")
                    )
                    HorizontalDivider(
                        color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.45f)
                    )
                    DropdownMenuItem(
                        text = {
                            Column {
                                Text(
                                    text = if (updateState.isUpdateAvailable) "Обновление SpoX!" else "Обновления",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.SemiBold,
                                    color = if (updateState.isUpdateAvailable) {
                                        MaterialTheme.colorScheme.primary
                                    } else {
                                        MaterialTheme.colorScheme.onSurface
                                    }
                                )
                                Text(
                                    text = if (updateState.isUpdateAvailable && updateState.latestRelease != null) {
                                        "Доступна v${updateState.latestRelease!!.versionName} на GitHub"
                                    } else {
                                        "GitHub Releases • v${updateState.currentVersion}"
                                    },
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (updateState.isUpdateAvailable) {
                                        MaterialTheme.colorScheme.primary
                                    } else {
                                        MaterialTheme.colorScheme.onSurfaceVariant
                                    }
                                )
                            }
                        },
                        leadingIcon = {
                            Surface(
                                shape = CircleShape,
                                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.16f),
                                modifier = Modifier.size(34.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Filled.SystemUpdate,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        },
                        onClick = {
                            showMainMoreMenu = false
                            showUpdatesSheet = true
                        },
                        modifier = Modifier.testTag("menu_updates")
                    )
                    HorizontalDivider(
                        color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.45f)
                    )
                    DropdownMenuItem(
                        text = {
                            Column {
                                Text(
                                    text = "Избранное",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = "Личные заметки и пересланное",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        },
                        leadingIcon = {
                            SavedMessagesAvatar(size = 34.dp)
                        },
                        enabled = !isBusy,
                        onClick = {
                            showMainMoreMenu = false
                            viewModel.openSavedMessages(onOpenChat)
                        },
                        modifier = Modifier.testTag("menu_open_saved_messages")
                    )
                    HorizontalDivider(
                        color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.45f)
                    )
                    DropdownMenuItem(
                        text = {
                            Column {
                                Text(
                                    text = "Изменение профиля",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = userDisplayName.ifBlank { "Никнейм, юзернейм, фото" },
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        },
                        leadingIcon = {
                            Box(contentAlignment = Alignment.BottomEnd) {
                                UserAvatar(
                                    name = userDisplayName,
                                    avatarBase64 = myAvatar,
                                    colorIndex = myColor,
                                    size = 34.dp
                                )
                                Surface(
                                    shape = CircleShape,
                                    color = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(14.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = Icons.Filled.Edit,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.onPrimary,
                                            modifier = Modifier.size(9.dp)
                                        )
                                    }
                                }
                            }
                        },
                        onClick = {
                            showMainMoreMenu = false
                            activeSettingsSection = ProfileSettingsSection.PROFILE
                        },
                        modifier = Modifier.testTag("menu_edit_profile")
                    )
                }
            }
        }
    }

    val allConversationsList = (conversationsState as? UiState.Success)?.data.orEmpty()
    val tabUnreadCounts = remember(allConversationsList, currentUserId) {
        mapOf(
            ChatFilter.ALL to allConversationsList.sumOf { it.unreadCountFor(currentUserId) },
            ChatFilter.DIRECT to allConversationsList.filter { !it.isGroup && !it.isSavedMessages(currentUserId) }
                .sumOf { it.unreadCountFor(currentUserId) },
            ChatFilter.GROUPS to allConversationsList.filter { it.isGroup }
                .sumOf { it.unreadCountFor(currentUserId) },
            ChatFilter.PEOPLE to 0,
            ChatFilter.PLAYER to 0
        )
    }

    val smoothChatsPanel = appearanceConfig.smoothChatsPanelAppearance && !isResourceSaving
    val headerControlsContent: @Composable () -> Unit = {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .smoothAppear(
                    enabled = appearanceConfig.smoothChatsPanelAppearance,
                    key = "chats_panel_root_${isLiquidGlass}",
                    initialTranslationYDp = -10f,
                    initialScale = 0.985f,
                    durationMillis = 250
                )
        ) {
            if (privateProfile?.isCurrentlyMuted() == true) {
                val mutedShape = RoundedCornerShape(16.dp)
                Surface(
                    shape = mutedShape,
                    color = if (isLiquidGlass) Color.Transparent else MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.72f),
                    border = if (isLiquidGlass) null else BorderStroke(1.dp, MaterialTheme.colorScheme.tertiary.copy(alpha = 0.45f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 8.dp)
                        .then(
                            if (isLiquidGlass) {
                                Modifier.liquidGlassSurface(
                                    shape = mutedShape,
                                    tintColor = MaterialTheme.colorScheme.tertiaryContainer,
                                    accentGlow = MaterialTheme.colorScheme.tertiary,
                                    isHighlighted = true
                                )
                            } else Modifier
                        )
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ModerationStatusChip(
                            status = ModerationStatus.MUTED,
                            mutedUntilEpochMs = privateProfile?.mutedUntilEpochMs ?: 0L,
                            compact = false
                        )
                        Text(
                            text = "Режим чтения: отправка сообщений отключена",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onTertiaryContainer,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            if (selectedBottomTab != MainBottomTab.CALLS) {
                activeCalls.firstOrNull()?.let { liveCall ->
                    IncomingOrActiveCallBanner(
                        call = liveCall,
                        currentUserId = currentUserId,
                        onAcceptOrJoin = { onOpenCall(liveCall.id) },
                        onDecline = { viewModel.declineIncomingCall(liveCall) },
                        modifier = Modifier.padding(bottom = 10.dp)
                    )
                }
            }

            val latestRelease = updateState.latestRelease
            AnimatedVisibility(
                visible = updateState.shouldShowBanner && latestRelease != null,
                enter = fadeIn(tween(220)) + expandVertically(tween(220)),
                exit = fadeOut(tween(180)) + shrinkVertically(tween(180))
            ) {
                if (latestRelease != null) {
                    UpdateAvailableBanner(
                        release = latestRelease,
                        currentVersion = updateState.currentVersion,
                        onOpenUpdates = { showUpdatesSheet = true },
                        onDismissVersion = { updateStore.skipVersion(latestRelease.tagName) },
                        modifier = Modifier.padding(bottom = 10.dp)
                    )
                }
            }

            if (selectedBottomTab == MainBottomTab.CHATS) {
                AnimatedVisibility(
                    visible = pagerState.targetPage != ChatFilter.PLAYER.ordinal,
                    enter = if (smoothChatsPanel) fadeIn(tween(220)) + expandVertically(tween(220)) else EnterTransition.None,
                    exit = if (smoothChatsPanel) fadeOut(tween(180)) + shrinkVertically(tween(180)) else ExitTransition.None
                ) {
                    Column {
                    val searchShape = RoundedCornerShape(24.dp)
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .then(
                                if (isLiquidGlass) {
                                    Modifier.liquidGlassSurface(
                                        shape = searchShape,
                                        isHighlighted = searchQuery.isNotEmpty()
                                    )
                                } else Modifier
                            )
                    ) {
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            placeholder = {
                                Text(
                                    text = "Поиск чатов и людей (имя, @ник)...",
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Filled.Search,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            },
                            trailingIcon = {
                                if (searchQuery.isNotEmpty()) {
                                    IconButton(onClick = { searchQuery = "" }) {
                                        Icon(Icons.Filled.Close, contentDescription = "Очистить поиск")
                                    }
                                }
                            },
                            singleLine = true,
                            shape = searchShape,
                            colors = if (isLiquidGlass) {
                                OutlinedTextFieldDefaults.colors(
                                    focusedContainerColor = Color.Transparent,
                                    unfocusedContainerColor = Color.Transparent,
                                    focusedBorderColor = Color.Transparent,
                                    unfocusedBorderColor = Color.Transparent
                                )
                            } else {
                                OutlinedTextFieldDefaults.colors(
                                    focusedContainerColor = MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.85f),
                                    unfocusedContainerColor = MaterialTheme.colorScheme.surfaceContainerLow.copy(alpha = 0.85f),
                                    focusedBorderColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.65f),
                                    unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.65f)
                                )
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("chat_search_input")
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                }
            }

            AnimatedVisibility(
                visible = appearanceConfig.showFolders,
                enter = if (smoothChatsPanel) expandVertically(tween(240)) + fadeIn(tween(220)) else EnterTransition.None,
                exit = if (smoothChatsPanel) shrinkVertically(tween(220)) + fadeOut(tween(180)) else ExitTransition.None
            ) {
                Column {
                    val foldersShape = RoundedCornerShape(22.dp)
                    Surface(
                        shape = foldersShape,
                        color = if (isLiquidGlass) Color.Transparent else MaterialTheme.colorScheme.surfaceContainerLow.copy(alpha = 0.92f),
                        border = if (isLiquidGlass) null else BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .smoothAppear(
                                enabled = appearanceConfig.smoothChatsPanelAppearance,
                                key = "folders_bar_${appearanceConfig.showFolders}",
                                initialTranslationYDp = -8f,
                                initialScale = 0.98f,
                                durationMillis = 220
                            )
                            .then(
                                if (isLiquidGlass) Modifier.liquidGlassSurface(shape = foldersShape) else Modifier
                            )
                            .testTag("chat_folders_bar")
                    ) {
                        BoxWithConstraints(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(4.dp)
                        ) {
                            val tabCount = ChatFilter.entries.size
                            val tabWidthDp = maxWidth / tabCount
                            val tabWidthPx = constraints.maxWidth.toFloat() / tabCount
                            val indicatorShape = RoundedCornerShape(16.dp)

                            Surface(
                                shape = indicatorShape,
                                color = if (isLiquidGlass) Color.Transparent else MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.85f),
                                border = if (isLiquidGlass) null else BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.45f)),
                                modifier = Modifier
                                    .width(tabWidthDp)
                                    .height(38.dp)
                                    .graphicsLayer {
                                        translationX =
                                            (pagerState.currentPage + pagerState.currentPageOffsetFraction) * tabWidthPx
                                    }
                                    .then(
                                        if (isLiquidGlass) {
                                            Modifier.liquidGlassSurface(
                                                shape = indicatorShape,
                                                tintColor = MaterialTheme.colorScheme.primaryContainer,
                                                isHighlighted = true
                                            )
                                        } else Modifier
                                    )
                            ) {}

                            Row(modifier = Modifier.fillMaxWidth()) {
                                ChatFilter.entries.forEachIndexed { index, filter ->
                                    val tabUnread = tabUnreadCounts[filter] ?: 0
                                    val isSelected = pagerState.targetPage == index
                                    val targetContentColor = if (isSelected) {
                                        MaterialTheme.colorScheme.onPrimaryContainer
                                    } else {
                                        MaterialTheme.colorScheme.onSurfaceVariant
                                    }
                                    val contentColor = if (isResourceSaving || !smoothChatsPanel) {
                                        targetContentColor
                                    } else {
                                        animateColorAsState(
                                            targetValue = targetContentColor,
                                            animationSpec = tween(220),
                                            label = "tab_fg_${filter.name}"
                                        ).value
                                    }
                                    Box(
                                        contentAlignment = Alignment.Center,
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(38.dp)
                                            .clip(RoundedCornerShape(16.dp))
                                            .clickable {
                                                scope.launch {
                                                    if (isResourceSaving || !smoothChatsPanel) {
                                                        pagerState.scrollToPage(index)
                                                    } else {
                                                        pagerState.animateScrollToPage(index)
                                                    }
                                                }
                                            }
                                            .testTag("filter_${filter.name.lowercase()}")
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 4.dp),
                                            horizontalArrangement = Arrangement.Center,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = filter.label,
                                                style = MaterialTheme.typography.labelMedium,
                                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                                color = contentColor,
                                                maxLines = 1,
                                                softWrap = false,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            if (tabUnread > 0) {
                                                Spacer(modifier = Modifier.width(3.dp))
                                                Box(
                                                    modifier = Modifier
                                                        .clip(CircleShape)
                                                        .background(MaterialTheme.colorScheme.primary)
                                                        .padding(horizontal = 5.dp, vertical = 1.dp),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Text(
                                                        text = if (tabUnread > 99) "99+" else tabUnread.toString(),
                                                        style = MaterialTheme.typography.labelSmall,
                                                        fontWeight = FontWeight.Bold,
                                                        color = MaterialTheme.colorScheme.onPrimary
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    if (!isLiquidGlass) {
                        Spacer(modifier = Modifier.height(10.dp))
                    }
                }
            }
            }
        }
    }

    Scaffold(
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        containerColor = Color.Transparent,
        modifier = Modifier
            .fillMaxSize()
            .then(
                if (isLiquidGlass) Modifier
                else Modifier.background(MaterialTheme.colorScheme.background)
            )
            .then(
                if (isResourceSaving || isLiquidGlass) {
                    Modifier
                } else {
                    Modifier.drawWithCache {
                        val topGlow = Brush.radialGradient(
                            colors = listOf(primaryGlowColor, Color.Transparent),
                            center = Offset(size.width * 0.85f, size.height * 0.06f),
                            radius = (size.minDimension * 0.85f).coerceAtLeast(1f)
                        )
                        val sideGlow = Brush.radialGradient(
                            colors = listOf(secondaryGlowColor, Color.Transparent),
                            center = Offset(size.width * 0.12f, size.height * 0.24f),
                            radius = (size.minDimension * 0.65f).coerceAtLeast(1f)
                        )
                        onDrawBehind {
                            drawRect(brush = topGlow)
                            drawRect(brush = sideGlow)
                        }
                    }
                }
            ),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            if (!isLiquidGlass) {
                TopAppBar(
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = Color.Transparent,
                        scrolledContainerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.92f)
                    ),
                    title = { brandBadgeContent() },
                    actions = { topActionsContent() }
                )
            }
        },
        bottomBar = {
            if (!isLiquidGlass) {
                SpoXBottomNavigationBar(
                    selectedTab = selectedBottomTab,
                    onSelectTab = { selectedBottomTab = it },
                    activeCallsCount = activeCalls.size,
                    unreadChatsCount = tabUnreadCounts[ChatFilter.ALL] ?: 0,
                    hasAvailableUpdate = updateState.isUpdateAvailable
                )
            }
        },
        floatingActionButton = {
            val showCallsFab = selectedBottomTab == MainBottomTab.CALLS
            val showChatsFab = selectedBottomTab == MainBottomTab.CHATS &&
                pagerState.currentPage != ChatFilter.PLAYER.ordinal
            if (showCallsFab || showChatsFab) {
                val fabLabel = if (showCallsFab) "Новый звонок" else "Новый чат"
                val fabIcon = if (showCallsFab) Icons.Filled.AddIcCall else Icons.AutoMirrored.Filled.Chat
                val fabTag = if (showCallsFab) "new_call_fab" else "new_chat_fab"
                val onFabClick = {
                    if (showCallsFab) showStartCallSheet = true else showNewChatSheet = true
                }
                if (isLiquidGlass) {
                    val fabShape = RoundedCornerShape(50)
                    Surface(
                        onClick = onFabClick,
                        shape = fabShape,
                        color = Color.Transparent,
                        shadowElevation = 0.dp,
                        modifier = Modifier
                            .navigationBarsPadding()
                            .padding(bottom = if (isAudioMiniBarVisible) 156.dp else 84.dp)
                            .defaultMinSize(minHeight = 56.dp)
                            .liquidGlassSurface(
                                shape = fabShape,
                                tintColor = MaterialTheme.colorScheme.primaryContainer,
                                accentGlow = MaterialTheme.colorScheme.primary,
                                isHighlighted = true
                            )
                            .testTag(fabTag)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 20.dp, vertical = 16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(
                                imageVector = fabIcon,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = fabLabel,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }
                    }
                } else {
                    ExtendedFloatingActionButton(
                        onClick = onFabClick,
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary,
                        shape = RoundedCornerShape(18.dp),
                        modifier = Modifier
                            .padding(bottom = if (isAudioMiniBarVisible) 74.dp else 0.dp)
                            .testTag(fabTag),
                        icon = { Icon(fabIcon, contentDescription = null) },
                        text = {
                            Text(
                                text = fabLabel,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    )
                }
            }
        }
    ) { innerPadding ->
        val scrollTopPadding = if (isLiquidGlass) {
            if (floatingHeaderHeightPx > 0) {
                floatingHeaderHeightDp + 10.dp
            } else {
                statusBarTopDp + 180.dp
            }
        } else {
            2.dp
        }
        val listBottomPadding = if (isLiquidGlass) {
            navBarBottomDp + (if (isAudioMiniBarVisible) 244.dp else 172.dp)
        } else {
            if (isAudioMiniBarVisible) 164.dp else 96.dp
        }
        val settingsBottomPadding = if (isLiquidGlass) {
            navBarBottomDp + (if (isAudioMiniBarVisible) 180.dp else 108.dp)
        } else {
            if (isAudioMiniBarVisible) 96.dp else 24.dp
        }

        val smoothChats = appearanceConfig.smoothChatsAppearance && !isResourceSaving
        val smoothStories = appearanceConfig.smoothStoriesAppearance && !isResourceSaving
        val pagerBodyContent: @Composable (Modifier) -> Unit = { bodyModifier ->
            AnimatedContent(
                targetState = conversationsState,
                transitionSpec = {
                    if (!smoothChats) EnterTransition.None togetherWith ExitTransition.None
                    else fadeIn(tween(220)) togetherWith fadeOut(tween(160))
                },
                contentKey = { it::class },
                label = "chats_loading_state",
                modifier = bodyModifier
            ) { state ->
                when (state) {
                    is UiState.Loading -> {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(top = scrollTopPadding),
                            contentAlignment = Alignment.Center
                        ) {
                            CipherLoadingStateView(label = "Загрузка защищённых чатов...")
                        }
                    }

                    is UiState.Error -> {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(top = scrollTopPadding + 12.dp, start = 16.dp, end = 16.dp)
                        ) {
                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = MaterialTheme.colorScheme.error.copy(alpha = 0.12f),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier.padding(16.dp),
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Text(
                                        text = state.message,
                                        color = MaterialTheme.colorScheme.error,
                                        style = MaterialTheme.typography.bodyMedium
                                    )
                                    Button(
                                        onClick = { viewModel.retryLoadConversations() },
                                        modifier = Modifier.testTag("retry_conversations_button")
                                    ) {
                                        Text("Повторить")
                                    }
                                }
                            }
                        }
                    }

                    is UiState.Success -> {
                        val usersById = chatPeersMap
                        val trimmedSearch = searchQuery.trim()
                        val searchEmailHash = remember(trimmedSearch) {
                            viewModel.computeEmailHash(trimmedSearch)
                        }
                        val existingDirectPeerUids = remember(state.data, currentUserId) {
                            state.data
                                .filter { !it.isGroup && !it.isSavedMessages(currentUserId) }
                                .mapNotNull { conv -> conv.memberUids.firstOrNull { it != currentUserId } }
                                .toSet()
                        }
                        val hasSavedConversation = remember(state.data, currentUserId) {
                            state.data.any { it.isSavedMessages(currentUserId) }
                        }
                        val presenceBucket = presenceNowMs / 30_000L
                        val sortedAllPeers = remember(directoryUsers, currentUserId, presenceBucket) {
                            viewModel.filterUsers(directoryUsers, "")
                                .sortedWith(
                                    compareBy<PublicUserProfile> {
                                        when (it.presenceStatus(presenceNowMs)) {
                                            UserPresenceStatus.ONLINE -> 0
                                            UserPresenceStatus.RECENTLY -> 1
                                            UserPresenceStatus.OFFLINE -> 2
                                        }
                                    }.thenBy { it.displayName.lowercase() }
                                )
                        }

                        HorizontalPager(
                            state = pagerState,
                            beyondViewportPageCount = 0,
                            userScrollEnabled = appearanceConfig.showFolders,
                            key = { ChatFilter.entries[it].name },
                            modifier = Modifier
                                .fillMaxSize()
                                .testTag("chat_tabs_pager")
                        ) { pageIndex ->
                            val activeTab = ChatFilter.entries[pageIndex]
                            if (activeTab == ChatFilter.PLAYER) {
                                SpoxMediaHubTab(
                                    onOpenVideo = { request -> activeVideoRequest = request },
                                    onShowMessage = { msg -> viewModel.showMessage(msg) },
                                    extraTopPaddingDp = if (isLiquidGlass) {
                                        kotlin.math.ceil(scrollTopPadding.value).toInt().coerceAtLeast(16)
                                    } else 8,
                                    extraBottomPaddingDp = if (isLiquidGlass) {
                                        kotlin.math.ceil(navBarBottomDp.value).toInt() + if (isAudioMiniBarVisible) 186 else 112
                                    } else {
                                        if (isAudioMiniBarVisible) 104 else 32
                                    }
                                )
                            } else {
                                val tabListState = rememberLazyListState()

                                val filtered = remember(
                                    state.data,
                                    usersById,
                                    trimmedSearch,
                                    searchEmailHash,
                                    activeTab,
                                    currentUserId
                                ) {
                                    if (activeTab == ChatFilter.PEOPLE || activeTab == ChatFilter.PLAYER) {
                                        emptyList()
                                    } else {
                                        val qClean = trimmedSearch.removePrefix("@")
                                        val baseFiltered = state.data.filter { conv ->
                                            val isSaved = conv.isSavedMessages(currentUserId)
                                            val matchesType = when (activeTab) {
                                                ChatFilter.ALL -> true
                                                ChatFilter.DIRECT -> !conv.isGroup && !isSaved
                                                ChatFilter.GROUPS -> conv.isGroup
                                                ChatFilter.PEOPLE, ChatFilter.PLAYER -> false
                                            }
                                            if (!matchesType) return@filter false
                                            if (trimmedSearch.isEmpty()) return@filter true

                                            val peerProfile = if (isSaved) null else resolveDirectPeer(conv, currentUserId, usersById)
                                            val displayTitle = peerProfile?.displayName ?: resolveConversationTitle(conv, currentUserId)
                                            val peerHandle = peerProfile?.handle.orEmpty()
                                            val memberMatches = conv.memberUids.any { uid ->
                                                val member = usersById[uid]
                                                val memberName = member?.displayName ?: conv.memberNames[uid].orEmpty()
                                                val memberHandle = member?.handle.orEmpty()
                                                (memberName.isNotBlank() && memberName.contains(trimmedSearch, ignoreCase = true)) ||
                                                    (memberHandle.isNotBlank() && (
                                                        memberHandle.contains(trimmedSearch, ignoreCase = true) ||
                                                            (qClean.isNotEmpty() && memberHandle.removePrefix("@").contains(qClean, ignoreCase = true))
                                                        )) ||
                                                    (searchEmailHash != null && member?.emailHash.equals(searchEmailHash, ignoreCase = true))
                                            }
                                            val savedKeywordsMatch = isSaved && (
                                                "избранное".contains(trimmedSearch, ignoreCase = true) ||
                                                    "saved".contains(trimmedSearch, ignoreCase = true) ||
                                                    "заметки".contains(trimmedSearch, ignoreCase = true)
                                                )
                                            displayTitle.contains(trimmedSearch, ignoreCase = true) ||
                                                savedKeywordsMatch ||
                                                (peerHandle.isNotBlank() && (
                                                    peerHandle.contains(trimmedSearch, ignoreCase = true) ||
                                                        (qClean.isNotEmpty() && peerHandle.removePrefix("@").contains(qClean, ignoreCase = true))
                                                    )) ||
                                                (searchEmailHash != null && peerProfile?.emailHash.equals(searchEmailHash, ignoreCase = true)) ||
                                                memberMatches
                                        }
                                        baseFiltered.sortedByDescending { it.isSavedMessages(currentUserId) }
                                    }
                                }

                                val showSavedShortcutCard = remember(activeTab, hasSavedConversation, trimmedSearch) {
                                    activeTab == ChatFilter.ALL &&
                                        !hasSavedConversation &&
                                        (trimmedSearch.isEmpty() ||
                                            "избранное".contains(trimmedSearch, ignoreCase = true) ||
                                            "saved".contains(trimmedSearch, ignoreCase = true) ||
                                            "заметки".contains(trimmedSearch, ignoreCase = true))
                                }

                                val matchingPeople = remember(
                                    directoryUsers,
                                    sortedAllPeers,
                                    trimmedSearch,
                                    activeTab,
                                    existingDirectPeerUids,
                                    filtered.size
                                ) {
                                    when {
                                        activeTab == ChatFilter.GROUPS || activeTab == ChatFilter.PLAYER -> emptyList()
                                        activeTab == ChatFilter.PEOPLE -> {
                                            if (trimmedSearch.isEmpty()) sortedAllPeers
                                            else viewModel.filterUsers(directoryUsers, trimmedSearch)
                                        }
                                        trimmedSearch.isNotEmpty() -> {
                                            viewModel.filterUsers(directoryUsers, trimmedSearch)
                                                .filter { it.userId !in existingDirectPeerUids }
                                        }
                                        activeTab == ChatFilter.DIRECT -> {
                                            sortedAllPeers.filter { it.userId !in existingDirectPeerUids }
                                        }
                                        filtered.isEmpty() -> sortedAllPeers
                                        else -> emptyList()
                                    }
                                }

                                if (filtered.isEmpty() && matchingPeople.isEmpty() && !showSavedShortcutCard) {
                                    if (trimmedSearch.isNotEmpty()) {
                                        EmptySearchResultState(
                                            query = trimmedSearch,
                                            topPadding = if (isLiquidGlass) scrollTopPadding else 0.dp,
                                            onOpenFindPeople = {
                                                viewModel.updatePeopleSearchQuery(trimmedSearch)
                                                showFindPeopleDialog = true
                                            },
                                            onClearSearch = { searchQuery = "" }
                                        )
                                    } else {
                                        EmptyChatsState(
                                            isGroupsTab = activeTab == ChatFilter.GROUPS,
                                            isPeopleTab = activeTab == ChatFilter.PEOPLE,
                                            topPadding = if (isLiquidGlass) scrollTopPadding else 0.dp,
                                            onNewChat = { showNewChatSheet = true },
                                            onNewGroup = { showNewGroupSheet = true },
                                            onFindPeople = {
                                                viewModel.clearPeopleSearch()
                                                showFindPeopleDialog = true
                                            }
                                        )
                                    }
                                } else {
                                    LazyColumn(
                                        state = tabListState,
                                        contentPadding = PaddingValues(
                                            start = if (isLiquidGlass) 16.dp else 0.dp,
                                            end = if (isLiquidGlass) 16.dp else 0.dp,
                                            top = scrollTopPadding,
                                            bottom = listBottomPadding
                                        ),
                                        verticalArrangement = Arrangement.spacedBy(10.dp),
                                        modifier = Modifier.fillMaxSize()
                                    ) {
                                        if (appearanceConfig.showStories && activeTab == ChatFilter.ALL && trimmedSearch.isEmpty()) {
                                            item(key = "quick_contacts_ribbon") {
                                                Box(
                                                    modifier = (if (smoothStories) Modifier.animateItem() else Modifier)
                                                        .smoothAppear(
                                                            enabled = appearanceConfig.smoothStoriesAppearance,
                                                            key = "stories_ribbon_${appearanceConfig.showStories}",
                                                            initialTranslationYDp = -8f,
                                                            initialScale = 0.97f,
                                                            durationMillis = 250
                                                        )
                                                ) {
                                                    QuickContactsRibbon(
                                                        peers = sortedAllPeers.take(10),
                                                        presenceNowMs = presenceNowMs,
                                                        enabled = !isBusy,
                                                        smoothAppearance = appearanceConfig.smoothStoriesAppearance,
                                                        onOpenSaved = { viewModel.openSavedMessages(onOpenChat) },
                                                        onSelectPeer = { person ->
                                                            viewModel.startDirectChat(person) { chatId ->
                                                                onOpenChat(chatId)
                                                            }
                                                        },
                                                        onEditMessenger = { showMessengerEditorSheet = true }
                                                    )
                                                }
                                            }
                                        }
                                        if (showSavedShortcutCard) {
                                            item(key = "saved_messages_shortcut") {
                                                Box(
                                                    modifier = (if (smoothChats) Modifier.animateItem() else Modifier)
                                                        .smoothAppear(
                                                            enabled = appearanceConfig.smoothChatsAppearance,
                                                            key = "saved_shortcut_${activeTab.name}",
                                                            initialTranslationYDp = 12f,
                                                            initialScale = 0.985f,
                                                            durationMillis = 230
                                                        )
                                                ) {
                                                    SavedMessagesShortcutCard(
                                                        enabled = !isBusy,
                                                        onClick = {
                                                            viewModel.openSavedMessages(onOpenChat)
                                                        }
                                                    )
                                                }
                                            }
                                        }
                                        itemsIndexed(filtered, key = { _, conv -> conv.id }) { index, conv ->
                                            val peerProfile = if (conv.isSavedMessages(currentUserId)) null else resolveDirectPeer(conv, currentUserId, usersById)
                                            val groupOnlineCount = remember(conv, usersById, presenceBucket) {
                                                if (!conv.isGroup) 0
                                                else conv.memberUids.count { uid ->
                                                    uid != currentUserId &&
                                                        usersById[uid]?.presenceStatus(presenceNowMs) == UserPresenceStatus.ONLINE
                                                }
                                            }
                                            Box(
                                                modifier = (if (smoothChats) Modifier.animateItem() else Modifier)
                                                    .smoothAppear(
                                                        enabled = appearanceConfig.smoothChatsAppearance,
                                                        key = "${activeTab.name}_${conv.id}",
                                                        delayMillis = index.coerceAtMost(6) * 22,
                                                        initialTranslationYDp = 12f,
                                                        initialScale = 0.985f,
                                                        durationMillis = 230
                                                    )
                                            ) {
                                                ConversationCard(
                                                    conversation = conv,
                                                    currentUserId = currentUserId,
                                                    peerProfile = peerProfile,
                                                    groupOnlineCount = groupOnlineCount,
                                                    presenceNowMs = presenceNowMs,
                                                    onClick = { onOpenChat(conv.id) },
                                                    onLongClick = { selectedConvForActions = conv },
                                                    onMoreClick = { selectedConvForActions = conv }
                                                )
                                            }
                                        }
                                        if (matchingPeople.isNotEmpty()) {
                                            item(key = "people_section_header") {
                                                Row(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .smoothAppear(
                                                            enabled = appearanceConfig.smoothChatsAppearance,
                                                            key = "people_hdr_${activeTab.name}",
                                                            initialTranslationYDp = 8f,
                                                            durationMillis = 200
                                                        )
                                                        .padding(top = if (filtered.isNotEmpty()) 8.dp else 2.dp, bottom = 2.dp),
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Text(
                                                        text = if (activeTab == ChatFilter.PEOPLE) {
                                                            "Люди в SpoX • нажмите для ЛС (${matchingPeople.size})"
                                                        } else {
                                                            "Написать в ЛС (${matchingPeople.size})"
                                                        },
                                                        style = MaterialTheme.typography.labelLarge,
                                                        color = MaterialTheme.colorScheme.primary
                                                    )
                                                }
                                            }
                                            itemsIndexed(matchingPeople, key = { _, person -> "person_${person.userId}" }) { index, person ->
                                                Box(
                                                    modifier = (if (smoothChats) Modifier.animateItem() else Modifier)
                                                        .smoothAppear(
                                                            enabled = appearanceConfig.smoothChatsAppearance,
                                                            key = "${activeTab.name}_person_${person.userId}",
                                                            delayMillis = index.coerceAtMost(6) * 20,
                                                            initialTranslationYDp = 12f,
                                                            initialScale = 0.985f,
                                                            durationMillis = 230
                                                        )
                                                ) {
                                                    DirectoryPersonCard(
                                                        person = person,
                                                        matchedByEmail = searchEmailHash != null && person.emailHash.equals(searchEmailHash, ignoreCase = true),
                                                        hasExistingChat = person.userId in existingDirectPeerUids,
                                                        presenceNowMs = presenceNowMs,
                                                        enabled = !isBusy,
                                                        onClick = {
                                                            viewModel.startDirectChat(person) { chatId ->
                                                                onOpenChat(chatId)
                                                            }
                                                        }
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        val mainTabBodyContent: @Composable (Modifier) -> Unit = { bodyModifier ->
            AnimatedContent(
                targetState = selectedBottomTab,
                transitionSpec = {
                    if (isResourceSaving) EnterTransition.None togetherWith ExitTransition.None
                    else fadeIn(tween(200)) togetherWith fadeOut(tween(150))
                },
                label = "main_bottom_tab_content",
                modifier = bodyModifier
            ) { bottomTab ->
                when (bottomTab) {
                    MainBottomTab.CHATS -> {
                        pagerBodyContent(Modifier.fillMaxSize())
                    }

                    MainBottomTab.CALLS -> {
                        val mePeers = remember(directoryUsers, currentUserId) {
                            viewModel.filterUsers(directoryUsers, "")
                        }
                        val allConvs = (conversationsState as? UiState.Success)?.data.orEmpty()
                        CallsTabContent(
                            currentUserId = currentUserId,
                            activeCalls = activeCalls,
                            callHistory = callHistory,
                            conversations = allConvs,
                            directoryUsers = mePeers,
                            chatPeersMap = chatPeersMap,
                            presenceNowMs = presenceNowMs,
                            isBusy = isBusy,
                            topPadding = scrollTopPadding,
                            bottomPadding = listBottomPadding,
                            horizontalPadding = if (isLiquidGlass) 16.dp else 0.dp,
                            smoothAppearance = smoothChats,
                            onJoinCall = { call -> onOpenCall(call.id) },
                            onDeclineCall = { call -> viewModel.declineIncomingCall(call) },
                            onStartCallWithConversation = { conv, callType ->
                                viewModel.startCallWithConversation(conv, callType) { callId ->
                                    onOpenCall(callId)
                                }
                            },
                            onStartCallWithPeer = { peer, callType ->
                                viewModel.startCallWithPeer(peer, callType) { callId ->
                                    onOpenCall(callId)
                                }
                            },
                            onOpenStartCallSheet = { showStartCallSheet = true }
                        )
                    }

                    MainBottomTab.SETTINGS -> {
                        val mePublic = directoryUsers.firstOrNull { it.userId == currentUserId }
                        SettingsTabContent(
                            privateProfile = privateProfile,
                            publicProfile = mePublic,
                            fallbackEmail = userEmail,
                            fallbackDisplayName = userDisplayName,
                            isPinEnabled = isPinEnabled,
                            isBiometricEnabled = isBiometricEnabled,
                            biometricCapability = biometricCapability,
                            appLockManager = appLockManager,
                            isResourceSavingEnabled = isResourceSaving,
                            savedAccountsCount = savedAccounts.size.coerceAtLeast(1),
                            activePluginsCount = installedPlugins.count { it.enabled },
                            hasAvailableUpdate = updateState.isUpdateAvailable,
                            latestUpdateVersion = updateState.latestRelease?.versionName,
                            canOpenModerationPanel = canOpenModerationPanel,
                            isDeveloper = isDeveloper,
                            adminUsersCount = allUsersForAdmin.size,
                            customRolesCount = customRoles.size,
                            topPadding = scrollTopPadding,
                            bottomPadding = settingsBottomPadding,
                            horizontalPadding = if (isLiquidGlass) 16.dp else 0.dp,
                            smoothAppearance = smoothChats,
                            onOpenOwnProfile = { showOwnProfileSheet = true },
                            onOpenEditProfile = { activeSettingsSection = ProfileSettingsSection.PROFILE },
                            onOpenAccountSwitcher = { showAccountSwitcherSheet = true },
                            onOpenMessengerEditor = { showMessengerEditorSheet = true },
                            onOpenCustomization = { activeSettingsSection = ProfileSettingsSection.CUSTOMIZATION },
                            onOpenPlugins = { showPluginsSheet = true },
                            onOpenUpdates = { showUpdatesSheet = true },
                            onOpenModerationPanel = { showAdminSheet = true },
                            onOpenCustomRoles = { showCustomRolesSheet = true },
                            onSetDiscoverable = { viewModel.setDiscoverable(it) },
                            onSetResourceSavingEnabled = onSetResourceSavingMode,
                            onSetPin = { newPin ->
                                onSetPin(newPin)
                                viewModel.showMessage("PIN-код установлен")
                            },
                            onDisablePin = {
                                onDisablePin()
                                viewModel.showMessage("Вход по PIN-коду отключён")
                            },
                            onSetBiometricEnabled = { enabled ->
                                onSetBiometricEnabled(enabled)
                                viewModel.showMessage(if (enabled) "Вход по биометрии включён" else "Вход по биометрии отключён")
                            },
                            onLockAppNow = onLockAppNow,
                            onShowMessage = { msg -> viewModel.showMessage(msg) },
                            onBiometricError = { msg -> viewModel.showMessage(msg) },
                            onSignOut = {
                                viewModel.clearGeneratedRoleCode()
                                onSignOutTriggered()
                                val appCtx = context.applicationContext
                                scope.launch {
                                    withContext(Dispatchers.IO) {
                                        MessagePushWorker.cancelAll(appCtx)
                                    }
                                    viewModel.markOfflineNow()
                                    signOutUser(credentialManager, scope)
                                }
                            }
                        )
                    }
                }
            }
        }

        if (isLiquidGlass) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (appearanceConfig.wallpaperPreset != ChatWallpaperPreset.THEME_DEFAULT) {
                    ChatWallpaperBackground(
                        appearance = appearanceConfig,
                        modifier = Modifier.fillMaxSize()
                    )
                }
                mainTabBodyContent(
                    Modifier
                        .fillMaxSize()
                        .widthIn(max = 700.dp)
                        .align(Alignment.TopCenter)
                )

                // Floating Telegram-style Liquid Glass Top Header overlay — content scrolls underneath!
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.TopCenter)
                        .onSizeChanged { floatingHeaderHeightPx = it.height }
                        .liquidGlassEdgeScrim(
                            isTop = true,
                            scrimColor = MaterialTheme.colorScheme.background
                        )
                        .statusBarsPadding()
                        .testTag("floating_glass_header")
                ) {
                    Column(
                        modifier = Modifier
                            .widthIn(max = 700.dp)
                            .align(Alignment.TopCenter)
                            .padding(horizontal = 16.dp, vertical = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                shape = RoundedCornerShape(50),
                                color = Color.Transparent,
                                modifier = Modifier
                                    .weight(1f, fill = false)
                                    .liquidGlassSurface(shape = RoundedCornerShape(50))
                            ) {
                                Box(
                                    modifier = Modifier.padding(start = 7.dp, end = 12.dp, top = 5.dp, bottom = 5.dp)
                                ) {
                                    brandBadgeContent()
                                }
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            topActionsContent()
                        }

                        headerControlsContent()
                    }
                }

                // Floating Liquid Glass Bottom Navigation Dock — content scrolls underneath!
                SpoXBottomNavigationBar(
                    selectedTab = selectedBottomTab,
                    onSelectTab = { selectedBottomTab = it },
                    activeCallsCount = activeCalls.size,
                    unreadChatsCount = tabUnreadCounts[ChatFilter.ALL] ?: 0,
                    hasAvailableUpdate = updateState.isUpdateAvailable,
                    modifier = Modifier.align(Alignment.BottomCenter)
                )
            }
        } else {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .widthIn(max = 700.dp)
                        .align(Alignment.TopCenter)
                        .padding(horizontal = 16.dp)
                ) {
                    headerControlsContent()
                    mainTabBodyContent(Modifier.weight(1f).fillMaxWidth())
                }
            }
        }
    }

    if (showStartCallSheet) {
        val allConvs = (conversationsState as? UiState.Success)?.data.orEmpty()
        StartCallPickerSheet(
            currentUserId = currentUserId,
            conversations = allConvs,
            directoryUsers = directoryUsers,
            presenceNowMs = presenceNowMs,
            isBusy = isBusy,
            onStartCallWithConversation = { conv, callType ->
                viewModel.startCallWithConversation(conv, callType) { callId ->
                    onOpenCall(callId)
                }
            },
            onStartCallWithPeer = { peer, callType ->
                viewModel.startCallWithPeer(peer, callType) { callId ->
                    onOpenCall(callId)
                }
            },
            onDismiss = { showStartCallSheet = false }
        )
    }

    activeVideoRequest?.let { videoReq ->
        SpoxVideoPlayerDialog(
            request = videoReq,
            onDismiss = { activeVideoRequest = null }
        )
    }

    if (showNewChatSheet) {
        var sheetQuery by remember { mutableStateOf("") }
        val peers = remember(directoryUsers, sheetQuery, currentUserId) {
            viewModel.filterUsers(directoryUsers, sheetQuery)
        }
        val sheetEmailHash = remember(sheetQuery) { viewModel.computeEmailHash(sheetQuery) }
        val allConvs = (conversationsState as? UiState.Success)?.data.orEmpty()
        val sheetExistingPeerUids = remember(allConvs, currentUserId) {
            allConvs.filter { !it.isGroup }
                .mapNotNull { conv -> conv.memberUids.firstOrNull { it != currentUserId } }
                .toSet()
        }

        ModalBottomSheet(
            onDismissRequest = { showNewChatSheet = false },
            containerColor = liquidGlassSheetContainerColor(),
            scrimColor = liquidGlassSheetScrimColor()
        ) {
            ApplyLiquidGlassWindowBlur()
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(horizontal = 20.dp, vertical = 8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Личное сообщение (ЛС)",
                            style = MaterialTheme.typography.titleLarge
                        )
                        Text(
                            text = "Нажмите на человека, чтобы сразу открыть чат",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    TextButton(
                        onClick = {
                            showNewChatSheet = false
                            viewModel.clearPeopleSearch()
                            showFindPeopleDialog = true
                        },
                        modifier = Modifier.testTag("find_people_button")
                    ) {
                        Icon(Icons.Filled.PersonSearch, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("По email")
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
                OutlinedTextField(
                    value = sheetQuery,
                    onValueChange = { sheetQuery = it },
                    placeholder = { Text("Имя, @юзернейм или email...") },
                    leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                    trailingIcon = {
                        if (sheetQuery.isNotEmpty()) {
                            IconButton(onClick = { sheetQuery = "" }) {
                                Icon(Icons.Filled.Close, contentDescription = "Очистить")
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("new_chat_people_search_input")
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = if (sheetQuery.isBlank()) "Пользователи (${peers.size})" else "Найдено (${peers.size})",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(8.dp))
                if (peers.isEmpty()) {
                    Text(
                        text = if (sheetQuery.isBlank()) {
                            "Пока нет других пользователей в открытом каталоге. Вы можете найти собеседника по точному email или @юзернейму."
                        } else {
                            "По запросу «$sheetQuery» никто не найден. Попробуйте ввести другое имя, @юзернейм или точный email."
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(vertical = 16.dp)
                    )
                } else {
                    LazyColumn(
                        modifier = Modifier.height(300.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(peers, key = { it.userId }) { peer ->
                            DirectoryPersonCard(
                                person = peer,
                                matchedByEmail = sheetEmailHash != null && peer.emailHash.equals(sheetEmailHash, ignoreCase = true),
                                hasExistingChat = peer.userId in sheetExistingPeerUids,
                                presenceNowMs = presenceNowMs,
                                enabled = !isBusy,
                                onClick = {
                                    viewModel.startDirectChat(peer) { chatId ->
                                        showNewChatSheet = false
                                        onOpenChat(chatId)
                                    }
                                },
                                modifier = Modifier.testTag("peer_item_${peer.userId}")
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }

    if (showNewGroupSheet) {
        val allPeers = remember(directoryUsers, currentUserId) {
            directoryUsers.filter { it.userId != currentUserId }
        }
        var groupTitle by remember { mutableStateOf("") }
        var memberFilterQuery by remember { mutableStateOf("") }
        val filteredGroupPeers = remember(allPeers, memberFilterQuery) {
            viewModel.filterUsers(allPeers, memberFilterQuery, excludeCurrentUser = false)
        }
        val selectedUids = remember { mutableStateListOf<String>() }

        ModalBottomSheet(
            onDismissRequest = { showNewGroupSheet = false },
            containerColor = liquidGlassSheetContainerColor(),
            scrimColor = liquidGlassSheetScrimColor()
        ) {
            ApplyLiquidGlassWindowBlur()
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(horizontal = 20.dp, vertical = 8.dp)
            ) {
                Text(
                    text = "Создать групповой чат",
                    style = MaterialTheme.typography.titleLarge
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Для группы генерируется общий AES-256 ключ, зашифрованный персонально для каждого участника.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedTextField(
                    value = groupTitle,
                    onValueChange = { groupTitle = it },
                    label = { Text("Название группы") },
                    placeholder = { Text("Например: Команда разработки") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("group_title_input")
                )
                Spacer(modifier = Modifier.height(10.dp))
                OutlinedTextField(
                    value = memberFilterQuery,
                    onValueChange = { memberFilterQuery = it },
                    placeholder = { Text("Поиск участников (имя, @юзернейм, email)...") },
                    leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                    trailingIcon = {
                        if (memberFilterQuery.isNotEmpty()) {
                            IconButton(onClick = { memberFilterQuery = "" }) {
                                Icon(Icons.Filled.Close, contentDescription = "Очистить")
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("group_member_search_input")
                )
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "Участники (${selectedUids.size} выбрано)",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(8.dp))
                if (allPeers.isEmpty()) {
                    Text(
                        text = "Других контактов пока нет — вы можете создать группу сейчас и добавить участников позже.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(vertical = 8.dp)
                    )
                } else if (filteredGroupPeers.isEmpty()) {
                    Text(
                        text = "Участники по запросу «$memberFilterQuery» не найдены.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(vertical = 8.dp)
                    )
                } else {
                    LazyColumn(
                        modifier = Modifier.height(200.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(filteredGroupPeers, key = { it.userId }) { peer ->
                            val checked = peer.userId in selectedUids
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = if (checked) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
                                else MaterialTheme.colorScheme.surfaceContainer,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        if (checked) selectedUids.remove(peer.userId)
                                        else selectedUids.add(peer.userId)
                                    }
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    UserAvatar(
                                        name = peer.displayName,
                                        avatarBase64 = peer.avatarBase64,
                                        colorIndex = peer.avatarColorIndex.toInt(),
                                        size = 38.dp,
                                        presenceStatus = peer.presenceStatus(presenceNowMs)
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(peer.displayName, style = MaterialTheme.typography.titleSmall)
                                        if (peer.handle.isNotBlank()) {
                                            Text(
                                                text = peer.handle,
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                    Checkbox(
                                        checked = checked,
                                        onCheckedChange = {
                                            if (checked) selectedUids.remove(peer.userId)
                                            else selectedUids.add(peer.userId)
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(14.dp))
                Button(
                    onClick = {
                        val chosen = allPeers.filter { it.userId in selectedUids }
                        viewModel.createGroupChat(
                            title = groupTitle.ifBlank { "Защищённая группа" },
                            selectedMembers = chosen
                        ) { chatId ->
                            showNewGroupSheet = false
                            onOpenChat(chatId)
                        }
                    },
                    enabled = !isBusy,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("confirm_create_group_button")
                ) {
                    Icon(Icons.Filled.Check, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Создать группу")
                }
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }

    if (showFindPeopleDialog) {
        val dialogEmailHash = remember(peopleSearchQuery) { viewModel.computeEmailHash(peopleSearchQuery) }
        AlertDialog(
            onDismissRequest = {
                showFindPeopleDialog = false
                viewModel.clearPeopleSearch()
            },
            containerColor = liquidGlassDialogContainerColor(),
            title = {
                ApplyLiquidGlassWindowBlur()
                Text("Поиск людей")
            },
            text = {
                Column {
                    Text(
                        text = "Ищите собеседников по имени, @юзернейму или точному email (проверяется через SHA-256).",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = peopleSearchQuery,
                        onValueChange = { viewModel.updatePeopleSearchQuery(it) },
                        label = { Text("Имя, @юзернейм или email") },
                        placeholder = { Text("Анна, @alex или name@gmail.com") },
                        leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                        trailingIcon = {
                            if (isSearchingPeople) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(18.dp),
                                    strokeWidth = 2.dp
                                )
                            } else if (peopleSearchQuery.isNotEmpty()) {
                                IconButton(onClick = { viewModel.clearPeopleSearch() }) {
                                    Icon(Icons.Filled.Close, contentDescription = "Очистить")
                                }
                            }
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("find_people_input")
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    if (peopleSearchError != null) {
                        Text(
                            text = peopleSearchError!!,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error
                        )
                    } else if (peopleSearchQuery.isBlank()) {
                        Text(
                            text = "Начните вводить имя, @username или адрес электронной почты.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else if (peopleSearchResults.isEmpty() && !isSearchingPeople) {
                        Text(
                            text = "Пользователи не найдены или скрыты настройками приватности.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else if (peopleSearchResults.isNotEmpty()) {
                        val dialogExistingPeerUids = (conversationsState as? UiState.Success)?.data
                            .orEmpty()
                            .filter { !it.isGroup }
                            .mapNotNull { conv -> conv.memberUids.firstOrNull { it != currentUserId } }
                            .toSet()
                        LazyColumn(
                            modifier = Modifier.height(210.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(peopleSearchResults, key = { it.userId }) { user ->
                                DirectoryPersonCard(
                                    person = user,
                                    matchedByEmail = dialogEmailHash != null && user.emailHash.equals(dialogEmailHash, ignoreCase = true),
                                    hasExistingChat = user.userId in dialogExistingPeerUids,
                                    presenceNowMs = presenceNowMs,
                                    enabled = !isBusy,
                                    onClick = {
                                        showFindPeopleDialog = false
                                        viewModel.clearPeopleSearch()
                                        viewModel.startDirectChat(user) { chatId ->
                                            onOpenChat(chatId)
                                        }
                                    },
                                    modifier = Modifier.testTag("find_people_result_${user.userId}")
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val querySnapshot = peopleSearchQuery
                        val firstMatch = peopleSearchResults.firstOrNull()
                        showFindPeopleDialog = false
                        viewModel.clearPeopleSearch()
                        if (firstMatch != null) {
                            viewModel.startDirectChat(firstMatch) { chatId ->
                                onOpenChat(chatId)
                            }
                        } else {
                            viewModel.findAndStartDirectChat(querySnapshot) { chatId ->
                                onOpenChat(chatId)
                            }
                        }
                    },
                    enabled = peopleSearchQuery.isNotBlank() && !isBusy,
                    modifier = Modifier.testTag("find_people_confirm_button")
                ) {
                    Text("Начать чат")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        showFindPeopleDialog = false
                        viewModel.clearPeopleSearch()
                    }
                ) {
                    Text("Отмена")
                }
            }
        )
    }

    activeSettingsSection?.let { section ->
        val mePublic = directoryUsers.firstOrNull { it.userId == currentUserId }
        ProfileSettingsSheet(
            privateProfile = privateProfile,
            publicProfile = mePublic,
            fallbackEmail = userEmail,
            fallbackDisplayName = userDisplayName,
            keyFingerprint = keyFingerprint,
            themeMode = themeMode,
            appearanceConfig = appearanceConfig,
            isBusy = isBusy,
            roleCodes = roleCodes,
            lastGeneratedRoleCode = lastGeneratedRoleCode,
            adminUsersCount = allUsersForAdmin.size,
            customRolesCount = customRoles.size,
            canOpenModerationPanel = canOpenModerationPanel,
            canIssueTesterCodes = canIssueTesterCodes,
            isPinEnabled = isPinEnabled,
            isBiometricEnabled = isBiometricEnabled,
            biometricCapability = biometricCapability,
            appLockManager = appLockManager,
            initialSection = section,
            onSwitchSection = { nextSection ->
                activeSettingsSection = nextSection
            },
            onDismiss = {
                viewModel.clearGeneratedRoleCode()
                activeSettingsSection = null
            },
            onSaveProfile = { name, username, avatar ->
                viewModel.updateProfile(name, username, avatar)
            },
            onDeleteUsername = { name, avatar ->
                viewModel.deleteUsername(name, avatar)
            },
            onAvatarError = { msg -> viewModel.showMessage(msg) },
            onRedeemRoleCode = { code, onRedeemed ->
                viewModel.redeemRoleCode(code) { onRedeemed() }
            },
            onGenerateRoleCode = { targetRole ->
                viewModel.generateRoleCode(targetRole)
            },
            onDeleteRoleCode = { codeHash ->
                viewModel.deleteRoleCode(codeHash)
            },
            onCodeCopied = { code ->
                viewModel.showMessage("Код $code скопирован")
            },
            onOpenModerationPanel = {
                activeSettingsSection = null
                showAdminSheet = true
            },
            onOpenCustomRoles = {
                activeSettingsSection = null
                showCustomRolesSheet = true
            },
            onSetPin = { newPin ->
                onSetPin(newPin)
                viewModel.showMessage("PIN-код установлен")
            },
            onDisablePin = {
                onDisablePin()
                viewModel.showMessage("Вход по PIN-коду отключён")
            },
            onSetBiometricEnabled = { enabled ->
                onSetBiometricEnabled(enabled)
                viewModel.showMessage(if (enabled) "Вход по биометрии включён" else "Вход по биометрии отключён")
            },
            onLockAppNow = {
                activeSettingsSection = null
                onLockAppNow()
            },
            onShowMessage = { msg -> viewModel.showMessage(msg) },
            onChangeThemeMode = { mode ->
                onChangeThemeMode(mode)
                viewModel.syncThemePreference(mode)
            },
            onSelectVisualTheme = onSelectVisualTheme,
            onSelectWallpaperPreset = onSelectWallpaperPreset,
            onPickCustomWallpaperUri = onPickCustomWallpaperUri,
            onSelectOutgoingBubbleStyle = onSelectOutgoingBubbleStyle,
            onSetShowStories = onSetShowStories,
            onSetShowFolders = onSetShowFolders,
            onSetLiquidGlassEnabled = onSetLiquidGlassEnabled,
            onSetResourceSavingMode = onSetResourceSavingMode,
            onResetCustomization = onResetCustomization,
            onOpenPlugins = {
                activeSettingsSection = null
                showPluginsSheet = true
            },
            hasAvailableUpdate = updateState.isUpdateAvailable,
            latestUpdateVersion = updateState.latestRelease?.versionName,
            onOpenUpdates = {
                activeSettingsSection = null
                showUpdatesSheet = true
            },
            onSetDiscoverable = { viewModel.setDiscoverable(it) },
            savedAccountsCount = savedAccounts.size.coerceAtLeast(1),
            onOpenAccountSwitcher = { showAccountSwitcherSheet = true },
            onSignOut = {
                viewModel.clearGeneratedRoleCode()
                activeSettingsSection = null
                onSignOutTriggered()
                val appCtx = context.applicationContext
                scope.launch {
                    withContext(Dispatchers.IO) {
                        MessagePushWorker.cancelAll(appCtx)
                    }
                    viewModel.markOfflineNow()
                    signOutUser(credentialManager, scope)
                }
            }
        )
    }

    if (showMessengerEditorSheet) {
        MessengerEditorSheet(
            appearance = appearanceConfig.copy(themeMode = themeMode),
            onSetShowStories = onSetShowStories,
            onSetShowFolders = onSetShowFolders,
            onSetLiquidGlassEnabled = onSetLiquidGlassEnabled,
            onSetSmoothStoriesAppearance = onSetSmoothStoriesAppearance,
            onSetSmoothChatsAppearance = onSetSmoothChatsAppearance,
            onSetSmoothChatsPanelAppearance = onSetSmoothChatsPanelAppearance,
            onSetSmoothChatMessagesAppearance = onSetSmoothChatMessagesAppearance,
            onOpenFullCustomization = {
                activeSettingsSection = ProfileSettingsSection.CUSTOMIZATION
            },
            onDismiss = { showMessengerEditorSheet = false }
        )
    }

    if (showPluginsSheet) {
        PluginManagerSheet(
            pluginStore = pluginStore,
            onShowMessage = { msg -> viewModel.showMessage(msg) },
            onDismiss = { showPluginsSheet = false }
        )
    }

    if (showUpdatesSheet) {
        AppUpdateSheet(
            updateStore = updateStore,
            onShowMessage = { msg -> viewModel.showMessage(msg) },
            onDismiss = { showUpdatesSheet = false }
        )
    }

    if (showAdminSheet && canOpenModerationPanel) {
        AdminModerationSheet(
            users = allUsersForAdmin,
            currentUserId = currentUserId,
            isDeveloper = isDeveloper,
            canMute = canMuteUsers,
            canBan = canBanUsers,
            canDelete = isDeveloper,
            customRoles = customRoles,
            isBusy = isBusy,
            onDismiss = { showAdminSheet = false },
            onModerateUser = { targetUid, status, durationMs, reason ->
                viewModel.moderateUser(targetUid, status, durationMs, reason)
            },
            onDeleteUserAccount = { targetUid, reason ->
                viewModel.deleteUserAccount(targetUid, reason)
            },
            onAssignCustomRole = { targetUid, customRole ->
                viewModel.assignCustomRole(targetUid, customRole)
            }
        )
    }

    if (showCustomRolesSheet && isDeveloper) {
        CustomRolesSheet(
            customRoles = customRoles,
            users = allUsersForAdmin,
            currentUserId = currentUserId,
            isBusy = isBusy,
            onDismiss = { showCustomRolesSheet = false },
            onSaveCustomRole = { roleId, name, badge, colorHex, permissions, onSuccess ->
                viewModel.saveCustomRole(roleId, name, badge, colorHex, permissions, onSuccess)
            },
            onDeleteCustomRole = { roleId ->
                viewModel.deleteCustomRole(roleId)
            },
            onAssignCustomRole = { targetUid, customRole ->
                viewModel.assignCustomRole(targetUid, customRole)
            }
        )
    }

    if (showOwnProfileSheet) {
        val mePublic = directoryUsers.firstOrNull { it.userId == currentUserId }
        val resolvedName = privateProfile?.displayName?.ifBlank { null }
            ?: mePublic?.displayName?.ifBlank { null }
            ?: userDisplayName
        val resolvedHandle = privateProfile?.handle?.ifBlank { null }
            ?: mePublic?.handle.orEmpty()
        val resolvedAvatar = privateProfile?.avatarBase64?.ifBlank { null }
            ?: mePublic?.avatarBase64.orEmpty()
        val resolvedFingerprint = privateProfile?.keyFingerprint?.ifBlank { null }
            ?: mePublic?.keyFingerprint?.ifBlank { null }
            ?: keyFingerprint
        UserProfileSheet(
            displayName = resolvedName,
            handle = resolvedHandle,
            avatarBase64 = resolvedAvatar,
            avatarColorIndex = (mePublic?.avatarColorIndex ?: 0L).toInt(),
            keyFingerprint = resolvedFingerprint,
            role = UserRole.fromWire(privateProfile?.role ?: mePublic?.role),
            customRoleName = privateProfile?.customRoleName?.ifBlank { null } ?: mePublic?.customRoleName.orEmpty(),
            customRoleBadge = privateProfile?.customRoleBadge?.ifBlank { null } ?: mePublic?.customRoleBadge.orEmpty(),
            customRoleColorHex = privateProfile?.customRoleColorHex?.ifBlank { null } ?: mePublic?.customRoleColorHex.orEmpty(),
            customRolePermissions = privateProfile?.customRolePermissions?.takeIf { it.isNotEmpty() }
                ?: mePublic?.customRolePermissions.orEmpty(),
            isSelf = true,
            savedAccountsCount = savedAccounts.size.coerceAtLeast(1),
            onDismiss = { showOwnProfileSheet = false },
            onEditProfile = { activeSettingsSection = ProfileSettingsSection.PROFILE },
            onSwitchAccount = { showAccountSwitcherSheet = true },
            onCopied = { msg -> viewModel.showMessage(msg) }
        )
    }

    if (showAccountSwitcherSheet) {
        val displayAccounts = if (savedAccounts.isNotEmpty()) {
            savedAccounts
        } else {
            val mePublic = directoryUsers.firstOrNull { it.userId == currentUserId }
            listOf(
                SavedAccount(
                    uid = currentUserId,
                    email = userEmail,
                    displayName = privateProfile?.displayName?.ifBlank { null }
                        ?: mePublic?.displayName?.ifBlank { null }
                        ?: userDisplayName,
                    handle = privateProfile?.handle ?: mePublic?.handle.orEmpty(),
                    avatarBase64 = privateProfile?.avatarBase64 ?: mePublic?.avatarBase64.orEmpty(),
                    avatarColorIndex = (mePublic?.avatarColorIndex ?: 0L).toInt(),
                    role = privateProfile?.role ?: mePublic?.role ?: "user",
                    keyFingerprint = privateProfile?.keyFingerprint?.ifBlank { null } ?: keyFingerprint
                )
            )
        }
        AccountSwitcherSheet(
            accounts = displayAccounts,
            currentUserId = currentUserId,
            isSwitching = isSwitchingAccount,
            hasLiveSession = { acc ->
                com.example.data.repository.FirebaseSessionManager.hasLiveSessionForAccount(
                    context.applicationContext,
                    acc
                )
            },
            onDismiss = { showAccountSwitcherSheet = false },
            onSwitchAccount = onSwitchAccount,
            onAddAccount = onAddAccount,
            onRemoveAccount = onRemoveSavedAccount,
            onSignOutCurrent = {
                onSignOutTriggered()
                val appCtx = context.applicationContext
                scope.launch {
                    withContext(Dispatchers.IO) {
                        MessagePushWorker.cancelAll(appCtx)
                    }
                    viewModel.markOfflineNow()
                    signOutUser(credentialManager, scope)
                }
            }
        )
    }

    inspectedPeerWithConvId?.let { (peer, convId) ->
        UserProfileSheet(
            displayName = peer.displayName,
            handle = peer.handle,
            avatarBase64 = peer.avatarBase64,
            avatarColorIndex = peer.avatarColorIndex.toInt(),
            keyFingerprint = peer.keyFingerprint,
            role = UserRole.fromWire(peer.role),
            customRoleName = peer.customRoleName,
            customRoleBadge = peer.customRoleBadge,
            customRoleColorHex = peer.customRoleColorHex,
            customRolePermissions = peer.customRolePermissions,
            presenceStatus = peer.presenceStatus(presenceNowMs),
            isSelf = peer.userId == currentUserId,
            onDismiss = { inspectedPeerWithConvId = null },
            onMessageAction = convId?.let { targetConvId ->
                { onOpenChat(targetConvId) }
            },
            onCopied = { msg -> viewModel.showMessage(msg) }
        )
    }

    selectedConvForActions?.let { conv ->
        val peerProfile = if (conv.isSavedMessages(currentUserId)) null else resolveDirectPeer(conv, currentUserId, chatPeersMap)
        val convTitle = if (conv.isSavedMessages(currentUserId)) {
            "Избранное"
        } else {
            peerProfile?.displayName?.ifBlank { null } ?: resolveConversationTitle(conv, currentUserId)
        }
        ModalBottomSheet(
            onDismissRequest = { selectedConvForActions = null },
            containerColor = liquidGlassSheetContainerColor(),
            scrimColor = liquidGlassSheetScrimColor()
        ) {
            ApplyLiquidGlassWindowBlur()
            val isGlassSheet = isLiquidGlassActive()
            val sheetCardShape = RoundedCornerShape(14.dp)
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(horizontal = 20.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = convTitle,
                    style = MaterialTheme.typography.titleLarge,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = when {
                        conv.isSavedMessages(currentUserId) -> "Избранное • личное хранилище E2EE"
                        conv.isGroup -> "Группа • участников: ${conv.memberUids.size}"
                        else -> "Личный чат • E2EE"
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(4.dp))
                Surface(
                    shape = sheetCardShape,
                    color = if (isGlassSheet) Color.Transparent else MaterialTheme.colorScheme.surfaceContainer,
                    modifier = Modifier
                        .fillMaxWidth()
                        .then(if (isGlassSheet) Modifier.liquidGlassSurface(shape = sheetCardShape) else Modifier)
                        .clickable {
                            selectedConvForActions = null
                            onOpenChat(conv.id)
                        }
                        .testTag("action_open_chat_${conv.id}")
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Chat, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(12.dp))
                        Text("Открыть чат", style = MaterialTheme.typography.titleSmall)
                    }
                }
                if (!conv.isGroup && !conv.isSavedMessages(currentUserId) && peerProfile != null) {
                    Surface(
                        shape = sheetCardShape,
                        color = if (isGlassSheet) Color.Transparent else MaterialTheme.colorScheme.surfaceContainer,
                        modifier = Modifier
                            .fillMaxWidth()
                            .then(if (isGlassSheet) Modifier.liquidGlassSurface(shape = sheetCardShape) else Modifier)
                            .clickable {
                                selectedConvForActions = null
                                inspectedPeerWithConvId = peerProfile to conv.id
                            }
                            .testTag("action_view_profile_${conv.id}")
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Filled.Person, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(12.dp))
                            Text("Профиль пользователя", style = MaterialTheme.typography.titleSmall)
                        }
                    }
                }
                if (conv.isGroup) {
                    Surface(
                        shape = sheetCardShape,
                        color = if (isGlassSheet) Color.Transparent else MaterialTheme.colorScheme.surfaceContainer,
                        modifier = Modifier
                            .fillMaxWidth()
                            .then(if (isGlassSheet) Modifier.liquidGlassSurface(shape = sheetCardShape) else Modifier)
                            .clickable {
                                selectedConvForActions = null
                                onOpenGroupSettings(conv.id)
                            }
                            .testTag("action_group_settings_${conv.id}")
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Filled.Settings, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(12.dp))
                            Text("Настройки группы и участники", style = MaterialTheme.typography.titleSmall)
                        }
                    }
                }
                if (conv.isGroup && !conv.isCreator(currentUserId)) {
                    Surface(
                        shape = sheetCardShape,
                        color = if (isGlassSheet) Color.Transparent else MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.45f),
                        modifier = Modifier
                            .fillMaxWidth()
                            .then(
                                if (isGlassSheet) {
                                    Modifier.liquidGlassSurface(
                                        shape = sheetCardShape,
                                        tintColor = MaterialTheme.colorScheme.errorContainer,
                                        accentGlow = MaterialTheme.colorScheme.error
                                    )
                                } else Modifier
                            )
                            .clickable {
                                selectedConvForActions = null
                                pendingLeaveConv = conv
                            }
                            .testTag("action_leave_group_${conv.id}")
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.AutoMirrored.Filled.ExitToApp, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                            Spacer(modifier = Modifier.width(12.dp))
                            Text("Покинуть группу", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.error)
                        }
                    }
                } else {
                    Surface(
                        shape = sheetCardShape,
                        color = if (isGlassSheet) Color.Transparent else MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.45f),
                        modifier = Modifier
                            .fillMaxWidth()
                            .then(
                                if (isGlassSheet) {
                                    Modifier.liquidGlassSurface(
                                        shape = sheetCardShape,
                                        tintColor = MaterialTheme.colorScheme.errorContainer,
                                        accentGlow = MaterialTheme.colorScheme.error
                                    )
                                } else Modifier
                            )
                            .clickable {
                                selectedConvForActions = null
                                pendingDeleteConv = conv
                            }
                            .testTag("action_delete_chat_${conv.id}")
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Filled.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = if (conv.isGroup) "Удалить группу" else "Удалить чат",
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.error
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
            }
        }
    }

    pendingDeleteConv?.let { conv ->
        val peerProfile = if (conv.isSavedMessages(currentUserId)) null else resolveDirectPeer(conv, currentUserId, chatPeersMap)
        val convTitle = if (conv.isSavedMessages(currentUserId)) {
            "Избранное"
        } else {
            peerProfile?.displayName?.ifBlank { null } ?: resolveConversationTitle(conv, currentUserId)
        }
        ConfirmDeleteChatDialog(
            conversation = conv,
            currentUserId = currentUserId,
            resolvedTitle = convTitle,
            onDismiss = { pendingDeleteConv = null },
            onConfirm = {
                pendingDeleteConv = null
                viewModel.deleteConversation(conv)
            }
        )
    }

    pendingLeaveConv?.let { conv ->
        ConfirmLeaveGroupDialog(
            groupTitle = resolveConversationTitle(conv, currentUserId),
            onDismiss = { pendingLeaveConv = null },
            onConfirm = {
                pendingLeaveConv = null
                viewModel.leaveGroup(conv)
            }
        )
    }
}

@Composable
private fun QuickContactsRibbon(
    peers: List<PublicUserProfile>,
    presenceNowMs: Long,
    enabled: Boolean,
    smoothAppearance: Boolean = true,
    onOpenSaved: () -> Unit,
    onSelectPeer: (PublicUserProfile) -> Unit,
    onEditMessenger: () -> Unit = {}
) {
    val isGlass = isLiquidGlassActive()
    val ribbonShape = RoundedCornerShape(22.dp)
    val storyRingBrush = Brush.linearGradient(
        listOf(
            MaterialTheme.colorScheme.primary,
            MaterialTheme.colorScheme.secondary,
            MaterialTheme.colorScheme.tertiary
        )
    )
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .then(
                if (isGlass) {
                    Modifier
                        .liquidGlassSurface(shape = ribbonShape)
                        .padding(horizontal = 10.dp, vertical = 10.dp)
                } else Modifier
            )
            .testTag("quick_contacts_ribbon")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 2.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Истории",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = "Изменить",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .clickable(onClick = onEditMessenger)
                    .padding(horizontal = 6.dp, vertical = 2.dp)
                    .testTag("stories_ribbon_edit_action")
            )
        }
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(horizontal = 2.dp, vertical = 4.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            item(key = "quick_saved") {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .width(64.dp)
                        .smoothAppear(
                            enabled = smoothAppearance,
                            key = "quick_saved",
                            initialTranslationXDp = 10f,
                            initialTranslationYDp = 0f,
                            initialScale = 0.92f,
                            durationMillis = 230
                        )
                        .clip(RoundedCornerShape(14.dp))
                        .clickable(enabled = enabled, onClick = onOpenSaved)
                        .padding(vertical = 4.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(52.dp)
                            .clip(CircleShape)
                            .border(2.dp, storyRingBrush, CircleShape)
                            .padding(3.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        SavedMessagesAvatar(size = 44.dp)
                    }
                    Spacer(modifier = Modifier.height(5.dp))
                    Text(
                        text = "Заметки",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
            itemsIndexed(peers, key = { _, it -> "quick_${it.userId}" }) { index, person ->
                val firstName = person.displayName.trim().substringBefore(' ').ifBlank { person.displayName }
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .width(64.dp)
                        .smoothAppear(
                            enabled = smoothAppearance,
                            key = "quick_${person.userId}",
                            delayMillis = (index + 1).coerceAtMost(6) * 28,
                            initialTranslationXDp = 12f,
                            initialTranslationYDp = 0f,
                            initialScale = 0.92f,
                            durationMillis = 240
                        )
                        .clip(RoundedCornerShape(14.dp))
                        .clickable(enabled = enabled) { onSelectPeer(person) }
                        .padding(vertical = 4.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(52.dp)
                            .clip(CircleShape)
                            .border(2.dp, storyRingBrush, CircleShape)
                            .padding(3.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        UserAvatar(
                            name = person.displayName,
                            avatarBase64 = person.avatarBase64,
                            colorIndex = person.avatarColorIndex.toInt(),
                            size = 44.dp,
                            presenceStatus = person.presenceStatus(presenceNowMs)
                        )
                    }
                    Spacer(modifier = Modifier.height(5.dp))
                    Text(
                        text = firstName,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

@Composable
private fun SavedMessagesShortcutCard(
    enabled: Boolean,
    onClick: () -> Unit
) {
    val isLiquidGlass = isLiquidGlassActive()
    val cardShape = RoundedCornerShape(22.dp)
    Surface(
        shape = cardShape,
        color = if (isLiquidGlass) Color.Transparent else MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.28f),
        border = if (isLiquidGlass) null else BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.42f)),
        modifier = Modifier
            .fillMaxWidth()
            .then(
                if (isLiquidGlass) {
                    Modifier.liquidGlassSurface(
                        shape = cardShape,
                        tintColor = MaterialTheme.colorScheme.primaryContainer,
                        isHighlighted = true
                    )
                } else Modifier
            )
            .clickable(enabled = enabled, onClick = onClick)
            .testTag("saved_messages_shortcut_card")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 13.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            SavedMessagesAvatar(size = 54.dp)
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "Избранное",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.16f)
                    ) {
                        Text(
                            text = "ЗАМЕТКИ",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Личное зашифрованное хранилище и заметки • E2EE",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ConversationCard(
    conversation: Conversation,
    currentUserId: String,
    peerProfile: PublicUserProfile?,
    groupOnlineCount: Int = 0,
    presenceNowMs: Long = System.currentTimeMillis(),
    onClick: () -> Unit,
    onLongClick: () -> Unit = {},
    onMoreClick: () -> Unit = {}
) {
    val isSavedChat = conversation.isSavedMessages(currentUserId)
    val displayTitle = if (isSavedChat) {
        "Избранное"
    } else {
        peerProfile?.displayName?.ifBlank { null }
            ?: resolveConversationTitle(conversation, currentUserId)
    }

    val peerUid = conversation.memberUids.firstOrNull { it != currentUserId } ?: currentUserId
    val isSelfChat = isSavedChat || (!conversation.isGroup && peerUid == currentUserId)
    val peerPresence = if (!conversation.isGroup && !isSelfChat) {
        peerProfile?.presenceStatus(presenceNowMs) ?: UserPresenceStatus.OFFLINE
    } else {
        null
    }

    val previewTextLower = conversation.lastMessagePreview.lowercase()
    val subtitle = when (conversation.lastMessageType) {
        "voice" -> "Голосовое сообщение"
        "image" -> "Фотография"
        "file" -> when {
            previewTextLower.startsWith("видео") -> conversation.lastMessagePreview
            previewTextLower.startsWith("музыка") || previewTextLower.startsWith("аудио") -> conversation.lastMessagePreview
            else -> conversation.lastMessagePreview.ifBlank { "Зашифрованный файл" }
        }
        "call_event" -> conversation.lastMessagePreview.ifBlank { "Звонок" }
        "text" -> conversation.lastMessagePreview.ifBlank { "Зашифрованное сообщение" }
        else -> when {
            isSavedChat -> "Личное хранилище и пересланное • E2EE"
            conversation.isGroup && groupOnlineCount > 0 -> "${conversation.memberUids.size} уч. • $groupOnlineCount в сети"
            conversation.isGroup -> "Группа • ${conversation.memberUids.size} уч."
            peerPresence != null -> peerPresence.labelRu
            else -> "Чат защищён E2EE"
        }
    }

    val previewIcon = when {
        conversation.lastMessageType == "voice" -> Icons.Filled.Mic
        conversation.lastMessageType == "image" -> Icons.Filled.Image
        conversation.lastMessageType == "file" && previewTextLower.startsWith("видео") -> Icons.Filled.VideoFile
        conversation.lastMessageType == "file" && (previewTextLower.startsWith("музыка") || previewTextLower.startsWith("аудио")) -> Icons.Filled.MusicNote
        conversation.lastMessageType == "file" -> Icons.Filled.AttachFile
        conversation.lastMessageType == "call_event" -> Icons.Filled.Call
        else -> Icons.Filled.Lock
    }

    val unreadCount = conversation.unreadCountFor(currentUserId)
    val showReadReceipt = !isSelfChat &&
        conversation.lastMessageSenderId == currentUserId &&
        conversation.lastMessageType != "none"
    val isLastMsgRead = conversation.isLastMessageReadByOther(currentUserId)

    val appearance = LocalChatAppearance.current
    val isResourceSaving = appearance.resourceSavingMode
    val isLiquidGlass = isLiquidGlassActive()
    val cardColor = when {
        isLiquidGlass -> Color.Transparent
        unreadCount > 0 -> MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.96f)
        isSavedChat -> MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.24f)
        else -> MaterialTheme.colorScheme.surfaceContainerLow.copy(alpha = 0.90f)
    }
    val cardBorder = when {
        unreadCount > 0 -> MaterialTheme.colorScheme.primary.copy(alpha = 0.58f)
        isSavedChat -> MaterialTheme.colorScheme.primary.copy(alpha = 0.36f)
        else -> MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.65f)
    }
    val convShape = RoundedCornerShape(22.dp)

    Surface(
        shape = convShape,
        color = cardColor,
        tonalElevation = if (isLiquidGlass || isResourceSaving) 0.dp else if (unreadCount > 0) 4.dp else 1.dp,
        border = if (isLiquidGlass) null else BorderStroke(1.dp, cardBorder),
        modifier = Modifier
            .fillMaxWidth()
            .then(
                if (isLiquidGlass) {
                    Modifier.liquidGlassSurface(
                        shape = convShape,
                        tintColor = when {
                            unreadCount > 0 -> MaterialTheme.colorScheme.surfaceContainerHigh
                            isSavedChat -> MaterialTheme.colorScheme.primaryContainer
                            else -> MaterialTheme.colorScheme.surfaceContainerLow
                        },
                        isHighlighted = unreadCount > 0 || isSavedChat
                    )
                } else Modifier
            )
            .combinedClickable(
                onClick = onClick,
                onLongClick = onLongClick
            )
            .testTag("conversation_card_${conversation.id}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 14.dp, end = 6.dp, top = 12.dp, bottom = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (isSavedChat) {
                SavedMessagesAvatar(size = 54.dp)
            } else {
                UserAvatar(
                    name = displayTitle,
                    avatarBase64 = if (conversation.isGroup) "" else peerProfile?.avatarBase64.orEmpty(),
                    colorIndex = peerProfile?.avatarColorIndex?.toInt() ?: kotlin.math.abs(displayTitle.hashCode()),
                    isGroup = conversation.isGroup,
                    size = 54.dp,
                    presenceStatus = peerPresence
                )
            }
            Spacer(modifier = Modifier.width(13.dp))
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        if (conversation.isGroup) {
                            Icon(
                                imageVector = Icons.Filled.Groups,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.tertiary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(5.dp))
                        }
                        Text(
                            text = displayTitle,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = if (unreadCount > 0 || isSavedChat) FontWeight.Bold else FontWeight.SemiBold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f, fill = false)
                        )
                        if (isSavedChat) {
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(
                                shape = RoundedCornerShape(7.dp),
                                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.16f)
                            ) {
                                Text(
                                    text = "ЗАМЕТКИ",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                        if (!conversation.isGroup && !isSavedChat && peerProfile != null) {
                            val peerRole = UserRole.fromWire(peerProfile.role)
                            if (peerRole != UserRole.USER) {
                                Spacer(modifier = Modifier.width(6.dp))
                                RoleBadge(role = peerRole, compact = true)
                            }
                            if (peerProfile.hasCustomRole()) {
                                Spacer(modifier = Modifier.width(6.dp))
                                CustomRoleBadge(
                                    name = peerProfile.customRoleName,
                                    badgeText = peerProfile.customRoleBadge,
                                    colorHex = peerProfile.customRoleColorHex,
                                    compact = true,
                                    isPriority = CustomRolePermission.PRIORITY_BADGE.wireKey in peerProfile.customRolePermissions
                                )
                            }
                        }
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        modifier = Modifier.padding(end = 6.dp)
                    ) {
                        if (showReadReceipt) {
                            ReadReceiptIcon(
                                isRead = isLastMsgRead,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Text(
                            text = formatChatListTimestamp(conversation.updatedAt ?: conversation.createdAt),
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = if (unreadCount > 0) FontWeight.Bold else FontWeight.Medium,
                            color = if (unreadCount > 0) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Spacer(modifier = Modifier.height(5.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.11f),
                            modifier = Modifier.size(20.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = previewIcon,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(12.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(7.dp))
                        Text(
                            text = subtitle,
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = if (unreadCount > 0) FontWeight.SemiBold else FontWeight.Normal,
                            color = if (unreadCount > 0) MaterialTheme.colorScheme.onSurface
                            else MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        if (conversation.activeCallId.isNotBlank()) {
                            Surface(
                                shape = RoundedCornerShape(50),
                                color = MaterialTheme.colorScheme.secondaryContainer
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        Icons.Filled.Call,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.secondary,
                                        modifier = Modifier.size(12.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        "Звонок",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSecondaryContainer
                                    )
                                }
                            }
                        }
                        if (unreadCount > 0) {
                            UnreadCountBadge(count = unreadCount)
                        }
                        IconButton(
                            onClick = onMoreClick,
                            modifier = Modifier
                                .size(48.dp)
                                .testTag("conversation_more_button_${conversation.id}")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.MoreVert,
                                contentDescription = "Действия с чатом",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DirectoryPersonCard(
    person: PublicUserProfile,
    matchedByEmail: Boolean,
    hasExistingChat: Boolean = false,
    presenceNowMs: Long = System.currentTimeMillis(),
    enabled: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val presence = person.presenceStatus(presenceNowMs)
    val isLiquidGlass = isLiquidGlassActive()
    val personShape = RoundedCornerShape(20.dp)
    Surface(
        shape = personShape,
        color = if (isLiquidGlass) Color.Transparent else MaterialTheme.colorScheme.surfaceContainerLow.copy(alpha = 0.92f),
        border = if (isLiquidGlass) null else BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.65f)),
        modifier = modifier
            .fillMaxWidth()
            .defaultMinSize(minHeight = 48.dp)
            .then(if (isLiquidGlass) Modifier.liquidGlassSurface(shape = personShape) else Modifier)
            .clickable(enabled = enabled, onClick = onClick)
            .testTag("directory_person_card_${person.userId}")
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            UserAvatar(
                name = person.displayName,
                avatarBase64 = person.avatarBase64,
                colorIndex = person.avatarColorIndex.toInt(),
                size = 50.dp,
                presenceStatus = presence
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = person.displayName,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    val personRole = UserRole.fromWire(person.role)
                    if (personRole != UserRole.USER) {
                        RoleBadge(role = personRole, compact = true)
                    }
                    if (person.hasCustomRole()) {
                        CustomRoleBadge(
                            name = person.customRoleName,
                            badgeText = person.customRoleBadge,
                            colorHex = person.customRoleColorHex,
                            compact = true,
                            isPriority = CustomRolePermission.PRIORITY_BADGE.wireKey in person.customRolePermissions
                        )
                    }
                }
                UserPresenceIndicator(
                    status = presence,
                    compact = true,
                    modifier = Modifier.padding(vertical = 2.dp)
                )
                val meta = buildString {
                    if (person.handle.isNotBlank()) {
                        append(person.handle)
                        append(" • ")
                    }
                    if (matchedByEmail) {
                        append("найден по email • ")
                    }
                    append("E2EE ${person.keyFingerprint.take(9)}")
                }
                Text(
                    text = meta,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Surface(
                shape = RoundedCornerShape(50),
                color = if (hasExistingChat) {
                    MaterialTheme.colorScheme.secondaryContainer
                } else {
                    MaterialTheme.colorScheme.primaryContainer
                },
                border = BorderStroke(
                    1.dp,
                    if (hasExistingChat) MaterialTheme.colorScheme.secondary.copy(alpha = 0.35f)
                    else MaterialTheme.colorScheme.primary.copy(alpha = 0.35f)
                )
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    Icon(
                        imageVector = if (hasExistingChat) {
                            Icons.AutoMirrored.Filled.Chat
                        } else {
                            Icons.AutoMirrored.Filled.Send
                        },
                        contentDescription = if (hasExistingChat) "Открыть личный чат" else "Написать в личные сообщения",
                        tint = if (hasExistingChat) {
                            MaterialTheme.colorScheme.onSecondaryContainer
                        } else {
                            MaterialTheme.colorScheme.primary
                        },
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        text = if (hasExistingChat) "Открыть" else "Написать",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = if (hasExistingChat) {
                            MaterialTheme.colorScheme.onSecondaryContainer
                        } else {
                            MaterialTheme.colorScheme.onPrimaryContainer
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun EmptySearchResultState(
    query: String,
    topPadding: Dp = 0.dp,
    onOpenFindPeople: () -> Unit,
    onClearSearch: () -> Unit
) {
    val isGlass = isLiquidGlassActive()
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(start = 24.dp, end = 24.dp, top = topPadding, bottom = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Surface(
            shape = CircleShape,
            color = if (isGlass) Color.Transparent else MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.38f),
            border = if (isGlass) null else BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.35f)),
            modifier = Modifier
                .size(80.dp)
                .then(
                    if (isGlass) {
                        Modifier.liquidGlassSurface(
                            shape = CircleShape,
                            tintColor = MaterialTheme.colorScheme.primaryContainer,
                            isHighlighted = true
                        )
                    } else Modifier
                )
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    imageVector = Icons.Filled.PersonSearch,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(38.dp)
                )
            }
        }
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "Ничего не найдено",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = "По запросу «$query» нет совпадений среди чатов и открытых профилей.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(18.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(onClick = onOpenFindPeople, shape = RoundedCornerShape(16.dp)) {
                Icon(Icons.Filled.PersonSearch, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Расширенный поиск")
            }
            OutlinedButton(onClick = onClearSearch, shape = RoundedCornerShape(16.dp)) {
                Text("Сбросить")
            }
        }
    }
}

@Composable
private fun EmptyChatsState(
    isGroupsTab: Boolean = false,
    isPeopleTab: Boolean = false,
    topPadding: Dp = 0.dp,
    onNewChat: () -> Unit,
    onNewGroup: () -> Unit,
    onFindPeople: () -> Unit
) {
    val isGlass = isLiquidGlassActive()
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(start = 24.dp, end = 24.dp, top = topPadding, bottom = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(contentAlignment = Alignment.Center) {
            Surface(
                shape = CircleShape,
                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.10f),
                modifier = Modifier.size(104.dp)
            ) {}
            val badgeShape = RoundedCornerShape(28.dp)
            Surface(
                shape = badgeShape,
                color = if (isGlass) Color.Transparent else MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.65f),
                border = if (isGlass) null else BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.45f)),
                modifier = Modifier
                    .size(76.dp)
                    .then(
                        if (isGlass) {
                            Modifier.liquidGlassSurface(
                                shape = badgeShape,
                                tintColor = MaterialTheme.colorScheme.primaryContainer,
                                isHighlighted = true
                            )
                        } else Modifier
                    )
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = when {
                            isGroupsTab -> Icons.Filled.Groups
                            isPeopleTab -> Icons.Filled.PersonSearch
                            else -> Icons.AutoMirrored.Filled.Chat
                        },
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(36.dp)
                    )
                }
            }
        }
        Spacer(modifier = Modifier.height(18.dp))
        Text(
            text = when {
                isGroupsTab -> "Пока нет групповых чатов"
                isPeopleTab -> "В каталоге пока никого нет"
                else -> "Пока нет личных чатов"
            },
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = when {
                isGroupsTab -> "Создайте защищённую группу с несколькими участниками. Переписка и файлы шифруются на устройстве."
                isPeopleTab -> "Вы можете найти собеседника вручную по точному email или @юзернейму, если он открыт для поиска."
                else -> "Найдите человека по имени, @юзернейму или email, нажмите на него и сразу начните личную переписку."
            },
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(22.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            when {
                isGroupsTab -> {
                    Button(
                        onClick = onNewGroup,
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.height(48.dp)
                    ) {
                        Icon(Icons.Filled.GroupAdd, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Создать группу")
                    }
                }
                isPeopleTab -> {
                    Button(
                        onClick = onFindPeople,
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.height(48.dp)
                    ) {
                        Icon(Icons.Filled.PersonSearch, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Найти человека")
                    }
                }
                else -> {
                    Button(
                        onClick = onNewChat,
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.height(48.dp)
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Chat, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Написать в ЛС")
                    }
                    OutlinedButton(
                        onClick = onNewGroup,
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.height(48.dp)
                    ) {
                        Icon(Icons.Filled.GroupAdd, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Группа")
                    }
                }
            }
        }
        if (!isPeopleTab) {
            Spacer(modifier = Modifier.height(10.dp))
            TextButton(onClick = onFindPeople) {
                Icon(Icons.Filled.PersonSearch, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Найти по имени, @юзернейму или email")
            }
        }
    }
}

fun resolveDirectPeer(
    conversation: Conversation,
    currentUserId: String,
    usersById: Map<String, PublicUserProfile>
): PublicUserProfile? {
    if (conversation.isGroup || conversation.isSavedMessages(currentUserId)) return null
    val peerUid = conversation.memberUids.firstOrNull { it != currentUserId } ?: return null
    return usersById[peerUid]
}

fun resolveConversationTitle(conversation: Conversation, currentUserId: String): String {
    if (conversation.isSavedMessages(currentUserId)) return "Избранное"
    if (conversation.isGroup) return conversation.title
    val otherName = conversation.memberNames
        .entries
        .firstOrNull { it.key != currentUserId }
        ?.value
    return otherName ?: conversation.title.ifBlank { "Избранное" }
}

fun formatChatTime(timestamp: Timestamp?): String =
    TimeFormatters.formatTimeHm(timestamp)

fun formatChatListTimestamp(timestamp: Timestamp?): String =
    TimeFormatters.formatChatListTimestamp(timestamp)
