package com.example.data.repository

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

data class SavedAccount(
    val uid: String,
    val email: String,
    val displayName: String,
    val handle: String = "",
    val avatarBase64: String = "",
    val avatarColorIndex: Int = 0,
    val role: String = "user",
    val keyFingerprint: String = "",
    val lastActiveAtMs: Long = System.currentTimeMillis()
)

class SavedAccountsStore(
    context: Context,
    eagerLoad: Boolean = true
) {

    private val prefs = context.applicationContext.getSharedPreferences(
        PREFS_NAME,
        Context.MODE_PRIVATE
    )

    @Volatile
    private var isLoaded = false

    private val _accounts = MutableStateFlow<List<SavedAccount>>(emptyList())
    val accounts: StateFlow<List<SavedAccount>> = _accounts.asStateFlow()

    init {
        if (eagerLoad) {
            ensureLoaded()
        }
    }

    @Synchronized
    private fun ensureLoaded() {
        if (isLoaded) return
        _accounts.value = readStoredAccounts()
        isLoaded = true
    }

    suspend fun ensureLoadedAsync() {
        if (isLoaded) return
        withContext(Dispatchers.IO) {
            ensureLoaded()
        }
    }

    fun canAddAnotherAccount(): Boolean {
        ensureLoaded()
        return _accounts.value.size < MAX_ACCOUNTS
    }

    fun hasAccountForEmail(email: String): Boolean {
        if (email.isBlank()) return false
        ensureLoaded()
        return _accounts.value.any { it.email.equals(email.trim(), ignoreCase = true) }
    }

    @Synchronized
    fun upsertAccount(account: SavedAccount) {
        if (account.uid.isBlank()) return
        ensureLoaded()
        val current = _accounts.value.toMutableList()
        val existingIdx = current.indexOfFirst { it.uid == account.uid }
        if (existingIdx >= 0) {
            current[existingIdx] = account
        } else {
            if (current.size >= MAX_ACCOUNTS) {
                val oldestIdx = current.indices.minByOrNull { current[it].lastActiveAtMs } ?: (current.lastIndex)
                current.removeAt(oldestIdx)
            }
            current.add(account)
        }
        val sorted = current
            .sortedByDescending { it.lastActiveAtMs }
            .take(MAX_ACCOUNTS)
        persistAccounts(sorted)
        _accounts.value = sorted
    }

    @Synchronized
    fun removeAccount(uid: String) {
        if (uid.isBlank()) return
        ensureLoaded()
        val updated = _accounts.value.filterNot { it.uid == uid }
        persistAccounts(updated)
        _accounts.value = updated
    }

    private fun readStoredAccounts(): List<SavedAccount> {
        val raw = runCatching { prefs.getString(KEY_ACCOUNTS_JSON, null) }.getOrNull()
        if (raw.isNullOrBlank()) return emptyList()
        return runCatching {
            val array = JSONArray(raw)
            buildList {
                for (i in 0 until array.length()) {
                    val obj = array.optJSONObject(i) ?: continue
                    val uid = obj.optString("uid")
                    if (uid.isBlank()) continue
                    add(
                        SavedAccount(
                            uid = uid,
                            email = obj.optString("email"),
                            displayName = obj.optString("displayName"),
                            handle = obj.optString("handle"),
                            avatarBase64 = obj.optString("avatarBase64"),
                            avatarColorIndex = obj.optInt("avatarColorIndex", 0),
                            role = obj.optString("role", "user"),
                            keyFingerprint = obj.optString("keyFingerprint"),
                            lastActiveAtMs = obj.optLong("lastActiveAtMs", 0L)
                        )
                    )
                }
            }
                .distinctBy { it.uid }
                .sortedByDescending { it.lastActiveAtMs }
                .take(MAX_ACCOUNTS)
        }.getOrDefault(emptyList())
    }

    private fun persistAccounts(accounts: List<SavedAccount>) {
        val array = JSONArray()
        accounts.take(MAX_ACCOUNTS).forEach { acc ->
            val obj = JSONObject().apply {
                put("uid", acc.uid)
                put("email", acc.email)
                put("displayName", acc.displayName)
                put("handle", acc.handle)
                put("avatarBase64", acc.avatarBase64)
                put("avatarColorIndex", acc.avatarColorIndex)
                put("role", acc.role)
                put("keyFingerprint", acc.keyFingerprint)
                put("lastActiveAtMs", acc.lastActiveAtMs)
            }
            array.put(obj)
        }
        prefs.edit().putString(KEY_ACCOUNTS_JSON, array.toString()).apply()
    }

    companion object {
        const val MAX_ACCOUNTS = 4
        private const val PREFS_NAME = "spox_saved_accounts"
        private const val KEY_ACCOUNTS_JSON = "saved_accounts_v1"
    }
}
