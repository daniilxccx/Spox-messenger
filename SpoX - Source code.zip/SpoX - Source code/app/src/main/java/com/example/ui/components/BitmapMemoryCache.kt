package com.example.ui.components

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import android.util.LruCache
import androidx.annotation.DrawableRes
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Thread-safe in-memory LRU cache and background downsampling decoder for avatars,
 * inline image attachments, fullscreen previews, and custom chat wallpapers.
 * Prevents synchronous Main-thread BitmapFactory decoding during scroll and swipe gestures.
 */
object BitmapMemoryCache {

    private const val MAX_AVATAR_CACHE_ENTRIES = 64
    private const val MAX_MEDIA_CACHE_ENTRIES = 48
    private const val MAX_WALLPAPER_CACHE_ENTRIES = 4
    private const val MAX_DRAWABLE_CACHE_ENTRIES = 8

    private val avatarCache = object : LruCache<String, ImageBitmap>(MAX_AVATAR_CACHE_ENTRIES) {}
    private val mediaThumbCache = object : LruCache<String, ImageBitmap>(MAX_MEDIA_CACHE_ENTRIES) {}
    private val wallpaperCache = object : LruCache<String, ImageBitmap>(MAX_WALLPAPER_CACHE_ENTRIES) {}
    private val drawableCache = object : LruCache<String, ImageBitmap>(MAX_DRAWABLE_CACHE_ENTRIES) {}

    private fun avatarKey(avatarBase64: String): String =
        "${avatarBase64.length}_${avatarBase64.hashCode()}_${avatarBase64.take(24)}"

    private fun mediaKey(messageId: String, sizeBytes: Int, maxDim: Int): String =
        "${messageId}_${sizeBytes}_$maxDim"

    private fun wallpaperKey(path: String, version: Long, maxDim: Int): String =
        "${path}_${version}_$maxDim"

    fun getCachedAvatar(avatarBase64: String): ImageBitmap? {
        if (avatarBase64.isBlank()) return null
        return avatarCache.get(avatarKey(avatarBase64))
    }

    suspend fun decodeAvatar(avatarBase64: String, maxDimensionPx: Int = 256): ImageBitmap? {
        if (avatarBase64.isBlank()) return null
        val key = avatarKey(avatarBase64)
        avatarCache.get(key)?.let { return it }

        return withContext(Dispatchers.Default) {
            avatarCache.get(key)?.let { return@withContext it }
            runCatching {
                val bytes = Base64.decode(avatarBase64, Base64.DEFAULT)
                val decoded = decodeSampledFromBytes(bytes, maxDimensionPx)?.asImageBitmap()
                if (decoded != null) {
                    avatarCache.put(key, decoded)
                }
                decoded
            }.getOrNull()
        }
    }

    fun getCachedMediaThumb(messageId: String, bytesSize: Int, maxDimensionPx: Int = 720): ImageBitmap? {
        if (messageId.isBlank() || bytesSize <= 0) return null
        return mediaThumbCache.get(mediaKey(messageId, bytesSize, maxDimensionPx))
    }

    suspend fun decodeMediaThumb(
        messageId: String,
        bytes: ByteArray,
        maxDimensionPx: Int = 720
    ): ImageBitmap? {
        if (bytes.isEmpty()) return null
        val key = mediaKey(messageId, bytes.size, maxDimensionPx)
        mediaThumbCache.get(key)?.let { return it }

        return withContext(Dispatchers.Default) {
            mediaThumbCache.get(key)?.let { return@withContext it }
            runCatching {
                val decoded = decodeSampledFromBytes(bytes, maxDimensionPx)?.asImageBitmap()
                if (decoded != null) {
                    mediaThumbCache.put(key, decoded)
                }
                decoded
            }.getOrNull()
        }
    }

    suspend fun decodeFullImage(bytes: ByteArray, maxDimensionPx: Int = 1800): ImageBitmap? {
        if (bytes.isEmpty()) return null
        return withContext(Dispatchers.Default) {
            runCatching {
                decodeSampledFromBytes(bytes, maxDimensionPx)?.asImageBitmap()
            }.getOrNull()
        }
    }

    fun getCachedWallpaper(path: String, version: Long, maxDimensionPx: Int = 1600): ImageBitmap? {
        if (path.isBlank()) return null
        return wallpaperCache.get(wallpaperKey(path, version, maxDimensionPx))
    }

    suspend fun decodeWallpaper(
        path: String,
        version: Long,
        maxDimensionPx: Int = 1600
    ): ImageBitmap? {
        if (path.isBlank()) return null
        val key = wallpaperKey(path, version, maxDimensionPx)
        wallpaperCache.get(key)?.let { return it }

        return withContext(Dispatchers.IO) {
            wallpaperCache.get(key)?.let { return@withContext it }
            runCatching {
                val file = File(path)
                if (!file.exists()) return@withContext null
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeFile(file.absolutePath, bounds)
                val opts = BitmapFactory.Options().apply {
                    inSampleSize = computeSampleSize(bounds.outWidth, bounds.outHeight, maxDimensionPx)
                    inPreferredConfig = Bitmap.Config.RGB_565
                }
                val bmp = BitmapFactory.decodeFile(file.absolutePath, opts) ?: return@withContext null
                bmp.asImageBitmap().also { wallpaperCache.put(key, it) }
            }.getOrNull()
        }
    }

    fun getCachedDrawable(@DrawableRes resId: Int, maxDimensionPx: Int = 960): ImageBitmap? {
        return drawableCache.get("${resId}_$maxDimensionPx")
    }

    suspend fun decodeDrawable(
        context: Context,
        @DrawableRes resId: Int,
        maxDimensionPx: Int = 960
    ): ImageBitmap? {
        val key = "${resId}_$maxDimensionPx"
        drawableCache.get(key)?.let { return it }

        val appContext = context.applicationContext
        return withContext(Dispatchers.Default) {
            drawableCache.get(key)?.let { return@withContext it }
            runCatching {
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeResource(appContext.resources, resId, bounds)
                val opts = BitmapFactory.Options().apply {
                    inSampleSize = computeSampleSize(bounds.outWidth, bounds.outHeight, maxDimensionPx)
                }
                val bmp = BitmapFactory.decodeResource(appContext.resources, resId, opts)
                    ?: return@withContext null
                bmp.asImageBitmap().also { drawableCache.put(key, it) }
            }.getOrNull()
        }
    }

    private fun decodeSampledFromBytes(bytes: ByteArray, maxDimensionPx: Int): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        val opts = BitmapFactory.Options().apply {
            inSampleSize = computeSampleSize(bounds.outWidth, bounds.outHeight, maxDimensionPx)
        }
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
    }

    internal fun computeSampleSize(width: Int, height: Int, maxDim: Int): Int {
        if (width <= 0 || height <= 0 || maxDim <= 0) return 1
        var sample = 1
        val maxSide = maxOf(width, height)
        while ((maxSide / sample) > maxDim) {
            sample *= 2
        }
        return sample.coerceAtLeast(1)
    }
}
