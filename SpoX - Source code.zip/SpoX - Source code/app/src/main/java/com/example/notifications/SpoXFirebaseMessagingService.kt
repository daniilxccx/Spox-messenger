package com.example.notifications

import android.util.Log
import com.example.R
import com.example.crypto.CryptoManager
import com.example.data.model.PublicUserProfile
import com.example.data.repository.ChatRepository
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.math.abs

class SpoXFirebaseMessagingService : FirebaseMessagingService() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        Log.d(TAG, "Refreshed FCM token")
        val appContext = applicationContext
        serviceScope.launch {
            runCatching {
                NotificationPreferences.saveFcmToken(appContext, token)
                val session = com.example.data.repository.FirebaseSessionManager.ensureInitialized(appContext)
                val activeAuth = session?.auth ?: Firebase.auth
                val currentUid = activeAuth.currentUser?.uid ?: return@launch
                val db = com.example.data.repository.FirebaseSessionManager.getActiveFirestore(appContext)
                    ?: FirebaseFirestore.getInstance(appContext.getString(R.string.firestore_database_id))
                ChatRepository(db = db, auth = activeAuth).updateFcmToken(currentUid, token)
            }.onFailure { err ->
                Log.w(TAG, "Failed to upload refreshed FCM token: ${err.message}")
            }
        }
    }

    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        super.onMessageReceived(remoteMessage)
        val data = remoteMessage.data
        val notification = remoteMessage.notification

        val session = com.example.data.repository.FirebaseSessionManager.ensureInitialized(applicationContext)
        val activeAuth = session?.auth ?: Firebase.auth
        val currentUid = runCatching { activeAuth.currentUser?.uid }.getOrNull().orEmpty()
        val db = if (currentUid.isNotBlank()) {
            com.example.data.repository.FirebaseSessionManager.getActiveFirestore(applicationContext)
                ?: runCatching {
                    FirebaseFirestore.getInstance(applicationContext.getString(R.string.firestore_database_id))
                }.getOrNull()
        } else {
            null
        }

        val payloadType = data["type"].orEmpty().lowercase()
        val callId = data["callId"].orEmpty()
        val chatId = data["chatId"].orEmpty()

        if (payloadType == "call" || callId.isNotBlank()) {
            val resolvedCallId = callId.ifBlank { "fcm_call_${System.currentTimeMillis()}" }
            val callerId = data["callerId"].orEmpty()
            val callerProfile = fetchProfileBestEffort(db, activeAuth, currentUid, callerId)
            val callerName = data["callerName"].orEmpty()
                .ifBlank { callerProfile?.displayName.orEmpty() }
                .ifBlank { notification?.title ?: "Входящий звонок" }
            val conversationTitle = data["conversationTitle"].orEmpty().ifBlank { "SpoX" }
            val isGroupCall = data["isGroupCall"]?.toBooleanStrictOrNull() ?: false
            val callType = data["callType"].orEmpty().ifBlank { "audio" }

            SpoXNotificationHelper.showIncomingCallNotification(
                context = applicationContext,
                callId = resolvedCallId,
                callerName = callerName,
                conversationTitle = conversationTitle,
                isGroupCall = isGroupCall,
                callType = callType,
                callerRole = data["callerRole"].orEmpty()
                    .ifBlank { callerProfile?.role.orEmpty() }
                    .ifBlank { "user" },
                customRoleName = data["customRoleName"].orEmpty()
                    .ifBlank { callerProfile?.customRoleName.orEmpty() },
                customRoleBadge = data["customRoleBadge"].orEmpty()
                    .ifBlank { callerProfile?.customRoleBadge.orEmpty() },
                callerAvatarBase64 = data["callerAvatarBase64"].orEmpty()
                    .ifBlank { callerProfile?.avatarBase64.orEmpty() },
                callerAvatarColorIndex = data["callerAvatarColorIndex"]?.toIntOrNull()
                    ?: callerProfile?.avatarColorIndex?.toInt()
                    ?: abs(callerName.hashCode())
            )
            return
        }

        val resolvedChatId = chatId.ifBlank { "general" }
        if (ActiveChatTracker.isActivelyViewingChat(resolvedChatId)) {
            return
        }

        val senderId = data["senderId"].orEmpty()
        val senderProfile = fetchProfileBestEffort(db, activeAuth, currentUid, senderId)

        val title = data["title"].orEmpty()
            .ifBlank { notification?.title ?: "SpoX" }
        val senderName = data["senderName"].orEmpty()
            .ifBlank { senderProfile?.displayName.orEmpty() }
            .ifBlank { title }
        val rawBody = data["body"].orEmpty()
            .ifBlank { notification?.body.orEmpty() }
        val decryptedBody = if (
            resolvedChatId != "general" &&
            currentUid.isNotBlank() &&
            db != null &&
            (rawBody.isBlank() || rawBody == "Новое зашифрованное сообщение" || rawBody == "Зашифрованное сообщение")
        ) {
            fetchDecryptedLatestPreviewBestEffort(db, activeAuth, currentUid, resolvedChatId, senderId)
        } else {
            null
        }
        val body = decryptedBody
            ?.takeIf { it.isNotBlank() }
            ?: rawBody.ifBlank { "Новое зашифрованное сообщение" }
        val unreadCount = data["unreadCount"]?.toIntOrNull()?.coerceAtLeast(1) ?: 1
        val sentAtMs = data["sentAtMs"]?.toLongOrNull() ?: System.currentTimeMillis()
        val isGroup = data["isGroup"]?.toBooleanStrictOrNull() ?: (title != senderName && title != "SpoX")

        if (currentUid.isNotBlank() && resolvedChatId != "general") {
            NotificationPreferences.markChatNotified(applicationContext, currentUid, resolvedChatId, sentAtMs)
        }

        SpoXNotificationHelper.showMessageNotification(
            context = applicationContext,
            chatId = resolvedChatId,
            chatTitle = title,
            body = body,
            unreadCount = unreadCount,
            senderName = senderName,
            senderRole = data["senderRole"].orEmpty()
                .ifBlank { senderProfile?.role.orEmpty() }
                .ifBlank { "user" },
            customRoleName = data["customRoleName"].orEmpty()
                .ifBlank { senderProfile?.customRoleName.orEmpty() },
            customRoleBadge = data["customRoleBadge"].orEmpty()
                .ifBlank { senderProfile?.customRoleBadge.orEmpty() },
            senderAvatarBase64 = data["senderAvatarBase64"].orEmpty()
                .ifBlank { senderProfile?.avatarBase64.orEmpty() },
            senderAvatarColorIndex = data["senderAvatarColorIndex"]?.toIntOrNull()
                ?: senderProfile?.avatarColorIndex?.toInt()
                ?: abs(senderName.hashCode()),
            isGroup = isGroup,
            timestampMs = sentAtMs
        )
    }

    private fun fetchProfileBestEffort(
        db: FirebaseFirestore?,
        auth: com.google.firebase.auth.FirebaseAuth,
        currentUid: String,
        targetUid: String
    ): PublicUserProfile? {
        if (db == null || currentUid.isBlank() || targetUid.isBlank()) return null
        return runCatching {
            runBlocking(Dispatchers.IO) {
                withTimeoutOrNull(1_500L) {
                    ChatRepository(db = db, auth = auth).getPublicProfile(targetUid)
                }
            }
        }.getOrNull()
    }

    private fun fetchDecryptedLatestPreviewBestEffort(
        db: FirebaseFirestore,
        auth: com.google.firebase.auth.FirebaseAuth,
        currentUid: String,
        chatId: String,
        senderId: String
    ): String? {
        return runCatching {
            runBlocking(Dispatchers.IO) {
                withTimeoutOrNull(2_000L) {
                    val repo = ChatRepository(
                        db = db,
                        crypto = CryptoManager(applicationContext, accountScope = currentUid),
                        auth = auth
                    )
                    val conv = repo.getConversationById(chatId) ?: return@withTimeoutOrNull null
                    repo.resolveLatestIncomingMessagePreview(
                        conversation = conv,
                        currentUserId = currentUid,
                        expectedSenderId = senderId
                    )
                }
            }
        }.getOrNull()
    }

    private companion object {
        const val TAG = "SpoXFcmService"
    }
}
