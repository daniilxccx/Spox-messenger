package com.example.util

import com.google.firebase.Timestamp
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * Thread-local cached date/time formatters and calendars to avoid per-item
 * SimpleDateFormat and Calendar allocations inside Compose LazyColumn / LazyRow items.
 */
object TimeFormatters {
    private val ruLocale = Locale.forLanguageTag("ru")

    private val timeHmFormat = object : ThreadLocal<SimpleDateFormat>() {
        override fun initialValue(): SimpleDateFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
    }
    private val shortDateFormat = object : ThreadLocal<SimpleDateFormat>() {
        override fun initialValue(): SimpleDateFormat = SimpleDateFormat("dd.MM", Locale.getDefault())
    }
    private val callDateTimeFormat = object : ThreadLocal<SimpleDateFormat>() {
        override fun initialValue(): SimpleDateFormat = SimpleDateFormat("d MMM, HH:mm", ruLocale)
    }
    private val dayMonthFormat = object : ThreadLocal<SimpleDateFormat>() {
        override fun initialValue(): SimpleDateFormat = SimpleDateFormat("d MMMM", ruLocale)
    }
    private val dayMonthYearFormat = object : ThreadLocal<SimpleDateFormat>() {
        override fun initialValue(): SimpleDateFormat = SimpleDateFormat("d MMMM yyyy", ruLocale)
    }

    private val calA = object : ThreadLocal<Calendar>() {
        override fun initialValue(): Calendar = Calendar.getInstance()
    }
    private val calB = object : ThreadLocal<Calendar>() {
        override fun initialValue(): Calendar = Calendar.getInstance()
    }

    fun formatTimeHm(timestamp: Timestamp?): String {
        if (timestamp == null) return ""
        return timeHmFormat.get()!!.format(timestamp.toDate())
    }

    fun formatChatListTimestamp(timestamp: Timestamp?): String {
        if (timestamp == null) return ""
        val date = timestamp.toDate()
        val msgCal = calA.get()!!.apply { time = date }
        val nowCal = calB.get()!!.apply { timeInMillis = System.currentTimeMillis() }
        val isSameDay = msgCal.get(Calendar.YEAR) == nowCal.get(Calendar.YEAR) &&
            msgCal.get(Calendar.DAY_OF_YEAR) == nowCal.get(Calendar.DAY_OF_YEAR)
        if (isSameDay) {
            return timeHmFormat.get()!!.format(date)
        }
        nowCal.add(Calendar.DAY_OF_YEAR, -1)
        val isYesterday = msgCal.get(Calendar.YEAR) == nowCal.get(Calendar.YEAR) &&
            msgCal.get(Calendar.DAY_OF_YEAR) == nowCal.get(Calendar.DAY_OF_YEAR)
        if (isYesterday) {
            return "Вчера"
        }
        return shortDateFormat.get()!!.format(date)
    }

    fun formatCallTimestamp(timestamp: Timestamp?): String {
        if (timestamp == null) return ""
        val date = timestamp.toDate()
        val callCal = calA.get()!!.apply { time = date }
        val nowCal = calB.get()!!.apply { timeInMillis = System.currentTimeMillis() }
        val sameDay = callCal.get(Calendar.YEAR) == nowCal.get(Calendar.YEAR) &&
            callCal.get(Calendar.DAY_OF_YEAR) == nowCal.get(Calendar.DAY_OF_YEAR)
        return if (sameDay) {
            timeHmFormat.get()!!.format(date)
        } else {
            callDateTimeFormat.get()!!.format(date)
        }
    }

    fun formatDateDivider(timestamp: Timestamp): String {
        val date = timestamp.toDate()
        val msgCal = calA.get()!!.apply { time = date }
        val nowCal = calB.get()!!.apply { timeInMillis = System.currentTimeMillis() }
        val msgYear = msgCal.get(Calendar.YEAR)
        val msgDay = msgCal.get(Calendar.DAY_OF_YEAR)
        val nowYear = nowCal.get(Calendar.YEAR)
        val nowDay = nowCal.get(Calendar.DAY_OF_YEAR)

        if (msgYear == nowYear && msgDay == nowDay) {
            return "Сегодня"
        }
        nowCal.add(Calendar.DAY_OF_YEAR, -1)
        if (msgYear == nowCal.get(Calendar.YEAR) && msgDay == nowCal.get(Calendar.DAY_OF_YEAR)) {
            return "Вчера"
        }
        return if (msgYear == nowYear) {
            dayMonthFormat.get()!!.format(date)
        } else {
            dayMonthYearFormat.get()!!.format(date)
        }
    }

    fun isSameCalendarDay(a: Timestamp?, b: Timestamp?): Boolean {
        if (a == null || b == null) return false
        val diffMs = kotlin.math.abs(a.seconds - b.seconds)
        if (diffMs >= 48 * 3600L) return false
        val c1 = calA.get()!!.apply { time = Date(a.seconds * 1000L) }
        val c2 = calB.get()!!.apply { time = Date(b.seconds * 1000L) }
        return c1.get(Calendar.YEAR) == c2.get(Calendar.YEAR) &&
            c1.get(Calendar.DAY_OF_YEAR) == c2.get(Calendar.DAY_OF_YEAR)
    }
}
