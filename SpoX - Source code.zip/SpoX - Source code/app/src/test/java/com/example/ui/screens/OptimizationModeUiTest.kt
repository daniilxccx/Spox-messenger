package com.example.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import com.example.data.model.AppThemeMode
import com.example.data.model.ChatAppearanceConfig
import com.example.ui.components.CipherLaunchSplashOverlay
import com.example.ui.components.CipherLoadingStateView
import com.example.ui.components.MainBottomTab
import com.example.ui.components.SpoXBottomNavigationBar
import com.example.ui.components.UserAvatar
import com.example.ui.theme.CipherChatTheme
import com.example.ui.theme.isLiquidGlassActive
import org.junit.Assert.assertFalse
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class OptimizationModeUiTest {

    @get:Rule
    val composeRule = createComposeRule()

    @Test
    fun resourceSavingMode_rendersNavigationLoadingSplashAndAvatarSmoothly() {
        var glassActive = true
        val optimizedConfig = ChatAppearanceConfig(
            liquidGlassEnabled = true,
            resourceSavingMode = true,
            smoothStoriesAppearance = true,
            smoothChatsAppearance = true,
            smoothChatsPanelAppearance = true,
            smoothChatMessagesAppearance = true
        )

        composeRule.setContent {
            CipherChatTheme(
                themeMode = AppThemeMode.DARK,
                appearanceConfig = optimizedConfig
            ) {
                glassActive = isLiquidGlassActive()
                Column {
                    UserAvatar(
                        name = "Alex Test",
                        showOnlineDot = true
                    )
                    SpoXBottomNavigationBar(
                        selectedTab = MainBottomTab.CHATS,
                        onSelectTab = {},
                        activeCallsCount = 1,
                        unreadChatsCount = 4
                    )
                    CipherLoadingStateView(label = "Быстрая загрузка")
                }
                CipherLaunchSplashOverlay(visible = false)
            }
        }

        composeRule.waitForIdle()
        assertFalse(glassActive)
        composeRule.onNodeWithText("AT").assertIsDisplayed()
        composeRule.onNodeWithTag("bottom_nav_bar").assertIsDisplayed()
        composeRule.onNodeWithTag("bottom_tab_calls").assertIsDisplayed()
        composeRule.onNodeWithTag("bottom_tab_chats").assertIsDisplayed()
        composeRule.onNodeWithTag("bottom_tab_settings").assertIsDisplayed()
        composeRule.onNodeWithText("Быстрая загрузка").assertIsDisplayed()
    }
}
