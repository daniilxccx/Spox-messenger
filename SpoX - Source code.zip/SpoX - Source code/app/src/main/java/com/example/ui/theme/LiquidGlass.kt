package com.example.ui.theme

import android.os.Build
import android.view.View
import android.view.WindowManager
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.BottomSheetDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawOutline
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.DialogWindowProvider
import com.example.data.model.AppThemeMode

@Composable
fun isLiquidGlassActive(): Boolean {
    val appearance = LocalChatAppearance.current
    return appearance.liquidGlassEnabled && !appearance.resourceSavingMode
}

@Composable
fun isAppDarkTheme(): Boolean {
    return when (LocalChatAppearance.current.themeMode) {
        AppThemeMode.DARK -> true
        AppThemeMode.LIGHT -> false
        AppThemeMode.SYSTEM -> isSystemInDarkTheme()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun liquidGlassSheetContainerColor(): Color {
    return if (isLiquidGlassActive()) {
        val isDark = isAppDarkTheme()
        MaterialTheme.colorScheme.surfaceContainer.copy(alpha = if (isDark) 0.78f else 0.84f)
    } else {
        BottomSheetDefaults.ContainerColor
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun liquidGlassSheetScrimColor(): Color {
    return if (isLiquidGlassActive()) {
        val isDark = isAppDarkTheme()
        Color.Black.copy(alpha = if (isDark) 0.34f else 0.24f)
    } else {
        BottomSheetDefaults.ScrimColor
    }
}

@Composable
fun liquidGlassMenuContainerColor(): Color {
    return if (isLiquidGlassActive()) {
        val isDark = isAppDarkTheme()
        MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = if (isDark) 0.80f else 0.86f)
    } else {
        MaterialTheme.colorScheme.surfaceContainerHigh
    }
}

@Composable
fun liquidGlassDialogContainerColor(): Color {
    return if (isLiquidGlassActive()) {
        val isDark = isAppDarkTheme()
        MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = if (isDark) 0.80f else 0.86f)
    } else {
        MaterialTheme.colorScheme.surfaceContainerHigh
    }
}

/**
 * Applies hardware window background blur behind ModalBottomSheets and Dialogs on Android 12+ (API 31+)
 * so the underlying messenger content genuinely blurs through translucent glass sheets.
 */
@Composable
fun ApplyLiquidGlassWindowBlur(enabled: Boolean = isLiquidGlassActive()) {
    val view = LocalView.current
    val isDark = isAppDarkTheme()
    SideEffect {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return@SideEffect
        runCatching {
            var current: View? = view
            var window: android.view.Window? = null
            while (current != null) {
                val parent = current.parent
                if (parent is DialogWindowProvider) {
                    window = parent.window
                    break
                }
                current = parent as? View
            }
            window?.let { w ->
                val attrs = w.attributes
                if (enabled) {
                    w.addFlags(WindowManager.LayoutParams.FLAG_BLUR_BEHIND)
                    attrs.blurBehindRadius = 48
                    attrs.dimAmount = if (isDark) 0.22f else 0.14f
                    w.attributes = attrs
                    w.setBackgroundBlurRadius(36)
                } else {
                    w.clearFlags(WindowManager.LayoutParams.FLAG_BLUR_BEHIND)
                    attrs.blurBehindRadius = 0
                    w.attributes = attrs
                    w.setBackgroundBlurRadius(0)
                }
            }
        }
    }
}

/**
 * Telegram-style optical Liquid Glass modifier:
 * 1) Translucent icy/smoked crystal tint so vibrant backdrops and scrolling content shine through,
 * 2) Curved upper specular reflection, diagonal refraction gleam & bottom caustic bounce,
 * 3) Crisp two-layer 45-degree luminous optical rim border.
 */
fun Modifier.liquidGlassSurface(
    shape: Shape,
    tintColor: Color? = null,
    accentGlow: Color? = null,
    isHighlighted: Boolean = false,
    tintAlpha: Float? = null,
    borderWidth: Dp = 1.dp
): Modifier = composed {
    val isDark = isAppDarkTheme()
    val primary = accentGlow ?: MaterialTheme.colorScheme.primary
    val secondary = MaterialTheme.colorScheme.secondary

    val crystalTint = if (isDark) {
        val rawTint = tintColor ?: MaterialTheme.colorScheme.surfaceContainer
        if (isHighlighted) lerp(rawTint, primary, 0.14f) else rawTint
    } else {
        val rawTint = tintColor ?: MaterialTheme.colorScheme.surface
        if (isHighlighted) lerp(rawTint, primary, 0.10f) else rawTint
    }

    val resolvedAlpha = tintAlpha ?: when {
        isHighlighted && isDark -> 0.72f
        isHighlighted -> 0.78f
        isDark -> 0.62f
        else -> 0.68f
    }

    val glassBodyColor = crystalTint.copy(alpha = resolvedAlpha)

    val topSheenColor = Color.White.copy(
        alpha = when {
            isHighlighted && isDark -> 0.07f
            isHighlighted -> 0.24f
            isDark -> 0.045f
            else -> 0.18f
        }
    )
    val midRefractionColor = if (isDark) {
        secondary.copy(alpha = if (isHighlighted) 0.04f else 0.02f)
    } else {
        Color.White.copy(alpha = 0.06f)
    }
    val bottomBounceColor = if (isDark) {
        primary.copy(alpha = if (isHighlighted) 0.05f else 0.025f)
    } else {
        Color.White.copy(alpha = 0.10f)
    }

    val rimStart = Color.White.copy(alpha = if (isDark) 0.22f else 0.64f)
    val rimMid = if (isHighlighted) {
        primary.copy(alpha = if (isDark) 0.34f else 0.48f)
    } else {
        Color.White.copy(alpha = if (isDark) 0.07f else 0.24f)
    }
    val rimEnd = lerp(Color.White, primary, 0.38f).copy(
        alpha = if (isDark) 0.18f else 0.44f
    )
    val innerRimColor = Color.White.copy(alpha = if (isDark) 0.05f else 0.16f)

    this
        .clip(shape)
        .drawWithCache {
            val outline = shape.createOutline(size, layoutDirection, this)
            val strokePx = borderWidth.toPx()

            val bodyBrush = Brush.verticalGradient(
                colorStops = arrayOf(
                    0.00f to topSheenColor,
                    0.26f to midRefractionColor,
                    0.75f to Color.Transparent,
                    1.00f to bottomBounceColor
                )
            )
            val diagonalSheenBrush = Brush.linearGradient(
                colorStops = arrayOf(
                    0.00f to Color.White.copy(alpha = if (isDark) 0.03f else 0.08f),
                    0.35f to Color.Transparent,
                    0.75f to Color.Transparent,
                    1.00f to primary.copy(alpha = if (isDark) 0.04f else 0.06f)
                ),
                start = Offset.Zero,
                end = Offset(size.width, size.height)
            )
            val rimBrush = Brush.linearGradient(
                colors = listOf(rimStart, rimMid, rimEnd),
                start = Offset.Zero,
                end = Offset(size.width, size.height)
            )
            val topHighlightBrush = Brush.verticalGradient(
                colors = listOf(
                    Color.White.copy(alpha = if (isDark) 0.04f else 0.14f),
                    Color.Transparent
                ),
                startY = 0f,
                endY = (size.height * 0.20f).coerceAtLeast(1f)
            )

            onDrawWithContent {
                drawOutline(outline = outline, color = glassBodyColor)
                drawOutline(outline = outline, brush = bodyBrush)
                drawOutline(outline = outline, brush = diagonalSheenBrush)
                drawOutline(outline = outline, brush = topHighlightBrush)
                drawContent()
                drawOutline(
                    outline = outline,
                    color = innerRimColor,
                    style = Stroke(width = strokePx * 1.4f)
                )
                drawOutline(
                    outline = outline,
                    brush = rimBrush,
                    style = Stroke(width = strokePx)
                )
            }
        }
}

/**
 * Subtle atmospheric edge fade behind floating glass TopBar / BottomBar so scrolled items stay
 * readable without washing out or brightening the theme.
 */
fun Modifier.liquidGlassEdgeScrim(
    isTop: Boolean,
    scrimColor: Color
): Modifier = drawWithCache {
    val brush = if (isTop) {
        Brush.verticalGradient(
            colorStops = arrayOf(
                0.00f to scrimColor.copy(alpha = 0.44f),
                0.65f to scrimColor.copy(alpha = 0.18f),
                1.00f to Color.Transparent
            ),
            startY = 0f,
            endY = size.height.coerceAtLeast(1f)
        )
    } else {
        Brush.verticalGradient(
            colorStops = arrayOf(
                0.00f to Color.Transparent,
                0.35f to scrimColor.copy(alpha = 0.18f),
                1.00f to scrimColor.copy(alpha = 0.46f)
            ),
            startY = 0f,
            endY = size.height.coerceAtLeast(1f)
        )
    }
    onDrawBehind {
        drawRect(brush = brush)
    }
}
