package com.example.ui.components

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Done
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Stars
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.data.model.CallSession
import com.example.data.model.ModerationStatus
import com.example.data.model.UserPresenceStatus
import com.example.data.model.UserRole
import com.example.ui.theme.AvatarPalette
import com.example.ui.theme.LocalChatAppearance
import com.example.ui.theme.LocalPresenceColors
import com.example.ui.theme.isLiquidGlassActive
import com.example.ui.theme.liquidGlassSurface
import com.example.ui.viewmodel.NetworkSyncPhase
import com.example.ui.viewmodel.TopStatusUiState
import kotlin.math.abs

private val AVATAR_WHITESPACE_REGEX = Regex("\\s+")

@Composable
fun UserAvatar(
    name: String,
    avatarBase64: String = "",
    colorIndex: Int = abs(name.hashCode()) % AvatarPalette.size,
    isGroup: Boolean = false,
    size: Dp = 46.dp,
    showOnlineDot: Boolean = false,
    presenceStatus: UserPresenceStatus? = null
) {
    val bgColor = AvatarPalette[abs(colorIndex) % AvatarPalette.size]
    val secondaryTint = AvatarPalette[(abs(colorIndex) + 2) % AvatarPalette.size]
    val initials = remember(name) {
        name.trim()
            .split(AVATAR_WHITESPACE_REGEX)
            .filter { it.isNotBlank() }
            .take(2)
            .joinToString("") { it.first().uppercaseChar().toString() }
            .ifBlank { "?" }
    }

    val avatarBitmap by produceState<ImageBitmap?>(
        initialValue = if (isGroup || avatarBase64.isBlank()) null else BitmapMemoryCache.getCachedAvatar(avatarBase64),
        key1 = avatarBase64,
        key2 = isGroup
    ) {
        value = if (isGroup || avatarBase64.isBlank()) {
            null
        } else {
            BitmapMemoryCache.decodeAvatar(avatarBase64)
        }
    }

    val effectivePresence = presenceStatus ?: if (showOnlineDot) UserPresenceStatus.ONLINE else null
    val presenceColors = LocalPresenceColors.current
    val avatarBrush = remember(bgColor, secondaryTint) {
        Brush.linearGradient(
            listOf(
                bgColor.copy(alpha = 0.28f),
                secondaryTint.copy(alpha = 0.16f)
            )
        )
    }

    Box(modifier = Modifier.size(size)) {
        Surface(
            shape = CircleShape,
            color = Color.Transparent,
            border = BorderStroke(
                width = if (effectivePresence == UserPresenceStatus.ONLINE) 1.5.dp else 1.dp,
                color = if (effectivePresence == UserPresenceStatus.ONLINE) {
                    presenceColors.online.copy(alpha = 0.65f)
                } else {
                    bgColor.copy(alpha = 0.38f)
                }
            ),
            modifier = Modifier.size(size)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(avatarBrush),
                contentAlignment = Alignment.Center
            ) {
                when {
                    isGroup -> {
                        Icon(
                            imageVector = Icons.Filled.Groups,
                            contentDescription = "Групповой чат",
                            tint = bgColor,
                            modifier = Modifier.size(size * 0.52f)
                        )
                    }
                    else -> {
                        val resolvedAvatar = avatarBitmap
                        if (resolvedAvatar != null) {
                            Image(
                                bitmap = resolvedAvatar,
                                contentDescription = "Аватар $name",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .fillMaxSize()
                                    .clip(CircleShape)
                            )
                        } else {
                            Text(
                                text = initials,
                                style = if (size >= 64.dp) MaterialTheme.typography.headlineSmall else MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = bgColor
                            )
                        }
                    }
                }
            }
        }
        if (effectivePresence != null) {
            val isResourceSaving = com.example.ui.theme.LocalChatAppearance.current.resourceSavingMode
            val targetDotColor = when (effectivePresence) {
                UserPresenceStatus.ONLINE -> presenceColors.online
                UserPresenceStatus.RECENTLY -> presenceColors.recent
                UserPresenceStatus.OFFLINE -> presenceColors.offline
            }
            val dotColor = if (isResourceSaving) {
                targetDotColor
            } else {
                animateColorAsState(
                    targetValue = targetDotColor,
                    animationSpec = tween(280),
                    label = "avatar_presence_color"
                ).value
            }
            val dotSize = if (size >= 48.dp) 14.dp else 11.dp
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(dotSize)
                    .align(Alignment.BottomEnd)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.background)
                    .padding(2.dp)
                    .clip(CircleShape)
                    .background(dotColor)
                    .testTag("avatar_presence_${effectivePresence.name.lowercase()}")
            ) {}
        }
    }
}

@Composable
fun UserPresenceIndicator(
    status: UserPresenceStatus,
    compact: Boolean = false,
    modifier: Modifier = Modifier
) {
    val isResourceSaving = com.example.ui.theme.LocalChatAppearance.current.resourceSavingMode
    val presenceColors = LocalPresenceColors.current
    val targetColor = when (status) {
        UserPresenceStatus.ONLINE -> presenceColors.online
        UserPresenceStatus.RECENTLY -> presenceColors.recent
        UserPresenceStatus.OFFLINE -> presenceColors.offline
    }
    val targetLabelColor = when (status) {
        UserPresenceStatus.ONLINE -> presenceColors.online
        UserPresenceStatus.RECENTLY -> presenceColors.recent
        UserPresenceStatus.OFFLINE -> MaterialTheme.colorScheme.onSurfaceVariant
    }
    val dotColor: Color
    val labelColor: Color
    if (isResourceSaving) {
        dotColor = targetColor
        labelColor = targetLabelColor
    } else {
        val animDot by animateColorAsState(
            targetValue = targetColor,
            animationSpec = tween(280),
            label = "presence_dot_color"
        )
        val animLabel by animateColorAsState(
            targetValue = targetLabelColor,
            animationSpec = tween(280),
            label = "presence_label_color"
        )
        dotColor = animDot
        labelColor = animLabel
    }

    val pulseAlpha = if (status == UserPresenceStatus.ONLINE) {
        if (isResourceSaving) {
            0.34f
        } else {
            val pulse = rememberInfiniteTransition(label = "online_dot_pulse")
            val anim by pulse.animateFloat(
                initialValue = 0.28f,
                targetValue = 0.72f,
                animationSpec = infiniteRepeatable(tween(900), RepeatMode.Reverse),
                label = "online_pulse_alpha"
            )
            anim
        }
    } else {
        0f
    }

    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = modifier.testTag("presence_indicator_${status.name.lowercase()}")
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.size(if (compact) 10.dp else 12.dp)
        ) {
            if (status == UserPresenceStatus.ONLINE) {
                Box(
                    modifier = Modifier
                        .size(if (compact) 10.dp else 12.dp)
                        .clip(CircleShape)
                        .background(dotColor.copy(alpha = pulseAlpha))
                )
            }
            Box(
                modifier = Modifier
                    .size(if (compact) 6.dp else 7.dp)
                    .clip(CircleShape)
                    .background(dotColor)
            )
        }
        Spacer(modifier = Modifier.width(if (compact) 4.dp else 5.dp))
        Text(
            text = status.labelRu,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = if (status == UserPresenceStatus.ONLINE) FontWeight.SemiBold else FontWeight.Medium,
            color = labelColor,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun EncryptionBadge(
    label: String = "E2EE",
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(50),
        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.14f),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.38f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Filled.Lock,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(11.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.primary,
                maxLines = 1,
                softWrap = false
            )
        }
    }
}

@Composable
fun RoleBadge(
    role: UserRole,
    compact: Boolean = false,
    modifier: Modifier = Modifier
) {
    if (role == UserRole.USER) return
    val isDev = role == UserRole.DEVELOPER
    val containerColor = if (isDev) {
        MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.85f)
    } else {
        MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.85f)
    }
    val contentColor = if (isDev) {
        MaterialTheme.colorScheme.onPrimaryContainer
    } else {
        MaterialTheme.colorScheme.onTertiaryContainer
    }
    val accentColor = if (isDev) {
        MaterialTheme.colorScheme.primary
    } else {
        MaterialTheme.colorScheme.tertiary
    }
    Surface(
        modifier = modifier.testTag("role_badge_${role.wireValue}"),
        shape = RoundedCornerShape(50),
        color = containerColor,
        border = BorderStroke(1.dp, accentColor.copy(alpha = 0.45f))
    ) {
        Row(
            modifier = Modifier.padding(
                horizontal = if (compact) 6.dp else 8.dp,
                vertical = if (compact) 2.dp else 3.dp
            ),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = if (isDev) Icons.Filled.Code else Icons.Filled.BugReport,
                contentDescription = role.labelRu,
                tint = accentColor,
                modifier = Modifier.size(if (compact) 11.dp else 13.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = if (compact) role.shortBadge else role.labelRu,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.SemiBold,
                color = contentColor,
                maxLines = 1,
                softWrap = false
            )
        }
    }
}

fun parseRoleColorHex(colorHex: String?, fallback: Color): Color {
    val clean = colorHex?.trim().orEmpty()
    if (!Regex("^#[0-9A-Fa-f]{6}$").matches(clean)) return fallback
    return runCatching {
        Color(android.graphics.Color.parseColor(clean))
    }.getOrDefault(fallback)
}

@Composable
fun CustomRoleBadge(
    name: String,
    badgeText: String,
    colorHex: String,
    compact: Boolean = false,
    isPriority: Boolean = false,
    modifier: Modifier = Modifier
) {
    val displayLabel = if (compact) {
        badgeText.ifBlank { name }.take(12)
    } else {
        name.ifBlank { badgeText }.take(32)
    }
    if (displayLabel.isBlank()) return
    val accentColor = parseRoleColorHex(colorHex, MaterialTheme.colorScheme.secondary)
    Surface(
        modifier = modifier.testTag("custom_role_badge"),
        shape = RoundedCornerShape(50),
        color = accentColor.copy(alpha = if (isPriority) 0.22f else 0.15f),
        border = BorderStroke(
            width = if (isPriority) 1.3.dp else 1.dp,
            color = accentColor.copy(alpha = if (isPriority) 0.72f else 0.50f)
        )
    ) {
        Row(
            modifier = Modifier.padding(
                horizontal = if (compact) 6.dp else 8.dp,
                vertical = if (compact) 2.dp else 3.dp
            ),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = if (isPriority) Icons.Filled.Verified else Icons.Filled.Stars,
                contentDescription = name.ifBlank { badgeText },
                tint = accentColor,
                modifier = Modifier.size(if (compact) 11.dp else 13.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = displayLabel,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.SemiBold,
                color = accentColor,
                maxLines = 1,
                softWrap = false
            )
        }
    }
}

@Composable
fun VoiceWaveformRow(
    bars: List<Int>,
    progress: Float,
    isPlaying: Boolean,
    onTogglePlay: () -> Unit,
    durationLabel: String,
    accentColor: Color,
    trackColor: Color,
    textColor: Color,
    modifier: Modifier = Modifier
) {
    val safeBars = if (bars.isEmpty()) List(24) { 25 } else bars
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(
            onClick = onTogglePlay,
            colors = IconButtonDefaults.iconButtonColors(
                containerColor = accentColor,
                contentColor = MaterialTheme.colorScheme.onPrimary
            ),
            modifier = Modifier
                .size(48.dp)
                .testTag("voice_play_button")
        ) {
            Icon(
                imageVector = if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                contentDescription = if (isPlaying) "Пауза" else "Воспроизвести"
            )
        }
        Spacer(modifier = Modifier.width(10.dp))
        Column(modifier = Modifier.weight(1f)) {
            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(28.dp)
            ) {
                val count = safeBars.size.coerceAtLeast(1)
                val gap = 3.dp.toPx()
                val totalGap = gap * (count - 1)
                val barW = ((size.width - totalGap) / count).coerceAtLeast(2.dp.toPx())
                safeBars.forEachIndexed { idx, amp ->
                    val frac = idx.toFloat() / count.toFloat()
                    val active = frac <= progress && (isPlaying || progress > 0f)
                    val h = (size.height * (amp.coerceIn(12, 100) / 100f)).coerceAtLeast(4.dp.toPx())
                    val x = idx * (barW + gap)
                    val y = (size.height - h) / 2f
                    drawRoundRect(
                        color = if (active) accentColor else trackColor,
                        topLeft = Offset(x, y),
                        size = Size(barW, h),
                        cornerRadius = CornerRadius(barW / 2f, barW / 2f)
                    )
                }
            }
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = durationLabel,
                style = MaterialTheme.typography.labelSmall,
                color = textColor.copy(alpha = 0.8f)
            )
        }
    }
}

@Composable
fun IncomingOrActiveCallBanner(
    call: CallSession,
    currentUserId: String,
    onAcceptOrJoin: () -> Unit,
    onDecline: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isAlreadyIn = currentUserId in call.activeParticipantUids
    val isResourceSaving = com.example.ui.theme.LocalChatAppearance.current.resourceSavingMode
    val bgColor = if (isResourceSaving) {
        MaterialTheme.colorScheme.secondaryContainer
    } else {
        val pulse = rememberInfiniteTransition(label = "call_pulse")
        val alpha by pulse.animateFloat(
            initialValue = 0.7f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(tween(750), RepeatMode.Reverse),
            label = "pulse_alpha"
        )
        val animatedBg by animateColorAsState(
            targetValue = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = alpha),
            label = "banner_bg"
        )
        animatedBg
    }

    val isLiquidGlass = isLiquidGlassActive()
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .then(
                if (isLiquidGlass) {
                    Modifier.liquidGlassSurface(
                        shape = RoundedCornerShape(22.dp),
                        tintColor = bgColor,
                        accentGlow = MaterialTheme.colorScheme.secondary,
                        isHighlighted = true,
                        tintAlpha = 0.48f
                    )
                } else {
                    Modifier
                }
            )
            .testTag("incoming_call_banner"),
        shape = RoundedCornerShape(if (isLiquidGlass) 22.dp else 20.dp),
        color = if (isLiquidGlass) Color.Transparent else bgColor,
        border = if (isLiquidGlass) null else BorderStroke(1.dp, MaterialTheme.colorScheme.secondary.copy(alpha = 0.55f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Surface(
                    shape = CircleShape,
                    color = MaterialTheme.colorScheme.secondary,
                    modifier = Modifier.size(40.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = if (call.callType == "video") Icons.Filled.Videocam else Icons.Filled.Call,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSecondary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = if (call.isGroupCall) "Групповой звонок • ${call.conversationTitle}" else call.callerName,
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.onSecondaryContainer,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = if (call.status == "ringing" && !isAlreadyIn) {
                            if (call.callType == "video") "Входящий видеозвонок" else "Входящий аудиозвонок"
                        } else {
                            "Активный звонок • участников: ${call.activeParticipantUids.size}"
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.85f)
                    )
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (!isAlreadyIn && call.callerId != currentUserId) {
                    IconButton(
                        onClick = onDecline,
                        colors = IconButtonDefaults.iconButtonColors(
                            containerColor = MaterialTheme.colorScheme.error,
                            contentColor = MaterialTheme.colorScheme.onError
                        ),
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("decline_call_button")
                    ) {
                        Icon(Icons.Filled.CallEnd, contentDescription = "Отклонить звонок")
                    }
                }
                Button(
                    onClick = onAcceptOrJoin,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    ),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .height(48.dp)
                        .testTag("accept_call_button")
                ) {
                    Text(
                        text = if (isAlreadyIn) "Вернуться" else "Ответить",
                        style = MaterialTheme.typography.labelLarge
                    )
                }
            }
        }
    }
}

fun formatDurationMillis(ms: Long): String {
    val totalSec = (ms / 1000L).coerceAtLeast(0L)
    val mins = totalSec / 60L
    val secs = totalSec % 60L
    return "%d:%02d".format(mins, secs)
}

fun formatMuteRemaining(mutedUntilEpochMs: Long, nowMs: Long = System.currentTimeMillis()): String {
    if (mutedUntilEpochMs <= 0L) return "бессрочно"
    val diffMs = (mutedUntilEpochMs - nowMs).coerceAtLeast(0L)
    if (diffMs == 0L) return "истёк"
    val totalMin = (diffMs / 60_000L).coerceAtLeast(1L)
    return when {
        totalMin >= 1440L -> "${totalMin / 1440L} дн."
        totalMin >= 60L -> "${totalMin / 60L} ч."
        else -> "$totalMin мин."
    }
}

@Composable
fun ModerationStatusChip(
    status: ModerationStatus,
    mutedUntilEpochMs: Long = 0L,
    compact: Boolean = false,
    modifier: Modifier = Modifier
) {
    if (status == ModerationStatus.ACTIVE) return
    val isBanned = status == ModerationStatus.BANNED
    val containerColor = if (isBanned) {
        MaterialTheme.colorScheme.errorContainer
    } else {
        MaterialTheme.colorScheme.tertiaryContainer
    }
    val contentColor = if (isBanned) {
        MaterialTheme.colorScheme.onErrorContainer
    } else {
        MaterialTheme.colorScheme.onTertiaryContainer
    }
    val accentColor = if (isBanned) {
        MaterialTheme.colorScheme.error
    } else {
        MaterialTheme.colorScheme.tertiary
    }
    val label = if (isBanned) {
        "Заблокирован"
    } else if (compact) {
        "Мут"
    } else {
        "Мут (${formatMuteRemaining(mutedUntilEpochMs)})"
    }

    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(50),
        color = containerColor,
        border = BorderStroke(1.dp, accentColor.copy(alpha = 0.5f))
    ) {
        Row(
            modifier = Modifier.padding(
                horizontal = if (compact) 6.dp else 8.dp,
                vertical = if (compact) 2.dp else 3.dp
            ),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = if (isBanned) Icons.Filled.Block else Icons.Filled.VolumeOff,
                contentDescription = label,
                tint = accentColor,
                modifier = Modifier.size(if (compact) 11.dp else 13.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.SemiBold,
                color = contentColor,
                maxLines = 1
            )
        }
    }
}

@Composable
fun UnreadCountBadge(
    count: Int,
    modifier: Modifier = Modifier
) {
    if (count <= 0) return
    val text = if (count > 99) "99+" else count.toString()
    Surface(
        modifier = modifier.testTag("unread_count_badge"),
        shape = RoundedCornerShape(50),
        color = MaterialTheme.colorScheme.primary
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.padding(horizontal = if (text.length == 1) 7.dp else 6.dp, vertical = 2.dp)
        ) {
            Text(
                text = text,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onPrimary,
                maxLines = 1
            )
        }
    }
}

@Composable
fun ReadReceiptIcon(
    isRead: Boolean,
    tint: Color,
    modifier: Modifier = Modifier
) {
    Icon(
        imageVector = if (isRead) Icons.Filled.DoneAll else Icons.Filled.Done,
        contentDescription = if (isRead) "Прочитано" else "Доставлено, не прочитано",
        tint = if (isRead) MaterialTheme.colorScheme.primary else tint,
        modifier = modifier.size(15.dp)
    )
}

@Composable
fun InAppMessageAlertBanner(
    title: String,
    body: String,
    unreadCount: Int,
    senderName: String = title,
    senderRole: UserRole = UserRole.USER,
    customRoleName: String = "",
    customRoleBadge: String = "",
    customRoleColorHex: String = "",
    avatarBase64: String = "",
    avatarColorIndex: Int = abs(senderName.hashCode()),
    isGroup: Boolean = false,
    onOpen: () -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isResourceSaving = com.example.ui.theme.LocalChatAppearance.current.resourceSavingMode
    val isLiquidGlass = isLiquidGlassActive()
    val resolvedSender = senderName.trim().ifBlank { title.trim().ifBlank { "SpoX" } }
    val showGroupSubtitle = isGroup && title.isNotBlank() && title.trim() != resolvedSender
    Surface(
        modifier = modifier
            .statusBarsPadding()
            .padding(horizontal = 14.dp, vertical = 8.dp)
            .widthIn(max = 560.dp)
            .fillMaxWidth()
            .then(
                if (isLiquidGlass) {
                    Modifier.liquidGlassSurface(
                        shape = RoundedCornerShape(20.dp),
                        tintColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                        accentGlow = MaterialTheme.colorScheme.primary,
                        isHighlighted = true,
                        tintAlpha = 0.54f
                    )
                } else {
                    Modifier
                }
            )
            .clickable(onClick = onOpen)
            .testTag("in_app_message_alert_banner"),
        shape = RoundedCornerShape(if (isLiquidGlass) 20.dp else 18.dp),
        color = if (isLiquidGlass) Color.Transparent else MaterialTheme.colorScheme.surfaceContainerHigh,
        tonalElevation = if (isLiquidGlass || isResourceSaving) 0.dp else 8.dp,
        shadowElevation = if (isLiquidGlass || isResourceSaving) 0.dp else 8.dp,
        border = if (isLiquidGlass) null else BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.55f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            UserAvatar(
                name = resolvedSender,
                avatarBase64 = avatarBase64,
                colorIndex = avatarColorIndex,
                isGroup = false,
                size = 44.dp
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = resolvedSender,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    if (unreadCount > 0) {
                        UnreadCountBadge(count = unreadCount)
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    when {
                        customRoleName.isNotBlank() || customRoleBadge.isNotBlank() -> {
                            CustomRoleBadge(
                                name = customRoleName,
                                badgeText = customRoleBadge,
                                colorHex = customRoleColorHex,
                                compact = true
                            )
                        }
                        senderRole != UserRole.USER -> {
                            RoleBadge(role = senderRole, compact = true)
                        }
                        else -> {
                            Surface(
                                shape = RoundedCornerShape(50),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.72f),
                                border = BorderStroke(
                                    1.dp,
                                    MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.65f)
                                ),
                                modifier = Modifier.testTag("role_badge_user")
                            ) {
                                Text(
                                    text = senderRole.labelRu,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Medium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1,
                                    softWrap = false,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }
                    if (showGroupSubtitle) {
                        Text(
                            text = "в чате «$title»",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f, fill = false)
                        )
                    }
                }
                Text(
                    text = body,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
            IconButton(
                onClick = onDismiss,
                modifier = Modifier.size(48.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.Close,
                    contentDescription = "Закрыть уведомление",
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

@Composable
fun AccountRestrictedScreen(
    isDeleted: Boolean,
    reason: String,
    onSignOut: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .navigationBarsPadding()
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        val isLiquidGlass = isLiquidGlassActive()
        Surface(
            shape = RoundedCornerShape(26.dp),
            color = if (isLiquidGlass) Color.Transparent else MaterialTheme.colorScheme.surfaceContainer,
            border = if (isLiquidGlass) null else BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.5f)),
            modifier = Modifier
                .widthIn(max = 460.dp)
                .then(
                    if (isLiquidGlass) {
                        Modifier.liquidGlassSurface(
                            shape = RoundedCornerShape(26.dp),
                            tintColor = MaterialTheme.colorScheme.surfaceContainer,
                            accentGlow = MaterialTheme.colorScheme.error,
                            tintAlpha = 0.50f
                        )
                    } else {
                        Modifier
                    }
                )
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Surface(
                    shape = CircleShape,
                    color = MaterialTheme.colorScheme.errorContainer,
                    modifier = Modifier.size(68.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = if (isDeleted) Icons.Filled.DeleteForever else Icons.Filled.Block,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(34.dp)
                        )
                    }
                }
                Text(
                    text = if (isDeleted) "Аккаунт удалён" else "Аккаунт заблокирован",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
                Text(
                    text = if (isDeleted) {
                        "Администратор SpoX удалил ваш аккаунт. Доступ к чатам и отправке сообщений закрыт."
                    } else {
                        "Администратор SpoX ограничил доступ к вашему аккаунту."
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )
                if (reason.isNotBlank()) {
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.4f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "Причина: $reason",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onErrorContainer,
                            modifier = Modifier.padding(12.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
                Button(
                    onClick = onSignOut,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.error,
                        contentColor = MaterialTheme.colorScheme.onError
                    ),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("restricted_sign_out_button")
                ) {
                    Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Выйти из аккаунта")
                }
            }
        }
    }
}

@Composable
fun TopNetworkStatusHeaderContent(
    topStatus: TopStatusUiState,
    isLiquidGlass: Boolean,
    appName: String = "SpoX",
    badgeContent: @Composable () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val isResourceSaving = LocalChatAppearance.current.resourceSavingMode
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = modifier
            .animateContentSize()
            .testTag("top_network_status_header")
    ) {
        when (topStatus.phase) {
            NetworkSyncPhase.WAITING_FOR_NETWORK -> {
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .clip(RoundedCornerShape(11.dp))
                        .background(MaterialTheme.colorScheme.tertiaryContainer),
                    contentAlignment = Alignment.Center
                ) {
                    if (isResourceSaving) {
                        Icon(
                            imageVector = Icons.Filled.CloudOff,
                            contentDescription = "Ожидание сети",
                            tint = MaterialTheme.colorScheme.tertiary,
                            modifier = Modifier.size(18.dp)
                        )
                    } else {
                        CircularProgressIndicator(
                            modifier = Modifier.size(17.dp),
                            strokeWidth = 2.2.dp,
                            color = MaterialTheme.colorScheme.tertiary
                        )
                    }
                }
            }
            NetworkSyncPhase.UPDATING -> {
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .clip(RoundedCornerShape(11.dp))
                        .background(MaterialTheme.colorScheme.primaryContainer),
                    contentAlignment = Alignment.Center
                ) {
                    if (isResourceSaving) {
                        Icon(
                            imageVector = Icons.Filled.Sync,
                            contentDescription = "Обновление",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                    } else {
                        CircularProgressIndicator(
                            modifier = Modifier.size(17.dp),
                            strokeWidth = 2.2.dp,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }
            NetworkSyncPhase.SYNCED -> {
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .clip(RoundedCornerShape(11.dp))
                        .background(
                            Brush.linearGradient(
                                listOf(
                                    MaterialTheme.colorScheme.primary,
                                    MaterialTheme.colorScheme.secondary
                                )
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.Shield,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onPrimary,
                        modifier = Modifier.size(19.dp)
                    )
                }
            }
        }
        Spacer(modifier = Modifier.width(10.dp))
        AnimatedContent(
            targetState = topStatus.phase to topStatus.isVerifyingAccount,
            transitionSpec = {
                if (isResourceSaving) {
                    fadeIn(tween(1)) togetherWith fadeOut(tween(1))
                } else {
                    fadeIn(tween(220)) togetherWith fadeOut(tween(160))
                }
            },
            label = "top_network_status_label"
        ) { (phase, verifyingAccount) ->
            when (phase) {
                NetworkSyncPhase.WAITING_FOR_NETWORK -> {
                    Column(verticalArrangement = Arrangement.Center) {
                        Text(
                            text = "Ожидание сети",
                            style = if (isLiquidGlass) MaterialTheme.typography.titleMedium else MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.tertiary,
                            maxLines = 1,
                            softWrap = false,
                            overflow = TextOverflow.Ellipsis
                        )
                        if (verifyingAccount) {
                            Text(
                                text = "Проверка после подключения",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
                NetworkSyncPhase.UPDATING -> {
                    Column(verticalArrangement = Arrangement.Center) {
                        Text(
                            text = "Обновление",
                            style = if (isLiquidGlass) MaterialTheme.typography.titleMedium else MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 1,
                            softWrap = false,
                            overflow = TextOverflow.Ellipsis
                        )
                        if (verifyingAccount) {
                            Text(
                                text = "Проверка профиля...",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
                NetworkSyncPhase.SYNCED -> {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = appName,
                            style = if (isLiquidGlass) MaterialTheme.typography.titleLarge else MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            softWrap = false
                        )
                        badgeContent()
                    }
                }
            }
        }
    }
}

@Composable
fun TopRoomNetworkStatusPill(
    topStatus: TopStatusUiState,
    visible: Boolean,
    appName: String = "SpoX",
    modifier: Modifier = Modifier
) {
    val isLiquidGlass = isLiquidGlassActive()
    val isResourceSaving = LocalChatAppearance.current.resourceSavingMode
    AnimatedVisibility(
        visible = visible,
        enter = expandVertically(tween(200)) + fadeIn(tween(180)),
        exit = shrinkVertically(tween(180)) + fadeOut(tween(150)),
        modifier = modifier.fillMaxWidth()
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 4.dp),
            contentAlignment = Alignment.Center
        ) {
            val pillShape = RoundedCornerShape(50)
            val tint = when (topStatus.phase) {
                NetworkSyncPhase.WAITING_FOR_NETWORK -> MaterialTheme.colorScheme.tertiaryContainer
                NetworkSyncPhase.UPDATING -> MaterialTheme.colorScheme.primaryContainer
                NetworkSyncPhase.SYNCED -> MaterialTheme.colorScheme.surfaceContainerHigh
            }
            val accent = when (topStatus.phase) {
                NetworkSyncPhase.WAITING_FOR_NETWORK -> MaterialTheme.colorScheme.tertiary
                NetworkSyncPhase.UPDATING -> MaterialTheme.colorScheme.primary
                NetworkSyncPhase.SYNCED -> MaterialTheme.colorScheme.primary
            }
            Surface(
                shape = pillShape,
                color = if (isLiquidGlass) Color.Transparent else tint.copy(alpha = 0.92f),
                border = if (isLiquidGlass) null else BorderStroke(1.dp, accent.copy(alpha = 0.42f)),
                modifier = Modifier
                    .then(
                        if (isLiquidGlass) {
                            Modifier.liquidGlassSurface(
                                shape = pillShape,
                                tintColor = tint,
                                accentGlow = accent,
                                isHighlighted = topStatus.phase != NetworkSyncPhase.SYNCED,
                                tintAlpha = 0.44f
                            )
                        } else Modifier
                    )
                    .testTag("room_network_status_pill")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(7.dp)
                ) {
                    when (topStatus.phase) {
                        NetworkSyncPhase.WAITING_FOR_NETWORK -> {
                            if (isResourceSaving) {
                                Icon(
                                    imageVector = Icons.Filled.CloudOff,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.tertiary,
                                    modifier = Modifier.size(14.dp)
                                )
                            } else {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(13.dp),
                                    strokeWidth = 2.dp,
                                    color = MaterialTheme.colorScheme.tertiary
                                )
                            }
                            Text(
                                text = "Ожидание сети",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onTertiaryContainer
                            )
                        }
                        NetworkSyncPhase.UPDATING -> {
                            if (isResourceSaving) {
                                Icon(
                                    imageVector = Icons.Filled.Sync,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(14.dp)
                                )
                            } else {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(13.dp),
                                    strokeWidth = 2.dp,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                            Text(
                                text = if (topStatus.isVerifyingAccount) "Обновление • проверка" else "Обновление",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }
                        NetworkSyncPhase.SYNCED -> {
                            Icon(
                                imageVector = Icons.Filled.Shield,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                text = appName,
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }
        }
    }
}


