package com.example.ui.screens

import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.assertIsOff
import androidx.compose.ui.test.assertIsOn
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import com.example.data.model.AppThemeMode
import com.example.data.model.ChatAppearanceConfig
import com.example.ui.theme.CipherChatTheme
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class MessengerEditorTest {

    @get:Rule
    val composeRule = createComposeRule()

    @Test
    fun messengerEditor_togglesStoriesAndFoldersAndUpdatesPreview() {
        composeRule.setContent {
            var config by remember { mutableStateOf(ChatAppearanceConfig()) }
            CipherChatTheme(themeMode = AppThemeMode.DARK, appearanceConfig = config) {
                MessengerEditorContent(
                    appearance = config,
                    onSetShowStories = { config = config.copy(showStories = it) },
                    onSetShowFolders = { config = config.copy(showFolders = it) },
                    modifier = Modifier.verticalScroll(rememberScrollState())
                )
            }
        }

        composeRule.waitForIdle()
        composeRule.onNodeWithTag("preview_stories_strip").assertIsDisplayed()
        composeRule.onNodeWithTag("preview_folders_bar").assertIsDisplayed()
        composeRule.onNodeWithTag("editor_show_stories_switch").assertIsOn()
        composeRule.onNodeWithTag("editor_show_folders_switch").assertIsOn()

        // Hide Stories
        composeRule.onNodeWithTag("editor_show_stories_switch").performScrollTo().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("editor_show_stories_switch").assertIsOff()
        composeRule.onNodeWithTag("preview_stories_strip").assertDoesNotExist()
        composeRule.onNodeWithTag("preview_folders_bar").assertIsDisplayed()

        // Hide Folders
        composeRule.onNodeWithTag("editor_show_folders_switch").performScrollTo().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("editor_show_folders_switch").assertIsOff()
        composeRule.onNodeWithTag("preview_folders_bar").assertDoesNotExist()

        // Re-enable both
        composeRule.onNodeWithTag("editor_show_stories_switch").performScrollTo().performClick()
        composeRule.onNodeWithTag("editor_show_folders_switch").performScrollTo().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("editor_show_stories_switch").assertIsOn()
        composeRule.onNodeWithTag("editor_show_folders_switch").assertIsOn()
        composeRule.onNodeWithTag("preview_stories_strip").assertIsDisplayed()
        composeRule.onNodeWithTag("preview_folders_bar").assertIsDisplayed()
    }

    @Test
    fun customizationSettingsTab_togglesStoriesAndFolders() {
        var storiesState = true
        var foldersState = true

        composeRule.setContent {
            var config by remember { mutableStateOf(ChatAppearanceConfig()) }
            CipherChatTheme(themeMode = AppThemeMode.DARK, appearanceConfig = config) {
                androidx.compose.foundation.layout.Column(
                    modifier = Modifier.verticalScroll(rememberScrollState())
                ) {
                    CustomizationSettingsTab(
                        appearance = config,
                        onSelectThemeMode = {},
                        onSelectVisualTheme = {},
                        onSelectWallpaperPreset = {},
                        onPickCustomWallpaperUri = {},
                        onSelectOutgoingBubbleStyle = {},
                        onSetShowStories = {
                            storiesState = it
                            config = config.copy(showStories = it)
                        },
                        onSetShowFolders = {
                            foldersState = it
                            config = config.copy(showFolders = it)
                        },
                        onResetCustomization = {}
                    )
                }
            }
        }

        composeRule.onNodeWithTag("custom_tab_show_stories_switch").performScrollTo().performClick()
        composeRule.onNodeWithTag("custom_tab_show_folders_switch").performScrollTo().performClick()
        composeRule.waitForIdle()

        assertEquals(false, storiesState)
        assertEquals(false, foldersState)
    }
}
