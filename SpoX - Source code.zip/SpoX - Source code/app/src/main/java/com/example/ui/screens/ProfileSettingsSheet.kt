package com.example.ui.screens

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.AlternateEmail
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.BuildConfig
import com.example.data.model.AppThemeMode
import com.example.data.model.AppVisualTheme
import com.example.data.model.ChatAppearanceConfig
import com.example.data.model.ChatWallpaperPreset
import com.example.data.model.ModerationStatus
import com.example.data.model.OutgoingBubbleStyle
import com.example.data.model.PublicUserProfile
import com.example.data.model.RoleCodeRecord
import com.example.data.model.UserPrivateProfile
import com.example.data.model.UserRole
import com.example.data.repository.SavedAccountsStore
import com.example.media.FileAttachmentHelper
import com.example.notifications.NotificationPreferences
import com.example.notifications.SpoXNotificationHelper
import com.example.security.AppLockManager
import com.example.security.BiometricCapability
import com.example.security.findFragmentActivity
import com.example.ui.auth.PinSetupDialog
import com.example.ui.components.ModerationStatusChip
import com.example.ui.components.RoleBadge
import com.example.ui.components.UserAvatar
import com.example.ui.components.formatMuteRemaining
import com.example.ui.viewmodel.GeneratedRoleCode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.abs

enum class ProfileSettingsSection {
    PROFILE,
    SETTINGS,
    CUSTOMIZATION
}

@Composable
fun ProfileSettingsSheet(
    privateProfile: UserPrivateProfile?,
    publicProfile: PublicUserProfile?,
    fallbackEmail: String,
    fallbackDisplayName: String,
    keyFingerprint: String,
    themeMode: AppThemeMode,
    appearanceConfig: ChatAppearanceConfig,
    isBusy: Boolean,
    roleCodes: List<RoleCodeRecord>,
    lastGeneratedRoleCode: GeneratedRoleCode?,
    adminUsersCount: Int,
    isPinEnabled: Boolean,
    isBiometricEnabled: Boolean,
    biometricCapability: BiometricCapability,
    appLockManager: AppLockManager,
    initialSection: ProfileSettingsSection = ProfileSettingsSection.PROFILE,
    onSwitchSection: (ProfileSettingsSection) -> Unit = {},
    onDismiss: () -> Unit,
    onSaveProfile: (displayName: String, rawUsername: String, avatarBase64: String) -> Unit,
    onDeleteUsername: (displayName: String, avatarBase64: String) -> Unit,
    onAvatarError: (String) -> Unit,
    onRedeemRoleCode: (String, onRedeemed: () -> Unit) -> Unit,
    onGenerateRoleCode: (UserRole) -> Unit,
    onDeleteRoleCode: (String) -> Unit,
    onCodeCopied: (String) -> Unit,
    onOpenModerationPanel: () -> Unit,
    onSetPin: (String) -> Unit,
    onDisablePin: () -> Unit,
    onSetBiometricEnabled: (Boolean) -> Unit,
    onLockAppNow: () -> Unit,
    onShowMessage: (String) -> Unit,
    onChangeThemeMode: (AppThemeMode) -> Unit,
    onSelectVisualTheme: (AppVisualTheme) -> Unit,
    onSelectWallpaperPreset: (ChatWallpaperPreset) -> Unit,
    onPickCustomWallpaperUri: (Uri) -> Unit,
    onSelectOutgoingBubbleStyle: (OutgoingBubbleStyle) -> Unit,
    onSetShowStories: (Boolean) -> Unit = {},
    onSetShowFolders: (Boolean) -> Unit = {},
    onResetCustomization: () -> Unit,
    onSetDiscoverable: (Boolean) -> Unit,
    savedAccountsCount: Int = 1,
    onOpenAccountSwitcher: (() -> Unit)? = null,
    onSignOut: () -> Unit
) {
    when (initialSection) {
        ProfileSettingsSection.PROFILE -> {
            ProfileEditSheet(
                privateProfile = privateProfile,
                publicProfile = publicProfile,
                fallbackEmail = fallbackEmail,
                fallbackDisplayName = fallbackDisplayName,
                keyFingerprint = keyFingerprint,
                isBusy = isBusy,
                roleCodes = roleCodes,
                lastGeneratedRoleCode = lastGeneratedRoleCode,
                adminUsersCount = adminUsersCount,
                savedAccountsCount = savedAccountsCount,
                onDismiss = onDismiss,
                onSaveProfile = onSaveProfile,
                onDeleteUsername = onDeleteUsername,
                onAvatarError = onAvatarError,
                onRedeemRoleCode = onRedeemRoleCode,
                onGenerateRoleCode = onGenerateRoleCode,
                onDeleteRoleCode = onDeleteRoleCode,
                onCodeCopied = onCodeCopied,
                onOpenModerationPanel = onOpenModerationPanel,
                onOpenAccountSwitcher = onOpenAccountSwitcher,
                onSignOut = onSignOut
            )
        }

        ProfileSettingsSection.SETTINGS -> {
            AppSettingsSheet(
                privateProfile = privateProfile,
                publicProfile = publicProfile,
                isPinEnabled = isPinEnabled,
                isBiometricEnabled = isBiometricEnabled,
                biometricCapability = biometricCapability,
                appLockManager = appLockManager,
                onDismiss = onDismiss,
                onOpenCustomization = { onSwitchSection(ProfileSettingsSection.CUSTOMIZATION) },
                onSetDiscoverable = onSetDiscoverable,
                onSetPin = onSetPin,
                onDisablePin = onDisablePin,
                onSetBiometricEnabled = onSetBiometricEnabled,
                onLockAppNow = onLockAppNow,
                onShowMessage = onShowMessage,
                onBiometricError = onAvatarError
            )
        }

        ProfileSettingsSection.CUSTOMIZATION -> {
            CustomizationSettingsSheet(
                appearance = appearanceConfig.copy(themeMode = themeMode),
                onDismiss = onDismiss,
                onSelectThemeMode = onChangeThemeMode,
                onSelectVisualTheme = onSelectVisualTheme,
                onSelectWallpaperPreset = onSelectWallpaperPreset,
                onPickCustomWallpaperUri = onPickCustomWallpaperUri,
                onSelectOutgoingBubbleStyle = onSelectOutgoingBubbleStyle,
                onSetShowStories = onSetShowStories,
                onSetShowFolders = onSetShowFolders,
                onResetCustomization = onResetCustomization
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileEditSheet(
    privateProfile: UserPrivateProfile?,
    publicProfile: PublicUserProfile?,
    fallbackEmail: String,
    fallbackDisplayName: String,
    keyFingerprint: String,
    isBusy: Boolean,
    roleCodes: List<RoleCodeRecord>,
    lastGeneratedRoleCode: GeneratedRoleCode?,
    adminUsersCount: Int,
    savedAccountsCount: Int = 1,
    onDismiss: () -> Unit,
    onSaveProfile: (displayName: String, rawUsername: String, avatarBase64: String) -> Unit,
    onDeleteUsername: (displayName: String, avatarBase64: String) -> Unit,
    onAvatarError: (String) -> Unit,
    onRedeemRoleCode: (String, onRedeemed: () -> Unit) -> Unit,
    onGenerateRoleCode: (UserRole) -> Unit,
    onDeleteRoleCode: (String) -> Unit,
    onCodeCopied: (String) -> Unit,
    onOpenModerationPanel: () -> Unit,
    onOpenAccountSwitcher: (() -> Unit)? = null,
    onSignOut: () -> Unit
) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val scrollState = rememberScrollState()

    val savedName = privateProfile?.displayName?.ifBlank { fallbackDisplayName }
        ?: publicProfile?.displayName?.ifBlank { fallbackDisplayName }
        ?: fallbackDisplayName
    val savedHandle = privateProfile?.handle ?: publicProfile?.handle.orEmpty()
    val savedAvatar = privateProfile?.avatarBase64 ?: publicProfile?.avatarBase64.orEmpty()
    val resolvedEmail = privateProfile?.email?.ifBlank { fallbackEmail } ?: fallbackEmail
    val currentRole = UserRole.fromWire(privateProfile?.role ?: publicProfile?.role)

    var nicknameDraft by remember(savedName) { mutableStateOf(savedName) }
    var usernameDraft by remember(savedHandle) { mutableStateOf(savedHandle.removePrefix("@")) }
    var avatarDraft by remember(savedAvatar) { mutableStateOf(savedAvatar) }
    var roleCodeInput by remember { mutableStateOf("") }
    var showAvatarPreview by remember { mutableStateOf(false) }

    LaunchedEffect(savedHandle) {
        usernameDraft = savedHandle.removePrefix("@")
    }
    LaunchedEffect(savedName) {
        nicknameDraft = savedName
    }
    LaunchedEffect(savedAvatar) {
        avatarDraft = savedAvatar
    }

    val coroutineScope = rememberCoroutineScope()
    val avatarPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            coroutineScope.launch {
                val result = withContext(Dispatchers.IO) {
                    FileAttachmentHelper.prepareAvatarBase64(context, uri)
                }
                result
                    .onSuccess { encoded -> avatarDraft = encoded }
                    .onFailure { err ->
                        onAvatarError(err.localizedMessage ?: "Не удалось загрузить аватар")
                    }
            }
        }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(scrollState)
                .navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 8.dp)
                .testTag("profile_edit_sheet"),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .clickable {
                            showAvatarPreview = true
                        }
                        .testTag("avatar_picker_trigger")
                ) {
                    UserAvatar(
                        name = nicknameDraft.ifBlank { savedName },
                        avatarBase64 = avatarDraft,
                        colorIndex = (publicProfile?.avatarColorIndex ?: 0L).toInt(),
                        size = 72.dp
                    )
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .align(Alignment.BottomEnd)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primary)
                            .clickable {
                                avatarPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Filled.CameraAlt,
                            contentDescription = "Изменить фото профиля",
                            tint = MaterialTheme.colorScheme.onPrimary,
                            modifier = Modifier.size(15.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.width(14.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = nicknameDraft.ifBlank { savedName },
                            style = MaterialTheme.typography.titleLarge
                        )
                        RoleBadge(role = currentRole, compact = true)
                    }
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (savedHandle.isNotBlank()) savedHandle else "Юзернейм не задан",
                            style = MaterialTheme.typography.bodyMedium,
                            fontStyle = if (savedHandle.isBlank()) FontStyle.Italic else FontStyle.Normal,
                            color = if (savedHandle.isNotBlank()) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.weight(1f, fill = false)
                        )
                        if (savedHandle.isNotBlank()) {
                            IconButton(
                                onClick = {
                                    clipboard.setText(AnnotatedString(savedHandle))
                                    onCodeCopied(savedHandle)
                                },
                                modifier = Modifier
                                    .size(48.dp)
                                    .testTag("profile_edit_copy_username_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.ContentCopy,
                                    contentDescription = "Скопировать юзернейм",
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                    Text(
                        text = resolvedEmail,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (privateProfile?.isCurrentlyMuted() == true) {
                        Spacer(modifier = Modifier.height(4.dp))
                        ModerationStatusChip(
                            status = ModerationStatus.MUTED,
                            mutedUntilEpochMs = privateProfile.mutedUntilEpochMs,
                            compact = false
                        )
                    }
                }
            }

            if (privateProfile?.isCurrentlyMuted() == true) {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.7f),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.tertiary.copy(alpha = 0.45f))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        Text(
                            text = "Ваш аккаунт в муте (${formatMuteRemaining(privateProfile.mutedUntilEpochMs)})",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.onTertiaryContainer
                        )
                        if (privateProfile.moderationReason.isNotBlank()) {
                            Text(
                                text = "Причина: ${privateProfile.moderationReason}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onTertiaryContainer.copy(alpha = 0.9f)
                            )
                        }
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = {
                        avatarPickerLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    },
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("upload_avatar_button")
                ) {
                    Icon(Icons.Filled.PhotoLibrary, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Загрузить фото", maxLines = 1)
                }
                if (avatarDraft.isNotBlank()) {
                    OutlinedButton(
                        onClick = { avatarDraft = "" },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .height(48.dp)
                            .testTag("remove_avatar_button")
                    ) {
                        Icon(
                            Icons.Filled.DeleteOutline,
                            contentDescription = "Удалить фото",
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Убрать", color = MaterialTheme.colorScheme.error)
                    }
                }
            }

            Surface(
                shape = RoundedCornerShape(18.dp),
                color = MaterialTheme.colorScheme.surfaceContainer,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "Изменение профиля",
                        style = MaterialTheme.typography.titleSmall
                    )

                    OutlinedTextField(
                        value = nicknameDraft,
                        onValueChange = { if (it.length <= 60) nicknameDraft = it },
                        label = { Text("Никнейм") },
                        placeholder = { Text("Как вас показывать в чатах") },
                        leadingIcon = { Icon(Icons.Filled.Badge, contentDescription = null) },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("profile_nickname_input")
                    )

                    OutlinedTextField(
                        value = usernameDraft,
                        onValueChange = { input ->
                            val filtered = input.removePrefix("@")
                            if (filtered.length <= 32) {
                                usernameDraft = filtered
                            }
                        },
                        label = { Text("Юзернейм (необязательно)") },
                        placeholder = { Text("ivan_cipher") },
                        prefix = { Text("@") },
                        leadingIcon = { Icon(Icons.Filled.AlternateEmail, contentDescription = null) },
                        supportingText = {
                            Text("Латинские буквы, цифры, _ и . (2–32 символа)")
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("profile_username_input")
                    )

                    if (usernameDraft.isNotBlank() || savedHandle.isNotBlank()) {
                        TextButton(
                            onClick = {
                                usernameDraft = ""
                                onDeleteUsername(nicknameDraft.ifBlank { savedName }, avatarDraft)
                            },
                            enabled = !isBusy,
                            modifier = Modifier
                                .align(Alignment.End)
                                .testTag("delete_username_button")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.DeleteOutline,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.error,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Удалить юзернейм",
                                color = MaterialTheme.colorScheme.error
                            )
                        }
                    }

                    Button(
                        onClick = {
                            onSaveProfile(nicknameDraft, usernameDraft, avatarDraft)
                        },
                        enabled = !isBusy && nicknameDraft.isNotBlank(),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("save_profile_button")
                    ) {
                        if (isBusy) {
                            CircularProgressIndicator(
                                strokeWidth = 2.dp,
                                color = MaterialTheme.colorScheme.onPrimary,
                                modifier = Modifier.size(18.dp)
                            )
                        } else {
                            Icon(Icons.Filled.Check, contentDescription = null, modifier = Modifier.size(18.dp))
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Сохранить профиль")
                    }
                }
            }

            Surface(
                shape = RoundedCornerShape(18.dp),
                color = MaterialTheme.colorScheme.surfaceContainer,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Filled.VerifiedUser,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Статус аккаунта",
                                style = MaterialTheme.typography.titleSmall
                            )
                        }
                        if (currentRole == UserRole.USER) {
                            Text(
                                text = currentRole.labelRu,
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        } else {
                            RoleBadge(role = currentRole)
                        }
                    }

                    Text(
                        text = "Введите специальный одноразовый код от разработчика, чтобы получить статус тестировщика или разработчика.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    OutlinedTextField(
                        value = roleCodeInput,
                        onValueChange = { input ->
                            if (input.length <= 40) {
                                roleCodeInput = input.uppercase()
                            }
                        },
                        label = { Text("Код статуса") },
                        placeholder = { Text("SPOX-DEV-XXXX-XXXX") },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("role_code_input")
                    )

                    Button(
                        onClick = {
                            onRedeemRoleCode(roleCodeInput) {
                                roleCodeInput = ""
                            }
                        },
                        enabled = !isBusy && roleCodeInput.trim().length >= 6,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("redeem_role_code_button")
                    ) {
                        Icon(Icons.Filled.Check, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Активировать код")
                    }
                }
            }

            if (currentRole == UserRole.DEVELOPER) {
                Surface(
                    shape = RoundedCornerShape(18.dp),
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.25f),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.45f)),
                    modifier = Modifier.testTag("developer_code_panel")
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Filled.Code,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Панель разработчика",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        Text(
                            text = "Модерация аккаунтов и генерация одноразовых кодов доступа.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        OutlinedButton(
                            onClick = onOpenModerationPanel,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("open_moderation_from_settings_button")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.AdminPanelSettings,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (adminUsersCount > 0) {
                                    "Модерация аккаунтов ($adminUsersCount)"
                                } else {
                                    "Модерация аккаунтов (Блок / Мут / Удаление)"
                                },
                                maxLines = 1
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = { onGenerateRoleCode(UserRole.DEVELOPER) },
                                enabled = !isBusy,
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .testTag("generate_dev_code_button")
                            ) {
                                Icon(Icons.Filled.Code, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Код Разраб.", maxLines = 1)
                            }
                            OutlinedButton(
                                onClick = { onGenerateRoleCode(UserRole.TESTER) },
                                enabled = !isBusy,
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .testTag("generate_tester_code_button")
                            ) {
                                Icon(Icons.Filled.BugReport, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Код Тестер", maxLines = 1)
                            }
                        }

                        if (lastGeneratedRoleCode != null) {
                            Surface(
                                shape = RoundedCornerShape(14.dp),
                                color = MaterialTheme.colorScheme.surface,
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f))
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 12.dp, vertical = 10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "Новый код (${lastGeneratedRoleCode.targetRole.labelRu}) — сохраните:",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(
                                            text = lastGeneratedRoleCode.plainCode,
                                            style = MaterialTheme.typography.titleMedium,
                                            fontFamily = FontFamily.Monospace,
                                            color = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.testTag("generated_plain_code_text")
                                        )
                                    }
                                    IconButton(
                                        onClick = {
                                            clipboard.setText(AnnotatedString(lastGeneratedRoleCode.plainCode))
                                            onCodeCopied(lastGeneratedRoleCode.plainCode)
                                        },
                                        modifier = Modifier.testTag("copy_generated_code_button")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Filled.ContentCopy,
                                            contentDescription = "Скопировать код",
                                            tint = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                }
                            }
                        }

                        if (roleCodes.isNotEmpty()) {
                            HorizontalDivider()
                            Text(
                                text = "Выпущенные коды (${roleCodes.size})",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                roleCodes.take(10).forEach { code ->
                                    val target = UserRole.fromWire(code.targetRole)
                                    Surface(
                                        shape = RoundedCornerShape(12.dp),
                                        color = MaterialTheme.colorScheme.surfaceContainerLow,
                                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(horizontal = 10.dp, vertical = 8.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(
                                                    text = code.codePreview,
                                                    style = MaterialTheme.typography.bodyMedium,
                                                    fontFamily = FontFamily.Monospace
                                                )
                                                Text(
                                                    text = "${target.labelRu} • ${if (code.isUsed) "Использован" else "Активен"}",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = if (code.isUsed) MaterialTheme.colorScheme.onSurfaceVariant
                                                    else MaterialTheme.colorScheme.primary
                                                )
                                            }
                                            IconButton(onClick = { onDeleteRoleCode(code.codeHash) }) {
                                                Icon(
                                                    imageVector = Icons.Filled.DeleteOutline,
                                                    contentDescription = "Удалить код",
                                                    tint = MaterialTheme.colorScheme.error
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Surface(
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surfaceContainer,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Filled.Key,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Отпечаток E2EE ключа (ECDH P-256)",
                            style = MaterialTheme.typography.titleSmall
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = keyFingerprint,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(
                            onClick = { clipboard.setText(AnnotatedString(keyFingerprint)) }
                        ) {
                            Icon(Icons.Filled.ContentCopy, contentDescription = "Скопировать отпечаток")
                        }
                    }
                }
            }

            if (onOpenAccountSwitcher != null) {
                FilledTonalButton(
                    onClick = {
                        onDismiss()
                        onOpenAccountSwitcher()
                    },
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("profile_open_account_switcher_button")
                ) {
                    Icon(Icons.Filled.SwapHoriz, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Сменить или добавить аккаунт ($savedAccountsCount/${SavedAccountsStore.MAX_ACCOUNTS})")
                }
            }

            OutlinedButton(
                onClick = onSignOut,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("sign_out_button")
            ) {
                Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Выйти из аккаунта")
            }

            Spacer(modifier = Modifier.height(10.dp))
        }
    }

    if (showAvatarPreview) {
        AvatarViewerDialog(
            displayName = nicknameDraft.ifBlank { savedName },
            handle = savedHandle,
            avatarBase64 = avatarDraft,
            avatarColorIndex = (publicProfile?.avatarColorIndex ?: 0L).toInt(),
            onEditAvatar = {
                showAvatarPreview = false
                avatarPickerLauncher.launch(
                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                )
            },
            onDismiss = { showAvatarPreview = false }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppSettingsSheet(
    privateProfile: UserPrivateProfile?,
    publicProfile: PublicUserProfile?,
    isPinEnabled: Boolean,
    isBiometricEnabled: Boolean,
    biometricCapability: BiometricCapability,
    appLockManager: AppLockManager,
    onDismiss: () -> Unit,
    onOpenCustomization: () -> Unit,
    onSetDiscoverable: (Boolean) -> Unit,
    onSetPin: (String) -> Unit,
    onDisablePin: () -> Unit,
    onSetBiometricEnabled: (Boolean) -> Unit,
    onLockAppNow: () -> Unit,
    onShowMessage: (String) -> Unit,
    onBiometricError: (String) -> Unit
) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val scrollState = rememberScrollState()

    var showPinSetupDialog by remember { mutableStateOf(false) }
    var messagePushEnabled by remember { mutableStateOf(NotificationPreferences.isMessagePushEnabled(context)) }
    var callPushEnabled by remember { mutableStateOf(NotificationPreferences.isCallPushEnabled(context)) }
    var hasNotificationPerm by remember { mutableStateOf(SpoXNotificationHelper.hasNotificationPermission(context)) }
    var canUseFullScreenCalls by remember { mutableStateOf(SpoXNotificationHelper.canUseFullScreenIntent(context)) }
    val cachedFcmToken = remember(privateProfile?.fcmToken) {
        privateProfile?.fcmToken?.ifBlank { null } ?: NotificationPreferences.getFcmToken(context)
    }
    val pushPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasNotificationPerm = granted || SpoXNotificationHelper.hasNotificationPermission(context)
        if (granted) {
            onShowMessage("Разрешение на Push-уведомления включено")
        } else {
            onShowMessage("Разрешение отклонено — включите уведомления в настройках Android")
        }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(scrollState)
                .navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 8.dp)
                .testTag("app_settings_sheet"),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Surface(
                    shape = CircleShape,
                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.14f),
                    modifier = Modifier.size(46.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Filled.Settings,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Настройки",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Приватность, уведомления и защита",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // Dedicated shortcut to Customization Settings
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.32f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .clickable(onClick = onOpenCustomization)
                    .testTag("open_customization_from_settings_button")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.16f),
                        modifier = Modifier.size(38.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Filled.Palette,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Кастомизация и оформление",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "Темы, обои, истории, папки и цвет сообщений",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
            }

            Surface(
                shape = RoundedCornerShape(18.dp),
                color = MaterialTheme.colorScheme.surfaceContainer,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Видимость в каталоге", style = MaterialTheme.typography.titleSmall)
                        Text(
                            text = "Позволяет другим находить вас по нику, юзернейму или email",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Switch(
                        checked = publicProfile?.isDiscoverable ?: true,
                        onCheckedChange = onSetDiscoverable,
                        modifier = Modifier.testTag("discoverable_switch")
                    )
                }
            }

            // Push Notifications Settings Card
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = MaterialTheme.colorScheme.surfaceContainer,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Filled.NotificationsActive,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Push-уведомления",
                                style = MaterialTheme.typography.titleSmall
                            )
                        }
                        Surface(
                            shape = RoundedCornerShape(50),
                            color = if (hasNotificationPerm) {
                                MaterialTheme.colorScheme.primaryContainer
                            } else {
                                MaterialTheme.colorScheme.error.copy(alpha = 0.14f)
                            }
                        ) {
                            Text(
                                text = if (hasNotificationPerm) "Разрешены" else "Выкл. в системе",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (hasNotificationPerm) {
                                    MaterialTheme.colorScheme.onPrimaryContainer
                                } else {
                                    MaterialTheme.colorScheme.error
                                },
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                    }

                    if (!hasNotificationPerm) {
                        OutlinedButton(
                            onClick = {
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                    pushPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                } else {
                                    val intent = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
                                        putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
                                    }
                                    runCatching { context.startActivity(intent) }
                                }
                            },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("grant_notification_permission_button")
                        ) {
                            Icon(Icons.Filled.NotificationsActive, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Разрешить Push-уведомления")
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Уведомления о сообщениях", style = MaterialTheme.typography.bodyMedium)
                            Text(
                                text = "Push в шторке и фоне при получении новых сообщений",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = messagePushEnabled,
                            onCheckedChange = { enabled ->
                                messagePushEnabled = enabled
                                NotificationPreferences.setMessagePushEnabled(context, enabled)
                                onShowMessage(
                                    if (enabled) "Push о сообщениях включены" else "Push о сообщениях отключены"
                                )
                            },
                            modifier = Modifier.testTag("push_messages_switch")
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Уведомления о звонках", style = MaterialTheme.typography.bodyMedium)
                            Text(
                                text = "Push с высоким приоритетом при входящем вызове",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = callPushEnabled,
                            onCheckedChange = { enabled ->
                                callPushEnabled = enabled
                                NotificationPreferences.setCallPushEnabled(context, enabled)
                                onShowMessage(
                                    if (enabled) "Push о звонках включены" else "Push о звонках отключены"
                                )
                            },
                            modifier = Modifier.testTag("push_calls_switch")
                        )
                    }

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE && !canUseFullScreenCalls) {
                        OutlinedButton(
                            onClick = {
                                val intent = Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT).apply {
                                    data = Uri.fromParts("package", context.packageName, null)
                                }
                                runCatching { context.startActivity(intent) }
                                canUseFullScreenCalls = SpoXNotificationHelper.canUseFullScreenIntent(context)
                            },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("grant_fullscreen_call_permission_button")
                        ) {
                            Icon(Icons.Filled.Lock, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Разрешить звонки на экране блокировки")
                        }
                    }

                    if (cachedFcmToken.isNotBlank()) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "FCM Push-токен подключён",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Text(
                                    text = cachedFcmToken.take(18) + "..." + cachedFcmToken.takeLast(8),
                                    style = MaterialTheme.typography.labelSmall,
                                    fontFamily = FontFamily.Monospace,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            IconButton(
                                onClick = {
                                    clipboard.setText(AnnotatedString(cachedFcmToken))
                                    onShowMessage("FCM-токен скопирован")
                                },
                                modifier = Modifier.testTag("copy_fcm_token_button")
                            ) {
                                Icon(Icons.Filled.ContentCopy, contentDescription = "Скопировать FCM-токен")
                            }
                        }
                    } else {
                        Text(
                            text = "Фоновая доставка (WorkManager + FCM) активна при наличии сети.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    OutlinedButton(
                        onClick = {
                            if (!SpoXNotificationHelper.hasNotificationPermission(context)) {
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                    pushPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                } else {
                                    onShowMessage("Нет системного разрешения на уведомления")
                                }
                            } else {
                                val sent = SpoXNotificationHelper.showTestPushNotification(context)
                                onShowMessage(
                                    if (sent) "Тестовый Push отправлен в шторку уведомлений"
                                    else "Не удалось показать уведомление"
                                )
                            }
                        },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("test_push_notification_button")
                    ) {
                        Icon(Icons.Filled.NotificationsActive, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Отправить тестовый Push")
                    }
                }
            }

            // Security & Additional Auth Card (PIN + Biometrics)
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = MaterialTheme.colorScheme.surfaceContainer,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Filled.Lock,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Дополнительная авторизация и защита",
                            style = MaterialTheme.typography.titleSmall
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Вход по PIN-коду", style = MaterialTheme.typography.bodyMedium)
                            Text(
                                text = if (isPinEnabled) "4-значный код активен для этого аккаунта"
                                else "Запрашивать код-пароль при открытии SpoX",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = isPinEnabled,
                            onCheckedChange = { enabled ->
                                if (enabled) {
                                    showPinSetupDialog = true
                                } else {
                                    onDisablePin()
                                }
                            },
                            modifier = Modifier.testTag("pin_lock_switch")
                        )
                    }

                    if (isPinEnabled) {
                        OutlinedButton(
                            onClick = { showPinSetupDialog = true },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("change_pin_button")
                        ) {
                            Icon(Icons.Filled.Lock, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Изменить PIN-код")
                        }
                    }

                    HorizontalDivider()

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Filled.Fingerprint,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.secondary,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Биометрия (Отпечаток / Face ID)", style = MaterialTheme.typography.bodyMedium)
                            }
                            Text(
                                text = when (biometricCapability) {
                                    BiometricCapability.READY ->
                                        if (isBiometricEnabled) "Быстрая разблокировка включена"
                                        else "Мгновенный вход по отпечатку или лицу"
                                    BiometricCapability.NONE_ENROLLED ->
                                        "Добавьте отпечаток или распознавание лица в настройках устройства"
                                    BiometricCapability.NO_HARDWARE,
                                    BiometricCapability.HARDWARE_UNAVAILABLE ->
                                        "Датчик биометрии недоступен на этом устройстве"
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = isBiometricEnabled,
                            enabled = biometricCapability == BiometricCapability.READY || isBiometricEnabled,
                            onCheckedChange = { enabled ->
                                if (!enabled) {
                                    onSetBiometricEnabled(false)
                                } else {
                                    val activity = context.findFragmentActivity()
                                    if (activity == null) {
                                        onBiometricError("Не удалось открыть биометрическую проверку")
                                    } else {
                                        appLockManager.showBiometricPrompt(
                                            activity = activity,
                                            title = "Включить биометрию",
                                            subtitle = "Подтвердите отпечаток или лицо для входа в SpoX",
                                            hasPinFallback = false,
                                            negativeButtonText = "Отмена",
                                            onSuccess = { onSetBiometricEnabled(true) },
                                            onError = { err -> onBiometricError(err) }
                                        )
                                    }
                                }
                            },
                            modifier = Modifier.testTag("biometric_lock_switch")
                        )
                    }

                    if (isPinEnabled || isBiometricEnabled) {
                        Button(
                            onClick = onLockAppNow,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("lock_app_now_button")
                        ) {
                            Icon(Icons.Filled.Lock, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Заблокировать SpoX сейчас")
                        }
                    }
                }
            }

            Text(
                text = "SpoX • Версия ${BuildConfig.VERSION_NAME}",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier
                    .align(Alignment.CenterHorizontally)
                    .padding(top = 4.dp)
                    .testTag("app_version_label")
            )
            Spacer(modifier = Modifier.height(10.dp))
        }
    }

    if (showPinSetupDialog) {
        PinSetupDialog(
            isChangingExisting = isPinEnabled,
            onDismiss = { showPinSetupDialog = false },
            onPinConfirmed = { newPin ->
                showPinSetupDialog = false
                onSetPin(newPin)
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CustomizationSettingsSheet(
    appearance: ChatAppearanceConfig,
    onDismiss: () -> Unit,
    onSelectThemeMode: (AppThemeMode) -> Unit,
    onSelectVisualTheme: (AppVisualTheme) -> Unit,
    onSelectWallpaperPreset: (ChatWallpaperPreset) -> Unit,
    onPickCustomWallpaperUri: (Uri) -> Unit,
    onSelectOutgoingBubbleStyle: (OutgoingBubbleStyle) -> Unit,
    onSetShowStories: (Boolean) -> Unit = {},
    onSetShowFolders: (Boolean) -> Unit = {},
    onResetCustomization: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val scrollState = rememberScrollState()

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(scrollState)
                .navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 8.dp)
                .testTag("customization_settings_sheet"),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Surface(
                    shape = CircleShape,
                    color = MaterialTheme.colorScheme.secondary.copy(alpha = 0.14f),
                    modifier = Modifier.size(46.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Filled.Palette,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.secondary,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Кастомизация",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Тема приложения, обои чатов и цвета сообщений",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            CustomizationSettingsTab(
                appearance = appearance,
                onSelectThemeMode = onSelectThemeMode,
                onSelectVisualTheme = onSelectVisualTheme,
                onSelectWallpaperPreset = onSelectWallpaperPreset,
                onPickCustomWallpaperUri = onPickCustomWallpaperUri,
                onSelectOutgoingBubbleStyle = onSelectOutgoingBubbleStyle,
                onSetShowStories = onSetShowStories,
                onSetShowFolders = onSetShowFolders,
                onResetCustomization = onResetCustomization
            )
            Spacer(modifier = Modifier.height(10.dp))
        }
    }
}
