package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.GroupAdd
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.PersonRemove
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.Conversation
import com.example.data.model.CustomRolePermission
import com.example.data.model.PublicUserProfile
import com.example.data.model.UserPresenceStatus
import com.example.data.model.UserRole
import com.example.ui.components.CustomRoleBadge
import com.example.ui.components.RoleBadge
import com.example.ui.components.UserAvatar
import com.example.ui.components.UserPresenceIndicator
import com.example.ui.theme.ApplyLiquidGlassWindowBlur
import com.example.ui.theme.isLiquidGlassActive
import com.example.ui.theme.liquidGlassDialogContainerColor
import com.example.ui.theme.liquidGlassSheetContainerColor
import com.example.ui.theme.liquidGlassSheetScrimColor
import com.example.ui.theme.liquidGlassSurface

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GroupSettingsSheet(
    conversation: Conversation,
    currentUserId: String,
    membersById: Map<String, PublicUserProfile>,
    directoryUsers: List<PublicUserProfile>,
    serverSearchResults: List<PublicUserProfile>,
    isSearchingMembers: Boolean,
    hasRoomKey: Boolean,
    isBusy: Boolean,
    presenceNowMs: Long,
    initialShowAddMembers: Boolean = false,
    onDismiss: () -> Unit,
    onOpenSecuritySheet: () -> Unit,
    onSaveGroupSettings: (title: String, description: String) -> Unit,
    onSearchUsers: (query: String) -> Unit,
    onAddMembers: (List<PublicUserProfile>) -> Unit,
    onRemoveMember: (uid: String, displayName: String) -> Unit,
    onLeaveGroup: () -> Unit,
    onDeleteGroup: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val isCreator = conversation.isCreator(currentUserId)

    var titleDraft by remember(conversation.id, conversation.title) { mutableStateOf(conversation.title) }
    var descriptionDraft by remember(conversation.id, conversation.description) {
        mutableStateOf(conversation.description)
    }
    var showAddPanel by remember(conversation.id, initialShowAddMembers) {
        mutableStateOf(initialShowAddMembers)
    }
    var memberSearchQuery by remember { mutableStateOf("") }
    val selectedNewUids = remember { mutableStateListOf<String>() }

    var pendingRemoveMember by remember { mutableStateOf<Pair<String, String>?>(null) }
    var inspectedMemberProfile by remember { mutableStateOf<PublicUserProfile?>(null) }
    var showConfirmDeleteGroup by remember { mutableStateOf(false) }
    var showConfirmLeaveGroup by remember { mutableStateOf(false) }

    val sortedMembers = remember(conversation.memberUids, conversation.createdBy, currentUserId, membersById) {
        conversation.memberUids.distinct().sortedWith(
            compareBy<String>(
                { it != conversation.createdBy },
                { it != currentUserId },
                { (membersById[it]?.displayName ?: conversation.memberNames[it] ?: "").lowercase() }
            )
        )
    }

    val candidateList = remember(
        directoryUsers,
        serverSearchResults,
        conversation.memberUids,
        memberSearchQuery
    ) {
        val q = memberSearchQuery.trim()
        val combined = if (q.isBlank()) {
            directoryUsers
        } else {
            (serverSearchResults + directoryUsers).distinctBy { it.userId }
        }
        combined.filter { candidate ->
            candidate.userId !in conversation.memberUids && !candidate.isBanned() && (
                q.isBlank() ||
                    candidate.displayName.contains(q, ignoreCase = true) ||
                    candidate.handle.contains(q, ignoreCase = true) ||
                    candidate.handle.removePrefix("@").contains(q.removePrefix("@"), ignoreCase = true)
                )
        }
    }

    val candidatesById = remember(candidateList) { candidateList.associateBy { it.userId } }
    val glassActive = isLiquidGlassActive()

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = liquidGlassSheetContainerColor(),
        scrimColor = liquidGlassSheetScrimColor()
    ) {
        ApplyLiquidGlassWindowBlur()
        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .testTag("group_settings_sheet"),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item(key = "header") {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Настройки группы",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("close_group_settings_button")
                    ) {
                        Icon(Icons.Filled.Close, contentDescription = "Закрыть настройки")
                    }
                }
            }

            item(key = "hero_card") {
                val heroShape = RoundedCornerShape(20.dp)
                Surface(
                    shape = heroShape,
                    color = if (glassActive) Color.Transparent else MaterialTheme.colorScheme.surfaceContainer,
                    border = if (glassActive) null else BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    modifier = Modifier
                        .fillMaxWidth()
                        .then(if (glassActive) Modifier.liquidGlassSurface(shape = heroShape, isHighlighted = true) else Modifier)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            UserAvatar(
                                name = conversation.title,
                                isGroup = true,
                                size = 58.dp
                            )
                            Spacer(modifier = Modifier.width(14.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = conversation.title,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Surface(
                                        shape = RoundedCornerShape(50),
                                        color = MaterialTheme.colorScheme.primaryContainer
                                    ) {
                                        Text(
                                            text = "${conversation.memberUids.size} / 50 уч.",
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.SemiBold,
                                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                        )
                                    }
                                    if (isCreator) {
                                        Surface(
                                            shape = RoundedCornerShape(50),
                                            color = MaterialTheme.colorScheme.secondaryContainer
                                        ) {
                                            Text(
                                                text = "Создатель",
                                                style = MaterialTheme.typography.labelSmall,
                                                fontWeight = FontWeight.SemiBold,
                                                color = MaterialTheme.colorScheme.onSecondaryContainer,
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                            )
                                        }
                                    }
                                }
                            }
                            FilledTonalButton(
                                onClick = {
                                    onDismiss()
                                    onOpenSecuritySheet()
                                },
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.testTag("group_settings_security_button")
                            ) {
                                Icon(
                                    Icons.Filled.Shield,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("E2EE", style = MaterialTheme.typography.labelMedium)
                            }
                        }
                        if (conversation.description.isNotBlank()) {
                            Text(
                                text = conversation.description,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            item(key = "edit_info") {
                val cleanTitle = titleDraft.trim()
                val cleanDesc = descriptionDraft.trim()
                val isDirty = cleanTitle != conversation.title.trim() ||
                    cleanDesc != conversation.description.trim()

                val infoShape = RoundedCornerShape(20.dp)
                Surface(
                    shape = infoShape,
                    color = if (glassActive) Color.Transparent else MaterialTheme.colorScheme.surfaceContainerLow,
                    border = if (glassActive) null else BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    modifier = Modifier
                        .fillMaxWidth()
                        .then(if (glassActive) Modifier.liquidGlassSurface(shape = infoShape) else Modifier)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Filled.Edit,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Информация о группе",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        OutlinedTextField(
                            value = titleDraft,
                            onValueChange = { if (it.length <= 80) titleDraft = it },
                            label = { Text("Название группы") },
                            singleLine = true,
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("group_settings_title_input")
                        )
                        OutlinedTextField(
                            value = descriptionDraft,
                            onValueChange = { if (it.length <= 300) descriptionDraft = it },
                            label = { Text("Описание (необязательно)") },
                            placeholder = { Text("Правила, тема чата или заметка...") },
                            minLines = 2,
                            maxLines = 3,
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("group_settings_description_input")
                        )
                        Button(
                            onClick = { onSaveGroupSettings(cleanTitle, cleanDesc) },
                            enabled = cleanTitle.isNotBlank() && isDirty && !isBusy,
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("group_settings_save_button")
                        ) {
                            if (isBusy) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(18.dp),
                                    strokeWidth = 2.dp
                                )
                            } else {
                                Icon(Icons.Filled.Check, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Сохранить изменения")
                            }
                        }
                    }
                }
            }

            item(key = "members_header") {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Участники (${sortedMembers.size})",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    if (hasRoomKey && conversation.memberUids.size < 50) {
                        FilledTonalButton(
                            onClick = {
                                showAddPanel = !showAddPanel
                                if (!showAddPanel) {
                                    memberSearchQuery = ""
                                    selectedNewUids.clear()
                                    onSearchUsers("")
                                }
                            },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .height(42.dp)
                                .testTag("toggle_add_members_button")
                        ) {
                            Icon(
                                imageVector = if (showAddPanel) Icons.Filled.Close else Icons.Filled.PersonAdd,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(if (showAddPanel) "Скрыть" else "Добавить")
                        }
                    }
                }
            }

            item(key = "add_members_panel") {
                AnimatedVisibility(visible = showAddPanel && hasRoomKey) {
                    Surface(
                        shape = RoundedCornerShape(18.dp),
                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.28f),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.4f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text(
                                text = "Добавить участников",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.SemiBold
                            )
                            OutlinedTextField(
                                value = memberSearchQuery,
                                onValueChange = {
                                    memberSearchQuery = it
                                    onSearchUsers(it)
                                },
                                placeholder = { Text("Имя, @юзернейм или точный email...") },
                                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                                trailingIcon = {
                                    if (memberSearchQuery.isNotEmpty()) {
                                        IconButton(onClick = {
                                            memberSearchQuery = ""
                                            onSearchUsers("")
                                        }) {
                                            Icon(Icons.Filled.Close, contentDescription = "Очистить")
                                        }
                                    }
                                },
                                singleLine = true,
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("group_add_member_search_input")
                            )
                            if (isSearchingMembers) {
                                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                            }
                            if (candidateList.isEmpty()) {
                                Text(
                                    text = if (memberSearchQuery.isBlank()) {
                                        "Нет доступных пользователей для добавления или введите точный email / @ник."
                                    } else {
                                        "Подходящие пользователи не найдены."
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            } else {
                                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    candidateList.take(12).forEach { candidate ->
                                        val isChecked = candidate.userId in selectedNewUids
                                        Surface(
                                            shape = RoundedCornerShape(12.dp),
                                            color = if (isChecked) {
                                                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f)
                                            } else {
                                                MaterialTheme.colorScheme.surface
                                            },
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clickable(enabled = !isBusy) {
                                                    if (isChecked) selectedNewUids.remove(candidate.userId)
                                                    else selectedNewUids.add(candidate.userId)
                                                }
                                                .testTag("add_member_candidate_${candidate.userId}")
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Checkbox(
                                                    checked = isChecked,
                                                    onCheckedChange = { checked ->
                                                        if (checked) {
                                                            if (!isChecked) selectedNewUids.add(candidate.userId)
                                                        } else {
                                                            selectedNewUids.remove(candidate.userId)
                                                        }
                                                    }
                                                )
                                                UserAvatar(
                                                    name = candidate.displayName,
                                                    avatarBase64 = candidate.avatarBase64,
                                                    colorIndex = candidate.avatarColorIndex.toInt(),
                                                    size = 34.dp,
                                                    presenceStatus = candidate.presenceStatus(presenceNowMs)
                                                )
                                                Spacer(modifier = Modifier.width(10.dp))
                                                Column(modifier = Modifier.weight(1f)) {
                                                    Row(
                                                        verticalAlignment = Alignment.CenterVertically,
                                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                                    ) {
                                                        Text(
                                                            text = candidate.displayName,
                                                            style = MaterialTheme.typography.bodyMedium,
                                                            fontWeight = FontWeight.Medium,
                                                            maxLines = 1,
                                                            overflow = TextOverflow.Ellipsis,
                                                            modifier = Modifier.weight(1f, fill = false)
                                                        )
                                                        val candRole = UserRole.fromWire(candidate.role)
                                                        if (candRole != UserRole.USER) {
                                                            RoleBadge(role = candRole, compact = true)
                                                        }
                                                        if (candidate.hasCustomRole()) {
                                                            CustomRoleBadge(
                                                                name = candidate.customRoleName,
                                                                badgeText = candidate.customRoleBadge,
                                                                colorHex = candidate.customRoleColorHex,
                                                                compact = true,
                                                                isPriority = CustomRolePermission.PRIORITY_BADGE.wireKey in candidate.customRolePermissions
                                                            )
                                                        }
                                                    }
                                                    if (candidate.handle.isNotBlank()) {
                                                        Text(
                                                            text = candidate.handle,
                                                            style = MaterialTheme.typography.labelSmall,
                                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                if (selectedNewUids.isNotEmpty()) {
                                    Button(
                                        onClick = {
                                            val chosen = selectedNewUids.mapNotNull { candidatesById[it] }
                                            if (chosen.isNotEmpty()) {
                                                onAddMembers(chosen)
                                                selectedNewUids.clear()
                                                memberSearchQuery = ""
                                                showAddPanel = false
                                            }
                                        },
                                        enabled = !isBusy,
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(48.dp)
                                            .testTag("confirm_add_members_button")
                                    ) {
                                        Icon(Icons.Filled.PersonAdd, contentDescription = null, modifier = Modifier.size(18.dp))
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("Добавить участников (${selectedNewUids.size})")
                                    }
                                }
                            }
                        }
                    }
                }
            }

            items(sortedMembers, key = { "member_$it" }) { uid ->
                val memberProfile = membersById[uid]
                val name = memberProfile?.displayName?.ifBlank { null }
                    ?: conversation.memberNames[uid]?.ifBlank { null }
                    ?: "Участник"
                val isMemberCreator = uid == conversation.createdBy
                val isSelf = uid == currentUserId
                val presence = if (!isSelf && memberProfile != null) {
                    memberProfile.presenceStatus(presenceNowMs)
                } else {
                    null
                }

                val memberShape = RoundedCornerShape(16.dp)
                Surface(
                    shape = memberShape,
                    color = if (glassActive) Color.Transparent else MaterialTheme.colorScheme.surfaceContainer,
                    border = if (glassActive) null else BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    modifier = Modifier
                        .fillMaxWidth()
                        .then(
                            if (glassActive) Modifier.liquidGlassSurface(shape = memberShape)
                            else Modifier
                        )
                        .let { base ->
                            if (memberProfile != null) {
                                base.clickable { inspectedMemberProfile = memberProfile }
                            } else {
                                base
                            }
                        }
                        .testTag("group_member_row_$uid")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        UserAvatar(
                            name = name,
                            avatarBase64 = memberProfile?.avatarBase64.orEmpty(),
                            colorIndex = memberProfile?.avatarColorIndex?.toInt() ?: kotlin.math.abs(name.hashCode()),
                            size = 42.dp,
                            presenceStatus = presence
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = if (isSelf) "$name (Вы)" else name,
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = if (isSelf || isMemberCreator) FontWeight.SemiBold else FontWeight.Medium,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f, fill = false)
                                )
                                val memberRole = UserRole.fromWire(memberProfile?.role)
                                if (memberRole != UserRole.USER) {
                                    RoleBadge(role = memberRole, compact = true)
                                }
                                if (memberProfile?.hasCustomRole() == true) {
                                    CustomRoleBadge(
                                        name = memberProfile.customRoleName,
                                        badgeText = memberProfile.customRoleBadge,
                                        colorHex = memberProfile.customRoleColorHex,
                                        compact = true,
                                        isPriority = CustomRolePermission.PRIORITY_BADGE.wireKey in memberProfile.customRolePermissions
                                    )
                                }
                                if (isMemberCreator) {
                                    Surface(
                                        shape = RoundedCornerShape(50),
                                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.7f)
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(
                                                Icons.Filled.Star,
                                                contentDescription = null,
                                                tint = MaterialTheme.colorScheme.primary,
                                                modifier = Modifier.size(11.dp)
                                            )
                                            Spacer(modifier = Modifier.width(3.dp))
                                            Text(
                                                text = "Создатель",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.onPrimaryContainer
                                            )
                                        }
                                    }
                                }
                            }
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                val handle = memberProfile?.handle.orEmpty()
                                if (handle.isNotBlank()) {
                                    Text(
                                        text = handle,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                if (presence != null && presence != UserPresenceStatus.OFFLINE) {
                                    UserPresenceIndicator(status = presence, compact = true)
                                }
                            }
                        }

                        if (isCreator && !isMemberCreator) {
                            IconButton(
                                onClick = { pendingRemoveMember = uid to name },
                                enabled = !isBusy,
                                modifier = Modifier
                                    .size(48.dp)
                                    .testTag("remove_member_button_$uid")
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.PersonRemove,
                                    contentDescription = "Удалить участника $name",
                                    tint = MaterialTheme.colorScheme.error
                                )
                            }
                        }
                    }
                }
            }

            item(key = "danger_zone") {
                Spacer(modifier = Modifier.height(4.dp))
                HorizontalDivider()
                Spacer(modifier = Modifier.height(10.dp))
                if (isCreator) {
                    OutlinedButton(
                        onClick = { showConfirmDeleteGroup = true },
                        enabled = !isBusy,
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = MaterialTheme.colorScheme.error
                        ),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.65f)),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("delete_group_button")
                    ) {
                        Icon(Icons.Filled.DeleteForever, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Удалить группу для всех")
                    }
                } else {
                    OutlinedButton(
                        onClick = { showConfirmLeaveGroup = true },
                        enabled = !isBusy,
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = MaterialTheme.colorScheme.error
                        ),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.65f)),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("leave_group_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ExitToApp, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Покинуть группу")
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }

    pendingRemoveMember?.let { (targetUid, targetName) ->
        AlertDialog(
            onDismissRequest = { pendingRemoveMember = null },
            containerColor = liquidGlassDialogContainerColor(),
            title = { Text("Удалить участника «$targetName»?") },
            text = {
                Text("Участник потеряет доступ к чату. Ключ шифрования AES-256 будет обновлён для оставшихся участников.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        pendingRemoveMember = null
                        onRemoveMember(targetUid, targetName)
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.error,
                        contentColor = MaterialTheme.colorScheme.onError
                    )
                ) {
                    Text("Удалить")
                }
            },
            dismissButton = {
                TextButton(onClick = { pendingRemoveMember = null }) {
                    Text("Отмена")
                }
            }
        )
    }

    if (showConfirmDeleteGroup) {
        ConfirmDeleteChatDialog(
            conversation = conversation,
            currentUserId = currentUserId,
            resolvedTitle = conversation.title,
            onDismiss = { showConfirmDeleteGroup = false },
            onConfirm = {
                showConfirmDeleteGroup = false
                onDeleteGroup()
            }
        )
    }

    if (showConfirmLeaveGroup) {
        ConfirmLeaveGroupDialog(
            groupTitle = conversation.title,
            onDismiss = { showConfirmLeaveGroup = false },
            onConfirm = {
                showConfirmLeaveGroup = false
                onLeaveGroup()
            }
        )
    }

    inspectedMemberProfile?.let { member ->
        UserProfileSheet(
            displayName = member.displayName,
            handle = member.handle,
            avatarBase64 = member.avatarBase64,
            avatarColorIndex = member.avatarColorIndex.toInt(),
            keyFingerprint = member.keyFingerprint,
            role = UserRole.fromWire(member.role),
            customRoleName = member.customRoleName,
            customRoleBadge = member.customRoleBadge,
            customRoleColorHex = member.customRoleColorHex,
            customRolePermissions = member.customRolePermissions,
            presenceStatus = if (member.userId == currentUserId) null else member.presenceStatus(presenceNowMs),
            isSelf = member.userId == currentUserId,
            onDismiss = { inspectedMemberProfile = null }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddParticipantsFromDmSheet(
    existingPeerName: String,
    existingMemberUids: List<String>,
    directoryUsers: List<PublicUserProfile>,
    serverSearchResults: List<PublicUserProfile>,
    isSearching: Boolean,
    isBusy: Boolean,
    onDismiss: () -> Unit,
    onSearchUsers: (String) -> Unit,
    onCreateGroup: (title: String, selectedMembers: List<PublicUserProfile>) -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var groupTitle by remember(existingPeerName) { mutableStateOf("") }
    var searchQuery by remember { mutableStateOf("") }
    val selectedUids = remember { mutableStateListOf<String>() }

    val candidates = remember(directoryUsers, serverSearchResults, existingMemberUids, searchQuery) {
        val q = searchQuery.trim()
        val combined = if (q.isBlank()) directoryUsers else (serverSearchResults + directoryUsers).distinctBy { it.userId }
        combined.filter { candidate ->
            candidate.userId !in existingMemberUids && !candidate.isBanned() && (
                q.isBlank() ||
                    candidate.displayName.contains(q, ignoreCase = true) ||
                    candidate.handle.contains(q, ignoreCase = true)
                )
        }
    }
    val candidatesById = remember(candidates) { candidates.associateBy { it.userId } }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = liquidGlassSheetContainerColor(),
        scrimColor = liquidGlassSheetScrimColor()
    ) {
        ApplyLiquidGlassWindowBlur()
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.GroupAdd, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text("Добавить участников в группу", style = MaterialTheme.typography.titleLarge)
                    Text(
                        text = "Создаётся новый защищённый E2EE групповой чат с $existingPeerName и выбранными людьми.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            OutlinedTextField(
                value = groupTitle,
                onValueChange = { if (it.length <= 80) groupTitle = it },
                label = { Text("Название группы") },
                placeholder = { Text("Например: $existingPeerName и команда") },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = searchQuery,
                onValueChange = {
                    searchQuery = it
                    onSearchUsers(it)
                },
                placeholder = { Text("Имя, @юзернейм или точный email...") },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            )
            if (isSearching) {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            }
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 260.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(candidates, key = { it.userId }) { candidate ->
                    val checked = candidate.userId in selectedUids
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (checked) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
                        else MaterialTheme.colorScheme.surfaceContainer,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable(enabled = !isBusy) {
                                if (checked) selectedUids.remove(candidate.userId)
                                else selectedUids.add(candidate.userId)
                            }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = checked,
                                onCheckedChange = { isChecked ->
                                    if (isChecked) {
                                        if (!checked) selectedUids.add(candidate.userId)
                                    } else {
                                        selectedUids.remove(candidate.userId)
                                    }
                                }
                            )
                            UserAvatar(
                                name = candidate.displayName,
                                avatarBase64 = candidate.avatarBase64,
                                colorIndex = candidate.avatarColorIndex.toInt(),
                                size = 34.dp
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(candidate.displayName, style = MaterialTheme.typography.bodyMedium)
                                if (candidate.handle.isNotBlank()) {
                                    Text(
                                        candidate.handle,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }
            Button(
                onClick = {
                    val picked = selectedUids.mapNotNull { candidatesById[it] }
                    if (picked.isNotEmpty()) {
                        onCreateGroup(groupTitle, picked)
                    }
                },
                enabled = selectedUids.isNotEmpty() && !isBusy,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
            ) {
                Text("Создать группу (${selectedUids.size + 2} уч.)")
            }
            Spacer(modifier = Modifier.height(6.dp))
        }
    }
}

@Composable
fun ConfirmDeleteChatDialog(
    conversation: Conversation,
    currentUserId: String,
    resolvedTitle: String,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit
) {
    val isSaved = conversation.isSavedMessages(currentUserId)
    val title = when {
        conversation.isGroup -> "Удалить группу «$resolvedTitle»?"
        isSaved -> "Удалить чат «Избранное»?"
        else -> "Удалить чат с $resolvedTitle?"
    }
    val message = when {
        conversation.isGroup -> "Группа и вся переписка в ней будут безвозвратно удалены для всех участников."
        isSaved -> "Все сохранённые заметки и пересланные сообщения в «Избранном» будут удалены."
        else -> "Переписка и все сообщения этого чата будут безвозвратно удалены для обоих собеседников."
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = liquidGlassDialogContainerColor(),
        title = { Text(title) },
        text = { Text(message) },
        confirmButton = {
            Button(
                onClick = onConfirm,
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.error,
                    contentColor = MaterialTheme.colorScheme.onError
                ),
                modifier = Modifier.testTag("confirm_delete_chat_button")
            ) {
                Text("Удалить")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Отмена")
            }
        }
    )
}

@Composable
fun ConfirmLeaveGroupDialog(
    groupTitle: String,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = liquidGlassDialogContainerColor(),
        title = { Text("Покинуть группу «$groupTitle»?") },
        text = {
            Text("Вы выйдете из группового чата. Ключ шифрования E2EE будет обновлён для оставшихся участников.")
        },
        confirmButton = {
            Button(
                onClick = onConfirm,
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.error,
                    contentColor = MaterialTheme.colorScheme.onError
                ),
                modifier = Modifier.testTag("confirm_leave_group_button")
            ) {
                Text("Покинуть")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Отмена")
            }
        }
    )
}
