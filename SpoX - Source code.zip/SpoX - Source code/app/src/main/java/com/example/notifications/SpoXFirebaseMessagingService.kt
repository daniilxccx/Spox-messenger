package com.example.notifications

import android.util.Log
import com.example.R
import com.example.data.repository.ChatRepository
import com.google.firebase.Firebase
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class SpoXFirebaseMessagingService : FirebaseMessagingService() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        Log.d(TAG, "Refreshed FCM token")
        val appContext = applicationContext
        serviceScope.launch {
            runCatching {
                NotificationPreferences.saveFcmToken(appContext, token)
                if (FirebaseApp.getApps(appContext).isEmpty()) {
                    FirebaseApp.initializeApp(appContext)
                }
                val currentUid = Firebase.auth.currentUser?.uid ?: return@launch
                val dbId = appContext.getString(R.string.firestore_database_id)
                val db = FirebaseFirestore.getInstance(dbId)
                ChatRepository(db).updateFcmToken(currentUid, token)
            }.onFailure { err ->
                Log.w(TAG, "Failed to upload refreshed FCM token: ${err.message}")
            }
        }
    }

    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        super.onMessageReceived(remoteMessage)
        val data = remoteMessage.data
        val notification = remoteMessage.notification

        val payloadType = data["type"].orEmpty().lowercase()
        val callId = data["callId"].orEmpty()
        val chatId = data["chatId"].orEmpty()

        if (payloadType == "call" || callId.isNotBlank()) {
            val resolvedCallId = callId.ifBlank { "fcm_call_${System.currentTimeMillis()}" }
            val callerName = data["callerName"].orEmpty()
                .ifBlank { notification?.title ?: "Входящий звонок" }
            val conversationTitle = data["conversationTitle"].orEmpty().ifBlank { "SpoX" }
            val isGroupCall = data["isGroupCall"]?.toBooleanStrictOrNull() ?: false
            val callType = data["callType"].orEmpty().ifBlank { "audio" }

            SpoXNotificationHelper.showIncomingCallNotification(
                context = applicationContext,
                callId = resolvedCallId,
                callerName = callerName,
                conversationTitle = conversationTitle,
                isGroupCall = isGroupCall,
                callType = callType
            )
            return
        }

        val resolvedChatId = chatId.ifBlank { "general" }
        if (ActiveChatTracker.isActivelyViewingChat(resolvedChatId)) {
            return
        }

        val title = data["title"].orEmpty()
            .ifBlank { notification?.title ?: "SpoX" }
        val senderName = data["senderName"].orEmpty().ifBlank { title }
        val body = data["body"].orEmpty()
            .ifBlank { notification?.body ?: "Новое зашифрованное сообщение" }
        val unreadCount = data["unreadCount"]?.toIntOrNull()?.coerceAtLeast(1) ?: 1
        val sentAtMs = data["sentAtMs"]?.toLongOrNull() ?: System.currentTimeMillis()

        if (FirebaseApp.getApps(applicationContext).isEmpty()) {
            runCatching { FirebaseApp.initializeApp(applicationContext) }
        }
        val currentUid = runCatching { Firebase.auth.currentUser?.uid }.getOrNull().orEmpty()
        if (currentUid.isNotBlank() && resolvedChatId != "general") {
            NotificationPreferences.markChatNotified(applicationContext, currentUid, resolvedChatId, sentAtMs)
        }

        SpoXNotificationHelper.showMessageNotification(
            context = applicationContext,
            chatId = resolvedChatId,
            chatTitle = title,
            body = body,
            unreadCount = unreadCount,
            senderName = senderName
        )
    }

    private companion object {
        const val TAG = "SpoXFcmService"
    }
}
