package com.example.util

import com.google.firebase.Timestamp
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Calendar

class TimeFormattersTest {

    @Test
    fun formatTimeHm_handlesNullAndValidTimestamp() {
        assertEquals("", TimeFormatters.formatTimeHm(null))
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 14)
            set(Calendar.MINUTE, 5)
            set(Calendar.SECOND, 0)
        }
        assertEquals("14:05", TimeFormatters.formatTimeHm(Timestamp(cal.time)))
    }

    @Test
    fun formatChatListTimestamp_formatsTodayYesterdayAndOlder() {
        assertEquals("", TimeFormatters.formatChatListTimestamp(null))

        val today = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 9)
            set(Calendar.MINUTE, 30)
        }
        assertEquals("09:30", TimeFormatters.formatChatListTimestamp(Timestamp(today.time)))

        val yesterday = Calendar.getInstance().apply {
            add(Calendar.DAY_OF_YEAR, -1)
            set(Calendar.HOUR_OF_DAY, 18)
            set(Calendar.MINUTE, 0)
        }
        assertEquals("Вчера", TimeFormatters.formatChatListTimestamp(Timestamp(yesterday.time)))

        val older = Calendar.getInstance().apply {
            add(Calendar.DAY_OF_YEAR, -10)
        }
        val formatted = TimeFormatters.formatChatListTimestamp(Timestamp(older.time))
        assertTrue("Expected dd.MM format, got $formatted", formatted.matches(Regex("\\d{2}\\.\\d{2}")))
    }

    @Test
    fun formatCallTimestamp_formatsTodayAsHmAndOlderWithDate() {
        assertEquals("", TimeFormatters.formatCallTimestamp(null))

        val today = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 11)
            set(Calendar.MINUTE, 42)
        }
        assertEquals("11:42", TimeFormatters.formatCallTimestamp(Timestamp(today.time)))

        val older = Calendar.getInstance().apply {
            add(Calendar.DAY_OF_YEAR, -5)
        }
        val formatted = TimeFormatters.formatCallTimestamp(Timestamp(older.time))
        assertTrue("Expected comma-separated date and time, got $formatted", formatted.contains(", "))
    }

    @Test
    fun formatDateDivider_formatsTodayYesterdayCurrentYearAndPastYear() {
        val today = Calendar.getInstance()
        assertEquals("Сегодня", TimeFormatters.formatDateDivider(Timestamp(today.time)))

        val yesterday = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -1) }
        assertEquals("Вчера", TimeFormatters.formatDateDivider(Timestamp(yesterday.time)))

        val prevYear = Calendar.getInstance().apply {
            set(Calendar.YEAR, 2022)
            set(Calendar.MONTH, Calendar.MARCH)
            set(Calendar.DAY_OF_MONTH, 15)
        }
        val formatted = TimeFormatters.formatDateDivider(Timestamp(prevYear.time))
        assertTrue("Expected year 2022 in divider, got $formatted", formatted.contains("2022"))
    }

    @Test
    fun isSameCalendarDay_distinguishesSameAndDifferentDays() {
        val day1Morning = Calendar.getInstance().apply {
            set(2025, Calendar.MAY, 10, 8, 15, 0)
        }
        val day1Evening = Calendar.getInstance().apply {
            set(2025, Calendar.MAY, 10, 23, 55, 0)
        }
        val day2 = Calendar.getInstance().apply {
            set(2025, Calendar.MAY, 11, 0, 5, 0)
        }
        assertFalse(TimeFormatters.isSameCalendarDay(null, Timestamp(day1Morning.time)))
        assertTrue(TimeFormatters.isSameCalendarDay(Timestamp(day1Morning.time), Timestamp(day1Evening.time)))
        assertFalse(TimeFormatters.isSameCalendarDay(Timestamp(day1Evening.time), Timestamp(day2.time)))
    }
}
