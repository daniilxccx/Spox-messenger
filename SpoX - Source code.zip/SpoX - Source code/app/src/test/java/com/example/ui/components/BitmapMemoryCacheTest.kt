package com.example.ui.components

import android.graphics.Bitmap
import android.util.Base64
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertSame
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.ByteArrayOutputStream

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class BitmapMemoryCacheTest {

    private fun createPngBytes(width: Int, height: Int): ByteArray {
        val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        return ByteArrayOutputStream().use { out ->
            bmp.compress(Bitmap.CompressFormat.PNG, 100, out)
            bmp.recycle()
            out.toByteArray()
        }
    }

    @Test
    fun computeSampleSize_calculatesPowerOfTwoCorrectly() {
        assertEquals(1, BitmapMemoryCache.computeSampleSize(400, 300, 720))
        assertEquals(2, BitmapMemoryCache.computeSampleSize(1200, 800, 720))
        assertEquals(4, BitmapMemoryCache.computeSampleSize(1600, 1200, 400))
        assertEquals(1, BitmapMemoryCache.computeSampleSize(0, 0, 400))
    }

    @Test
    fun mediaThumb_decodesAndHitsLruCache() = runTest {
        val bytes = createPngBytes(64, 64)
        val first = BitmapMemoryCache.decodeMediaThumb("msg_thumb_test", bytes, maxDimensionPx = 400)
        assertNotNull(first)

        val cached = BitmapMemoryCache.getCachedMediaThumb("msg_thumb_test", bytes.size, maxDimensionPx = 400)
        assertNotNull(cached)
        assertSame(first, cached)
    }

    @Test
    fun avatar_cachesDecodedBitmap_andHandlesBlankOrMalformedBase64Safely() = runTest {
        assertNull(BitmapMemoryCache.decodeAvatar(""))
        assertNull(BitmapMemoryCache.decodeAvatar("===="))

        val bytes = createPngBytes(64, 64)
        val base64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
        val first = BitmapMemoryCache.decodeAvatar(base64)
        assertNotNull(first)

        val cached = BitmapMemoryCache.getCachedAvatar(base64)
        assertSame(first, cached)
    }

    @Test
    fun fullImage_handlesEmptySafely() = runTest {
        assertNull(BitmapMemoryCache.decodeFullImage(ByteArray(0)))
    }
}
