package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.SystemUpdate
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.BuildConfig
import com.example.data.model.CustomRolePermission
import com.example.data.model.PublicUserProfile
import com.example.data.model.UserPrivateProfile
import com.example.data.model.UserRole
import com.example.data.repository.SavedAccountsStore
import com.example.security.AppLockManager
import com.example.security.BiometricCapability
import com.example.ui.components.CustomRoleBadge
import com.example.ui.components.EncryptionBadge
import com.example.ui.components.RoleBadge
import com.example.ui.components.UserAvatar
import com.example.ui.components.smoothAppear
import com.example.ui.theme.isLiquidGlassActive
import com.example.ui.theme.liquidGlassSurface

@Composable
fun SettingsTabContent(
    privateProfile: UserPrivateProfile?,
    publicProfile: PublicUserProfile?,
    fallbackEmail: String,
    fallbackDisplayName: String,
    isPinEnabled: Boolean,
    isBiometricEnabled: Boolean,
    biometricCapability: BiometricCapability,
    appLockManager: AppLockManager,
    isResourceSavingEnabled: Boolean,
    savedAccountsCount: Int,
    activePluginsCount: Int,
    hasAvailableUpdate: Boolean,
    latestUpdateVersion: String?,
    canOpenModerationPanel: Boolean,
    isDeveloper: Boolean,
    adminUsersCount: Int,
    customRolesCount: Int,
    topPadding: Dp,
    bottomPadding: Dp,
    horizontalPadding: Dp,
    smoothAppearance: Boolean,
    onOpenOwnProfile: () -> Unit,
    onOpenEditProfile: () -> Unit,
    onOpenAccountSwitcher: () -> Unit,
    onOpenMessengerEditor: () -> Unit,
    onOpenCustomization: () -> Unit,
    onOpenPlugins: () -> Unit,
    onOpenUpdates: () -> Unit,
    onOpenModerationPanel: () -> Unit,
    onOpenCustomRoles: () -> Unit,
    onSetDiscoverable: (Boolean) -> Unit,
    onSetResourceSavingEnabled: (Boolean) -> Unit,
    onSetPin: (String) -> Unit,
    onDisablePin: () -> Unit,
    onSetBiometricEnabled: (Boolean) -> Unit,
    onLockAppNow: () -> Unit,
    onShowMessage: (String) -> Unit,
    onBiometricError: (String) -> Unit,
    onSignOut: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isGlass = isLiquidGlassActive()
    val scrollState = rememberScrollState()
    val displayName = privateProfile?.displayName?.ifBlank { null }
        ?: publicProfile?.displayName?.ifBlank { null }
        ?: fallbackDisplayName.ifBlank { "Пользователь" }
    val handle = privateProfile?.handle?.ifBlank { null } ?: publicProfile?.handle.orEmpty()
    val email = privateProfile?.email?.ifBlank { null } ?: fallbackEmail
    val avatarBase64 = privateProfile?.avatarBase64?.ifBlank { null } ?: publicProfile?.avatarBase64.orEmpty()
    val avatarColorIndex = (publicProfile?.avatarColorIndex ?: 0L).toInt()
    val role = UserRole.fromWire(privateProfile?.role ?: publicProfile?.role)

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(
                PaddingValues(
                    start = horizontalPadding,
                    end = horizontalPadding,
                    top = topPadding,
                    bottom = bottomPadding
                )
            )
            .testTag("settings_tab_content"),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Profile Hero Card
        val heroShape = RoundedCornerShape(22.dp)
        Surface(
            shape = heroShape,
            color = if (isGlass) Color.Transparent else MaterialTheme.colorScheme.surfaceContainerLow,
            border = if (isGlass) null else BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
            modifier = Modifier
                .fillMaxWidth()
                .smoothAppear(
                    enabled = smoothAppearance,
                    key = "settings_hero",
                    initialTranslationYDp = -8f,
                    durationMillis = 220
                )
                .then(
                    if (isGlass) {
                        Modifier.liquidGlassSurface(
                            shape = heroShape,
                            tintColor = MaterialTheme.colorScheme.primaryContainer,
                            isHighlighted = true
                        )
                    } else Modifier
                )
                .testTag("settings_profile_hero_card")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    UserAvatar(
                        name = displayName,
                        avatarBase64 = avatarBase64,
                        colorIndex = avatarColorIndex,
                        size = 58.dp
                    )
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = displayName,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f, fill = false)
                            )
                            EncryptionBadge(label = "E2EE")
                        }
                        if (handle.isNotBlank()) {
                            Text(
                                text = "@${handle.removePrefix("@")}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.primary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        } else if (email.isNotBlank()) {
                            Text(
                                text = email,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        if (role != UserRole.USER || privateProfile?.hasCustomRole() == true) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                if (role != UserRole.USER) {
                                    RoleBadge(role = role, compact = true)
                                }
                                if (privateProfile?.hasCustomRole() == true) {
                                    CustomRoleBadge(
                                        name = privateProfile.customRoleName,
                                        badgeText = privateProfile.customRoleBadge,
                                        colorHex = privateProfile.customRoleColorHex,
                                        compact = true,
                                        isPriority = privateProfile.hasPermission(CustomRolePermission.PRIORITY_BADGE)
                                    )
                                }
                            }
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilledTonalButton(
                        onClick = onOpenOwnProfile,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .defaultMinSize(minHeight = 48.dp)
                            .testTag("settings_tab_view_profile_button")
                    ) {
                        Icon(Icons.Filled.Person, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Профиль", maxLines = 1)
                    }
                    Button(
                        onClick = onOpenEditProfile,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .defaultMinSize(minHeight = 48.dp)
                            .testTag("settings_tab_edit_profile_button")
                    ) {
                        Icon(Icons.Filled.Edit, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Изменить", maxLines = 1)
                    }
                }
            }
        }

        // Messenger Tools & Appearance Shortcuts
        SettingsShortcutCard(
            icon = Icons.Filled.SwapHoriz,
            iconTint = MaterialTheme.colorScheme.tertiary,
            title = "Аккаунты ($savedAccountsCount/${SavedAccountsStore.MAX_ACCOUNTS})",
            subtitle = "Сменить или добавить профиль Google",
            onClick = onOpenAccountSwitcher,
            testTag = "settings_tab_accounts_button"
        )

        SettingsShortcutCard(
            icon = Icons.Filled.Tune,
            iconTint = MaterialTheme.colorScheme.primary,
            title = "Редактировать мессенджер",
            subtitle = "Истории, папки, плавное появление, Liquid Glass",
            onClick = onOpenMessengerEditor,
            testTag = "settings_tab_messenger_editor_button"
        )

        SettingsShortcutCard(
            icon = Icons.Filled.Palette,
            iconTint = MaterialTheme.colorScheme.secondary,
            title = "Кастомизация и оформление",
            subtitle = "Темы, обои чатов и цвета сообщений",
            onClick = onOpenCustomization,
            highlighted = false,
            testTag = "settings_tab_customization_button"
        )

        SettingsShortcutCard(
            icon = Icons.Filled.Extension,
            iconTint = MaterialTheme.colorScheme.tertiary,
            title = "Плагины и скрипты (Lua)",
            subtitle = "$activePluginsCount вкл. • встроенные модули и шаблон .lua",
            onClick = onOpenPlugins,
            testTag = "settings_tab_plugins_button"
        )

        SettingsShortcutCard(
            icon = Icons.Filled.SystemUpdate,
            iconTint = MaterialTheme.colorScheme.primary,
            title = "Обновления (GitHub Releases)",
            subtitle = if (hasAvailableUpdate && !latestUpdateVersion.isNullOrBlank()) {
                "Доступна новая версия v$latestUpdateVersion"
            } else {
                "Текущая v${BuildConfig.VERSION_NAME} • Проверка релизов"
            },
            onClick = onOpenUpdates,
            highlighted = hasAvailableUpdate,
            showBadgeDot = hasAvailableUpdate,
            testTag = "settings_tab_updates_button"
        )

        if (canOpenModerationPanel) {
            SettingsShortcutCard(
                icon = Icons.Filled.AdminPanelSettings,
                iconTint = MaterialTheme.colorScheme.primary,
                title = if (adminUsersCount > 0) "Модерация аккаунтов ($adminUsersCount)" else "Модерация аккаунтов",
                subtitle = "Блокировки, муты и управление доступом",
                onClick = onOpenModerationPanel,
                testTag = "settings_tab_moderation_button"
            )
        }

        if (isDeveloper) {
            SettingsShortcutCard(
                icon = Icons.Filled.AutoAwesome,
                iconTint = MaterialTheme.colorScheme.primary,
                title = "Кастомные роли ($customRolesCount)",
                subtitle = "Создание ролей, прав и выдача пользователям",
                onClick = onOpenCustomRoles,
                testTag = "settings_tab_custom_roles_button"
            )
        }

        // Core Settings Cards (Privacy, Resource Saving, Push, PIN/Biometric, Version)
        AppSettingsBody(
            privateProfile = privateProfile,
            publicProfile = publicProfile,
            isPinEnabled = isPinEnabled,
            isBiometricEnabled = isBiometricEnabled,
            biometricCapability = biometricCapability,
            appLockManager = appLockManager,
            isResourceSavingEnabled = isResourceSavingEnabled,
            showQuickFeatureLinks = false,
            onSetDiscoverable = onSetDiscoverable,
            onSetResourceSavingEnabled = onSetResourceSavingEnabled,
            onSetPin = onSetPin,
            onDisablePin = onDisablePin,
            onSetBiometricEnabled = onSetBiometricEnabled,
            onLockAppNow = onLockAppNow,
            onShowMessage = onShowMessage,
            onBiometricError = onBiometricError
        )

        OutlinedButton(
            onClick = onSignOut,
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier
                .fillMaxWidth()
                .defaultMinSize(minHeight = 50.dp)
                .testTag("settings_tab_sign_out_button")
        ) {
            Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Выйти из аккаунта")
        }
    }
}

@Composable
private fun SettingsShortcutCard(
    icon: ImageVector,
    iconTint: Color,
    title: String,
    subtitle: String,
    onClick: () -> Unit,
    highlighted: Boolean = false,
    showBadgeDot: Boolean = false,
    testTag: String
) {
    val isGlass = isLiquidGlassActive()
    val cardShape = RoundedCornerShape(18.dp)
    Surface(
        shape = cardShape,
        color = if (isGlass) {
            Color.Transparent
        } else if (highlighted) {
            MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.34f)
        } else {
            MaterialTheme.colorScheme.surfaceContainer
        },
        border = if (isGlass) null else BorderStroke(
            width = 1.dp,
            color = if (highlighted) {
                MaterialTheme.colorScheme.primary.copy(alpha = 0.45f)
            } else {
                MaterialTheme.colorScheme.outlineVariant
            }
        ),
        modifier = Modifier
            .fillMaxWidth()
            .defaultMinSize(minHeight = 64.dp)
            .then(
                if (isGlass) {
                    Modifier.liquidGlassSurface(
                        shape = cardShape,
                        tintColor = if (highlighted) MaterialTheme.colorScheme.primaryContainer else null,
                        isHighlighted = highlighted
                    )
                } else Modifier
            )
            .clip(cardShape)
            .clickable(onClick = onClick)
            .testTag(testTag)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                shape = CircleShape,
                color = iconTint.copy(alpha = 0.16f),
                modifier = Modifier.size(38.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = iconTint,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    if (showBadgeDot) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primary)
                        )
                    }
                }
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = if (highlighted) {
                        MaterialTheme.colorScheme.primary
                    } else {
                        MaterialTheme.colorScheme.onSurfaceVariant
                    },
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Icon(
                imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                contentDescription = null,
                tint = iconTint
            )
        }
    }
}
