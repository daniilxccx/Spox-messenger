package com.example.ui.media

import android.content.Intent
import android.view.TextureView
import androidx.annotation.OptIn
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.AspectRatio
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.Forward10
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.filled.Replay10
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Subtitles
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.VideoSize
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import com.example.media.FileAttachmentHelper
import com.example.media.LocalSpoxAudioPlayer
import com.example.media.SpoxMediaEngine
import com.example.media.SpoxTrackOption
import com.example.media.SpoxVideoRequest
import kotlinx.coroutines.delay

private enum class VideoScaleMode(val label: String) {
    FIT("По размеру"),
    CROP("Заполнить"),
    FILL("Растянуть")
}

@OptIn(UnstableApi::class)
@Composable
fun SpoxVideoPlayerDialog(
    request: SpoxVideoRequest,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val hostView = LocalView.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val audioPlayer = LocalSpoxAudioPlayer.current

    val trackSelector = remember(request.id) { DefaultTrackSelector(context) }
    val exoPlayer = remember(request.id) {
        SpoxMediaEngine.createExoPlayer(
            context = context,
            trackSelector = trackSelector,
            isAudioOnly = false
        )
    }

    var isPlaying by remember(request.id) { mutableStateOf(false) }
    var isBuffering by remember(request.id) { mutableStateOf(true) }
    var isEnded by remember(request.id) { mutableStateOf(false) }
    var hasRenderedFirstFrame by remember(request.id) { mutableStateOf(false) }
    var durationMs by remember(request.id) { mutableLongStateOf(0L) }
    var positionMs by remember(request.id) { mutableLongStateOf(0L) }
    var bufferedMs by remember(request.id) { mutableLongStateOf(0L) }
    var videoWidth by remember(request.id) { mutableIntStateOf(16) }
    var videoHeight by remember(request.id) { mutableIntStateOf(9) }
    var pixelRatio by remember(request.id) { mutableFloatStateOf(1f) }
    var currentTracks by remember(request.id) { mutableStateOf(Tracks.EMPTY) }
    var errorMessage by remember(request.id) { mutableStateOf<String?>(null) }

    var controlsVisible by remember { mutableStateOf(true) }
    var controlsLocked by remember { mutableStateOf(false) }
    var isMuted by remember { mutableStateOf(false) }
    var loopEnabled by remember { mutableStateOf(false) }
    var playbackSpeed by remember { mutableFloatStateOf(1f) }
    var scaleMode by remember { mutableStateOf(VideoScaleMode.FIT) }
    var showTracksDialog by remember { mutableStateOf(false) }
    var seekFeedbackText by remember { mutableStateOf<String?>(null) }
    var isDraggingSlider by remember { mutableStateOf(false) }
    var sliderDragMs by remember { mutableFloatStateOf(0f) }

    LaunchedEffect(request.id) {
        audioPlayer?.pauseIfPlaying()
        val item = MediaItem.Builder()
            .setMediaId(request.id)
            .setUri(request.uri)
            .apply {
                if (request.mimeType.isNotBlank() && request.mimeType != "application/octet-stream") {
                    setMimeType(request.mimeType)
                }
            }
            .build()
        exoPlayer.setMediaItem(item)
        exoPlayer.prepare()
        exoPlayer.playWhenReady = true
    }

    DisposableEffect(exoPlayer, hostView) {
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) {
                isPlaying = playing
                hostView.keepScreenOn = playing
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                isBuffering = playbackState == Player.STATE_BUFFERING
                isEnded = playbackState == Player.STATE_ENDED
                if (playbackState == Player.STATE_ENDED) {
                    controlsVisible = true
                }
                val dur = exoPlayer.duration
                if (dur != C.TIME_UNSET && dur > 0) {
                    durationMs = dur
                }
            }

            override fun onVideoSizeChanged(videoSize: VideoSize) {
                if (videoSize.width > 0 && videoSize.height > 0) {
                    videoWidth = videoSize.width
                    videoHeight = videoSize.height
                    pixelRatio = if (videoSize.pixelWidthHeightRatio > 0f) videoSize.pixelWidthHeightRatio else 1f
                }
            }

            override fun onRenderedFirstFrame() {
                hasRenderedFirstFrame = true
            }

            override fun onTracksChanged(tracks: Tracks) {
                currentTracks = tracks
                val dur = exoPlayer.duration
                if (dur != C.TIME_UNSET && dur > 0) {
                    durationMs = dur
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                isPlaying = false
                isBuffering = false
                controlsVisible = true
                errorMessage = SpoxMediaEngine.describePlaybackError(error)
            }
        }
        exoPlayer.addListener(listener)

        val lifecycleObserver = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_PAUSE) {
                exoPlayer.pause()
            }
        }
        lifecycleOwner.lifecycle.addObserver(lifecycleObserver)

        onDispose {
            hostView.keepScreenOn = false
            lifecycleOwner.lifecycle.removeObserver(lifecycleObserver)
            exoPlayer.removeListener(listener)
            runCatching { exoPlayer.clearVideoTextureView(null) }
            runCatching { exoPlayer.release() }
        }
    }

    LaunchedEffect(isPlaying, isDraggingSlider) {
        while (true) {
            positionMs = exoPlayer.currentPosition.coerceAtLeast(0L)
            bufferedMs = exoPlayer.bufferedPosition.coerceAtLeast(0L)
            val dur = exoPlayer.duration
            if (dur != C.TIME_UNSET && dur > 0) durationMs = dur
            delay(180L)
        }
    }

    LaunchedEffect(controlsVisible, isPlaying, controlsLocked, showTracksDialog) {
        if (controlsVisible && isPlaying && !controlsLocked && !showTracksDialog) {
            delay(3500L)
            controlsVisible = false
        }
    }

    LaunchedEffect(seekFeedbackText) {
        if (seekFeedbackText != null) {
            delay(750L)
            seekFeedbackText = null
        }
    }

    val audioTracks = remember(currentTracks) {
        SpoxMediaEngine.extractTrackOptions(currentTracks, C.TRACK_TYPE_AUDIO)
    }
    val subtitleTracks = remember(currentTracks) {
        SpoxMediaEngine.extractTrackOptions(currentTracks, C.TRACK_TYPE_TEXT)
    }
    val streamSummary = remember(currentTracks, videoWidth, videoHeight) {
        val vs = VideoSize(videoWidth, videoHeight)
        SpoxMediaEngine.extractVideoSummary(currentTracks, vs)
    }

    val safeAspectRatio = remember(videoWidth, videoHeight, pixelRatio) {
        val raw = (videoWidth.toFloat() * pixelRatio) / videoHeight.coerceAtLeast(1).toFloat()
        raw.coerceIn(0.35f, 3.2f)
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            decorFitsSystemWindows = false
        )
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFF06080D))
                .testTag("spox_video_player_dialog")
        ) {
            // Video Viewport
            BoxWithConstraints(
                modifier = Modifier
                    .fillMaxSize()
                    .clipToBounds()
                    .pointerInput(controlsLocked, durationMs) {
                        detectTapGestures(
                            onTap = {
                                controlsVisible = !controlsVisible
                            },
                            onDoubleTap = { offset ->
                                if (controlsLocked) {
                                    controlsVisible = true
                                    return@detectTapGestures
                                }
                                val width = size.width.toFloat().coerceAtLeast(1f)
                                if (offset.x < width * 0.36f) {
                                    val target = (exoPlayer.currentPosition - 10_000L).coerceAtLeast(0L)
                                    exoPlayer.seekTo(target)
                                    positionMs = target
                                    seekFeedbackText = "« -10 сек"
                                } else if (offset.x > width * 0.64f) {
                                    val maxDur = durationMs.coerceAtLeast(exoPlayer.currentPosition + 10_000L)
                                    val target = (exoPlayer.currentPosition + 10_000L).coerceAtMost(maxDur)
                                    exoPlayer.seekTo(target)
                                    positionMs = target
                                    seekFeedbackText = "+10 сек »"
                                } else {
                                    if (exoPlayer.isPlaying) exoPlayer.pause() else exoPlayer.play()
                                }
                            }
                        )
                    },
                contentAlignment = Alignment.Center
            ) {
                val containerAspect = if (maxHeight.value > 0f) maxWidth.value / maxHeight.value else 16f / 9f
                val videoModifier = when (scaleMode) {
                    VideoScaleMode.FILL -> Modifier.fillMaxSize()
                    VideoScaleMode.FIT -> {
                        if (safeAspectRatio >= containerAspect) {
                            Modifier
                                .fillMaxWidth()
                                .height(maxWidth / safeAspectRatio)
                        } else {
                            Modifier
                                .height(maxHeight)
                                .width(maxHeight * safeAspectRatio)
                        }
                    }
                    VideoScaleMode.CROP -> {
                        if (safeAspectRatio >= containerAspect) {
                            Modifier
                                .height(maxHeight)
                                .width(maxHeight * safeAspectRatio)
                        } else {
                            Modifier
                                .fillMaxWidth()
                                .height(maxWidth / safeAspectRatio)
                        }
                    }
                }

                AndroidView(
                    factory = { ctx ->
                        TextureView(ctx).also { tv ->
                            exoPlayer.setVideoTextureView(tv)
                        }
                    },
                    modifier = videoModifier
                )

                if (!hasRenderedFirstFrame && errorMessage == null) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color(0xFF06080D))
                    )
                }
            }

            if (isBuffering && errorMessage == null) {
                CircularProgressIndicator(
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier
                        .size(44.dp)
                        .align(Alignment.Center)
                )
            }

            // Double-tap seek feedback pill
            AnimatedVisibility(
                visible = seekFeedbackText != null,
                enter = fadeIn(),
                exit = fadeOut(),
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .statusBarsPadding()
                    .padding(top = 74.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(50),
                    color = Color.Black.copy(alpha = 0.72f),
                    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.22f))
                ) {
                    Text(
                        text = seekFeedbackText.orEmpty(),
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.SemiBold,
                        color = Color.White,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                    )
                }
            }

            // Error fallback card
            if (errorMessage != null) {
                Surface(
                    shape = RoundedCornerShape(22.dp),
                    color = Color(0xFF141822),
                    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.14f)),
                    modifier = Modifier
                        .align(Alignment.Center)
                        .padding(24.dp)
                        .fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(22.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = "Не удалось воспроизвести видео",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = errorMessage.orEmpty(),
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.White.copy(alpha = 0.78f),
                            textAlign = TextAlign.Center
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            TextButton(onClick = onDismiss) {
                                Text("Закрыть", color = Color.White.copy(alpha = 0.85f))
                            }
                            if (!FileAttachmentHelper.isUnsafeExecutableFile(request.title, request.mimeType)) {
                                Button(
                                    onClick = {
                                        runCatching {
                                            val openIntent = Intent(Intent.ACTION_VIEW).apply {
                                                setDataAndType(request.uri, request.mimeType.ifBlank { "video/*" })
                                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                                            }
                                            context.startActivity(Intent.createChooser(openIntent, "Открыть видео"))
                                        }
                                    }
                                ) {
                                    Icon(Icons.Filled.OpenInNew, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Внешний плеер")
                                }
                            }
                        }
                    }
                }
            }

            // Locked overlay pill
            AnimatedVisibility(
                visible = controlsVisible && controlsLocked,
                enter = fadeIn(),
                exit = fadeOut(),
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .navigationBarsPadding()
                    .padding(bottom = 28.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(50),
                    color = Color.Black.copy(alpha = 0.72f),
                    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.25f)),
                    modifier = Modifier
                        .clickable { controlsLocked = false }
                        .testTag("video_unlock_button")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 18.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.Lock, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Экран заблокирован • Нажмите для разблокировки", color = Color.White, style = MaterialTheme.typography.labelMedium)
                    }
                }
            }

            // Full HUD Controls
            AnimatedVisibility(
                visible = controlsVisible && !controlsLocked && errorMessage == null,
                enter = fadeIn(),
                exit = fadeOut(),
                modifier = Modifier.fillMaxSize()
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    // Top gradient bar
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .align(Alignment.TopCenter)
                            .background(
                                Brush.verticalGradient(
                                    listOf(Color.Black.copy(alpha = 0.82f), Color.Transparent)
                                )
                            )
                            .statusBarsPadding()
                            .padding(horizontal = 10.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = onDismiss,
                            modifier = Modifier
                                .size(48.dp)
                                .testTag("video_close_button")
                        ) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Закрыть видео", tint = Color.White)
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = request.title,
                                style = MaterialTheme.typography.titleMedium,
                                color = Color.White,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            val infoLine = listOfNotNull(
                                request.formatBadge.takeIf { it.isNotBlank() },
                                streamSummary.takeIf { it.isNotBlank() }
                            ).joinToString(" • ")
                            if (infoLine.isNotBlank()) {
                                Text(
                                    text = infoLine,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color.White.copy(alpha = 0.76f),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                        if (audioTracks.size > 1 || subtitleTracks.isNotEmpty()) {
                            IconButton(
                                onClick = { showTracksDialog = true },
                                modifier = Modifier
                                    .size(48.dp)
                                    .testTag("video_tracks_button")
                            ) {
                                Icon(
                                    imageVector = if (subtitleTracks.isNotEmpty()) Icons.Filled.Subtitles else Icons.Filled.Audiotrack,
                                    contentDescription = "Дорожки и субтитры",
                                    tint = Color.White
                                )
                            }
                        }
                        IconButton(
                            onClick = {
                                val modes = VideoScaleMode.entries
                                scaleMode = modes[(modes.indexOf(scaleMode) + 1) % modes.size]
                            },
                            modifier = Modifier
                                .size(48.dp)
                                .testTag("video_aspect_button")
                        ) {
                            Icon(Icons.Filled.AspectRatio, contentDescription = scaleMode.label, tint = Color.White)
                        }
                    }

                    // Center transport controls
                    Row(
                        modifier = Modifier.align(Alignment.Center),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(24.dp)
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = Color.Black.copy(alpha = 0.56f),
                            modifier = Modifier.size(54.dp)
                        ) {
                            IconButton(
                                onClick = {
                                    val target = (exoPlayer.currentPosition - 10_000L).coerceAtLeast(0L)
                                    exoPlayer.seekTo(target)
                                    positionMs = target
                                },
                                modifier = Modifier.fillMaxSize()
                            ) {
                                Icon(Icons.Filled.Replay10, contentDescription = "-10 сек", tint = Color.White, modifier = Modifier.size(28.dp))
                            }
                        }

                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.92f),
                            shadowElevation = 6.dp,
                            modifier = Modifier.size(68.dp)
                        ) {
                            IconButton(
                                onClick = {
                                    if (isEnded) {
                                        exoPlayer.seekTo(0L)
                                        exoPlayer.play()
                                    } else if (isPlaying) {
                                        exoPlayer.pause()
                                    } else {
                                        exoPlayer.play()
                                    }
                                },
                                modifier = Modifier
                                    .fillMaxSize()
                                    .testTag("video_play_pause_button")
                            ) {
                                Icon(
                                    imageVector = when {
                                        isEnded -> Icons.Filled.Replay
                                        isPlaying -> Icons.Filled.Pause
                                        else -> Icons.Filled.PlayArrow
                                    },
                                    contentDescription = if (isPlaying) "Пауза" else "Воспроизвести",
                                    tint = MaterialTheme.colorScheme.onPrimary,
                                    modifier = Modifier.size(36.dp)
                                )
                            }
                        }

                        Surface(
                            shape = CircleShape,
                            color = Color.Black.copy(alpha = 0.56f),
                            modifier = Modifier.size(54.dp)
                        ) {
                            IconButton(
                                onClick = {
                                    val maxDur = durationMs.coerceAtLeast(exoPlayer.currentPosition + 10_000L)
                                    val target = (exoPlayer.currentPosition + 10_000L).coerceAtMost(maxDur)
                                    exoPlayer.seekTo(target)
                                    positionMs = target
                                },
                                modifier = Modifier.fillMaxSize()
                            ) {
                                Icon(Icons.Filled.Forward10, contentDescription = "+10 сек", tint = Color.White, modifier = Modifier.size(28.dp))
                            }
                        }
                    }

                    // Bottom gradient bar with scrubber & options
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .align(Alignment.BottomCenter)
                            .background(
                                Brush.verticalGradient(
                                    listOf(Color.Transparent, Color.Black.copy(alpha = 0.88f))
                                )
                            )
                            .navigationBarsPadding()
                            .padding(horizontal = 16.dp, vertical = 12.dp)
                    ) {
                        val effectiveDuration = durationMs.coerceAtLeast(1L)
                        val displayedPosition = if (isDraggingSlider) sliderDragMs.toLong() else positionMs
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = SpoxMediaEngine.formatMediaDuration(displayedPosition),
                                style = MaterialTheme.typography.labelMedium,
                                color = Color.White
                            )
                            Text(
                                text = scaleMode.label,
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.White.copy(alpha = 0.72f)
                            )
                            Text(
                                text = SpoxMediaEngine.formatMediaDuration(durationMs),
                                style = MaterialTheme.typography.labelMedium,
                                color = Color.White.copy(alpha = 0.82f)
                            )
                        }

                        Slider(
                            value = displayedPosition.toFloat().coerceIn(0f, effectiveDuration.toFloat()),
                            onValueChange = { value ->
                                isDraggingSlider = true
                                sliderDragMs = value
                            },
                            onValueChangeFinished = {
                                val target = sliderDragMs.toLong()
                                exoPlayer.seekTo(target)
                                positionMs = target
                                isDraggingSlider = false
                            },
                            valueRange = 0f..effectiveDuration.toFloat(),
                            colors = SliderDefaults.colors(
                                thumbColor = MaterialTheme.colorScheme.primary,
                                activeTrackColor = MaterialTheme.colorScheme.primary,
                                inactiveTrackColor = Color.White.copy(alpha = 0.28f)
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("video_seek_slider")
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                IconButton(
                                    onClick = {
                                        isMuted = !isMuted
                                        exoPlayer.volume = if (isMuted) 0f else 1f
                                    },
                                    modifier = Modifier.size(48.dp)
                                ) {
                                    Icon(
                                        imageVector = if (isMuted) Icons.AutoMirrored.Filled.VolumeOff else Icons.AutoMirrored.Filled.VolumeUp,
                                        contentDescription = if (isMuted) "Включить звук" else "Выключить звук",
                                        tint = Color.White
                                    )
                                }
                                IconButton(
                                    onClick = {
                                        loopEnabled = !loopEnabled
                                        exoPlayer.repeatMode = if (loopEnabled) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF
                                    },
                                    modifier = Modifier.size(48.dp)
                                ) {
                                    Icon(
                                        imageVector = if (loopEnabled) Icons.Filled.RepeatOne else Icons.Filled.Repeat,
                                        contentDescription = "Повтор",
                                        tint = if (loopEnabled) MaterialTheme.colorScheme.primary else Color.White.copy(alpha = 0.82f)
                                    )
                                }
                                IconButton(
                                    onClick = { controlsLocked = true },
                                    modifier = Modifier.size(48.dp)
                                ) {
                                    Icon(Icons.Filled.LockOpen, contentDescription = "Блокировка экрана", tint = Color.White.copy(alpha = 0.85f))
                                }
                            }

                            val speeds = listOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f)
                            Surface(
                                shape = RoundedCornerShape(50),
                                color = Color.White.copy(alpha = 0.14f),
                                modifier = Modifier
                                    .clickable {
                                        val idx = speeds.indexOfFirst { kotlin.math.abs(it - playbackSpeed) < 0.05f }
                                        val next = speeds[(idx + 1) % speeds.size]
                                        playbackSpeed = next
                                        exoPlayer.playbackParameters = PlaybackParameters(next)
                                    }
                                    .testTag("video_speed_button")
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 9.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Filled.Speed, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    val speedLabel = if (playbackSpeed == 1.0f) "1.0x" else "${playbackSpeed}x"
                                    Text(speedLabel, color = Color.White, style = MaterialTheme.typography.labelLarge)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showTracksDialog) {
        VideoTracksDialog(
            audioTracks = audioTracks,
            subtitleTracks = subtitleTracks,
            onSelectAudio = { opt ->
                val group = currentTracks.groups.getOrNull(opt.groupIndex)?.mediaTrackGroup
                if (group != null) {
                    trackSelector.parameters = trackSelector.buildUponParameters()
                        .setOverrideForType(TrackSelectionOverride(group, opt.trackIndex))
                        .build()
                }
            },
            onSelectSubtitle = { opt ->
                if (opt == null) {
                    trackSelector.parameters = trackSelector.buildUponParameters()
                        .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                        .build()
                } else {
                    val group = currentTracks.groups.getOrNull(opt.groupIndex)?.mediaTrackGroup
                    if (group != null) {
                        trackSelector.parameters = trackSelector.buildUponParameters()
                            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
                            .setOverrideForType(TrackSelectionOverride(group, opt.trackIndex))
                            .build()
                    }
                }
            },
            onDismiss = { showTracksDialog = false }
        )
    }
}

@Composable
private fun VideoTracksDialog(
    audioTracks: List<SpoxTrackOption>,
    subtitleTracks: List<SpoxTrackOption>,
    onSelectAudio: (SpoxTrackOption) -> Unit,
    onSelectSubtitle: (SpoxTrackOption?) -> Unit,
    onDismiss: () -> Unit
) {
    val noSubtitleSelected = subtitleTracks.none { it.isSelected }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Дорожки и субтитры") },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (audioTracks.isNotEmpty()) {
                    Text("Аудиодорожка", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                    audioTracks.forEach { track ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onSelectAudio(track) }
                                .padding(vertical = 4.dp)
                        ) {
                            RadioButton(selected = track.isSelected, onClick = { onSelectAudio(track) })
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(track.label, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
                if (subtitleTracks.isNotEmpty()) {
                    if (audioTracks.isNotEmpty()) HorizontalDivider()
                    Text("Субтитры", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSelectSubtitle(null) }
                            .padding(vertical = 4.dp)
                    ) {
                        RadioButton(selected = noSubtitleSelected, onClick = { onSelectSubtitle(null) })
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Отключены", style = MaterialTheme.typography.bodyMedium)
                    }
                    subtitleTracks.forEach { sub ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onSelectSubtitle(sub) }
                                .padding(vertical = 4.dp)
                        ) {
                            RadioButton(selected = sub.isSelected, onClick = { onSelectSubtitle(sub) })
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(sub.label, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Готово") }
        }
    )
}
