package com.example

import android.Manifest
import android.app.PictureInPictureParams
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.util.Rational
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.FragmentActivity
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.repeatOnLifecycle
import androidx.lifecycle.viewmodel.compose.LocalViewModelStoreOwner
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.crypto.CryptoManager
import com.example.data.model.AppThemeMode
import com.example.data.model.AppVisualTheme
import com.example.data.model.ChatAppearanceConfig
import com.example.data.model.ChatWallpaperPreset
import com.example.data.model.OutgoingBubbleStyle
import com.example.data.network.AppNetworkMonitor
import com.example.data.repository.ActiveFirebaseSession
import com.example.data.repository.CallRepository
import com.example.data.repository.ChatRepository
import com.example.data.repository.FirebaseSessionManager
import com.example.data.repository.SavedAccount
import com.example.data.repository.SavedAccountsStore
import com.example.data.repository.ThemePreferenceStore
import com.example.media.LocalSpoxAudioPlayer
import com.example.media.OngoingCallService
import com.example.media.SpoxAudioPlayerManager
import com.example.notifications.MessagePushWorker
import com.example.notifications.NotificationPreferences
import com.example.notifications.SpoXNotificationHelper
import com.example.security.AppLockManager
import com.example.security.BiometricCapability
import com.example.ui.auth.AppLockScreen
import com.example.ui.auth.AuthScreen
import com.example.ui.auth.ProfileRegistrationScreen
import com.example.ui.auth.signInToSavedGoogleAccount
import com.example.ui.auth.signOutUser
import com.example.ui.auth.switchOrAddGoogleAccount
import com.example.ui.components.AccountRestrictedScreen
import com.example.ui.components.BitmapMemoryCache
import com.example.ui.components.InAppMessageAlertBanner
import com.example.ui.media.SpoxAudioMiniBar
import com.example.ui.media.SpoxAudioPlayerSheet
import com.example.ui.screens.CallScreen
import com.example.ui.screens.ChatListScreen
import com.example.ui.screens.ChatRoomScreen
import com.example.ui.theme.CipherChatTheme
import com.example.ui.theme.LiquidGlassBackdrop
import com.example.ui.viewmodel.CallViewModel
import com.example.ui.viewmodel.ChatListViewModel
import com.example.ui.viewmodel.ChatRoomViewModel
import com.example.ui.viewmodel.IncomingMessageAlert
import com.example.ui.viewmodel.RegistrationStatus
import com.google.firebase.Firebase
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.messaging.FirebaseMessaging
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

sealed interface PendingDeepLink {
    data class OpenChat(val chatId: String) : PendingDeepLink
    data class OpenCall(val callId: String, val autoAnswer: Boolean = true) : PendingDeepLink
}

class MainActivity : FragmentActivity() {

    private val pendingDeepLink = MutableStateFlow<PendingDeepLink?>(null)
    private val isInPipFlow = MutableStateFlow(false)
    private var isCallScreenVisible = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        handleDeepLinkIntent(intent)
        setContent {
            val deepLink by pendingDeepLink.collectAsStateWithLifecycle()
            val isInPip by isInPipFlow.collectAsStateWithLifecycle()
            CipherChatRootApp(
                pendingDeepLink = deepLink,
                isInPictureInPicture = isInPip,
                onCallScreenVisibilityChanged = { visible -> isCallScreenVisible = visible },
                onConsumeDeepLink = { pendingDeepLink.value = null }
            )
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleDeepLinkIntent(intent)
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (isCallScreenVisible && OngoingCallService.isCallRunning.value) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O &&
                packageManager.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE) &&
                !isInPictureInPictureMode
            ) {
                runCatching {
                    val params = PictureInPictureParams.Builder()
                        .setAspectRatio(Rational(3, 4))
                        .build()
                    enterPictureInPictureMode(params)
                }
            }
        }
    }

    override fun onPictureInPictureModeChanged(
        isInPictureInPictureMode: Boolean,
        newConfig: Configuration
    ) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        isInPipFlow.value = isInPictureInPictureMode
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        BitmapMemoryCache.trimOnMemoryPressure(level)
    }

    private fun handleDeepLinkIntent(intent: Intent?) {
        intent ?: return
        val callId = intent.getStringExtra(SpoXNotificationHelper.EXTRA_OPEN_CALL_ID)
        if (!callId.isNullOrBlank()) {
            val autoAnswer = intent.getBooleanExtra(SpoXNotificationHelper.EXTRA_AUTO_ANSWER, true)
            pendingDeepLink.value = PendingDeepLink.OpenCall(callId = callId, autoAnswer = autoAnswer)
            intent.removeExtra(SpoXNotificationHelper.EXTRA_OPEN_CALL_ID)
            intent.removeExtra(SpoXNotificationHelper.EXTRA_AUTO_ANSWER)
            return
        }
        val chatId = intent.getStringExtra(SpoXNotificationHelper.EXTRA_OPEN_CHAT_ID)
        if (!chatId.isNullOrBlank()) {
            pendingDeepLink.value = PendingDeepLink.OpenChat(chatId)
            intent.removeExtra(SpoXNotificationHelper.EXTRA_OPEN_CHAT_ID)
        }
    }
}

private fun FirebaseAuth.authStateFlow(): Flow<FirebaseUser?> = callbackFlow {
    val listener = FirebaseAuth.AuthStateListener { firebaseAuth ->
        trySend(firebaseAuth.currentUser)
    }
    addAuthStateListener(listener)
    awaitClose { removeAuthStateListener(listener) }
}

@Composable
fun CipherChatRootApp(
    pendingDeepLink: PendingDeepLink? = null,
    isInPictureInPicture: Boolean = false,
    onCallScreenVisibilityChanged: (Boolean) -> Unit = {},
    onConsumeDeepLink: () -> Unit = {}
) {
    val context = LocalContext.current
    val appContext = context.applicationContext
    val scope = rememberCoroutineScope()
    val themeStore = remember(appContext) { ThemePreferenceStore(appContext) }
    val accountsStore = remember(appContext) { SavedAccountsStore(appContext, eagerLoad = false) }
    val savedAccounts by accountsStore.accounts.collectAsStateWithLifecycle()
    val appearanceConfig by themeStore.appearanceConfig.collectAsStateWithLifecycle(
        initialValue = ChatAppearanceConfig()
    )
    val themeMode = appearanceConfig.themeMode
    val isSystemDark = isSystemInDarkTheme()
    val onToggleThemeMode: () -> Unit = {
        val currentlyDark = when (themeMode) {
            AppThemeMode.DARK -> true
            AppThemeMode.LIGHT -> false
            AppThemeMode.SYSTEM -> isSystemDark
        }
        val next = if (currentlyDark) AppThemeMode.LIGHT else AppThemeMode.DARK
        scope.launch { themeStore.setThemeMode(next) }
    }
    var skipAutoSignInOnce by remember { mutableStateOf(false) }
    var firebaseRetryTick by remember { mutableIntStateOf(0) }

    LaunchedEffect(accountsStore) {
        accountsStore.ensureLoadedAsync()
    }

    LaunchedEffect(savedAccounts) {
        FirebaseSessionManager.syncSavedAccountApps(appContext, savedAccounts)
    }

    val initialSession = remember(appContext) {
        FirebaseSessionManager.ensureInitialized(appContext, savedAccounts)
    }
    val activeSessionState by FirebaseSessionManager.observeActiveSession(appContext)
        .collectAsStateWithLifecycle(initialValue = initialSession)
    val activeSession = remember(activeSessionState, firebaseRetryTick) {
        activeSessionState ?: FirebaseSessionManager.ensureInitialized(appContext, savedAccounts)
    }
    val auth = activeSession?.auth

    LaunchedEffect(appearanceConfig.resourceSavingMode) {
        BitmapMemoryCache.setResourceSavingMode(appearanceConfig.resourceSavingMode)
    }

    val networkMonitor = remember(appContext) { AppNetworkMonitor(appContext) }
    DisposableEffect(networkMonitor) {
        onDispose { networkMonitor.stop() }
    }

    CipherChatTheme(
        themeMode = themeMode,
        appearanceConfig = appearanceConfig
    ) {
        Surface(
            color = MaterialTheme.colorScheme.background,
            modifier = Modifier.fillMaxSize()
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                if (appearanceConfig.liquidGlassEnabled && !appearanceConfig.resourceSavingMode) {
                    LiquidGlassBackdrop(modifier = Modifier.fillMaxSize())
                }
                if (auth == null) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp)
                            .widthIn(max = 420.dp)
                            .align(Alignment.Center),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = "Не удалось инициализировать сервисы SpoX",
                            style = MaterialTheme.typography.titleMedium,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Повторите запуск подключения — настройки и чаты сохранены.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(onClick = { firebaseRetryTick++ }) {
                            Text("Повторить")
                        }
                    }
                } else {
                    val currentUser by remember(auth) { auth.authStateFlow() }
                        .collectAsStateWithLifecycle(initialValue = auth.currentUser)

                    AnimatedContent(
                        targetState = currentUser,
                        transitionSpec = {
                            if (appearanceConfig.resourceSavingMode) {
                                EnterTransition.None togetherWith ExitTransition.None
                            } else {
                                (fadeIn(tween(300)) + scaleIn(initialScale = 0.97f, animationSpec = tween(300))) togetherWith
                                    fadeOut(tween(220))
                            }
                        },
                        contentKey = { it?.uid ?: "unauth" },
                        label = "root_auth_transition"
                    ) { user ->
                        if (user == null) {
                            AuthScreen(
                                themeMode = themeMode,
                                onToggleTheme = onToggleThemeMode,
                                savedAccounts = savedAccounts,
                                skipAutoSignIn = skipAutoSignInOnce,
                                canAutoSignIn = true,
                                hasLiveSession = { acc ->
                                    FirebaseSessionManager.hasLiveSessionForAccount(appContext, acc)
                                },
                                onQuickSelectSavedAccount = { acc, onDone, onError ->
                                    val switched = FirebaseSessionManager.tryInstantSwitch(appContext, acc)
                                    if (switched) {
                                        skipAutoSignInOnce = false
                                        onDone()
                                    } else {
                                        onError("Сессия истекла — выполните вход через Google")
                                    }
                                },
                                onRemoveSavedAccount = { targetUid ->
                                    val targetAcc = savedAccounts.firstOrNull { it.uid == targetUid }
                                    scope.launch(Dispatchers.IO) {
                                        if (targetAcc != null) {
                                            FirebaseSessionManager.clearAccountSession(appContext, targetAcc)
                                        }
                                        accountsStore.removeAccount(targetUid)
                                    }
                                },
                                onAuthSuccess = { skipAutoSignInOnce = false }
                            )
                        } else {
                            key(user.uid) {
                                AuthenticatedChatApp(
                                    user = user,
                                    activeSession = activeSession,
                                    networkMonitor = networkMonitor,
                                    themeMode = themeMode,
                                    appearanceConfig = appearanceConfig,
                                    themeStore = themeStore,
                                    accountsStore = accountsStore,
                                    savedAccounts = savedAccounts,
                                    pendingDeepLink = pendingDeepLink,
                                    isInPictureInPicture = isInPictureInPicture,
                                    onCallScreenVisibilityChanged = onCallScreenVisibilityChanged,
                                    onConsumeDeepLink = onConsumeDeepLink,
                                    onSignOutTriggered = { skipAutoSignInOnce = true },
                                    onChangeThemeMode = { next ->
                                        scope.launch { themeStore.setThemeMode(next) }
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AuthenticatedChatApp(
    user: FirebaseUser,
    activeSession: ActiveFirebaseSession,
    networkMonitor: AppNetworkMonitor,
    themeMode: AppThemeMode,
    appearanceConfig: ChatAppearanceConfig,
    themeStore: ThemePreferenceStore,
    accountsStore: SavedAccountsStore,
    savedAccounts: List<SavedAccount>,
    pendingDeepLink: PendingDeepLink?,
    isInPictureInPicture: Boolean,
    onCallScreenVisibilityChanged: (Boolean) -> Unit,
    onConsumeDeepLink: () -> Unit,
    onSignOutTriggered: () -> Unit,
    onChangeThemeMode: (AppThemeMode) -> Unit
) {
    val context = LocalContext.current
    val appContext = context.applicationContext
    val uid = user.uid
    val cryptoManager = remember(appContext, uid) {
        CryptoManager(appContext, accountScope = uid)
    }
    val appLockManager = remember(appContext) { AppLockManager(appContext) }

    val firestoreDb = remember(appContext, activeSession.appName) {
        FirebaseSessionManager.getFirestore(appContext, activeSession.app)
    }

    var isLockStateReady by remember(uid) { mutableStateOf(false) }
    var isPinEnabled by remember(uid) { mutableStateOf(false) }
    var isBiometricEnabled by remember(uid) { mutableStateOf(false) }
    var isSessionUnlocked by remember(uid) { mutableStateOf(false) }

    LaunchedEffect(appLockManager, uid) {
        val (pinEnabled, bioEnabled) = appLockManager.loadUserLockStateAsync(uid)
        isPinEnabled = pinEnabled
        isBiometricEnabled = bioEnabled
        isSessionUnlocked = !pinEnabled && !bioEnabled
        isLockStateReady = true
    }

    val biometricCapability by produceState(
        initialValue = BiometricCapability.HARDWARE_UNAVAILABLE,
        key1 = appContext,
        key2 = isBiometricEnabled
    ) {
        value = appLockManager.getBiometricCapabilityAsync(appContext)
    }

    val keyFingerprint by produceState(
        initialValue = cryptoManager.getCachedKeyFingerprint().orEmpty(),
        key1 = cryptoManager
    ) {
        value = cryptoManager.getKeyFingerprintAsync()
    }

    val db = firestoreDb
    if (db == null || !isLockStateReady) {
        Box(modifier = Modifier.fillMaxSize())
        return
    }

    val sessionViewModelStore = remember(uid) { ViewModelStore() }
    val sessionViewModelStoreOwner = remember(sessionViewModelStore) {
        object : ViewModelStoreOwner {
            override val viewModelStore: ViewModelStore = sessionViewModelStore
        }
    }
    DisposableEffect(sessionViewModelStore) {
        onDispose {
            sessionViewModelStore.clear()
        }
    }

    CompositionLocalProvider(LocalViewModelStoreOwner provides sessionViewModelStoreOwner) {
        AuthenticatedChatSession(
            user = user,
            activeSession = activeSession,
            db = db,
            networkMonitor = networkMonitor,
            cryptoManager = cryptoManager,
            keyFingerprint = keyFingerprint,
            appLockManager = appLockManager,
            isPinEnabled = isPinEnabled,
            isBiometricEnabled = isBiometricEnabled,
            biometricCapability = biometricCapability,
            isSessionUnlocked = isSessionUnlocked,
            onPinStateChanged = { enabled -> isPinEnabled = enabled },
            onBiometricStateChanged = { enabled -> isBiometricEnabled = enabled },
            onSessionUnlockedChanged = { unlocked -> isSessionUnlocked = unlocked },
            themeMode = themeMode,
            appearanceConfig = appearanceConfig,
            themeStore = themeStore,
            accountsStore = accountsStore,
            savedAccounts = savedAccounts,
            pendingDeepLink = pendingDeepLink,
            isInPictureInPicture = isInPictureInPicture,
            onCallScreenVisibilityChanged = onCallScreenVisibilityChanged,
            onConsumeDeepLink = onConsumeDeepLink,
            onSignOutTriggered = onSignOutTriggered,
            onChangeThemeMode = onChangeThemeMode
        )
    }
}

@Composable
private fun AuthenticatedChatSession(
    user: FirebaseUser,
    activeSession: ActiveFirebaseSession,
    db: FirebaseFirestore,
    networkMonitor: AppNetworkMonitor,
    cryptoManager: CryptoManager,
    keyFingerprint: String,
    appLockManager: AppLockManager,
    isPinEnabled: Boolean,
    isBiometricEnabled: Boolean,
    biometricCapability: BiometricCapability,
    isSessionUnlocked: Boolean,
    onPinStateChanged: (Boolean) -> Unit,
    onBiometricStateChanged: (Boolean) -> Unit,
    onSessionUnlockedChanged: (Boolean) -> Unit,
    themeMode: AppThemeMode,
    appearanceConfig: ChatAppearanceConfig,
    themeStore: ThemePreferenceStore,
    accountsStore: SavedAccountsStore,
    savedAccounts: List<SavedAccount>,
    pendingDeepLink: PendingDeepLink?,
    isInPictureInPicture: Boolean,
    onCallScreenVisibilityChanged: (Boolean) -> Unit,
    onConsumeDeepLink: () -> Unit,
    onSignOutTriggered: () -> Unit,
    onChangeThemeMode: (AppThemeMode) -> Unit
) {
    val context = LocalContext.current
    val appContext = context.applicationContext
    val scope = rememberCoroutineScope()
    val lifecycleOwner = LocalLifecycleOwner.current
    val navController = rememberNavController()
    val uid = user.uid
    val activeAuth = activeSession.auth

    val email = user.email.orEmpty().ifBlank { "$uid@cipherchat.local" }
    val displayName = user.displayName.orEmpty().ifBlank { email.substringBefore("@") }

    val chatListViewModel: ChatListViewModel = viewModel(
        key = "list_$uid",
        factory = viewModelFactory {
            initializer {
                ChatListViewModel(
                    chatRepository = ChatRepository(db, cryptoManager, activeAuth),
                    callRepository = CallRepository(db, activeAuth),
                    currentUserId = uid,
                    userEmail = email,
                    userDisplayName = displayName,
                    initialTheme = themeMode,
                    networkConnectedFlow = networkMonitor.isConnected
                )
            }
        }
    )

    LaunchedEffect(chatListViewModel, appearanceConfig.resourceSavingMode) {
        chatListViewModel.setResourceSavingMode(appearanceConfig.resourceSavingMode)
    }

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { }

    val registrationStatus by chatListViewModel.registrationStatus.collectAsStateWithLifecycle()
    val topStatusUiState by chatListViewModel.topStatusUiState.collectAsStateWithLifecycle()
    val registrationError by chatListViewModel.registrationError.collectAsStateWithLifecycle()
    val isRegistrationBusy by chatListViewModel.isBusy.collectAsStateWithLifecycle()
    var hasSyncedPushInfra by remember(uid) { mutableStateOf(false) }
    var hasPromptedNotificationPermission by remember(uid) { mutableStateOf(false) }

    LaunchedEffect(uid, registrationStatus, isSessionUnlocked, lifecycleOwner) {
        if (registrationStatus != RegistrationStatus.COMPLETED || !isSessionUnlocked) {
            return@LaunchedEffect
        }
        if (!hasSyncedPushInfra) {
            hasSyncedPushInfra = true
            withContext(Dispatchers.IO) {
                runCatching { SpoXNotificationHelper.ensureChannels(appContext) }
                MessagePushWorker.schedulePeriodicSync(appContext)
            }
            runCatching {
                FirebaseMessaging.getInstance().token.addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        val token = task.result.orEmpty()
                        if (token.isNotBlank()) {
                            scope.launch(Dispatchers.IO) {
                                NotificationPreferences.saveFcmToken(appContext, token)
                            }
                            chatListViewModel.syncFcmToken(token)
                        }
                    }
                }
            }
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            !hasPromptedNotificationPermission &&
            !SpoXNotificationHelper.hasNotificationPermission(appContext)
        ) {
            lifecycleOwner.lifecycle.repeatOnLifecycle(Lifecycle.State.RESUMED) {
                if (!hasPromptedNotificationPermission &&
                    !SpoXNotificationHelper.hasNotificationPermission(appContext)
                ) {
                    hasPromptedNotificationPermission = true
                    delay(250L)
                    runCatching {
                        notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    }
                }
            }
        }
    }

    var backgroundedAtMs by remember(uid) { mutableLongStateOf(0L) }

    LaunchedEffect(chatListViewModel, appearanceConfig.resourceSavingMode) {
        chatListViewModel.setResourceSavingMode(appearanceConfig.resourceSavingMode)
    }

    DisposableEffect(lifecycleOwner, chatListViewModel, uid, appContext) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_START -> {
                    chatListViewModel.setAppInForeground(true)
                    if (backgroundedAtMs > 0L && (isPinEnabled || isBiometricEnabled)) {
                        val elapsed = System.currentTimeMillis() - backgroundedAtMs
                        if (elapsed > 60_000L) {
                            onSessionUnlockedChanged(false)
                        }
                    }
                    backgroundedAtMs = 0L
                }
                Lifecycle.Event.ON_STOP -> {
                    chatListViewModel.setAppInForeground(false)
                    backgroundedAtMs = System.currentTimeMillis()
                    scope.launch(Dispatchers.IO) {
                        MessagePushWorker.triggerBackgroundCheck(appContext)
                    }
                }
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    val privateProfile by chatListViewModel.privateProfile.collectAsStateWithLifecycle()
    val directoryUsers by chatListViewModel.directoryUsers.collectAsStateWithLifecycle()
    val deletedAccount by chatListViewModel.deletedAccountRecord.collectAsStateWithLifecycle()
    val mePublic = directoryUsers.firstOrNull { it.userId == uid }
    val activeDisplayName = privateProfile?.displayName?.ifBlank { null }
        ?: mePublic?.displayName?.ifBlank { null }
        ?: displayName
    val activeHandle = privateProfile?.handle?.ifBlank { null } ?: mePublic?.handle.orEmpty()
    val activeAvatar = privateProfile?.avatarBase64?.ifBlank { null } ?: mePublic?.avatarBase64.orEmpty()
    val activeColorIdx = (mePublic?.avatarColorIndex ?: 0L).toInt()
    val activeRole = privateProfile?.role ?: mePublic?.role ?: "user"
    val activeFingerprint = privateProfile?.keyFingerprint?.ifBlank { null }
        ?: mePublic?.keyFingerprint?.ifBlank { null }
        ?: keyFingerprint

    val isDeleted = deletedAccount != null
    val isBanned = privateProfile?.isBanned() == true
    val isRestricted = isDeleted || isBanned

    LaunchedEffect(
        uid,
        email,
        activeDisplayName,
        activeHandle,
        activeAvatar,
        activeColorIdx,
        activeRole,
        activeFingerprint,
        activeSession.appName,
        isRestricted,
        registrationStatus
    ) {
        withContext(Dispatchers.IO) {
            if (isRestricted) {
                accountsStore.removeAccount(uid)
            } else if (registrationStatus == RegistrationStatus.COMPLETED) {
                accountsStore.upsertAccount(
                    SavedAccount(
                        uid = uid,
                        email = email,
                        displayName = activeDisplayName,
                        handle = activeHandle,
                        avatarBase64 = activeAvatar,
                        avatarColorIndex = activeColorIdx,
                        role = activeRole,
                        keyFingerprint = activeFingerprint,
                        lastActiveAtMs = System.currentTimeMillis(),
                        sessionAppName = activeSession.appName
                    )
                )
            }
        }
    }

    val credentialManager = remember(context) { CredentialManager.create(context) }
    var isSwitchingAccount by remember(uid) { mutableStateOf(false) }

    if (isRestricted) {
        val reason = if (isDeleted) {
            deletedAccount?.reason.orEmpty()
        } else {
            privateProfile?.moderationReason.orEmpty()
        }
        AccountRestrictedScreen(
            isDeleted = isDeleted,
            reason = reason,
            onSignOut = {
                onSignOutTriggered()
                signOutUser(credentialManager, scope, authToSignOut = activeAuth)
            }
        )
        return
    }

    if (!isSessionUnlocked) {
        AppLockScreen(
            uid = uid,
            userDisplayName = activeDisplayName,
            userEmail = email,
            pinEnabled = isPinEnabled,
            biometricEnabled = isBiometricEnabled,
            biometricCapability = biometricCapability,
            appLockManager = appLockManager,
            onUnlocked = { onSessionUnlockedChanged(true) },
            onSignOutAndResetLock = {
                appLockManager.clearAllForUser(uid)
                onPinStateChanged(false)
                onBiometricStateChanged(false)
                onSignOutTriggered()
                scope.launch(Dispatchers.IO) {
                    MessagePushWorker.cancelAll(appContext)
                }
                scope.launch {
                    chatListViewModel.markOfflineNow()
                    signOutUser(credentialManager, scope, authToSignOut = activeAuth)
                }
            }
        )
        return
    }

    if (registrationStatus == RegistrationStatus.NEEDS_PROFILE_SETUP) {
        val isSystemDark = isSystemInDarkTheme()
        ProfileRegistrationScreen(
            uid = uid,
            userEmail = email,
            initialDisplayName = displayName,
            keyFingerprint = keyFingerprint,
            isBusy = isRegistrationBusy,
            errorMessage = registrationError,
            themeMode = themeMode,
            onToggleTheme = {
                val currentlyDark = when (themeMode) {
                    AppThemeMode.DARK -> true
                    AppThemeMode.LIGHT -> false
                    AppThemeMode.SYSTEM -> isSystemDark
                }
                val next = if (currentlyDark) AppThemeMode.LIGHT else AppThemeMode.DARK
                onChangeThemeMode(next)
            },
            onClearError = { chatListViewModel.clearRegistrationError() },
            onSubmitProfile = { chosenName, chosenHandle, chosenAvatar ->
                chatListViewModel.completeRegistrationProfile(
                    displayName = chosenName,
                    rawUsername = chosenHandle,
                    avatarBase64 = chosenAvatar,
                    preferredTheme = themeMode
                )
            },
            onSignOut = {
                onSignOutTriggered()
                scope.launch(Dispatchers.IO) {
                    MessagePushWorker.cancelAll(appContext)
                }
                signOutUser(credentialManager, scope, authToSignOut = activeAuth)
            }
        )
        return
    }

    val navBackStackEntry by navController.currentBackStackEntryAsState()
    LaunchedEffect(navBackStackEntry) {
        val route = navBackStackEntry?.destination?.route
        val isCallRoute = route?.startsWith("call/") == true
        onCallScreenVisibilityChanged(isCallRoute)
        val openChatId = if (route == "chat/{chatId}") {
            navBackStackEntry?.arguments?.getString("chatId")
        } else {
            null
        }
        chatListViewModel.setActiveOpenChatId(openChatId)
        if (!openChatId.isNullOrBlank()) {
            SpoXNotificationHelper.cancelChatNotification(appContext, openChatId)
        }
        if (isCallRoute) {
            navBackStackEntry?.arguments?.getString("callId")?.let { callId ->
                SpoXNotificationHelper.cancelCallNotification(appContext, callId)
            }
        }
    }

    LaunchedEffect(pendingDeepLink, navBackStackEntry) {
        if (navBackStackEntry == null) return@LaunchedEffect
        when (val link = pendingDeepLink) {
            is PendingDeepLink.OpenChat -> {
                if (link.chatId.isNotBlank()) {
                    runCatching {
                        navController.navigate("chat/${Uri.encode(link.chatId)}") { launchSingleTop = true }
                    }
                }
                onConsumeDeepLink()
            }
            is PendingDeepLink.OpenCall -> {
                if (link.callId.isNotBlank()) {
                    runCatching {
                        navController.navigate("call/${Uri.encode(link.callId)}?autoAnswer=${link.autoAnswer}") {
                            launchSingleTop = true
                        }
                    }
                }
                onConsumeDeepLink()
            }
            null -> Unit
        }
    }

    var activeAlertBanner by remember { mutableStateOf<IncomingMessageAlert?>(null) }

    LaunchedEffect(chatListViewModel) {
        chatListViewModel.incomingMessageAlerts.collect { alert ->
            val appContext = context.applicationContext
            NotificationPreferences.markChatNotified(
                context = appContext,
                uid = uid,
                chatId = alert.chatId,
                messageTimeMs = alert.msgTimeMs
            )
            if (NotificationPreferences.isMessagePushEnabled(appContext)) {
                SpoXNotificationHelper.showMessageNotification(
                    context = appContext,
                    chatId = alert.chatId,
                    chatTitle = alert.title,
                    body = alert.body,
                    unreadCount = alert.unreadCount,
                    senderName = alert.senderName,
                    senderRole = alert.senderRole,
                    customRoleName = alert.customRoleName,
                    customRoleBadge = alert.customRoleBadge,
                    senderAvatarBase64 = alert.senderAvatarBase64,
                    senderAvatarColorIndex = alert.senderAvatarColorIndex,
                    isGroup = alert.isGroup,
                    timestampMs = alert.msgTimeMs
                )
                activeAlertBanner = alert
            }
        }
    }

    LaunchedEffect(chatListViewModel) {
        chatListViewModel.incomingCallAlerts.collect { call ->
            val appContext = context.applicationContext
            if (NotificationPreferences.isCallPushEnabled(appContext)) {
                val callerProfile = chatListViewModel.chatPeersMap.value[call.callerId]
                val callerDisplay = callerProfile?.displayName?.ifBlank { null } ?: call.callerName
                SpoXNotificationHelper.showIncomingCallNotification(
                    context = appContext,
                    callId = call.id,
                    callerName = callerDisplay,
                    conversationTitle = call.conversationTitle,
                    isGroupCall = call.isGroupCall,
                    callType = call.callType,
                    callerRole = callerProfile?.role.orEmpty().ifBlank { "user" },
                    customRoleName = callerProfile?.customRoleName.orEmpty(),
                    customRoleBadge = callerProfile?.customRoleBadge.orEmpty(),
                    callerAvatarBase64 = callerProfile?.avatarBase64.orEmpty(),
                    callerAvatarColorIndex = callerProfile?.avatarColorIndex?.toInt()
                        ?: kotlin.math.abs(callerDisplay.hashCode())
                )
            }
        }
    }

    LaunchedEffect(chatListViewModel) {
        var previousRingingIds = emptySet<String>()
        chatListViewModel.activeCalls.collect { calls ->
            val currentRingingIds = calls
                .filter { it.status == "ringing" && it.callerId != uid && uid !in it.activeParticipantUids }
                .map { it.id }
                .toSet()
            val finishedRingingIds = previousRingingIds - currentRingingIds
            if (finishedRingingIds.isNotEmpty()) {
                val appContext = context.applicationContext
                finishedRingingIds.forEach { callId ->
                    SpoXNotificationHelper.cancelCallNotification(appContext, callId)
                }
            }
            previousRingingIds = currentRingingIds
        }
    }

    LaunchedEffect(activeAlertBanner) {
        if (activeAlertBanner != null) {
            delay(4200L)
            activeAlertBanner = null
        }
    }

    val spoxAudioPlayer = remember(context.applicationContext) {
        SpoxAudioPlayerManager(context.applicationContext)
    }
    var showAudioPlayerSheet by remember { mutableStateOf(false) }
    val isCallRunning by OngoingCallService.isCallRunning.collectAsStateWithLifecycle()

    LaunchedEffect(isCallRunning) {
        if (isCallRunning) {
            spoxAudioPlayer.pauseIfPlaying()
        }
    }

    DisposableEffect(spoxAudioPlayer) {
        onDispose {
            spoxAudioPlayer.release()
        }
    }

    val currentRoute = navBackStackEntry?.destination?.route
    val isChatsRoute = currentRoute == null || currentRoute == "chats"

    CompositionLocalProvider(LocalSpoxAudioPlayer provides spoxAudioPlayer) {
        Box(modifier = Modifier.fillMaxSize()) {
        val isResourceSaving = appearanceConfig.resourceSavingMode
        NavHost(
            navController = navController,
            startDestination = "chats",
            enterTransition = {
                if (isResourceSaving) EnterTransition.None
                else slideInHorizontally(tween(300, easing = FastOutSlowInEasing)) { it / 4 } + fadeIn(tween(260))
            },
            exitTransition = {
                if (isResourceSaving) ExitTransition.None
                else slideOutHorizontally(tween(260, easing = FastOutSlowInEasing)) { -it / 6 } + fadeOut(tween(220))
            },
            popEnterTransition = {
                if (isResourceSaving) EnterTransition.None
                else slideInHorizontally(tween(300, easing = FastOutSlowInEasing)) { -it / 5 } + fadeIn(tween(260))
            },
            popExitTransition = {
                if (isResourceSaving) ExitTransition.None
                else slideOutHorizontally(tween(280, easing = FastOutSlowInEasing)) { it / 4 } + fadeOut(tween(220))
            }
        ) {
            composable("chats") {
                ChatListScreen(
                    viewModel = chatListViewModel,
                    currentUserId = uid,
                    userEmail = email,
                    userDisplayName = activeDisplayName,
                    keyFingerprint = keyFingerprint,
                    themeMode = themeMode,
                    appearanceConfig = appearanceConfig,
                    isPinEnabled = isPinEnabled,
                    isBiometricEnabled = isBiometricEnabled,
                    biometricCapability = biometricCapability,
                    appLockManager = appLockManager,
                    onSetPin = { newPin ->
                        scope.launch(Dispatchers.IO) {
                            appLockManager.setPin(uid, newPin)
                            val enabled = appLockManager.isPinEnabled(uid)
                            withContext(Dispatchers.Main) {
                                onPinStateChanged(enabled)
                            }
                        }
                    },
                    onDisablePin = {
                        scope.launch(Dispatchers.IO) {
                            appLockManager.disablePin(uid)
                            withContext(Dispatchers.Main) {
                                onPinStateChanged(false)
                            }
                        }
                    },
                    onSetBiometricEnabled = { enabled ->
                        scope.launch(Dispatchers.IO) {
                            appLockManager.setBiometricEnabled(uid, enabled)
                            val active = appLockManager.isBiometricEnabled(uid)
                            withContext(Dispatchers.Main) {
                                onBiometricStateChanged(active)
                            }
                        }
                    },
                    onLockAppNow = {
                        if (isPinEnabled || isBiometricEnabled) {
                            onSessionUnlockedChanged(false)
                        }
                    },
                    onChangeThemeMode = onChangeThemeMode,
                    onSelectVisualTheme = { visualTheme: AppVisualTheme ->
                        scope.launch {
                            themeStore.setVisualTheme(visualTheme)
                            chatListViewModel.showMessage("Тема «${visualTheme.labelRu}» применена")
                        }
                    },
                    onSelectWallpaperPreset = { preset: ChatWallpaperPreset ->
                        scope.launch {
                            themeStore.setWallpaperPreset(preset)
                        }
                    },
                    onPickCustomWallpaperUri = { uri ->
                        scope.launch {
                            themeStore.saveCustomWallpaperFromUri(uri)
                                .onSuccess {
                                    chatListViewModel.showMessage("Свои обои установлены")
                                }
                                .onFailure { err ->
                                    chatListViewModel.showMessage(
                                        err.localizedMessage ?: "Не удалось загрузить обои"
                                    )
                                }
                        }
                    },
                    onSelectOutgoingBubbleStyle = { style: OutgoingBubbleStyle ->
                        scope.launch {
                            themeStore.setOutgoingBubbleStyle(style)
                        }
                    },
                    onSetShowStories = { visible ->
                        scope.launch {
                            themeStore.setShowStories(visible)
                        }
                    },
                    onSetShowFolders = { visible ->
                        scope.launch {
                            themeStore.setShowFolders(visible)
                        }
                    },
                    onSetLiquidGlassEnabled = { enabled ->
                        scope.launch {
                            themeStore.setLiquidGlassEnabled(enabled)
                            chatListViewModel.showMessage(
                                if (enabled) "Эффект Liquid Glass включён"
                                else "Эффект Liquid Glass выключен"
                            )
                        }
                    },
                    onSetResourceSavingMode = { enabled ->
                        scope.launch {
                            themeStore.setResourceSavingMode(enabled)
                            chatListViewModel.setResourceSavingMode(enabled)
                            chatListViewModel.showMessage(
                                if (enabled) "Режим экономии ресурсов (RAM, GPU, CPU) включён"
                                else "Режим экономии ресурсов выключен"
                            )
                        }
                    },
                    onSetSmoothStoriesAppearance = { enabled ->
                        scope.launch {
                            themeStore.setSmoothStoriesAppearance(enabled)
                        }
                    },
                    onSetSmoothChatsAppearance = { enabled ->
                        scope.launch {
                            themeStore.setSmoothChatsAppearance(enabled)
                        }
                    },
                    onSetSmoothChatsPanelAppearance = { enabled ->
                        scope.launch {
                            themeStore.setSmoothChatsPanelAppearance(enabled)
                        }
                    },
                    onSetSmoothChatMessagesAppearance = { enabled ->
                        scope.launch {
                            themeStore.setSmoothChatMessagesAppearance(enabled)
                        }
                    },
                    onResetCustomization = {
                        scope.launch {
                            themeStore.resetCustomization()
                            chatListViewModel.showMessage("Оформление сброшено к стандартному")
                        }
                    },
                    onOpenChat = { chatId -> navController.navigate("chat/$chatId") },
                    onOpenGroupSettings = { chatId ->
                        navController.navigate("chat/${Uri.encode(chatId)}?openGroupSettings=true")
                    },
                    onOpenCall = { callId -> navController.navigate("call/$callId") },
                    savedAccounts = savedAccounts,
                    isSwitchingAccount = isSwitchingAccount,
                    onSwitchAccount = { targetAccount, onDone, onError ->
                        if (FirebaseSessionManager.hasLiveSessionForAccount(appContext, targetAccount)) {
                            isSwitchingAccount = true
                            scope.launch {
                                try {
                                    withContext(Dispatchers.IO) {
                                        MessagePushWorker.cancelAll(appContext)
                                    }
                                    chatListViewModel.markOfflineNow()
                                    val switched = FirebaseSessionManager.tryInstantSwitch(appContext, targetAccount)
                                    isSwitchingAccount = false
                                    if (switched) {
                                        onDone()
                                    } else {
                                        onError("Сессия истекла — выберите аккаунт заново")
                                    }
                                } catch (e: kotlinx.coroutines.CancellationException) {
                                    isSwitchingAccount = false
                                    throw e
                                } catch (e: Exception) {
                                    isSwitchingAccount = false
                                    onError(e.localizedMessage ?: "Не удалось переключить аккаунт")
                                }
                            }
                        } else {
                            isSwitchingAccount = true
                            signInToSavedGoogleAccount(
                                context = context,
                                credentialManager = credentialManager,
                                targetAccount = targetAccount,
                                savedAccounts = savedAccounts,
                                onBeforeCredentialSwap = {
                                    withContext(Dispatchers.IO) {
                                        MessagePushWorker.cancelAll(appContext)
                                    }
                                    chatListViewModel.markOfflineNow()
                                },
                                onAuthSuccess = {
                                    isSwitchingAccount = false
                                    onDone()
                                },
                                onAuthError = { msg ->
                                    isSwitchingAccount = false
                                    onError(msg)
                                },
                                onAuthCancelled = {
                                    isSwitchingAccount = false
                                },
                                scope = scope
                            )
                        }
                    },
                    onAddAccount = { onDone, onError ->
                        if (!accountsStore.canAddAnotherAccount()) {
                            onError(
                                "Достигнут лимит: не более ${SavedAccountsStore.MAX_ACCOUNTS} аккаунтов. " +
                                    "Удалите один из сохранённых аккаунтов."
                            )
                        } else {
                            isSwitchingAccount = true
                            switchOrAddGoogleAccount(
                                context = context,
                                credentialManager = credentialManager,
                                enforceMaxAccounts = true,
                                existingAccountEmails = savedAccounts.map { it.email },
                                savedAccounts = savedAccounts,
                                onBeforeCredentialSwap = {
                                    withContext(Dispatchers.IO) {
                                        MessagePushWorker.cancelAll(appContext)
                                    }
                                    chatListViewModel.markOfflineNow()
                                },
                                onAuthSuccess = {
                                    isSwitchingAccount = false
                                    onDone()
                                },
                                onAuthError = { msg ->
                                    isSwitchingAccount = false
                                    onError(msg)
                                },
                                onAuthCancelled = {
                                    isSwitchingAccount = false
                                },
                                scope = scope
                            )
                        }
                    },
                    onRemoveSavedAccount = { targetUid ->
                        if (targetUid != uid) {
                            val targetAcc = savedAccounts.firstOrNull { it.uid == targetUid }
                            scope.launch(Dispatchers.IO) {
                                if (targetAcc != null) {
                                    FirebaseSessionManager.clearAccountSession(appContext, targetAcc)
                                }
                                accountsStore.removeAccount(targetUid)
                            }
                        }
                    },
                    onSignOutTriggered = onSignOutTriggered
                )
            }

            composable(
                route = "chat/{chatId}?openGroupSettings={openGroupSettings}",
                arguments = listOf(
                    navArgument("chatId") { type = NavType.StringType },
                    navArgument("openGroupSettings") {
                        type = NavType.BoolType
                        defaultValue = false
                    }
                )
            ) { entry ->
                val chatId = entry.arguments?.getString("chatId") ?: return@composable
                val openGroupSettings = entry.arguments?.getBoolean("openGroupSettings") ?: false
                val roomViewModel: ChatRoomViewModel = viewModel(
                    key = "room_${uid}_$chatId",
                    factory = viewModelFactory {
                        initializer {
                            ChatRoomViewModel(
                                chatRepository = ChatRepository(db, cryptoManager, activeAuth),
                                callRepository = CallRepository(db, activeAuth),
                                crypto = cryptoManager,
                                chatId = chatId,
                                currentUserId = uid,
                                currentUserName = activeDisplayName,
                                pluginStore = com.example.plugins.PluginStore.getInstance(appContext)
                            )
                        }
                    }
                )
                ChatRoomScreen(
                    viewModel = roomViewModel,
                    currentUserId = uid,
                    topStatus = topStatusUiState,
                    openGroupSettingsInitially = openGroupSettings,
                    onBack = { navController.popBackStack() },
                    onOpenCall = { callId -> navController.navigate("call/$callId") },
                    onOpenChat = { targetChatId ->
                        navController.navigate("chat/${Uri.encode(targetChatId)}") {
                            launchSingleTop = true
                        }
                    }
                )
            }

            composable(
                route = "call/{callId}?autoAnswer={autoAnswer}",
                arguments = listOf(
                    navArgument("callId") { type = NavType.StringType },
                    navArgument("autoAnswer") {
                        type = NavType.BoolType
                        defaultValue = true
                    }
                ),
                enterTransition = {
                    if (isResourceSaving) EnterTransition.None
                    else slideInVertically(tween(340, easing = FastOutSlowInEasing)) { it / 3 } +
                        scaleIn(initialScale = 0.94f, animationSpec = tween(340)) +
                        fadeIn(tween(280))
                },
                popExitTransition = {
                    if (isResourceSaving) ExitTransition.None
                    else slideOutVertically(tween(280, easing = FastOutSlowInEasing)) { it / 3 } +
                        fadeOut(tween(240))
                }
            ) { entry ->
                val callId = entry.arguments?.getString("callId") ?: return@composable
                val autoAnswer = entry.arguments?.getBoolean("autoAnswer") ?: true
                val callViewModel: CallViewModel = viewModel(
                    key = "call_${uid}_${callId}_$autoAnswer",
                    factory = viewModelFactory {
                        initializer {
                            CallViewModel(
                                callRepository = CallRepository(db, activeAuth),
                                chatRepository = ChatRepository(db, cryptoManager, activeAuth),
                                callId = callId,
                                currentUserId = uid,
                                currentUserName = activeDisplayName,
                                autoAnswer = autoAnswer
                            )
                        }
                    }
                )
                CallScreen(
                    viewModel = callViewModel,
                    currentUserId = uid,
                    isInPictureInPicture = isInPictureInPicture,
                    onMinimizeCall = { navController.popBackStack() },
                    onCallClosed = { navController.popBackStack() }
                )
            }
        }

        if (isChatsRoute) {
            SpoxAudioMiniBar(
                manager = spoxAudioPlayer,
                onExpand = { showAudioPlayerSheet = true },
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .navigationBarsPadding()
                    .padding(start = 12.dp, end = 12.dp, top = 8.dp, bottom = 88.dp)
            )
        }

        AnimatedVisibility(
            visible = activeAlertBanner != null,
            enter = slideInVertically(tween(260)) { -it } + fadeIn(tween(220)),
            exit = slideOutVertically(tween(220)) { -it } + fadeOut(tween(180)),
            modifier = Modifier.align(Alignment.TopCenter)
        ) {
            activeAlertBanner?.let { banner ->
                InAppMessageAlertBanner(
                    title = banner.title,
                    body = banner.body,
                    unreadCount = banner.unreadCount,
                    senderName = banner.senderName,
                    senderRole = com.example.data.model.UserRole.fromWire(banner.senderRole),
                    customRoleName = banner.customRoleName,
                    customRoleBadge = banner.customRoleBadge,
                    customRoleColorHex = banner.customRoleColorHex,
                    avatarBase64 = banner.senderAvatarBase64,
                    avatarColorIndex = banner.senderAvatarColorIndex,
                    isGroup = banner.isGroup,
                    onOpen = {
                        val targetId = banner.chatId
                        activeAlertBanner = null
                        navController.navigate("chat/$targetId") { launchSingleTop = true }
                    },
                    onDismiss = { activeAlertBanner = null }
                )
            }
        }
        }
    }

    if (showAudioPlayerSheet) {
        SpoxAudioPlayerSheet(
            manager = spoxAudioPlayer,
            onDismiss = { showAudioPlayerSheet = false }
        )
    }
}

