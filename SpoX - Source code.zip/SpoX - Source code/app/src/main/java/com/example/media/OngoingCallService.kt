package com.example.media

import android.Manifest
import android.annotation.SuppressLint
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.util.Log
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.example.data.model.CallSession
import com.example.data.repository.CallRepository
import com.example.notifications.SpoXNotificationHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class OngoingCallService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private lateinit var callMedia: CallMediaController
    private lateinit var callRepository: CallRepository
    private var wakeLock: PowerManager.WakeLock? = null

    private var activeCallJob: Job? = null
    private var incomingAudioJob: Job? = null
    private var timerJob: Job? = null
    private var ringtoneJob: Job? = null

    @Volatile
    private var currentCallSession: CallSession? = null

    @Volatile
    private var lastMediaSyncAt = 0L

    @Volatile
    private var callStartedAtMs = 0L

    @Volatile
    private var serviceCallId = ""

    @Volatile
    private var serviceCallTitle = "Звонок SpoX"

    @Volatile
    private var serviceUserId = ""

    @Volatile
    private var localCameraEnabled = false

    override fun onCreate() {
        super.onCreate()
        callMedia = CallMediaController(applicationContext)
        callRepository = CallRepository(applicationContext)
        instance = this
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                val callId = intent.getStringExtra(EXTRA_CALL_ID).orEmpty()
                val title = intent.getStringExtra(EXTRA_TITLE).orEmpty().ifBlank { "Звонок SpoX" }
                val userId = intent.getStringExtra(EXTRA_USER_ID).orEmpty()
                val cameraOn = intent.getBooleanExtra(EXTRA_CAMERA_ON, false)
                if (callId.isBlank() || userId.isBlank()) {
                    stopCallSession(endRemote = false)
                    return START_NOT_STICKY
                }
                startOrUpdateCallSession(callId, title, userId, cameraOn)
            }

            ACTION_TOGGLE_MUTE -> {
                val nextMuted = !_isMuted.value
                _isMuted.value = nextMuted
                if (nextMuted) _localAudioLevel.value = 0
                refreshOngoingNotification()
                syncMediaStateToFirestore(speaking = false, level = _localAudioLevel.value, force = true)
            }

            ACTION_TOGGLE_SPEAKER -> {
                val nextSpeaker = !_isSpeakerOn.value
                _isSpeakerOn.value = nextSpeaker
                callMedia.setSpeakerphone(nextSpeaker)
            }

            ACTION_UPDATE_CAMERA -> {
                localCameraEnabled = intent.getBooleanExtra(EXTRA_CAMERA_ON, false)
                syncMediaStateToFirestore(speaking = false, level = _localAudioLevel.value, force = true)
            }

            ACTION_STOP_AND_END -> {
                stopCallSession(endRemote = true)
            }

            ACTION_STOP_LOCAL -> {
                stopCallSession(endRemote = false)
            }
        }
        return START_NOT_STICKY
    }

    @SuppressLint("WakelockTimeout")
    private fun startOrUpdateCallSession(
        callId: String,
        title: String,
        userId: String,
        cameraOn: Boolean
    ) {
        val isSameCall = serviceCallId == callId && serviceUserId == userId && _isCallRunning.value
        serviceCallId = callId
        serviceCallTitle = title
        serviceUserId = userId
        localCameraEnabled = cameraOn
        _activeCallId.value = callId

        if (!isSameCall) {
            callStartedAtMs = System.currentTimeMillis()
            _elapsedSeconds.value = 0L
            _isMuted.value = false
            _localAudioLevel.value = 0
            // Auto-select earpiece/BT if headset connected so game & call play through headphones
            val defaultSpeaker = !callMedia.hasConnectedHeadset()
            _isSpeakerOn.value = defaultSpeaker
            _isCallRunning.value = true

            acquireWakeLock()
            promoteToForeground()

            callMedia.enterCallAudioMode(speakerOn = defaultSpeaker)
            callMedia.startAudioPlayback()
            ensureMicCaptureRunning()
            observeCallStateAndAudio(callId, userId)
        } else {
            promoteToForeground()
            ensureMicCaptureRunning()
        }
    }

    private fun promoteToForeground() {
        val notification = SpoXNotificationHelper.buildOngoingCallNotification(
            context = applicationContext,
            callId = serviceCallId,
            title = serviceCallTitle,
            startedAtMs = callStartedAtMs.takeIf { it > 0L } ?: System.currentTimeMillis(),
            isMuted = _isMuted.value
        )

        val hasMicPerm = ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED

        val serviceType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && hasMicPerm) {
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        } else {
            0
        }

        runCatching {
            ServiceCompat.startForeground(
                this,
                ONGOING_CALL_NOTIFICATION_ID,
                notification,
                serviceType
            )
        }.onFailure { err ->
            Log.w(TAG, "Unable to promote OngoingCallService to foreground: ${err.message}")
            _isCallRunning.value = false
            _activeCallId.value = null
            releaseWakeLock()
            stopSelf()
        }
    }

    @SuppressLint("MissingPermission")
    private fun refreshOngoingNotification() {
        if (!_isCallRunning.value || serviceCallId.isBlank()) return
        if (!SpoXNotificationHelper.hasNotificationPermission(this)) return
        val notification = SpoXNotificationHelper.buildOngoingCallNotification(
            context = applicationContext,
            callId = serviceCallId,
            title = serviceCallTitle,
            startedAtMs = callStartedAtMs,
            isMuted = _isMuted.value
        )
        runCatching {
            NotificationManagerCompat.from(this).notify(ONGOING_CALL_NOTIFICATION_ID, notification)
        }
    }

    private fun ensureMicCaptureRunning() {
        val hasMicPerm = ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
        if (!hasMicPerm) {
            callMedia.stopMicCapture()
            return
        }

        callMedia.startMicCapture(
            scope = serviceScope,
            isMutedProvider = { _isMuted.value },
            canTransmitProvider = {
                val call = currentCallSession
                call != null && call.status != "ended" &&
                    (call.status == "active" || call.activeParticipantUids.size > 1)
            },
            onLevelSampled = { level, speaking ->
                _localAudioLevel.value = level
                syncMediaStateToFirestore(speaking = speaking, level = level, force = false)
            },
            onEncodedFrameCaptured = { seq, payloadBase64 ->
                val call = currentCallSession ?: return@startMicCapture
                if (call.status == "ended" || _isMuted.value) return@startMicCapture
                serviceScope.launch(Dispatchers.IO) {
                    callRepository.sendAudioFrame(
                        callId = call.id,
                        memberUids = call.memberUids,
                        seq = seq,
                        payloadBase64 = payloadBase64
                    )
                }
            }
        )
    }

    private fun observeCallStateAndAudio(callId: String, userId: String) {
        activeCallJob?.cancel()
        incomingAudioJob?.cancel()
        timerJob?.cancel()
        ringtoneJob?.cancel()

        incomingAudioJob = serviceScope.launch {
            callRepository.observeIncomingAudioFrames(callId, userId)
                .catch { err ->
                    Log.w(TAG, "Incoming audio stream ended: ${err.message}")
                }
                .collect { frame ->
                    callMedia.enqueueIncomingAudio(
                        senderId = frame.senderId,
                        seq = frame.seq,
                        payloadBase64 = frame.payloadBase64
                    )
                }
        }

        activeCallJob = serviceScope.launch {
            callRepository.observeCall(callId, userId)
                .catch { err ->
                    Log.w(TAG, "Call state observer error: ${err.message}")
                }
                .collect { call ->
                    currentCallSession = call
                    if (call != null && call.conversationTitle.isNotBlank() && serviceCallTitle != call.conversationTitle) {
                        serviceCallTitle = call.conversationTitle
                        refreshOngoingNotification()
                    }
                    if (call?.status == "ringing" && call.callerId == userId && call.activeParticipantUids.size <= 1) {
                        startRingbackIfNeeded()
                    } else {
                        ringtoneJob?.cancel()
                        ringtoneJob = null
                    }
                    if (call?.status == "ended") {
                        callMedia.playEndCallTone()
                        stopCallSession(endRemote = false)
                    }
                }
        }

        timerJob = serviceScope.launch {
            while (isActive) {
                delay(1000L)
                if (currentCallSession?.status == "active") {
                    _elapsedSeconds.value += 1L
                }
            }
        }
    }

    private fun startRingbackIfNeeded() {
        if (ringtoneJob?.isActive == true) return
        ringtoneJob = serviceScope.launch {
            while (isActive) {
                callMedia.playRingTonePulse()
                delay(2400L)
            }
        }
    }

    private fun syncMediaStateToFirestore(speaking: Boolean, level: Int, force: Boolean) {
        val now = System.currentTimeMillis()
        if (!force && now - lastMediaSyncAt < 1400L) return
        val callId = serviceCallId
        if (callId.isBlank()) return
        lastMediaSyncAt = now
        serviceScope.launch {
            callRepository.updateMyMediaState(
                callId = callId,
                isMuted = _isMuted.value,
                isCameraOn = localCameraEnabled,
                isSpeaking = speaking && !_isMuted.value,
                audioLevel = if (_isMuted.value) 0 else level
            )
        }
    }

    private fun acquireWakeLock() {
        runCatching {
            if (wakeLock == null) {
                val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
                wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "SpoX:OngoingCallWakeLock")
                    .apply { setReferenceCounted(false) }
            }
            if (wakeLock?.isHeld != true) {
                wakeLock?.acquire(4 * 60 * 60 * 1000L)
            }
        }
    }

    private fun releaseWakeLock() {
        runCatching {
            if (wakeLock?.isHeld == true) {
                wakeLock?.release()
            }
            wakeLock = null
        }
    }

    private fun stopCallSession(endRemote: Boolean) {
        val snapshotCall = currentCallSession
        val cid = serviceCallId
        _isCallRunning.value = false
        _activeCallId.value = null
        _localAudioLevel.value = 0
        _elapsedSeconds.value = 0L
        currentCallSession = null
        serviceCallId = ""

        activeCallJob?.cancel()
        incomingAudioJob?.cancel()
        timerJob?.cancel()
        ringtoneJob?.cancel()

        callMedia.release()
        releaseWakeLock()

        if (endRemote) {
            serviceScope.launch {
                withContext(NonCancellable) {
                    if (snapshotCall != null) {
                        callRepository.leaveOrEndCall(snapshotCall)
                    } else if (cid.isNotBlank()) {
                        callRepository.declineCallById(cid)
                    }
                }
                withContext(Dispatchers.Main) {
                    runCatching { ServiceCompat.stopForeground(this@OngoingCallService, ServiceCompat.STOP_FOREGROUND_REMOVE) }
                    stopSelf()
                }
            }
        } else {
            runCatching { ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE) }
            stopSelf()
        }
    }

    override fun onDestroy() {
        if (instance === this) instance = null
        _isCallRunning.value = false
        _activeCallId.value = null
        _localAudioLevel.value = 0
        runCatching { callMedia.release() }
        releaseWakeLock()
        serviceScope.cancel()
        super.onDestroy()
    }

    companion object {
        private const val TAG = "OngoingCallService"
        private const val ONGOING_CALL_NOTIFICATION_ID = 77421

        private const val ACTION_START = "com.example.media.ACTION_START_CALL"
        private const val ACTION_TOGGLE_MUTE = "com.example.media.ACTION_TOGGLE_MUTE"
        private const val ACTION_TOGGLE_SPEAKER = "com.example.media.ACTION_TOGGLE_SPEAKER"
        private const val ACTION_UPDATE_CAMERA = "com.example.media.ACTION_UPDATE_CAMERA"
        private const val ACTION_STOP_AND_END = "com.example.media.ACTION_STOP_AND_END"
        private const val ACTION_STOP_LOCAL = "com.example.media.ACTION_STOP_LOCAL"

        private const val EXTRA_CALL_ID = "extra_call_id"
        private const val EXTRA_TITLE = "extra_title"
        private const val EXTRA_USER_ID = "extra_user_id"
        private const val EXTRA_CAMERA_ON = "extra_camera_on"

        @Volatile
        private var instance: OngoingCallService? = null

        private val _isCallRunning = MutableStateFlow(false)
        val isCallRunning: StateFlow<Boolean> = _isCallRunning.asStateFlow()

        private val _activeCallId = MutableStateFlow<String?>(null)
        val activeCallId: StateFlow<String?> = _activeCallId.asStateFlow()

        private val _isMuted = MutableStateFlow(false)
        val isMuted: StateFlow<Boolean> = _isMuted.asStateFlow()

        private val _isSpeakerOn = MutableStateFlow(true)
        val isSpeakerOn: StateFlow<Boolean> = _isSpeakerOn.asStateFlow()

        private val _localAudioLevel = MutableStateFlow(0)
        val localAudioLevel: StateFlow<Int> = _localAudioLevel.asStateFlow()

        private val _elapsedSeconds = MutableStateFlow(0L)
        val elapsedSeconds: StateFlow<Long> = _elapsedSeconds.asStateFlow()

        fun startOrAttach(
            context: Context,
            callId: String,
            title: String,
            userId: String,
            cameraOn: Boolean
        ) {
            if (callId.isBlank() || userId.isBlank()) return
            val intent = Intent(context, OngoingCallService::class.java).apply {
                action = ACTION_START
                putExtra(EXTRA_CALL_ID, callId)
                putExtra(EXTRA_TITLE, title)
                putExtra(EXTRA_USER_ID, userId)
                putExtra(EXTRA_CAMERA_ON, cameraOn)
            }
            runCatching {
                ContextCompat.startForegroundService(context.applicationContext, intent)
            }
        }

        fun toggleMute(context: Context) {
            if (_isCallRunning.value) {
                val intent = Intent(context, OngoingCallService::class.java).apply {
                    action = ACTION_TOGGLE_MUTE
                }
                runCatching { context.applicationContext.startService(intent) }
            } else {
                _isMuted.value = !_isMuted.value
            }
        }

        fun toggleSpeaker(context: Context): Boolean {
            val expectedNext = !_isSpeakerOn.value
            if (_isCallRunning.value) {
                val intent = Intent(context, OngoingCallService::class.java).apply {
                    action = ACTION_TOGGLE_SPEAKER
                }
                runCatching { context.applicationContext.startService(intent) }
            } else {
                _isSpeakerOn.value = expectedNext
            }
            return expectedNext
        }

        fun updateCameraState(context: Context, cameraOn: Boolean) {
            if (!_isCallRunning.value) return
            val intent = Intent(context, OngoingCallService::class.java).apply {
                action = ACTION_UPDATE_CAMERA
                putExtra(EXTRA_CAMERA_ON, cameraOn)
            }
            runCatching { context.applicationContext.startService(intent) }
        }

        fun stopAndEndCall(context: Context) {
            val intent = Intent(context, OngoingCallService::class.java).apply {
                action = ACTION_STOP_AND_END
            }
            runCatching { context.applicationContext.startService(intent) }
        }

        fun stopLocalOnly(context: Context) {
            val intent = Intent(context, OngoingCallService::class.java).apply {
                action = ACTION_STOP_LOCAL
            }
            runCatching { context.applicationContext.startService(intent) }
        }
    }
}
