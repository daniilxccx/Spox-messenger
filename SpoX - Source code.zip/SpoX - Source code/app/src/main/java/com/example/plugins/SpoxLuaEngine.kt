package com.example.plugins

import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.ln
import kotlin.math.pow
import kotlin.math.round
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan
import kotlin.random.Random

/**
 * Sandboxed pure-Kotlin Lua interpreter ("SpoX Lua") compliant with Google Play Dynamic Code Loading rules.
 * No .dex/.jar/.so code is loaded; scripts execute inside an isolated AST VM with a strict step budget.
 */
object SpoxLuaEngine {

    private const val DEFAULT_MAX_STEPS = 40_000
    private const val MAX_LOG_ENTRIES = 64

    sealed class LuaVal {
        data object Nil : LuaVal()
        data class Bool(val value: Boolean) : LuaVal()
        data class Num(val value: Double) : LuaVal()
        data class Str(val value: String) : LuaVal()
        class Table : LuaVal() {
            val entries = LinkedHashMap<LuaVal, LuaVal>()

            fun get(key: LuaVal): LuaVal = entries[key] ?: Nil

            fun set(key: LuaVal, value: LuaVal) {
                if (key is Nil) throw LuaRuntimeException("Ключ таблицы не может быть nil")
                if (value is Nil) {
                    entries.remove(key)
                } else {
                    entries[key] = value
                }
            }

            fun getField(name: String): LuaVal = get(Str(name))
            fun setField(name: String, value: LuaVal) = set(Str(name), value)

            fun getIndex(index: Int): LuaVal = get(Num(index.toDouble()))
            fun setIndex(index: Int, value: LuaVal) = set(Num(index.toDouble()), value)

            fun arrayLength(): Int {
                var i = 1
                while (entries[Num(i.toDouble())] != null && entries[Num(i.toDouble())] !is Nil) {
                    i++
                }
                return i - 1
            }

            fun arrayItems(): List<LuaVal> {
                val len = arrayLength()
                val out = ArrayList<LuaVal>(len)
                for (i in 1..len) {
                    out.add(entries[Num(i.toDouble())] ?: Nil)
                }
                return out
            }
        }

        class NativeFn(
            val name: String,
            val impl: (vm: LuaVm, args: List<LuaVal>) -> List<LuaVal>
        ) : LuaVal()

        class Closure(
            val params: List<String>,
            val hasVararg: Boolean,
            val body: List<Stmt>,
            val env: LuaEnv
        ) : LuaVal()

        fun isTruthy(): Boolean = when (this) {
            Nil -> false
            is Bool -> value
            else -> true
        }

        fun typeName(): String = when (this) {
            Nil -> "nil"
            is Bool -> "boolean"
            is Num -> "number"
            is Str -> "string"
            is Table -> "table"
            is NativeFn, is Closure -> "function"
        }

        fun asDisplayString(): String = when (this) {
            Nil -> "nil"
            is Bool -> if (value) "true" else "false"
            is Num -> {
                if (value.isNaN()) "nan"
                else if (value.isInfinite()) if (value > 0) "inf" else "-inf"
                else if (value % 1.0 == 0.0 && abs(value) <= 9_000_000_000_000_000.0) {
                    value.toLong().toString()
                } else {
                    value.toString()
                }
            }
            is Str -> value
            is Table -> "table"
            is NativeFn -> "function: $name"
            is Closure -> "function"
        }

        fun asDoubleOrNull(): Double? = when (this) {
            is Num -> value
            is Str -> value.trim().toDoubleOrNull()
            else -> null
        }

        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            if (other !is LuaVal) return false
            return when {
                this is Nil && other is Nil -> true
                this is Bool && other is Bool -> value == other.value
                this is Num && other is Num -> value == other.value
                this is Str && other is Str -> value == other.value
                else -> false
            }
        }

        override fun hashCode(): Int = when (this) {
            Nil -> 0
            is Bool -> value.hashCode()
            is Num -> if (value == 0.0) 0 else value.hashCode()
            is Str -> value.hashCode()
            else -> System.identityHashCode(this)
        }
    }

    class LuaRuntimeException(message: String) : RuntimeException(message)
    private class ReturnSignal(val values: List<LuaVal>) : RuntimeException(null, null, false, false)
    private class BreakSignal : RuntimeException(null, null, false, false)

    class LuaEnv(private val parent: LuaEnv? = null) {
        private val vars = HashMap<String, LuaVal>()

        fun defineLocal(name: String, value: LuaVal) {
            vars[name] = value
        }

        fun get(name: String): LuaVal {
            var curr: LuaEnv? = this
            while (curr != null) {
                if (curr.vars.containsKey(name)) {
                    return curr.vars[name] ?: LuaVal.Nil
                }
                curr = curr.parent
            }
            return LuaVal.Nil
        }

        fun assign(name: String, value: LuaVal) {
            var curr: LuaEnv? = this
            while (curr != null) {
                if (curr.vars.containsKey(name)) {
                    if (value is LuaVal.Nil && curr.parent == null) {
                        curr.vars.remove(name)
                    } else {
                        curr.vars[name] = value
                    }
                    return
                }
                if (curr.parent == null) {
                    if (value !is LuaVal.Nil) {
                        curr.vars[name] = value
                    }
                    return
                }
                curr = curr.parent
            }
        }
    }

    // --- Lexer ---
    private enum class TokType {
        IDENT, NUMBER, STRING,
        AND, BREAK, DO, ELSE, ELSEIF, END, FALSE, FOR, FUNCTION,
        IF, IN, LOCAL, NIL, NOT, OR, REPEAT, RETURN, THEN, TRUE, UNTIL, WHILE,
        PLUS, MINUS, STAR, SLASH, FLOOR_DIV, PERCENT, CARET, HASH,
        EQ, NEQ, LT, LTE, GT, GTE, ASSIGN,
        LPAREN, RPAREN, LBRACE, RBRACE, LBRACKET, RBRACKET,
        SEMICOLON, COLON, COMMA, DOT, CONCAT, VARARG,
        EOF
    }

    private data class Token(val type: TokType, val text: String, val line: Int)

    private val keywords = mapOf(
        "and" to TokType.AND, "break" to TokType.BREAK, "do" to TokType.DO,
        "else" to TokType.ELSE, "elseif" to TokType.ELSEIF, "end" to TokType.END,
        "false" to TokType.FALSE, "for" to TokType.FOR, "function" to TokType.FUNCTION,
        "if" to TokType.IF, "in" to TokType.IN, "local" to TokType.LOCAL,
        "nil" to TokType.NIL, "not" to TokType.NOT, "or" to TokType.OR,
        "repeat" to TokType.REPEAT, "return" to TokType.RETURN, "then" to TokType.THEN,
        "true" to TokType.TRUE, "until" to TokType.UNTIL, "while" to TokType.WHILE
    )

    private fun tokenize(src: String): List<Token> {
        val tokens = ArrayList<Token>()
        var i = 0
        var line = 1
        val n = src.length

        fun peek(offset: Int = 0): Char = if (i + offset < n) src[i + offset] else '\u0000'

        while (i < n) {
            val c = src[i]
            when {
                c == '\n' -> { line++; i++ }
                c.isWhitespace() -> i++
                c == '-' && peek(1) == '-' -> {
                    i += 2
                    if (peek() == '[' && peek(1) == '[') {
                        i += 2
                        while (i < n && !(src[i] == ']' && peek(1) == ']')) {
                            if (src[i] == '\n') line++
                            i++
                        }
                        if (i < n) i += 2
                    } else {
                        while (i < n && src[i] != '\n') i++
                    }
                }
                c == '[' && peek(1) == '[' -> {
                    val startLine = line
                    i += 2
                    if (peek() == '\n') { line++; i++ }
                    val sb = StringBuilder()
                    while (i < n && !(src[i] == ']' && peek(1) == ']')) {
                        if (src[i] == '\n') line++
                        sb.append(src[i++])
                    }
                    if (i >= n) throw LuaRuntimeException("Строка $startLine: незакрытая длинная строка [[...]]")
                    i += 2
                    tokens.add(Token(TokType.STRING, sb.toString(), startLine))
                }
                c == '"' || c == '\'' -> {
                    val quote = c
                    val startLine = line
                    i++
                    val sb = StringBuilder()
                    while (i < n && src[i] != quote) {
                        val ch = src[i]
                        if (ch == '\n') throw LuaRuntimeException("Строка $startLine: незакрытая строка")
                        if (ch == '\\' && i + 1 < n) {
                            i++
                            when (val esc = src[i]) {
                                'n' -> sb.append('\n')
                                'r' -> sb.append('\r')
                                't' -> sb.append('\t')
                                '\\' -> sb.append('\\')
                                '"' -> sb.append('"')
                                '\'' -> sb.append('\'')
                                else -> sb.append(esc)
                            }
                        } else {
                            sb.append(ch)
                        }
                        i++
                    }
                    if (i >= n) throw LuaRuntimeException("Строка $startLine: незакрытая строка")
                    i++
                    tokens.add(Token(TokType.STRING, sb.toString(), startLine))
                }
                c.isDigit() -> {
                    val start = i
                    if (c == '0' && (peek(1) == 'x' || peek(1) == 'X')) {
                        i += 2
                        while (i < n && (src[i].isDigit() || src[i] in 'a'..'f' || src[i] in 'A'..'F')) i++
                    } else {
                        while (i < n && src[i].isDigit()) i++
                        if (peek() == '.' && peek(1).isDigit()) {
                            i++
                            while (i < n && src[i].isDigit()) i++
                        }
                        if (peek() == 'e' || peek() == 'E') {
                            i++
                            if (peek() == '+' || peek() == '-') i++
                            while (i < n && src[i].isDigit()) i++
                        }
                    }
                    tokens.add(Token(TokType.NUMBER, src.substring(start, i), line))
                }
                c.isLetter() || c == '_' -> {
                    val start = i
                    while (i < n && (src[i].isLetterOrDigit() || src[i] == '_')) i++
                    val word = src.substring(start, i)
                    tokens.add(Token(keywords[word] ?: TokType.IDENT, word, line))
                }
                else -> {
                    val tok = when (c) {
                        '+' -> { i++; Token(TokType.PLUS, "+", line) }
                        '-' -> { i++; Token(TokType.MINUS, "-", line) }
                        '*' -> { i++; Token(TokType.STAR, "*", line) }
                        '/' -> if (peek(1) == '/') { i += 2; Token(TokType.FLOOR_DIV, "//", line) }
                               else { i++; Token(TokType.SLASH, "/", line) }
                        '%' -> { i++; Token(TokType.PERCENT, "%", line) }
                        '^' -> { i++; Token(TokType.CARET, "^", line) }
                        '#' -> { i++; Token(TokType.HASH, "#", line) }
                        '(' -> { i++; Token(TokType.LPAREN, "(", line) }
                        ')' -> { i++; Token(TokType.RPAREN, ")", line) }
                        '{' -> { i++; Token(TokType.LBRACE, "{", line) }
                        '}' -> { i++; Token(TokType.RBRACE, "}", line) }
                        '[' -> { i++; Token(TokType.LBRACKET, "[", line) }
                        ']' -> { i++; Token(TokType.RBRACKET, "]", line) }
                        ';' -> { i++; Token(TokType.SEMICOLON, ";", line) }
                        ':' -> { i++; Token(TokType.COLON, ":", line) }
                        ',' -> { i++; Token(TokType.COMMA, ",", line) }
                        '=' -> if (peek(1) == '=') { i += 2; Token(TokType.EQ, "==", line) }
                               else { i++; Token(TokType.ASSIGN, "=", line) }
                        '~' -> if (peek(1) == '=') { i += 2; Token(TokType.NEQ, "~=", line) }
                               else throw LuaRuntimeException("Строка $line: неожиданный символ '~'")
                        '<' -> if (peek(1) == '=') { i += 2; Token(TokType.LTE, "<=", line) }
                               else { i++; Token(TokType.LT, "<", line) }
                        '>' -> if (peek(1) == '=') { i += 2; Token(TokType.GTE, ">=", line) }
                               else { i++; Token(TokType.GT, ">", line) }
                        '.' -> when {
                            peek(1) == '.' && peek(2) == '.' -> { i += 3; Token(TokType.VARARG, "...", line) }
                            peek(1) == '.' -> { i += 2; Token(TokType.CONCAT, "..", line) }
                            else -> { i++; Token(TokType.DOT, ".", line) }
                        }
                        else -> throw LuaRuntimeException("Строка $line: неизвестный символ '$c'")
                    }
                    tokens.add(tok)
                }
            }
        }
        tokens.add(Token(TokType.EOF, "", line))
        return tokens
    }

    // --- AST ---
    sealed interface Expr {
        data object NilLit : Expr
        data class BoolLit(val v: Boolean) : Expr
        data class NumLit(val v: Double) : Expr
        data class StrLit(val v: String) : Expr
        data object VarargExpr : Expr
        data class Var(val name: String) : Expr
        data class Unary(val op: String, val expr: Expr) : Expr
        data class Binary(val op: String, val left: Expr, val right: Expr) : Expr
        data class TableCtor(val fields: List<TableField>) : Expr
        data class FuncExpr(val params: List<String>, val hasVararg: Boolean, val body: List<Stmt>) : Expr
        data class Index(val target: Expr, val key: Expr) : Expr
        data class Call(val target: Expr, val methodName: String?, val args: List<Expr>) : Expr
    }

    sealed interface TableField {
        data class Positional(val value: Expr) : TableField
        data class Named(val key: Expr, val value: Expr) : TableField
    }

    sealed interface LValue {
        data class VarTarget(val name: String) : LValue
        data class IndexTarget(val target: Expr, val key: Expr) : LValue
    }

    sealed interface Stmt {
        data class LocalAssign(val names: List<String>, val values: List<Expr>) : Stmt
        data class Assign(val targets: List<LValue>, val values: List<Expr>) : Stmt
        data class ExprStmt(val expr: Expr) : Stmt
        data class Block(val body: List<Stmt>) : Stmt
        data class IfStmt(val branches: List<Pair<Expr, List<Stmt>>>, val elseBody: List<Stmt>?) : Stmt
        data class WhileStmt(val cond: Expr, val body: List<Stmt>) : Stmt
        data class RepeatStmt(val body: List<Stmt>, val cond: Expr) : Stmt
        data class ForNumStmt(val varName: String, val start: Expr, val limit: Expr, val step: Expr?, val body: List<Stmt>) : Stmt
        data class ForInStmt(val names: List<String>, val iterExprs: List<Expr>, val body: List<Stmt>) : Stmt
        data class ReturnStmt(val values: List<Expr>) : Stmt
        data object BreakStmt : Stmt
    }

    // --- Parser ---
    private class Parser(private val tokens: List<Token>) {
        private var pos = 0

        private fun cur(): Token = tokens[pos]
        private fun peek(offset: Int = 1): Token = tokens[(pos + offset).coerceAtMost(tokens.lastIndex)]
        private fun match(type: TokType): Boolean {
            if (cur().type == type) {
                pos++
                return true
            }
            return false
        }
        private fun expect(type: TokType, what: String): Token {
            val t = cur()
            if (t.type != type) {
                throw LuaRuntimeException("Строка ${t.line}: ожидалось '$what', получено '${t.text.ifEmpty { t.type.name }}'")
            }
            pos++
            return t
        }

        fun parseChunk(): List<Stmt> = parseBlock(setOf(TokType.EOF))

        private fun parseBlock(stopTokens: Set<TokType>): List<Stmt> {
            val stmts = ArrayList<Stmt>()
            while (cur().type !in stopTokens && cur().type != TokType.EOF) {
                while (match(TokType.SEMICOLON)) { /* skip extra semicolons */ }
                if (cur().type in stopTokens || cur().type == TokType.EOF) break
                val stmt = parseStatement()
                stmts.add(stmt)
                match(TokType.SEMICOLON)
                if (stmt is Stmt.ReturnStmt || stmt is Stmt.BreakStmt) break
            }
            return stmts
        }

        private fun parseStatement(): Stmt {
            val t = cur()
            return when (t.type) {
                TokType.LOCAL -> parseLocal()
                TokType.FUNCTION -> parseFunctionDecl()
                TokType.IF -> parseIf()
                TokType.WHILE -> parseWhile()
                TokType.REPEAT -> parseRepeat()
                TokType.FOR -> parseFor()
                TokType.DO -> {
                    pos++
                    val body = parseBlock(setOf(TokType.END))
                    expect(TokType.END, "end")
                    Stmt.Block(body)
                }
                TokType.RETURN -> {
                    pos++
                    val values = if (cur().type in setOf(TokType.EOF, TokType.END, TokType.ELSE, TokType.ELSEIF, TokType.UNTIL, TokType.SEMICOLON)) {
                        emptyList()
                    } else {
                        parseExprList()
                    }
                    Stmt.ReturnStmt(values)
                }
                TokType.BREAK -> {
                    pos++
                    Stmt.BreakStmt
                }
                else -> parseExprOrAssign()
            }
        }

        private fun parseLocal(): Stmt {
            pos++
            if (match(TokType.FUNCTION)) {
                val name = expect(TokType.IDENT, "имя функции").text
                val fn = parseFuncBody(addSelf = false)
                return Stmt.LocalAssign(listOf(name), listOf(fn))
            }
            val names = ArrayList<String>()
            names.add(expect(TokType.IDENT, "имя переменной").text)
            while (match(TokType.COMMA)) {
                names.add(expect(TokType.IDENT, "имя переменной").text)
            }
            val values = if (match(TokType.ASSIGN)) parseExprList() else emptyList()
            return Stmt.LocalAssign(names, values)
        }

        private fun parseFunctionDecl(): Stmt {
            pos++
            var target: LValue = LValue.VarTarget(expect(TokType.IDENT, "имя функции").text)
            var exprTarget: Expr = Expr.Var((target as LValue.VarTarget).name)
            while (match(TokType.DOT)) {
                val field = expect(TokType.IDENT, "имя поля").text
                target = LValue.IndexTarget(exprTarget, Expr.StrLit(field))
                exprTarget = Expr.Index(exprTarget, Expr.StrLit(field))
            }
            var addSelf = false
            if (match(TokType.COLON)) {
                val method = expect(TokType.IDENT, "имя метода").text
                target = LValue.IndexTarget(exprTarget, Expr.StrLit(method))
                addSelf = true
            }
            val fn = parseFuncBody(addSelf = addSelf)
            return Stmt.Assign(listOf(target), listOf(fn))
        }

        private fun parseFuncBody(addSelf: Boolean): Expr.FuncExpr {
            expect(TokType.LPAREN, "(")
            val params = ArrayList<String>()
            if (addSelf) params.add("self")
            var hasVararg = false
            if (cur().type != TokType.RPAREN) {
                do {
                    if (match(TokType.VARARG)) {
                        hasVararg = true
                        break
                    }
                    params.add(expect(TokType.IDENT, "параметр").text)
                } while (match(TokType.COMMA))
            }
            expect(TokType.RPAREN, ")")
            val body = parseBlock(setOf(TokType.END))
            expect(TokType.END, "end")
            return Expr.FuncExpr(params, hasVararg, body)
        }

        private fun parseIf(): Stmt {
            pos++
            val branches = ArrayList<Pair<Expr, List<Stmt>>>()
            val firstCond = parseExpr()
            expect(TokType.THEN, "then")
            val firstBody = parseBlock(setOf(TokType.ELSEIF, TokType.ELSE, TokType.END))
            branches.add(firstCond to firstBody)

            while (match(TokType.ELSEIF)) {
                val cond = parseExpr()
                expect(TokType.THEN, "then")
                val body = parseBlock(setOf(TokType.ELSEIF, TokType.ELSE, TokType.END))
                branches.add(cond to body)
            }
            val elseBody = if (match(TokType.ELSE)) {
                parseBlock(setOf(TokType.END))
            } else {
                null
            }
            expect(TokType.END, "end")
            return Stmt.IfStmt(branches, elseBody)
        }

        private fun parseWhile(): Stmt {
            pos++
            val cond = parseExpr()
            expect(TokType.DO, "do")
            val body = parseBlock(setOf(TokType.END))
            expect(TokType.END, "end")
            return Stmt.WhileStmt(cond, body)
        }

        private fun parseRepeat(): Stmt {
            pos++
            val body = parseBlock(setOf(TokType.UNTIL))
            expect(TokType.UNTIL, "until")
            val cond = parseExpr()
            return Stmt.RepeatStmt(body, cond)
        }

        private fun parseFor(): Stmt {
            pos++
            val firstVar = expect(TokType.IDENT, "переменная цикла").text
            if (match(TokType.ASSIGN)) {
                val start = parseExpr()
                expect(TokType.COMMA, ",")
                val limit = parseExpr()
                val step = if (match(TokType.COMMA)) parseExpr() else null
                expect(TokType.DO, "do")
                val body = parseBlock(setOf(TokType.END))
                expect(TokType.END, "end")
                return Stmt.ForNumStmt(firstVar, start, limit, step, body)
            } else {
                val names = ArrayList<String>()
                names.add(firstVar)
                while (match(TokType.COMMA)) {
                    names.add(expect(TokType.IDENT, "переменная цикла").text)
                }
                expect(TokType.IN, "in")
                val iters = parseExprList()
                expect(TokType.DO, "do")
                val body = parseBlock(setOf(TokType.END))
                expect(TokType.END, "end")
                return Stmt.ForInStmt(names, iters, body)
            }
        }

        private fun parseExprOrAssign(): Stmt {
            val first = parseSuffixedExpr()
            if (cur().type == TokType.ASSIGN || cur().type == TokType.COMMA) {
                val targets = ArrayList<LValue>()
                targets.add(toLValue(first))
                while (match(TokType.COMMA)) {
                    targets.add(toLValue(parseSuffixedExpr()))
                }
                expect(TokType.ASSIGN, "=")
                val values = parseExprList()
                return Stmt.Assign(targets, values)
            }
            if (first !is Expr.Call) {
                throw LuaRuntimeException("Строка ${cur().line}: ожидался вызов функции или присваивание")
            }
            return Stmt.ExprStmt(first)
        }

        private fun toLValue(expr: Expr): LValue = when (expr) {
            is Expr.Var -> LValue.VarTarget(expr.name)
            is Expr.Index -> LValue.IndexTarget(expr.target, expr.key)
            else -> throw LuaRuntimeException("Строка ${cur().line}: некорректная цель присваивания")
        }

        private fun parseExprList(): List<Expr> {
            val list = ArrayList<Expr>()
            list.add(parseExpr())
            while (match(TokType.COMMA)) {
                list.add(parseExpr())
            }
            return list
        }

        private fun parseExpr(): Expr = parseOr()

        private fun parseOr(): Expr {
            var left = parseAnd()
            while (match(TokType.OR)) {
                left = Expr.Binary("or", left, parseAnd())
            }
            return left
        }

        private fun parseAnd(): Expr {
            var left = parseComparison()
            while (match(TokType.AND)) {
                left = Expr.Binary("and", left, parseComparison())
            }
            return left
        }

        private fun parseComparison(): Expr {
            var left = parseConcat()
            while (true) {
                val op = when (cur().type) {
                    TokType.EQ -> "=="
                    TokType.NEQ -> "~="
                    TokType.LT -> "<"
                    TokType.LTE -> "<="
                    TokType.GT -> ">"
                    TokType.GTE -> ">="
                    else -> break
                }
                pos++
                left = Expr.Binary(op, left, parseConcat())
            }
            return left
        }

        private fun parseConcat(): Expr {
            val left = parseAddSub()
            if (match(TokType.CONCAT)) {
                return Expr.Binary("..", left, parseConcat())
            }
            return left
        }

        private fun parseAddSub(): Expr {
            var left = parseMulDiv()
            while (cur().type == TokType.PLUS || cur().type == TokType.MINUS) {
                val op = cur().text
                pos++
                left = Expr.Binary(op, left, parseMulDiv())
            }
            return left
        }

        private fun parseMulDiv(): Expr {
            var left = parseUnary()
            while (cur().type in setOf(TokType.STAR, TokType.SLASH, TokType.FLOOR_DIV, TokType.PERCENT)) {
                val op = cur().text
                pos++
                left = Expr.Binary(op, left, parseUnary())
            }
            return left
        }

        private fun parseUnary(): Expr {
            return when (cur().type) {
                TokType.NOT -> { pos++; Expr.Unary("not", parseUnary()) }
                TokType.MINUS -> { pos++; Expr.Unary("-", parseUnary()) }
                TokType.HASH -> { pos++; Expr.Unary("#", parseUnary()) }
                else -> parsePower()
            }
        }

        private fun parsePower(): Expr {
            val left = parseSuffixedExpr()
            if (match(TokType.CARET)) {
                return Expr.Binary("^", left, parseUnary())
            }
            return left
        }

        private fun parseSuffixedExpr(): Expr {
            var expr = parsePrimary()
            while (true) {
                when (cur().type) {
                    TokType.DOT -> {
                        pos++
                        val field = expect(TokType.IDENT, "имя поля").text
                        expr = Expr.Index(expr, Expr.StrLit(field))
                    }
                    TokType.LBRACKET -> {
                        pos++
                        val key = parseExpr()
                        expect(TokType.RBRACKET, "]")
                        expr = Expr.Index(expr, key)
                    }
                    TokType.COLON -> {
                        pos++
                        val method = expect(TokType.IDENT, "имя метода").text
                        val args = parseCallArgs()
                        expr = Expr.Call(expr, method, args)
                    }
                    TokType.LPAREN, TokType.STRING, TokType.LBRACE -> {
                        val args = parseCallArgs()
                        expr = Expr.Call(expr, null, args)
                    }
                    else -> break
                }
            }
            return expr
        }

        private fun parseCallArgs(): List<Expr> {
            return when (cur().type) {
                TokType.LPAREN -> {
                    pos++
                    val args = if (cur().type == TokType.RPAREN) emptyList() else parseExprList()
                    expect(TokType.RPAREN, ")")
                    args
                }
                TokType.STRING -> {
                    val s = cur().text
                    pos++
                    listOf(Expr.StrLit(s))
                }
                TokType.LBRACE -> {
                    listOf(parseTableCtor())
                }
                else -> throw LuaRuntimeException("Строка ${cur().line}: ожидались аргументы вызова функции")
            }
        }

        private fun parsePrimary(): Expr {
            val t = cur()
            return when (t.type) {
                TokType.NIL -> { pos++; Expr.NilLit }
                TokType.TRUE -> { pos++; Expr.BoolLit(true) }
                TokType.FALSE -> { pos++; Expr.BoolLit(false) }
                TokType.NUMBER -> {
                    pos++
                    val parsed = if (t.text.startsWith("0x", ignoreCase = true)) {
                        t.text.substring(2).toLong(16).toDouble()
                    } else {
                        t.text.toDouble()
                    }
                    Expr.NumLit(parsed)
                }
                TokType.STRING -> { pos++; Expr.StrLit(t.text) }
                TokType.VARARG -> { pos++; Expr.VarargExpr }
                TokType.IDENT -> { pos++; Expr.Var(t.text) }
                TokType.FUNCTION -> { pos++; parseFuncBody(addSelf = false) }
                TokType.LBRACE -> parseTableCtor()
                TokType.LPAREN -> {
                    pos++
                    val inner = parseExpr()
                    expect(TokType.RPAREN, ")")
                    inner
                }
                else -> throw LuaRuntimeException("Строка ${t.line}: неожиданное выражение '${t.text.ifEmpty { t.type.name }}'")
            }
        }

        private fun parseTableCtor(): Expr {
            expect(TokType.LBRACE, "{")
            val fields = ArrayList<TableField>()
            while (cur().type != TokType.RBRACE) {
                when {
                    cur().type == TokType.LBRACKET -> {
                        pos++
                        val key = parseExpr()
                        expect(TokType.RBRACKET, "]")
                        expect(TokType.ASSIGN, "=")
                        val valExpr = parseExpr()
                        fields.add(TableField.Named(key, valExpr))
                    }
                    cur().type == TokType.IDENT && peek().type == TokType.ASSIGN -> {
                        val key = cur().text
                        pos += 2
                        val valExpr = parseExpr()
                        fields.add(TableField.Named(Expr.StrLit(key), valExpr))
                    }
                    else -> {
                        fields.add(TableField.Positional(parseExpr()))
                    }
                }
                if (!match(TokType.COMMA) && !match(TokType.SEMICOLON)) break
            }
            expect(TokType.RBRACE, "}")
            return Expr.TableCtor(fields)
        }
    }

    // --- VM ---
    class LuaVm(
        private val maxSteps: Int = DEFAULT_MAX_STEPS,
        val logs: MutableList<String> = ArrayList(),
        val queuedMessages: MutableList<String> = ArrayList(),
        val notices: MutableList<String> = ArrayList()
    ) {
        val globals = LuaEnv()
        private var steps = 0

        init {
            installStdLib()
        }

        fun tick() {
            steps++
            if (steps > maxSteps) {
                throw LuaRuntimeException("Превышен лимит шагов выполнения ($maxSteps). Возможен бесконечный цикл.")
            }
        }

        fun addLog(msg: String) {
            if (logs.size < MAX_LOG_ENTRIES) {
                logs.add(msg)
            }
        }

        fun execChunk(source: String): List<LuaVal> {
            val stmts = Parser(tokenize(source)).parseChunk()
            return try {
                execBlock(stmts, globals, varargs = emptyList())
                emptyList()
            } catch (ret: ReturnSignal) {
                ret.values
            }
        }

        fun callHook(fnName: String, vararg args: LuaVal): List<LuaVal> {
            val fn = globals.get(fnName)
            if (fn is LuaVal.Nil) return emptyList()
            return callValue(fn, args.toList())
        }

        fun callValue(fn: LuaVal, args: List<LuaVal>): List<LuaVal> {
            tick()
            return when (fn) {
                is LuaVal.NativeFn -> fn.impl(this, args)
                is LuaVal.Closure -> {
                    val fnEnv = LuaEnv(fn.env)
                    for (i in fn.params.indices) {
                        fnEnv.defineLocal(fn.params[i], args.getOrElse(i) { LuaVal.Nil })
                    }
                    val varargs = if (fn.hasVararg && args.size > fn.params.size) {
                        args.subList(fn.params.size, args.size)
                    } else {
                        emptyList()
                    }
                    try {
                        execBlock(fn.body, fnEnv, varargs)
                        emptyList()
                    } catch (ret: ReturnSignal) {
                        ret.values
                    }
                }
                else -> throw LuaRuntimeException("Попытка вызвать значение типа '${fn.typeName()}' как функцию")
            }
        }

        private fun execBlock(stmts: List<Stmt>, env: LuaEnv, varargs: List<LuaVal>) {
            for (stmt in stmts) {
                tick()
                execStmt(stmt, env, varargs)
            }
        }

        private fun evalList(exprs: List<Expr>, env: LuaEnv, varargs: List<LuaVal>): List<LuaVal> {
            if (exprs.isEmpty()) return emptyList()
            val out = ArrayList<LuaVal>(exprs.size)
            for (i in exprs.indices) {
                val multi = evalMulti(exprs[i], env, varargs)
                if (i == exprs.lastIndex) {
                    out.addAll(multi)
                } else {
                    out.add(multi.firstOrNull() ?: LuaVal.Nil)
                }
            }
            return out
        }

        private fun execStmt(stmt: Stmt, env: LuaEnv, varargs: List<LuaVal>) {
            when (stmt) {
                is Stmt.LocalAssign -> {
                    val vals = evalList(stmt.values, env, varargs)
                    stmt.names.forEachIndexed { idx, name ->
                        env.defineLocal(name, vals.getOrElse(idx) { LuaVal.Nil })
                    }
                }
                is Stmt.Assign -> {
                    val vals = evalList(stmt.values, env, varargs)
                    stmt.targets.forEachIndexed { idx, target ->
                        val v = vals.getOrElse(idx) { LuaVal.Nil }
                        when (target) {
                            is LValue.VarTarget -> env.assign(target.name, v)
                            is LValue.IndexTarget -> {
                                val tbl = evalSingle(target.target, env, varargs)
                                if (tbl !is LuaVal.Table) {
                                    throw LuaRuntimeException("Ожидалась таблица для записи поля, получено '${tbl.typeName()}'")
                                }
                                val key = evalSingle(target.key, env, varargs)
                                tbl.set(key, v)
                            }
                        }
                    }
                }
                is Stmt.ExprStmt -> {
                    evalMulti(stmt.expr, env, varargs)
                }
                is Stmt.Block -> {
                    execBlock(stmt.body, LuaEnv(env), varargs)
                }
                is Stmt.IfStmt -> {
                    var matched = false
                    for ((cond, body) in stmt.branches) {
                        if (evalSingle(cond, env, varargs).isTruthy()) {
                            execBlock(body, LuaEnv(env), varargs)
                            matched = true
                            break
                        }
                    }
                    if (!matched && stmt.elseBody != null) {
                        execBlock(stmt.elseBody, LuaEnv(env), varargs)
                    }
                }
                is Stmt.WhileStmt -> {
                    while (evalSingle(stmt.cond, env, varargs).isTruthy()) {
                        tick()
                        try {
                            execBlock(stmt.body, LuaEnv(env), varargs)
                        } catch (_: BreakSignal) {
                            break
                        }
                    }
                }
                is Stmt.RepeatStmt -> {
                    do {
                        tick()
                        val loopEnv = LuaEnv(env)
                        try {
                            execBlock(stmt.body, loopEnv, varargs)
                        } catch (_: BreakSignal) {
                            break
                        }
                    } while (!evalSingle(stmt.cond, loopEnv, varargs).isTruthy())
                }
                is Stmt.ForNumStmt -> {
                    val startVal = evalSingle(stmt.start, env, varargs).asDoubleOrNull()
                        ?: throw LuaRuntimeException("Начало цикла for должно быть числом")
                    val limitVal = evalSingle(stmt.limit, env, varargs).asDoubleOrNull()
                        ?: throw LuaRuntimeException("Граница цикла for должна быть числом")
                    val stepVal = if (stmt.step != null) {
                        evalSingle(stmt.step, env, varargs).asDoubleOrNull()
                            ?: throw LuaRuntimeException("Шаг цикла for должен быть числом")
                    } else 1.0
                    if (stepVal == 0.0) throw LuaRuntimeException("Шаг цикла for не может быть 0")

                    var curr = startVal
                    while ((stepVal > 0 && curr <= limitVal) || (stepVal < 0 && curr >= limitVal)) {
                        tick()
                        val loopEnv = LuaEnv(env)
                        loopEnv.defineLocal(stmt.varName, LuaVal.Num(curr))
                        try {
                            execBlock(stmt.body, loopEnv, varargs)
                        } catch (_: BreakSignal) {
                            break
                        }
                        curr += stepVal
                    }
                }
                is Stmt.ForInStmt -> {
                    val iterVals = evalList(stmt.iterExprs, env, varargs)
                    val iterFn = iterVals.getOrElse(0) { LuaVal.Nil }
                    val stateVal = iterVals.getOrElse(1) { LuaVal.Nil }
                    var controlVal = iterVals.getOrElse(2) { LuaVal.Nil }
                    while (true) {
                        tick()
                        val res = callValue(iterFn, listOf(stateVal, controlVal))
                        val firstRes = res.getOrElse(0) { LuaVal.Nil }
                        if (firstRes is LuaVal.Nil) break
                        controlVal = firstRes
                        val loopEnv = LuaEnv(env)
                        stmt.names.forEachIndexed { idx, name ->
                            loopEnv.defineLocal(name, res.getOrElse(idx) { LuaVal.Nil })
                        }
                        try {
                            execBlock(stmt.body, loopEnv, varargs)
                        } catch (_: BreakSignal) {
                            break
                        }
                    }
                }
                is Stmt.ReturnStmt -> {
                    throw ReturnSignal(evalList(stmt.values, env, varargs))
                }
                is Stmt.BreakStmt -> throw BreakSignal()
            }
        }

        private fun evalSingle(expr: Expr, env: LuaEnv, varargs: List<LuaVal>): LuaVal =
            evalMulti(expr, env, varargs).firstOrNull() ?: LuaVal.Nil

        private fun evalMulti(expr: Expr, env: LuaEnv, varargs: List<LuaVal>): List<LuaVal> {
            return when (expr) {
                is Expr.NilLit -> listOf(LuaVal.Nil)
                is Expr.BoolLit -> listOf(LuaVal.Bool(expr.v))
                is Expr.NumLit -> listOf(LuaVal.Num(expr.v))
                is Expr.StrLit -> listOf(LuaVal.Str(expr.v))
                is Expr.VarargExpr -> varargs
                is Expr.Var -> listOf(env.get(expr.name))
                is Expr.FuncExpr -> listOf(LuaVal.Closure(expr.params, expr.hasVararg, expr.body, env))
                is Expr.TableCtor -> {
                    val tbl = LuaVal.Table()
                    var arrayIdx = 1
                    expr.fields.forEachIndexed { idx, field ->
                        when (field) {
                            is TableField.Positional -> {
                                if (idx == expr.fields.lastIndex) {
                                    val multi = evalMulti(field.value, env, varargs)
                                    for (v in multi) {
                                        tbl.setIndex(arrayIdx++, v)
                                    }
                                } else {
                                    tbl.setIndex(arrayIdx++, evalSingle(field.value, env, varargs))
                                }
                            }
                            is TableField.Named -> {
                                val k = evalSingle(field.key, env, varargs)
                                val v = evalSingle(field.value, env, varargs)
                                tbl.set(k, v)
                            }
                        }
                    }
                    listOf(tbl)
                }
                is Expr.Index -> {
                    val target = evalSingle(expr.target, env, varargs)
                    val key = evalSingle(expr.key, env, varargs)
                    when (target) {
                        is LuaVal.Table -> listOf(target.get(key))
                        is LuaVal.Str -> {
                            val strLib = globals.get("string") as? LuaVal.Table
                            listOf(strLib?.get(key) ?: LuaVal.Nil)
                        }
                        else -> throw LuaRuntimeException("Невозможно индексировать '${target.typeName()}'")
                    }
                }
                is Expr.Call -> {
                    val receiver = evalSingle(expr.target, env, varargs)
                    val argVals = evalList(expr.args, env, varargs)
                    if (expr.methodName != null) {
                        val methodFn = when (receiver) {
                            is LuaVal.Table -> receiver.getField(expr.methodName)
                            is LuaVal.Str -> (globals.get("string") as? LuaVal.Table)?.getField(expr.methodName) ?: LuaVal.Nil
                            else -> LuaVal.Nil
                        }
                        callValue(methodFn, listOf(receiver) + argVals)
                    } else {
                        callValue(receiver, argVals)
                    }
                }
                is Expr.Unary -> {
                    val v = evalSingle(expr.expr, env, varargs)
                    val out = when (expr.op) {
                        "not" -> LuaVal.Bool(!v.isTruthy())
                        "-" -> {
                            val n = v.asDoubleOrNull()
                                ?: throw LuaRuntimeException("Ожидалось число для унарного '-'")
                            LuaVal.Num(-n)
                        }
                        "#" -> when (v) {
                            is LuaVal.Str -> LuaVal.Num(v.value.length.toDouble())
                            is LuaVal.Table -> LuaVal.Num(v.arrayLength().toDouble())
                            else -> throw LuaRuntimeException("Операция # не поддерживается для '${v.typeName()}'")
                        }
                        else -> LuaVal.Nil
                    }
                    listOf(out)
                }
                is Expr.Binary -> listOf(evalBinary(expr, env, varargs))
            }
        }

        private fun evalBinary(expr: Expr.Binary, env: LuaEnv, varargs: List<LuaVal>): LuaVal {
            if (expr.op == "and") {
                val l = evalSingle(expr.left, env, varargs)
                return if (!l.isTruthy()) l else evalSingle(expr.right, env, varargs)
            }
            if (expr.op == "or") {
                val l = evalSingle(expr.left, env, varargs)
                return if (l.isTruthy()) l else evalSingle(expr.right, env, varargs)
            }

            val l = evalSingle(expr.left, env, varargs)
            val r = evalSingle(expr.right, env, varargs)

            return when (expr.op) {
                ".." -> LuaVal.Str(l.asDisplayString() + r.asDisplayString())
                "==" -> LuaVal.Bool(l == r)
                "~=" -> LuaVal.Bool(l != r)
                "<", "<=", ">", ">=" -> compareValues(expr.op, l, r)
                "+", "-", "*", "/", "//", "%", "^" -> arithmetic(expr.op, l, r)
                else -> LuaVal.Nil
            }
        }

        private fun compareValues(op: String, l: LuaVal, r: LuaVal): LuaVal {
            val cmp = when {
                l is LuaVal.Num && r is LuaVal.Num -> l.value.compareTo(r.value)
                l is LuaVal.Str && r is LuaVal.Str -> l.value.compareTo(r.value)
                else -> throw LuaRuntimeException("Нельзя сравнить '${l.typeName()}' и '${r.typeName()}'")
            }
            val res = when (op) {
                "<" -> cmp < 0
                "<=" -> cmp <= 0
                ">" -> cmp > 0
                ">=" -> cmp >= 0
                else -> false
            }
            return LuaVal.Bool(res)
        }

        private fun arithmetic(op: String, l: LuaVal, r: LuaVal): LuaVal {
            val a = l.asDoubleOrNull() ?: throw LuaRuntimeException("Арифметика ожидает число, получено '${l.typeName()}'")
            val b = r.asDoubleOrNull() ?: throw LuaRuntimeException("Арифметика ожидает число, получено '${r.typeName()}'")
            val res = when (op) {
                "+" -> a + b
                "-" -> a - b
                "*" -> a * b
                "/" -> a / b
                "//" -> floor(a / b)
                "%" -> a - floor(a / b) * b
                "^" -> a.pow(b)
                else -> 0.0
            }
            return LuaVal.Num(res)
        }

        private fun installStdLib() {
            fun fn(name: String, block: (LuaVm, List<LuaVal>) -> List<LuaVal>) = LuaVal.NativeFn(name, block)

            globals.defineLocal("print", fn("print") { vm, args ->
                vm.addLog(args.joinToString("\t") { it.asDisplayString() })
                emptyList()
            })

            globals.defineLocal("tostring", fn("tostring") { _, args ->
                listOf(LuaVal.Str(args.firstOrNull()?.asDisplayString() ?: "nil"))
            })

            globals.defineLocal("tonumber", fn("tonumber") { _, args ->
                val v = args.firstOrNull() ?: LuaVal.Nil
                val base = args.getOrNull(1)?.asDoubleOrNull()?.toInt()
                val num = if (base != null && v is LuaVal.Str) {
                    v.value.trim().toLongOrNull(base)?.toDouble()
                } else {
                    v.asDoubleOrNull()
                }
                listOf(num?.let { LuaVal.Num(it) } ?: LuaVal.Nil)
            })

            globals.defineLocal("type", fn("type") { _, args ->
                listOf(LuaVal.Str(args.firstOrNull()?.typeName() ?: "nil"))
            })

            globals.defineLocal("error", fn("error") { _, args ->
                throw LuaRuntimeException(args.firstOrNull()?.asDisplayString() ?: "Ошибка скрипта")
            })

            globals.defineLocal("pcall", fn("pcall") { vm, args ->
                val target = args.firstOrNull() ?: return@fn listOf(LuaVal.Bool(false), LuaVal.Str("Нет функции"))
                val rest = if (args.size > 1) args.subList(1, args.size) else emptyList()
                try {
                    listOf(LuaVal.Bool(true)) + vm.callValue(target, rest)
                } catch (e: LuaRuntimeException) {
                    listOf(LuaVal.Bool(false), LuaVal.Str(e.message ?: "Ошибка"))
                }
            })

            globals.defineLocal("select", fn("select") { _, args ->
                val selector = args.firstOrNull() ?: LuaVal.Nil
                val rest = if (args.size > 1) args.subList(1, args.size) else emptyList()
                if (selector is LuaVal.Str && selector.value == "#") {
                    listOf(LuaVal.Num(rest.size.toDouble()))
                } else {
                    val idx = (selector.asDoubleOrNull()?.toInt() ?: 1).coerceAtLeast(1)
                    if (idx <= rest.size) rest.subList(idx - 1, rest.size) else emptyList()
                }
            })

            globals.defineLocal("ipairs", fn("ipairs") { _, args ->
                val tbl = args.firstOrNull() as? LuaVal.Table
                    ?: throw LuaRuntimeException("ipairs ожидает таблицу")
                val iter = fn("ipairs_iter") { _, iArgs ->
                    val t = iArgs.getOrNull(0) as? LuaVal.Table ?: return@fn listOf(LuaVal.Nil)
                    val nextIdx = (iArgs.getOrNull(1)?.asDoubleOrNull()?.toInt() ?: 0) + 1
                    val v = t.getIndex(nextIdx)
                    if (v is LuaVal.Nil) listOf(LuaVal.Nil) else listOf(LuaVal.Num(nextIdx.toDouble()), v)
                }
                listOf(iter, tbl, LuaVal.Num(0.0))
            })

            globals.defineLocal("pairs", fn("pairs") { _, args ->
                val tbl = args.firstOrNull() as? LuaVal.Table
                    ?: throw LuaRuntimeException("pairs ожидает таблицу")
                val keysSnapshot = tbl.entries.keys.toList()
                var cursor = 0
                val iter = fn("pairs_iter") { _, _ ->
                    while (cursor < keysSnapshot.size) {
                        val k = keysSnapshot[cursor++]
                        val v = tbl.get(k)
                        if (v !is LuaVal.Nil) return@fn listOf(k, v)
                    }
                    listOf(LuaVal.Nil)
                }
                listOf(iter, tbl, LuaVal.Nil)
            })

            // string library
            val strLib = LuaVal.Table().apply {
                setField("len", fn("string.len") { _, args ->
                    val s = args.firstOrNull()?.asDisplayString() ?: ""
                    listOf(LuaVal.Num(s.length.toDouble()))
                })
                setField("upper", fn("string.upper") { _, args ->
                    val s = args.firstOrNull()?.asDisplayString() ?: ""
                    listOf(LuaVal.Str(s.uppercase(Locale.getDefault())))
                })
                setField("lower", fn("string.lower") { _, args ->
                    val s = args.firstOrNull()?.asDisplayString() ?: ""
                    listOf(LuaVal.Str(s.lowercase(Locale.getDefault())))
                })
                setField("reverse", fn("string.reverse") { _, args ->
                    val s = args.firstOrNull()?.asDisplayString() ?: ""
                    listOf(LuaVal.Str(s.reversed()))
                })
                setField("rep", fn("string.rep") { _, args ->
                    val s = args.firstOrNull()?.asDisplayString() ?: ""
                    val count = (args.getOrNull(1)?.asDoubleOrNull()?.toInt() ?: 0).coerceIn(0, 1000)
                    val sep = args.getOrNull(2)?.takeUnless { it is LuaVal.Nil }?.asDisplayString() ?: ""
                    val joined = if (count == 0) "" else List(count) { s }.joinToString(sep)
                    listOf(LuaVal.Str(joined))
                })
                setField("sub", fn("string.sub") { _, args ->
                    val s = args.firstOrNull()?.asDisplayString() ?: ""
                    val n = s.length
                    var i = args.getOrNull(1)?.asDoubleOrNull()?.toInt() ?: 1
                    var j = args.getOrNull(2)?.asDoubleOrNull()?.toInt() ?: n
                    if (i < 0) i += n + 1
                    if (j < 0) j += n + 1
                    i = i.coerceAtLeast(1)
                    j = j.coerceAtMost(n)
                    val res = if (i > j || n == 0) "" else s.substring(i - 1, j)
                    listOf(LuaVal.Str(res))
                })
                setField("find", fn("string.find") { _, args ->
                    val s = args.firstOrNull()?.asDisplayString() ?: ""
                    val pat = args.getOrNull(1)?.asDisplayString() ?: return@fn listOf(LuaVal.Nil)
                    val init = ((args.getOrNull(2)?.asDoubleOrNull()?.toInt() ?: 1) - 1).coerceAtLeast(0)
                    val plain = args.getOrNull(3)?.isTruthy() == true
                    if (plain || pat.none { it in ".%+*?[]^$()" }) {
                        val idx = s.indexOf(pat, startIndex = init)
                        if (idx < 0) listOf(LuaVal.Nil)
                        else listOf(LuaVal.Num((idx + 1).toDouble()), LuaVal.Num((idx + pat.length).toDouble()))
                    } else {
                        val regex = luaPatternToRegex(pat)
                        val match = regex.find(s, startIndex = init) ?: return@fn listOf(LuaVal.Nil)
                        listOf(LuaVal.Num((match.range.first + 1).toDouble()), LuaVal.Num((match.range.last + 1).toDouble()))
                    }
                })
                setField("match", fn("string.match") { _, args ->
                    val s = args.firstOrNull()?.asDisplayString() ?: ""
                    val pat = args.getOrNull(1)?.asDisplayString() ?: return@fn listOf(LuaVal.Nil)
                    val init = ((args.getOrNull(2)?.asDoubleOrNull()?.toInt() ?: 1) - 1).coerceAtLeast(0)
                    val regex = luaPatternToRegex(pat)
                    val m = regex.find(s, startIndex = init) ?: return@fn listOf(LuaVal.Nil)
                    if (m.groupValues.size > 1) {
                        m.groupValues.drop(1).map { LuaVal.Str(it) }
                    } else {
                        listOf(LuaVal.Str(m.value))
                    }
                })
                setField("gsub", fn("string.gsub") { _, args ->
                    val s = args.firstOrNull()?.asDisplayString() ?: ""
                    val pat = args.getOrNull(1)?.asDisplayString() ?: return@fn listOf(LuaVal.Str(s), LuaVal.Num(0.0))
                    val repl = args.getOrNull(2) ?: LuaVal.Str("")
                    val limit = args.getOrNull(3)?.asDoubleOrNull()?.toInt()
                    val regex = luaPatternToRegex(pat)
                    var count = 0
                    val replaced = regex.replace(s) { m ->
                        if (limit != null && count >= limit) return@replace m.value
                        count++
                        when (repl) {
                            is LuaVal.Str -> repl.value
                            is LuaVal.NativeFn, is LuaVal.Closure -> {
                                val capArgs = if (m.groupValues.size > 1) m.groupValues.drop(1).map { LuaVal.Str(it) }
                                else listOf(LuaVal.Str(m.value))
                                callValue(repl, capArgs).firstOrNull()?.takeUnless { it is LuaVal.Nil }?.asDisplayString() ?: m.value
                            }
                            is LuaVal.Table -> repl.get(LuaVal.Str(m.value)).takeUnless { it is LuaVal.Nil }?.asDisplayString() ?: m.value
                            else -> repl.asDisplayString()
                        }
                    }
                    listOf(LuaVal.Str(replaced), LuaVal.Num(count.toDouble()))
                })
                setField("format", fn("string.format") { _, args ->
                    val fmt = args.firstOrNull()?.asDisplayString() ?: ""
                    val params: Array<Any> = args.drop(1).map<LuaVal, Any> { arg ->
                        when (arg) {
                            is LuaVal.Num -> if (arg.value % 1.0 == 0.0) arg.value.toLong() else arg.value
                            is LuaVal.Bool -> arg.value
                            is LuaVal.Str -> arg.value
                            else -> arg.asDisplayString()
                        }
                    }.toTypedArray()
                    val formatted = runCatching { String.format(Locale.US, fmt, *params) }.getOrElse { fmt }
                    listOf(LuaVal.Str(formatted))
                })
            }
            globals.defineLocal("string", strLib)

            // math library
            val mathLib = LuaVal.Table().apply {
                setField("pi", LuaVal.Num(Math.PI))
                setField("huge", LuaVal.Num(Double.POSITIVE_INFINITY))
                setField("abs", fn("math.abs") { _, args -> LuaVal.Num(abs(args.first().asDoubleOrNull() ?: 0.0)).let(::listOf) })
                setField("floor", fn("math.floor") { _, args -> LuaVal.Num(floor(args.first().asDoubleOrNull() ?: 0.0)).let(::listOf) })
                setField("ceil", fn("math.ceil") { _, args -> LuaVal.Num(ceil(args.first().asDoubleOrNull() ?: 0.0)).let(::listOf) })
                setField("round", fn("math.round") { _, args -> LuaVal.Num(round(args.first().asDoubleOrNull() ?: 0.0)).let(::listOf) })
                setField("sqrt", fn("math.sqrt") { _, args -> LuaVal.Num(sqrt(args.first().asDoubleOrNull() ?: 0.0)).let(::listOf) })
                setField("pow", fn("math.pow") { _, args ->
                    val a = args.getOrNull(0)?.asDoubleOrNull() ?: 0.0
                    val b = args.getOrNull(1)?.asDoubleOrNull() ?: 1.0
                    listOf(LuaVal.Num(a.pow(b)))
                })
                setField("sin", fn("math.sin") { _, args -> listOf(LuaVal.Num(sin(args.first().asDoubleOrNull() ?: 0.0))) })
                setField("cos", fn("math.cos") { _, args -> listOf(LuaVal.Num(cos(args.first().asDoubleOrNull() ?: 0.0))) })
                setField("tan", fn("math.tan") { _, args -> listOf(LuaVal.Num(tan(args.first().asDoubleOrNull() ?: 0.0))) })
                setField("log", fn("math.log") { _, args -> listOf(LuaVal.Num(ln(args.first().asDoubleOrNull() ?: 1.0))) })
                setField("exp", fn("math.exp") { _, args -> listOf(LuaVal.Num(exp(args.first().asDoubleOrNull() ?: 0.0))) })
                setField("min", fn("math.min") { _, args ->
                    val nums = args.mapNotNull { it.asDoubleOrNull() }
                    listOf(LuaVal.Num(nums.minOrNull() ?: 0.0))
                })
                setField("max", fn("math.max") { _, args ->
                    val nums = args.mapNotNull { it.asDoubleOrNull() }
                    listOf(LuaVal.Num(nums.maxOrNull() ?: 0.0))
                })
                setField("random", fn("math.random") { _, args ->
                    when (args.size) {
                        0 -> listOf(LuaVal.Num(Random.nextDouble()))
                        1 -> {
                            val u = (args[0].asDoubleOrNull()?.toInt() ?: 1).coerceAtLeast(1)
                            listOf(LuaVal.Num(Random.nextInt(1, u + 1).toDouble()))
                        }
                        else -> {
                            val l = args[0].asDoubleOrNull()?.toInt() ?: 1
                            val u = (args[1].asDoubleOrNull()?.toInt() ?: l).coerceAtLeast(l)
                            listOf(LuaVal.Num(Random.nextInt(l, u + 1).toDouble()))
                        }
                    }
                })
            }
            globals.defineLocal("math", mathLib)

            // table library
            val tableLib = LuaVal.Table().apply {
                setField("insert", fn("table.insert") { _, args ->
                    val tbl = args.firstOrNull() as? LuaVal.Table ?: return@fn emptyList()
                    val len = tbl.arrayLength()
                    if (args.size == 2) {
                        tbl.setIndex(len + 1, args[1])
                    } else if (args.size >= 3) {
                        val posIdx = (args[1].asDoubleOrNull()?.toInt() ?: (len + 1)).coerceIn(1, len + 1)
                        for (i in len downTo posIdx) {
                            tbl.setIndex(i + 1, tbl.getIndex(i))
                        }
                        tbl.setIndex(posIdx, args[2])
                    }
                    emptyList()
                })
                setField("remove", fn("table.remove") { _, args ->
                    val tbl = args.firstOrNull() as? LuaVal.Table ?: return@fn listOf(LuaVal.Nil)
                    val len = tbl.arrayLength()
                    if (len == 0) return@fn listOf(LuaVal.Nil)
                    val posIdx = (args.getOrNull(1)?.asDoubleOrNull()?.toInt() ?: len).coerceIn(1, len)
                    val removed = tbl.getIndex(posIdx)
                    for (i in posIdx until len) {
                        tbl.setIndex(i, tbl.getIndex(i + 1))
                    }
                    tbl.setIndex(len, LuaVal.Nil)
                    listOf(removed)
                })
                setField("concat", fn("table.concat") { _, args ->
                    val tbl = args.firstOrNull() as? LuaVal.Table ?: return@fn listOf(LuaVal.Str(""))
                    val sep = args.getOrNull(1)?.takeUnless { it is LuaVal.Nil }?.asDisplayString() ?: ""
                    val i = (args.getOrNull(2)?.asDoubleOrNull()?.toInt() ?: 1).coerceAtLeast(1)
                    val j = args.getOrNull(3)?.asDoubleOrNull()?.toInt() ?: tbl.arrayLength()
                    if (i > j) return@fn listOf(LuaVal.Str(""))
                    val items = (i..j).map { tbl.getIndex(it).asDisplayString() }
                    listOf(LuaVal.Str(items.joinToString(sep)))
                })
                setField("unpack", fn("table.unpack") { _, args ->
                    val tbl = args.firstOrNull() as? LuaVal.Table ?: return@fn emptyList()
                    tbl.arrayItems()
                })
                setField("sort", fn("table.sort") { vm, args ->
                    val tbl = args.firstOrNull() as? LuaVal.Table ?: return@fn emptyList()
                    val comp = args.getOrNull(1)?.takeUnless { it is LuaVal.Nil }
                    val items = tbl.arrayItems().toMutableList()
                    items.sortWith { a, b ->
                        if (comp != null) {
                            val aBeforeB = vm.callValue(comp, listOf(a, b)).firstOrNull()?.isTruthy() == true
                            if (aBeforeB) -1 else 1
                        } else {
                            val da = a.asDoubleOrNull()
                            val db = b.asDoubleOrNull()
                            if (da != null && db != null) da.compareTo(db)
                            else a.asDisplayString().compareTo(b.asDisplayString())
                        }
                    }
                    items.forEachIndexed { idx, value -> tbl.setIndex(idx + 1, value) }
                    emptyList()
                })
            }
            globals.defineLocal("table", tableLib)

            // os library (safe subset: time, date)
            val osLib = LuaVal.Table().apply {
                setField("time", fn("os.time") { _, _ ->
                    listOf(LuaVal.Num((System.currentTimeMillis() / 1000L).toDouble()))
                })
                setField("date", fn("os.date") { _, args ->
                    val fmt = args.getOrNull(0)?.takeUnless { it is LuaVal.Nil }?.asDisplayString() ?: "%Y-%m-%d %H:%M:%S"
                    val sec = args.getOrNull(1)?.asDoubleOrNull()?.toLong() ?: (System.currentTimeMillis() / 1000L)
                    val javaFmt = fmt
                        .replace("%Y", "yyyy")
                        .replace("%m", "MM")
                        .replace("%d", "dd")
                        .replace("%H", "HH")
                        .replace("%M", "mm")
                        .replace("%S", "ss")
                    val formatted = runCatching {
                        SimpleDateFormat(javaFmt, Locale.getDefault()).format(Date(sec * 1000L))
                    }.getOrElse { "" }
                    listOf(LuaVal.Str(formatted))
                })
            }
            globals.defineLocal("os", osLib)

            // SpoX Messenger Sandbox API
            val spoxLib = LuaVal.Table().apply {
                setField("log", fn("spox.log") { vm, args ->
                    vm.addLog(args.joinToString(" ") { it.asDisplayString() })
                    emptyList()
                })
                setField("notify", fn("spox.notify") { vm, args ->
                    val msg = args.firstOrNull()?.asDisplayString()?.trim().orEmpty()
                    if (msg.isNotEmpty()) vm.notices.add(msg)
                    emptyList()
                })
                setField("send", fn("spox.send") { vm, args ->
                    val msg = args.firstOrNull()?.asDisplayString()?.trim().orEmpty()
                    if (msg.isNotEmpty()) vm.queuedMessages.add(msg)
                    emptyList()
                })
                setField("app_version", fn("spox.app_version") { _, _ ->
                    listOf(LuaVal.Str(com.example.BuildConfig.VERSION_NAME))
                })
                setField("now_ms", fn("spox.now_ms") { _, _ ->
                    listOf(LuaVal.Num(System.currentTimeMillis().toDouble()))
                })
                setField("format_time", fn("spox.format_time") { _, args ->
                    val ms = args.firstOrNull()?.asDoubleOrNull()?.toLong() ?: System.currentTimeMillis()
                    val formatted = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(ms))
                    listOf(LuaVal.Str(formatted))
                })
                setField("upper", fn("spox.upper") { _, args ->
                    listOf(LuaVal.Str(args.firstOrNull()?.asDisplayString()?.uppercase(Locale.getDefault()) ?: ""))
                })
                setField("lower", fn("spox.lower") { _, args ->
                    listOf(LuaVal.Str(args.firstOrNull()?.asDisplayString()?.lowercase(Locale.getDefault()) ?: ""))
                })
                setField("trim", fn("spox.trim") { _, args ->
                    listOf(LuaVal.Str(args.firstOrNull()?.asDisplayString()?.trim() ?: ""))
                })
                setField("replace", fn("spox.replace") { _, args ->
                    val s = args.getOrNull(0)?.asDisplayString() ?: ""
                    val old = args.getOrNull(1)?.asDisplayString() ?: ""
                    val newVal = args.getOrNull(2)?.asDisplayString() ?: ""
                    listOf(LuaVal.Str(if (old.isEmpty()) s else s.replace(old, newVal)))
                })
                setField("contains", fn("spox.contains") { _, args ->
                    val s = args.getOrNull(0)?.asDisplayString() ?: ""
                    val sub = args.getOrNull(1)?.asDisplayString() ?: ""
                    listOf(LuaVal.Bool(s.contains(sub, ignoreCase = false)))
                })
                setField("starts_with", fn("spox.starts_with") { _, args ->
                    val s = args.getOrNull(0)?.asDisplayString() ?: ""
                    val prefix = args.getOrNull(1)?.asDisplayString() ?: ""
                    listOf(LuaVal.Bool(s.startsWith(prefix)))
                })
                setField("split", fn("spox.split") { _, args ->
                    val s = args.getOrNull(0)?.asDisplayString() ?: ""
                    val sep = args.getOrNull(1)?.asDisplayString() ?: " "
                    val tbl = LuaVal.Table()
                    val parts = if (sep.isEmpty()) s.map { it.toString() } else s.split(sep)
                    parts.forEachIndexed { idx, part -> tbl.setIndex(idx + 1, LuaVal.Str(part)) }
                    listOf(tbl)
                })
                setField("sha256_short", fn("spox.sha256_short") { _, args ->
                    val input = args.firstOrNull()?.asDisplayString() ?: ""
                    val digest = MessageDigest.getInstance("SHA-256").digest(input.toByteArray(Charsets.UTF_8))
                    val hex = digest.take(6).joinToString("") { "%02x".format(it) }
                    listOf(LuaVal.Str(hex))
                })
            }
            globals.defineLocal("spox", spoxLib)
        }

        private fun luaPatternToRegex(pattern: String): Regex {
            val sb = StringBuilder()
            var i = 0
            while (i < pattern.length) {
                val c = pattern[i]
                if (c == '%' && i + 1 < pattern.length) {
                    when (val next = pattern[i + 1]) {
                        's' -> sb.append("\\s")
                        'S' -> sb.append("\\S")
                        'd' -> sb.append("\\d")
                        'D' -> sb.append("\\D")
                        'w' -> sb.append("[\\p{L}\\p{N}_]")
                        'W' -> sb.append("[^\\p{L}\\p{N}_]")
                        'a' -> sb.append("\\p{L}")
                        'A' -> sb.append("[^\\p{L}]")
                        'p' -> sb.append("\\p{Punct}")
                        '.', '+', '*', '?', '[', ']', '(', ')', '^', '$', '%' -> {
                            sb.append('\\').append(next)
                        }
                        else -> sb.append(Regex.escape(next.toString()))
                    }
                    i += 2
                } else {
                    sb.append(c)
                    i++
                }
            }
            return runCatching { Regex(sb.toString()) }.getOrElse { Regex(Regex.escape(pattern)) }
        }
    }

    fun extractMetadata(sourceCode: String, fallbackId: String? = null): Result<SpoXPluginMetadata> {
        return runCatching {
            val vm = LuaVm(maxSteps = DEFAULT_MAX_STEPS)
            vm.execChunk(sourceCode)

            val headerMap = HashMap<String, String>()
            sourceCode.lineSequence().forEach { rawLine ->
                val line = rawLine.trim()
                if (line.startsWith("--")) {
                    val body = line.removePrefix("--").trim()
                    if (body.startsWith("@")) {
                        val key = body.substring(1).substringBefore(' ').substringBefore(':').trim().lowercase()
                        val value = body.substringAfter(' ', "").removePrefix(":").trim()
                        if (key.isNotBlank() && value.isNotBlank()) {
                            headerMap[key] = value
                        }
                    }
                }
            }

            val pluginTable = vm.globals.get("plugin") as? LuaVal.Table
            fun tableStr(field: String): String? =
                pluginTable?.getField(field)?.takeUnless { it is LuaVal.Nil }?.asDisplayString()?.trim()?.ifBlank { null }

            val rawId = tableStr("id")
                ?: headerMap["id"]
                ?: fallbackId
                ?: "custom_${shaShort(sourceCode)}"
            val cleanId = rawId.lowercase().replace(Regex("[^a-z0-9_\\-]"), "_").ifBlank { "custom_${shaShort(sourceCode)}" }
            val name = tableStr("name") ?: headerMap["name"] ?: "Пользовательский плагин"
            val version = tableStr("version") ?: headerMap["version"] ?: "1.0"
            val author = tableStr("author") ?: headerMap["author"] ?: "Пользователь"
            val description = tableStr("description") ?: headerMap["description"] ?: "Скрипт на SpoX Lua"

            val tableCommands = (pluginTable?.getField("commands") as? LuaVal.Table)
                ?.arrayItems()
                ?.mapNotNull { it.takeUnless { v -> v is LuaVal.Nil }?.asDisplayString()?.trim()?.ifBlank { null } }
                .orEmpty()
            val headerCommands = headerMap["commands"]
                ?.split(',', ' ')
                ?.map { it.trim() }
                ?.filter { it.isNotBlank() }
                .orEmpty()
            val commands = (tableCommands + headerCommands)
                .map { if (it.startsWith("/")) it else "/$it" }
                .distinct()

            SpoXPluginMetadata(
                id = cleanId,
                name = name,
                version = version,
                author = author,
                description = description,
                commands = commands
            )
        }
    }

    fun executeCommand(
        sourceCode: String,
        command: String,
        argsText: String,
        rawText: String,
        ctx: PluginHookContext
    ): Result<Pair<PluginCommandOutcome, List<String>>> {
        return runCatching {
            val vm = LuaVm(maxSteps = DEFAULT_MAX_STEPS)
            vm.execChunk(sourceCode)
            val ctxTable = buildContextTable(ctx).apply {
                setField("command", LuaVal.Str(command))
                setField("args", LuaVal.Str(argsText))
                setField("text", LuaVal.Str(rawText))
            }
            val ret = vm.callHook("on_command", ctxTable)
            val first = ret.firstOrNull() ?: LuaVal.Nil

            val outcome = when {
                first is LuaVal.Table -> {
                    val action = first.getField("action").takeUnless { it is LuaVal.Nil }?.asDisplayString()?.lowercase()
                    val textVal = first.getField("text").takeUnless { it is LuaVal.Nil }?.asDisplayString()?.trim().orEmpty()
                    val notice = first.getField("notice").takeUnless { it is LuaVal.Nil }?.asDisplayString()?.trim()
                    when (action) {
                        "local", "notify" -> PluginCommandOutcome.HandledLocal(textVal.ifEmpty { notice.orEmpty() })
                        "send" -> if (textVal.isNotEmpty()) PluginCommandOutcome.HandledSend(textVal, notice) else PluginCommandOutcome.NotHandled
                        else -> if (textVal.isNotEmpty()) PluginCommandOutcome.HandledSend(textVal, notice) else PluginCommandOutcome.NotHandled
                    }
                }
                first is LuaVal.Str && first.value.trim().isNotEmpty() -> {
                    PluginCommandOutcome.HandledSend(first.value.trim(), vm.notices.firstOrNull())
                }
                vm.queuedMessages.isNotEmpty() -> {
                    PluginCommandOutcome.HandledSend(vm.queuedMessages.joinToString("\n"), vm.notices.firstOrNull())
                }
                vm.notices.isNotEmpty() -> {
                    PluginCommandOutcome.HandledLocal(vm.notices.joinToString("\n"))
                }
                else -> PluginCommandOutcome.NotHandled
            }
            outcome to vm.logs.toList()
        }
    }

    fun executeOnSendMessage(
        sourceCode: String,
        text: String,
        ctx: PluginHookContext
    ): Result<OutgoingTransformResult> {
        return runCatching {
            val vm = LuaVm(maxSteps = DEFAULT_MAX_STEPS)
            vm.execChunk(sourceCode)
            val ctxTable = buildContextTable(ctx).apply {
                setField("text", LuaVal.Str(text))
            }
            val ret = vm.callHook("on_send_message", ctxTable)
            val first = ret.firstOrNull() ?: LuaVal.Nil

            when (first) {
                is LuaVal.Table -> {
                    val cancelled = first.getField("cancel").isTruthy()
                    if (cancelled) {
                        val reason = first.getField("reason")
                            .takeUnless { it is LuaVal.Nil }
                            ?.asDisplayString()
                            ?.ifBlank { null }
                            ?: "Отправка отменена плагином"
                        OutgoingTransformResult.Cancelled(reason)
                    } else {
                        val nextText = first.getField("text")
                            .takeUnless { it is LuaVal.Nil }
                            ?.asDisplayString()
                            ?: text
                        OutgoingTransformResult.Proceed(nextText, vm.notices.toList())
                    }
                }
                is LuaVal.Str -> OutgoingTransformResult.Proceed(first.value, vm.notices.toList())
                else -> {
                    val finalText = if (vm.queuedMessages.isNotEmpty()) vm.queuedMessages.last() else text
                    OutgoingTransformResult.Proceed(finalText, vm.notices.toList())
                }
            }
        }
    }

    fun executeOnRenderMessage(
        sourceCode: String,
        text: String,
        ctx: PluginHookContext
    ): Result<String> {
        return runCatching {
            val vm = LuaVm(maxSteps = DEFAULT_MAX_STEPS)
            vm.execChunk(sourceCode)
            val ctxTable = buildContextTable(ctx).apply {
                setField("text", LuaVal.Str(text))
            }
            val ret = vm.callHook("on_render_message", ctxTable)
            val first = ret.firstOrNull() ?: LuaVal.Nil
            when (first) {
                is LuaVal.Str -> first.value
                is LuaVal.Table -> first.getField("text").takeUnless { it is LuaVal.Nil }?.asDisplayString() ?: text
                else -> text
            }
        }
    }

    fun runSandboxTest(sourceCode: String, sampleInput: String): PluginTestRunResult {
        val metaRes = extractMetadata(sourceCode)
        if (metaRes.isFailure) {
            return PluginTestRunResult(
                success = false,
                errorMessage = metaRes.exceptionOrNull()?.message ?: "Ошибка синтаксиса Lua"
            )
        }
        val metadata = metaRes.getOrThrow()
        val ctx = PluginHookContext(
            chatId = "sandbox_room",
            chatTitle = "Тестовый чат",
            isGroup = false,
            senderName = "Вы",
            memberCount = 2
        )
        val trimmed = sampleInput.trim()
        val allLogs = ArrayList<String>()

        val cmdOutcome = if (trimmed.startsWith("/")) {
            val parts = trimmed.split(Regex("\\s+"), limit = 2)
            val cmd = parts[0].lowercase()
            val args = parts.getOrElse(1) { "" }
            val res = executeCommand(sourceCode, cmd, args, trimmed, ctx)
            if (res.isFailure) {
                return PluginTestRunResult(
                    success = false,
                    metadata = metadata,
                    errorMessage = res.exceptionOrNull()?.message ?: "Ошибка выполнения on_command"
                )
            }
            val (outcome, logs) = res.getOrThrow()
            allLogs.addAll(logs)
            outcome
        } else {
            PluginCommandOutcome.NotHandled
        }

        val sendRes = executeOnSendMessage(sourceCode, sampleInput, ctx)
        if (sendRes.isFailure) {
            return PluginTestRunResult(
                success = false,
                metadata = metadata,
                commandOutcome = cmdOutcome,
                logs = allLogs,
                errorMessage = sendRes.exceptionOrNull()?.message ?: "Ошибка выполнения on_send_message"
            )
        }
        val sendText = when (val s = sendRes.getOrThrow()) {
            is OutgoingTransformResult.Proceed -> s.text
            is OutgoingTransformResult.Cancelled -> "[ОТМЕНЕНО]: ${s.reason}"
        }

        val renderRes = executeOnRenderMessage(sourceCode, sampleInput, ctx)
        if (renderRes.isFailure) {
            return PluginTestRunResult(
                success = false,
                metadata = metadata,
                commandOutcome = cmdOutcome,
                transformedSendText = sendText,
                logs = allLogs,
                errorMessage = renderRes.exceptionOrNull()?.message ?: "Ошибка выполнения on_render_message"
            )
        }

        return PluginTestRunResult(
            success = true,
            metadata = metadata,
            commandOutcome = cmdOutcome,
            transformedSendText = sendText,
            renderedDisplayText = renderRes.getOrThrow(),
            logs = allLogs
        )
    }

    private fun buildContextTable(ctx: PluginHookContext): LuaVal.Table {
        return LuaVal.Table().apply {
            setField("chat_id", LuaVal.Str(ctx.chatId))
            setField("chat_title", LuaVal.Str(ctx.chatTitle))
            setField("is_group", LuaVal.Bool(ctx.isGroup))
            setField("sender_name", LuaVal.Str(ctx.senderName))
            setField("member_count", LuaVal.Num(ctx.memberCount.toDouble()))
            setField("reply_to_text", LuaVal.Str(ctx.replyToText))
        }
    }

    private fun shaShort(text: String): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(text.toByteArray(Charsets.UTF_8))
        return digest.take(4).joinToString("") { "%02x".format(it) }
    }
}
