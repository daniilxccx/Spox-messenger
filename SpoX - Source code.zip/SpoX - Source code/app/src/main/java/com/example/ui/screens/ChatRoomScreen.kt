package com.example.ui.screens

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.pm.PackageManager
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Reply
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.GroupAdd
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.VideoFile
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.util.VelocityTracker
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.Conversation
import com.example.data.model.DecryptedContent
import com.example.data.model.DecryptedMessageItem
import androidx.compose.runtime.mutableLongStateOf
import com.example.data.model.ModerationStatus
import com.example.data.model.OutgoingBubbleStyle
import com.example.data.model.PublicUserProfile
import com.example.data.model.UserPresenceStatus
import com.example.data.model.UserRole
import com.example.media.FileAttachmentHelper
import com.example.media.LocalSpoxAudioPlayer
import com.example.media.MediaKind
import com.example.media.SpoxAudioTrack
import com.example.media.SpoxVideoRequest
import com.example.media.VoicePlayerManager
import com.example.media.VoiceRecorderManager
import com.example.ui.components.BitmapMemoryCache
import com.example.ui.components.ChatWallpaperBackground
import com.example.ui.components.CipherLoadingStateView
import com.example.ui.components.ForwardTargetSheet
import com.example.ui.components.ForwardedHeaderLabel
import com.example.ui.components.MediaDownloadBadge
import com.example.ui.components.MediaUploadBanner
import com.example.ui.components.MessageActionsSheet
import com.example.ui.components.MessageQuoteBlock
import com.example.ui.components.ModerationStatusChip
import com.example.ui.components.ReadReceiptIcon
import com.example.ui.components.ReplyComposerPreviewBar
import com.example.ui.components.RoleBadge
import com.example.ui.components.SavedMessagesAvatar
import com.example.ui.components.UserAvatar
import com.example.ui.components.UserPresenceIndicator
import com.example.ui.components.VoiceWaveformRow
import com.example.ui.components.formatDurationMillis
import com.example.ui.components.formatMuteRemaining
import com.example.ui.components.mediaKindIcon
import com.example.ui.components.resolveOutgoingBubblePalette
import com.example.ui.media.SpoxAudioPlayerSheet
import com.example.ui.media.SpoxVideoPlayerDialog
import com.example.ui.theme.LocalChatAppearance
import com.example.ui.viewmodel.ChatRoomUiData
import com.example.ui.viewmodel.ChatRoomViewModel
import com.example.ui.viewmodel.UiState
import com.google.firebase.Timestamp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatRoomScreen(
    viewModel: ChatRoomViewModel,
    currentUserId: String,
    openGroupSettingsInitially: Boolean = false,
    onBack: () -> Unit,
    onOpenCall: (String) -> Unit,
    onOpenChat: (String) -> Unit = {}
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val appearance = LocalChatAppearance.current

    val roomState by viewModel.roomState.collectAsStateWithLifecycle()
    val directoryUsers by viewModel.directoryUsers.collectAsStateWithLifecycle()
    val userConversations by viewModel.userConversations.collectAsStateWithLifecycle()
    val statusBanner by viewModel.statusBanner.collectAsStateWithLifecycle()
    val isSending by viewModel.isSending.collectAsStateWithLifecycle()
    val isForwarding by viewModel.isForwarding.collectAsStateWithLifecycle()
    val isGroupActionBusy by viewModel.isGroupActionBusy.collectAsStateWithLifecycle()
    val isChatClosedOrRemoved by viewModel.isChatClosedOrRemoved.collectAsStateWithLifecycle()
    val memberSearchResults by viewModel.memberSearchResults.collectAsStateWithLifecycle()
    val isSearchingMembers by viewModel.isSearchingMembers.collectAsStateWithLifecycle()
    val replyingTo by viewModel.replyingTo.collectAsStateWithLifecycle()
    val activeUpload by viewModel.activeUpload.collectAsStateWithLifecycle()
    val downloadProgress by viewModel.downloadProgress.collectAsStateWithLifecycle()
    val completedDownloads by viewModel.completedDownloads.collectAsStateWithLifecycle()

    val voiceRecorder = remember(context) { VoiceRecorderManager(context) }
    val voicePlayer = remember(context) { VoicePlayerManager(context) }
    val audioPlayer = LocalSpoxAudioPlayer.current
    val audioUiState = audioPlayer?.uiState?.collectAsStateWithLifecycle()?.value
    val isRecording by voiceRecorder.isRecording.collectAsStateWithLifecycle()
    val recordElapsedMs by voiceRecorder.elapsedMs.collectAsStateWithLifecycle()
    val liveBars by voiceRecorder.liveBars.collectAsStateWithLifecycle()
    val playbackState by voicePlayer.playbackState.collectAsStateWithLifecycle()

    DisposableEffect(Unit) {
        onDispose {
            voiceRecorder.cancelRecording()
            voicePlayer.stop()
        }
    }

    LaunchedEffect(isChatClosedOrRemoved) {
        if (isChatClosedOrRemoved) {
            voicePlayer.stop()
            onBack()
        }
    }

    val snackbarHostState = remember { SnackbarHostState() }
    LaunchedEffect(statusBanner) {
        statusBanner?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearBanner()
        }
    }

    var textDraft by remember { mutableStateOf("") }
    var showAttachSheet by remember { mutableStateOf(false) }
    var showSecuritySheet by remember { mutableStateOf(false) }
    var showPeerProfileSheet by remember { mutableStateOf(false) }
    var inspectedMemberProfile by remember { mutableStateOf<PublicUserProfile?>(null) }
    var showGroupInfoSheet by remember(openGroupSettingsInitially) { mutableStateOf(openGroupSettingsInitially) }
    var openAddMembersInGroupSheet by remember { mutableStateOf(false) }
    var showDmAddParticipantsSheet by remember { mutableStateOf(false) }
    var showChatMenu by remember { mutableStateOf(false) }
    var showConfirmDeleteChat by remember { mutableStateOf(false) }
    var showConfirmLeaveGroup by remember { mutableStateOf(false) }
    var previewImageBytes by remember { mutableStateOf<ByteArray?>(null) }
    var activeVideoRequest by remember { mutableStateOf<SpoxVideoRequest?>(null) }
    var showInlineAudioSheet by remember { mutableStateOf(false) }
    var messagePendingDelete by remember { mutableStateOf<DecryptedMessageItem?>(null) }
    var selectedMessageForActions by remember { mutableStateOf<DecryptedMessageItem?>(null) }
    var messagePendingForward by remember { mutableStateOf<DecryptedMessageItem?>(null) }
    val listState = rememberLazyListState()

    val recordAudioPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            voicePlayer.stop()
            audioPlayer?.pauseIfPlaying()
            val started = voiceRecorder.startRecording(scope)
            if (!started) {
                viewModel.showError("Не удалось запустить запись с микрофона")
            }
        } else {
            viewModel.showError("Нужен доступ к микрофону для записи голосового сообщения")
        }
    }

    fun handlePickedUri(uri: Uri, forceImageCompression: Boolean, fallbackError: String) {
        scope.launch {
            val result = withContext(Dispatchers.IO) {
                FileAttachmentHelper.readAndPrepareUri(context, uri, forceImageCompression = forceImageCompression)
            }
            result
                .onSuccess { viewModel.sendAttachment(it) }
                .onFailure { viewModel.showError(it.localizedMessage ?: fallbackError) }
        }
    }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            handlePickedUri(uri, forceImageCompression = true, fallbackError = "Не удалось прочитать изображение")
        }
    }

    val videoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            handlePickedUri(uri, forceImageCompression = false, fallbackError = "Не удалось прочитать видео")
        }
    }

    val documentPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            handlePickedUri(uri, forceImageCompression = false, fallbackError = "Не удалось прочитать файл")
        }
    }

    val roomData = (roomState as? UiState.Success<ChatRoomUiData>)?.data
    val conversation = roomData?.conversation
    val isSavedChat = conversation?.isSavedMessages(currentUserId) == true
    val membersById = remember(roomData?.memberProfiles) {
        roomData?.memberProfiles.orEmpty().associateBy { it.userId }
    }
    val directPeer = remember(conversation, membersById, currentUserId, isSavedChat) {
        if (conversation == null || conversation.isGroup || isSavedChat) null
        else {
            val peerUid = conversation.memberUids.firstOrNull { it != currentUserId } ?: currentUserId
            membersById[peerUid]
        }
    }
    val title = if (isSavedChat) {
        "Избранное"
    } else {
        directPeer?.displayName?.ifBlank { null }
            ?: conversation?.let { resolveConversationTitle(it, currentUserId) }
            ?: "Чат"
    }
    var presenceNowMs by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(30_000L)
            presenceNowMs = System.currentTimeMillis()
        }
    }
    val peerPresence = if (conversation != null && !conversation.isGroup && !isSavedChat && directPeer?.userId != currentUserId) {
        directPeer?.presenceStatus(presenceNowMs) ?: UserPresenceStatus.OFFLINE
    } else {
        null
    }

    val haptic = LocalHapticFeedback.current
    val density = LocalDensity.current
    val exitVelocityThresholdPx = with(density) { 680.dp.toPx() }
    val minFlingDistancePx = with(density) { 48.dp.toPx() }
    var containerWidthPx by remember { mutableFloatStateOf(0f) }
    var swipeExitOffsetPx by remember { mutableFloatStateOf(0f) }
    val swipeExitAnimatable = remember { Animatable(0f) }
    var isExitingViaSwipe by remember { mutableStateOf(false) }

    val isSwipeBackEnabled = !isExitingViaSwipe &&
        !isRecording &&
        previewImageBytes == null &&
        activeVideoRequest == null &&
        !showInlineAudioSheet &&
        !showAttachSheet &&
        !showSecuritySheet &&
        !showPeerProfileSheet &&
        inspectedMemberProfile == null &&
        !showGroupInfoSheet &&
        !showDmAddParticipantsSheet &&
        !showChatMenu &&
        !showConfirmDeleteChat &&
        !showConfirmLeaveGroup &&
        selectedMessageForActions == null &&
        messagePendingForward == null &&
        messagePendingDelete == null

    val isPastExitThreshold by remember {
        derivedStateOf {
            containerWidthPx > 0f && swipeExitOffsetPx >= containerWidthPx * 0.26f
        }
    }

    BackHandler(enabled = previewImageBytes != null) {
        previewImageBytes = null
    }

    BackHandler(enabled = activeVideoRequest != null) {
        activeVideoRequest = null
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .onSizeChanged { containerWidthPx = it.width.toFloat() }
            .pointerInput(isSwipeBackEnabled, containerWidthPx) {
                if (!isSwipeBackEnabled) return@pointerInput
                val touchSlop = viewConfiguration.touchSlop
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    val velocityTracker = VelocityTracker()
                    velocityTracker.addPosition(down.uptimeMillis, down.position)
                    var lockedRightSwipe = false
                    var totalDx = 0f
                    var totalDy = 0f
                    var lastX = down.position.x
                    var crossedThreshold = false

                    while (true) {
                        val event = awaitPointerEvent()
                        val change = event.changes.firstOrNull { it.id == down.id } ?: event.changes.firstOrNull() ?: break
                        if (!change.pressed) {
                            if (lockedRightSwipe) {
                                val vx = velocityTracker.calculateVelocity().x
                                val curOffset = swipeExitOffsetPx
                                val width = containerWidthPx.coerceAtLeast(1f)
                                val shouldExit = curOffset >= width * 0.26f ||
                                    (vx >= exitVelocityThresholdPx && curOffset >= minFlingDistancePx)
                                scope.launch {
                                    swipeExitAnimatable.snapTo(curOffset)
                                    if (shouldExit) {
                                        isExitingViaSwipe = true
                                        voicePlayer.stop()
                                        swipeExitAnimatable.animateTo(
                                            targetValue = width,
                                            animationSpec = tween(165, easing = FastOutSlowInEasing)
                                        ) {
                                            swipeExitOffsetPx = value
                                        }
                                        onBack()
                                    } else {
                                        swipeExitAnimatable.animateTo(
                                            targetValue = 0f,
                                            animationSpec = spring(
                                                dampingRatio = 0.86f,
                                                stiffness = Spring.StiffnessMediumLow
                                            )
                                        ) {
                                            swipeExitOffsetPx = value
                                        }
                                    }
                                }
                            }
                            break
                        }

                        val dxStep = change.position.x - lastX
                        lastX = change.position.x
                        totalDx = change.position.x - down.position.x
                        totalDy = change.position.y - down.position.y
                        velocityTracker.addPosition(change.uptimeMillis, change.position)

                        if (!lockedRightSwipe) {
                            if (change.isConsumed) break
                            val absDx = kotlin.math.abs(totalDx)
                            val absDy = kotlin.math.abs(totalDy)
                            if (absDy > touchSlop && absDy * 1.05f >= absDx) {
                                break
                            }
                            if (totalDx < -touchSlop && absDx > absDy * 1.15f) {
                                break
                            }
                            if (totalDx > touchSlop && totalDx > absDy * 1.35f) {
                                lockedRightSwipe = true
                                change.consume()
                                val initialOffset = (totalDx - touchSlop).coerceAtLeast(0f)
                                swipeExitOffsetPx = initialOffset
                            }
                        } else {
                            change.consume()
                            val nextOffset = (swipeExitOffsetPx + dxStep).coerceAtLeast(0f)
                            swipeExitOffsetPx = nextOffset
                            val threshold = containerWidthPx * 0.26f
                            if (!crossedThreshold && threshold > 0f && nextOffset >= threshold) {
                                crossedThreshold = true
                                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            } else if (crossedThreshold && nextOffset < threshold * 0.85f) {
                                crossedThreshold = false
                            }
                        }
                    }
                }
            }
    ) {
        // Subtle parallax dim backdrop visible while swiping right to exit chat
        Box(
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    val width = containerWidthPx.coerceAtLeast(1f)
                    val progress = (swipeExitOffsetPx / width).coerceIn(0f, 1f)
                    alpha = if (swipeExitOffsetPx > 0f) (1f - progress) * 0.34f else 0f
                }
                .background(Color.Black)
        )

        // Edge back pill indicator peeking from left side while swiping right
        val badgeColor = if (isPastExitThreshold) {
            MaterialTheme.colorScheme.primary
        } else {
            MaterialTheme.colorScheme.surfaceContainerHigh
        }
        val badgeTint = if (isPastExitThreshold) {
            MaterialTheme.colorScheme.onPrimary
        } else {
            MaterialTheme.colorScheme.onSurface
        }
        Surface(
            shape = CircleShape,
            color = badgeColor,
            shadowElevation = 4.dp,
            modifier = Modifier
                .align(Alignment.CenterStart)
                .padding(start = 12.dp)
                .size(44.dp)
                .graphicsLayer {
                    val width = containerWidthPx.coerceAtLeast(1f)
                    val progress = (swipeExitOffsetPx / (width * 0.26f)).coerceIn(0f, 1.25f)
                    alpha = (swipeExitOffsetPx / 36f).coerceIn(0f, 1f)
                    val scale = 0.72f + (progress.coerceAtMost(1f) * 0.34f)
                    scaleX = scale
                    scaleY = scale
                    translationX = (swipeExitOffsetPx * 0.22f - 28f).coerceAtMost(24f)
                }
                .testTag("swipe_back_edge_indicator")
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = null,
                    tint = badgeTint,
                    modifier = Modifier.size(22.dp)
                )
            }
        }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .graphicsLayer {
                translationX = swipeExitOffsetPx
            },
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            Column(
                modifier = Modifier.background(MaterialTheme.colorScheme.surface.copy(alpha = 0.94f))
            ) {
                TopAppBar(
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = Color.Transparent
                    ),
                    navigationIcon = {
                        IconButton(
                            onClick = onBack,
                            modifier = Modifier.testTag("chat_back_button")
                        ) {
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.85f))
                            ) {
                                Icon(
                                    Icons.AutoMirrored.Filled.ArrowBack,
                                    contentDescription = "Назад",
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    },
                    title = {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clip(RoundedCornerShape(14.dp))
                                .clickable(enabled = conversation != null) {
                                    when {
                                        conversation?.isGroup == true -> showGroupInfoSheet = true
                                        !isSavedChat && directPeer != null -> showPeerProfileSheet = true
                                        else -> showSecuritySheet = true
                                    }
                                }
                                .testTag("chat_header_profile_button")
                                .padding(horizontal = 4.dp, vertical = 4.dp)
                        ) {
                            if (isSavedChat) {
                                SavedMessagesAvatar(size = 40.dp)
                            } else {
                                UserAvatar(
                                    name = title,
                                    avatarBase64 = if (conversation?.isGroup == true) "" else directPeer?.avatarBase64.orEmpty(),
                                    colorIndex = directPeer?.avatarColorIndex?.toInt() ?: 0,
                                    isGroup = conversation?.isGroup == true,
                                    size = 40.dp,
                                    presenceStatus = peerPresence
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = title,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.SemiBold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.weight(1f, fill = false)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.14f)
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(
                                                imageVector = Icons.Filled.Lock,
                                                contentDescription = null,
                                                tint = MaterialTheme.colorScheme.primary,
                                                modifier = Modifier.size(10.dp)
                                            )
                                            Spacer(modifier = Modifier.width(2.dp))
                                            Text(
                                                text = "E2EE",
                                                style = MaterialTheme.typography.labelSmall,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.primary
                                            )
                                        }
                                    }
                                }
                                Spacer(modifier = Modifier.height(1.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    if (peerPresence != null) {
                                        UserPresenceIndicator(
                                            status = peerPresence,
                                            compact = true
                                        )
                                    } else {
                                        val peerHandle = directPeer?.handle.orEmpty()
                                        Text(
                                            text = when {
                                                isSavedChat -> "Личные заметки и пересланное"
                                                conversation?.isGroup == true -> "${conversation.memberUids.size} участников • настройки"
                                                peerHandle.isNotBlank() -> peerHandle
                                                else -> "Шифрование AES-256-GCM"
                                            },
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }
                            }
                        }
                    },
                    actions = {
                        if (conversation != null) {
                            val isMuted = roomData.isCurrentUserMuted
                            if (!isSavedChat) {
                                IconButton(
                                    onClick = { viewModel.startOrJoinCall("audio", onOpenCall) },
                                    enabled = !isMuted || conversation.activeCallId.isNotBlank(),
                                    modifier = Modifier.testTag("start_audio_call_button")
                                ) {
                                    Box(
                                        contentAlignment = Alignment.Center,
                                        modifier = Modifier
                                            .size(36.dp)
                                            .clip(CircleShape)
                                            .background(MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.85f))
                                    ) {
                                        Icon(
                                            Icons.Filled.Call,
                                            contentDescription = "Аудиозвонок",
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                                IconButton(
                                    onClick = { viewModel.startOrJoinCall("video", onOpenCall) },
                                    enabled = !isMuted || conversation.activeCallId.isNotBlank(),
                                    modifier = Modifier.testTag("start_video_call_button")
                                ) {
                                    Box(
                                        contentAlignment = Alignment.Center,
                                        modifier = Modifier
                                            .size(36.dp)
                                            .clip(CircleShape)
                                            .background(MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.85f))
                                    ) {
                                        Icon(
                                            Icons.Filled.Videocam,
                                            contentDescription = "Видеозвонок",
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                            }
                            if (conversation.isGroup) {
                                IconButton(
                                    onClick = {
                                        openAddMembersInGroupSheet = false
                                        showGroupInfoSheet = true
                                    },
                                    modifier = Modifier.testTag("group_info_button")
                                ) {
                                    Box(
                                        contentAlignment = Alignment.Center,
                                        modifier = Modifier
                                            .size(36.dp)
                                            .clip(CircleShape)
                                            .background(MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.85f))
                                    ) {
                                        Icon(
                                            Icons.Filled.Groups,
                                            contentDescription = "Настройки группы",
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                            }
                            Box {
                                IconButton(
                                    onClick = { showChatMenu = true },
                                    modifier = Modifier.testTag("chat_more_menu_button")
                                ) {
                                    Box(
                                        contentAlignment = Alignment.Center,
                                        modifier = Modifier
                                            .size(36.dp)
                                            .clip(CircleShape)
                                            .background(MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.85f))
                                    ) {
                                        Icon(
                                            Icons.Filled.MoreVert,
                                            contentDescription = "Меню чата",
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                                DropdownMenu(
                                    expanded = showChatMenu,
                                    onDismissRequest = { showChatMenu = false }
                                ) {
                                    if (conversation.isGroup) {
                                        DropdownMenuItem(
                                            text = { Text("Настройки группы") },
                                            leadingIcon = { Icon(Icons.Filled.Settings, contentDescription = null) },
                                            onClick = {
                                                showChatMenu = false
                                                openAddMembersInGroupSheet = false
                                                showGroupInfoSheet = true
                                            },
                                            modifier = Modifier.testTag("menu_group_settings")
                                        )
                                        DropdownMenuItem(
                                            text = { Text("Добавить участников") },
                                            leadingIcon = { Icon(Icons.Filled.PersonAdd, contentDescription = null) },
                                            onClick = {
                                                showChatMenu = false
                                                openAddMembersInGroupSheet = true
                                                showGroupInfoSheet = true
                                            },
                                            modifier = Modifier.testTag("menu_group_add_members")
                                        )
                                    } else if (!isSavedChat) {
                                        if (directPeer != null) {
                                            DropdownMenuItem(
                                                text = { Text("Профиль пользователя") },
                                                leadingIcon = { Icon(Icons.Filled.Person, contentDescription = null) },
                                                onClick = {
                                                    showChatMenu = false
                                                    showPeerProfileSheet = true
                                                },
                                                modifier = Modifier.testTag("menu_peer_profile")
                                            )
                                        }
                                        DropdownMenuItem(
                                            text = { Text("Добавить участников (группа)") },
                                            leadingIcon = { Icon(Icons.Filled.GroupAdd, contentDescription = null) },
                                            onClick = {
                                                showChatMenu = false
                                                viewModel.clearMemberSearch()
                                                showDmAddParticipantsSheet = true
                                            },
                                            modifier = Modifier.testTag("menu_dm_add_participants")
                                        )
                                    }
                                    DropdownMenuItem(
                                        text = { Text("Проверка E2EE") },
                                        leadingIcon = { Icon(Icons.Filled.Shield, contentDescription = null) },
                                        onClick = {
                                            showChatMenu = false
                                            showSecuritySheet = true
                                        },
                                        modifier = Modifier.testTag("menu_verify_e2ee")
                                    )
                                    HorizontalDivider()
                                    if (conversation.isGroup && !conversation.isCreator(currentUserId)) {
                                        DropdownMenuItem(
                                            text = { Text("Покинуть группу", color = MaterialTheme.colorScheme.error) },
                                            leadingIcon = {
                                                Icon(
                                                    Icons.Filled.Close,
                                                    contentDescription = null,
                                                    tint = MaterialTheme.colorScheme.error
                                                )
                                            },
                                            onClick = {
                                                showChatMenu = false
                                                showConfirmLeaveGroup = true
                                            },
                                            modifier = Modifier.testTag("menu_leave_group")
                                        )
                                    } else {
                                        DropdownMenuItem(
                                            text = {
                                                Text(
                                                    if (conversation.isGroup) "Удалить группу" else "Удалить чат",
                                                    color = MaterialTheme.colorScheme.error
                                                )
                                            },
                                            leadingIcon = {
                                                Icon(
                                                    Icons.Filled.Delete,
                                                    contentDescription = null,
                                                    tint = MaterialTheme.colorScheme.error
                                                )
                                            },
                                            onClick = {
                                                showChatMenu = false
                                                showConfirmDeleteChat = true
                                            },
                                            modifier = Modifier.testTag("menu_delete_chat")
                                        )
                                    }
                                }
                            }
                        }
                    }
                )
                HorizontalDivider(
                    color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.42f)
                )
            }
        },
        bottomBar = {
            Surface(
                color = MaterialTheme.colorScheme.surface.copy(alpha = 0.95f),
                tonalElevation = 3.dp,
                shadowElevation = 6.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .imePadding()
            ) {
                Column {
                    HorizontalDivider(
                        color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f)
                    )
                    if (roomData?.isCurrentUserMuted == true) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 14.dp)
                                .testTag("muted_composer_banner"),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.VolumeOff,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.tertiary
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Режим чтения • мут (${formatMuteRemaining(roomData.mutedUntilEpochMs)})",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                val reasonText = roomData.moderationReason.ifBlank {
                                    "Отправка сообщений и звонки временно ограничены администратором."
                                }
                                Text(
                                    text = reasonText,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    } else if (isRecording) {
                        VoiceRecordingComposerBar(
                            elapsedMs = recordElapsedMs,
                            liveBars = liveBars,
                            onCancel = { voiceRecorder.cancelRecording() },
                            onSend = {
                                val recorded = voiceRecorder.stopAndBuild()
                                if (recorded != null) {
                                    viewModel.sendVoiceMessage(recorded)
                                } else {
                                    viewModel.showError("Запись слишком короткая или превышает 650 КБ")
                                }
                            }
                        )
                    } else {
                        AnimatedVisibility(visible = replyingTo != null) {
                            replyingTo?.let { quote ->
                                ReplyComposerPreviewBar(
                                    replyTo = quote,
                                    onCancel = { viewModel.cancelReply() }
                                )
                            }
                        }
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 8.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(
                                onClick = { showAttachSheet = true },
                                enabled = !isSending && conversation != null,
                                modifier = Modifier
                                    .size(48.dp)
                                    .testTag("attach_file_button")
                            ) {
                                Box(
                                    contentAlignment = Alignment.Center,
                                    modifier = Modifier
                                        .size(38.dp)
                                        .clip(CircleShape)
                                        .background(MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.85f))
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.AttachFile,
                                        contentDescription = "Прикрепить файл или фото",
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }

                            OutlinedTextField(
                                value = textDraft,
                                onValueChange = { textDraft = it },
                                placeholder = {
                                    Text(
                                        when {
                                            isSavedChat -> "Заметка в Избранное..."
                                            conversation?.isGroup == false -> "Сообщение..."
                                            else -> "Зашифрованное сообщение..."
                                        }
                                    )
                                },
                                maxLines = 5,
                                shape = RoundedCornerShape(24.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedContainerColor = MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.88f),
                                    unfocusedContainerColor = MaterialTheme.colorScheme.surfaceContainer.copy(alpha = 0.9f),
                                    focusedBorderColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.55f),
                                    unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.65f)
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("message_input_field")
                            )

                            Spacer(modifier = Modifier.width(6.dp))

                            AnimatedContent(
                                targetState = textDraft.isNotBlank(),
                                transitionSpec = {
                                    (fadeIn(tween(140)) + scaleIn(initialScale = 0.84f)) togetherWith
                                        (fadeOut(tween(110)) + scaleOut(targetScale = 0.84f))
                                },
                                label = "composer_action_btn"
                            ) { hasText ->
                                if (hasText) {
                                    IconButton(
                                        onClick = {
                                            val msg = textDraft
                                            textDraft = ""
                                            viewModel.sendTextMessage(msg)
                                        },
                                        enabled = !isSending,
                                        modifier = Modifier
                                            .size(48.dp)
                                            .testTag("send_message_button")
                                    ) {
                                        Box(
                                            contentAlignment = Alignment.Center,
                                            modifier = Modifier
                                                .size(42.dp)
                                                .clip(CircleShape)
                                                .background(
                                                    Brush.linearGradient(
                                                        listOf(
                                                            MaterialTheme.colorScheme.primary,
                                                            MaterialTheme.colorScheme.secondary
                                                        )
                                                    )
                                                )
                                        ) {
                                            Icon(
                                                Icons.AutoMirrored.Filled.Send,
                                                contentDescription = "Отправить",
                                                tint = MaterialTheme.colorScheme.onPrimary,
                                                modifier = Modifier.size(19.dp)
                                            )
                                        }
                                    }
                                } else {
                                    IconButton(
                                        onClick = {
                                            val granted = ContextCompat.checkSelfPermission(
                                                context,
                                                Manifest.permission.RECORD_AUDIO
                                            ) == PackageManager.PERMISSION_GRANTED
                                            if (granted) {
                                                voicePlayer.stop()
                                                audioPlayer?.pauseIfPlaying()
                                                if (!voiceRecorder.startRecording(scope)) {
                                                    viewModel.showError("Микрофон недоступен")
                                                }
                                            } else {
                                                recordAudioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                            }
                                        },
                                        enabled = !isSending && conversation != null,
                                        modifier = Modifier
                                            .size(48.dp)
                                            .testTag("record_voice_button")
                                    ) {
                                        Box(
                                            contentAlignment = Alignment.Center,
                                            modifier = Modifier
                                                .size(42.dp)
                                                .clip(CircleShape)
                                                .background(MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.9f))
                                        ) {
                                            Icon(
                                                Icons.Filled.Mic,
                                                contentDescription = "Записать голосовое сообщение",
                                                tint = MaterialTheme.colorScheme.onSecondaryContainer,
                                                modifier = Modifier.size(20.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    ) { innerPadding ->
        ChatWallpaperBackground(
            appearance = appearance,
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            AnimatedContent(
                targetState = roomState,
                transitionSpec = { fadeIn(tween(240)) togetherWith fadeOut(tween(180)) },
                contentKey = { it::class },
                label = "room_state_transition"
            ) { state ->
                when (state) {
                    is UiState.Loading -> {
                        CipherLoadingStateView(label = "Расшифровка переписки...")
                    }

                    is UiState.Error -> {
                        Box(modifier = Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                            Text(state.message, color = MaterialTheme.colorScheme.error)
                        }
                    }

                    is UiState.Success -> {
                        val messages = state.data.messages

                        LaunchedEffect(messages.size) {
                            if (messages.isNotEmpty()) {
                                listState.animateScrollToItem(messages.lastIndex)
                            }
                        }

                        val showScrollToBottom by remember(messages) {
                            derivedStateOf {
                                val lastVisible = listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index
                                    ?: messages.lastIndex
                                messages.size > 6 && lastVisible < (messages.lastIndex - 1)
                            }
                        }

                        Box(modifier = Modifier.fillMaxSize()) {
                            Column(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .widthIn(max = 720.dp)
                                    .align(Alignment.TopCenter)
                            ) {
                                if (conversation != null && !state.data.hasRoomKey) {
                                    Surface(
                                        shape = RoundedCornerShape(14.dp),
                                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.88f),
                                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.35f)),
                                        shadowElevation = 2.dp,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 12.dp, vertical = 6.dp)
                                            .clickable { viewModel.retryRepairRoomKey() }
                                            .testTag("repair_room_key_banner")
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(
                                                Icons.Filled.Key,
                                                contentDescription = null,
                                                tint = MaterialTheme.colorScheme.primary,
                                                modifier = Modifier.size(18.dp)
                                            )
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(
                                                text = "Синхронизация ключа E2EE — нажмите, чтобы обновить",
                                                style = MaterialTheme.typography.labelLarge,
                                                color = MaterialTheme.colorScheme.onPrimaryContainer
                                            )
                                        }
                                    }
                                }

                                if (conversation?.activeCallId?.isNotBlank() == true) {
                                    Surface(
                                        shape = RoundedCornerShape(14.dp),
                                        color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.92f),
                                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.secondary.copy(alpha = 0.35f)),
                                        shadowElevation = 2.dp,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 12.dp, vertical = 6.dp)
                                            .clickable { onOpenCall(conversation.activeCallId) }
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Icon(
                                                    Icons.Filled.Call,
                                                    contentDescription = null,
                                                    tint = MaterialTheme.colorScheme.secondary,
                                                    modifier = Modifier.size(18.dp)
                                                )
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Text(
                                                    text = "В этом чате идёт звонок — нажмите, чтобы подключиться",
                                                    style = MaterialTheme.typography.labelLarge,
                                                    color = MaterialTheme.colorScheme.onSecondaryContainer
                                                )
                                            }
                                        }
                                    }
                                }

                                val currentTrack = audioUiState?.activeTrack
                                if (currentTrack != null && audioPlayer != null) {
                                    Surface(
                                        shape = RoundedCornerShape(16.dp),
                                        color = MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.94f),
                                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.28f)),
                                        tonalElevation = 3.dp,
                                        shadowElevation = 2.dp,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 12.dp, vertical = 6.dp)
                                            .clickable { showInlineAudioSheet = true }
                                            .testTag("in_chat_audio_bar")
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Box(
                                                contentAlignment = Alignment.Center,
                                                modifier = Modifier
                                                    .size(32.dp)
                                                    .clip(CircleShape)
                                                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.14f))
                                            ) {
                                                Icon(
                                                    imageVector = if (audioUiState.isPlaying) Icons.Filled.GraphicEq else Icons.Filled.MusicNote,
                                                    contentDescription = null,
                                                    tint = MaterialTheme.colorScheme.primary,
                                                    modifier = Modifier.size(17.dp)
                                                )
                                            }
                                            Spacer(modifier = Modifier.width(10.dp))
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(
                                                    text = currentTrack.title,
                                                    style = MaterialTheme.typography.labelLarge,
                                                    fontWeight = FontWeight.SemiBold,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                                Text(
                                                    text = "${currentTrack.formatBadge} • ${if (audioUiState.isPlaying) "Играет" else "Пауза"} • Открыть плеер",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                            }
                                            IconButton(
                                                onClick = { audioPlayer.togglePlayPause() },
                                                modifier = Modifier.size(40.dp)
                                            ) {
                                                Icon(
                                                    imageVector = if (audioUiState.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                                                    contentDescription = if (audioUiState.isPlaying) "Пауза" else "Воспроизвести",
                                                    tint = MaterialTheme.colorScheme.primary
                                                )
                                            }
                                            IconButton(
                                                onClick = { audioPlayer.stopAndDismiss() },
                                                modifier = Modifier.size(40.dp)
                                            ) {
                                                Icon(Icons.Filled.Close, contentDescription = "Закрыть плеер", modifier = Modifier.size(18.dp))
                                            }
                                        }
                                    }
                                }

                                if (messages.isEmpty()) {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .padding(24.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Surface(
                                            shape = RoundedCornerShape(26.dp),
                                            color = MaterialTheme.colorScheme.surface.copy(alpha = 0.90f),
                                            border = BorderStroke(
                                                1.dp,
                                                MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.55f)
                                            ),
                                            shadowElevation = 4.dp,
                                            modifier = Modifier.widthIn(max = 360.dp)
                                        ) {
                                            Column(
                                                modifier = Modifier.padding(horizontal = 24.dp, vertical = 24.dp),
                                                horizontalAlignment = Alignment.CenterHorizontally
                                            ) {
                                                Box(
                                                    contentAlignment = Alignment.Center,
                                                    modifier = Modifier
                                                        .size(84.dp)
                                                        .clip(CircleShape)
                                                        .background(
                                                            Brush.radialGradient(
                                                                listOf(
                                                                    MaterialTheme.colorScheme.primary.copy(alpha = 0.22f),
                                                                    Color.Transparent
                                                                )
                                                            )
                                                        )
                                                ) {
                                                    if (isSavedChat) {
                                                        SavedMessagesAvatar(size = 62.dp)
                                                    } else if (conversation != null && !conversation.isGroup && directPeer != null) {
                                                        UserAvatar(
                                                            name = title,
                                                            avatarBase64 = directPeer.avatarBase64,
                                                            colorIndex = directPeer.avatarColorIndex.toInt(),
                                                            size = 62.dp,
                                                            presenceStatus = peerPresence
                                                        )
                                                    } else {
                                                        Surface(
                                                            shape = CircleShape,
                                                            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.7f),
                                                            modifier = Modifier.size(60.dp)
                                                        ) {
                                                            Box(contentAlignment = Alignment.Center) {
                                                                Icon(
                                                                    Icons.Filled.VerifiedUser,
                                                                    contentDescription = null,
                                                                    tint = MaterialTheme.colorScheme.primary,
                                                                    modifier = Modifier.size(30.dp)
                                                                )
                                                            }
                                                        }
                                                    }
                                                }
                                                Spacer(modifier = Modifier.height(12.dp))
                                                Text(
                                                    text = when {
                                                        isSavedChat -> "Избранное"
                                                        conversation?.isGroup == false -> title
                                                        else -> "Защищённый чат"
                                                    },
                                                    style = MaterialTheme.typography.titleLarge,
                                                    fontWeight = FontWeight.Bold,
                                                    textAlign = TextAlign.Center
                                                )
                                                Spacer(modifier = Modifier.height(6.dp))
                                                Surface(
                                                    shape = RoundedCornerShape(50),
                                                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)
                                                ) {
                                                    Row(
                                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        Icon(
                                                            imageVector = Icons.Filled.Lock,
                                                            contentDescription = null,
                                                            tint = MaterialTheme.colorScheme.primary,
                                                            modifier = Modifier.size(12.dp)
                                                        )
                                                        Spacer(modifier = Modifier.width(5.dp))
                                                        Text(
                                                            text = "Сквозное шифрование AES-256-GCM",
                                                            style = MaterialTheme.typography.labelSmall,
                                                            fontWeight = FontWeight.SemiBold,
                                                            color = MaterialTheme.colorScheme.primary
                                                        )
                                                    }
                                                }
                                                Spacer(modifier = Modifier.height(10.dp))
                                                Text(
                                                    text = when {
                                                        isSavedChat -> "Пересылайте сюда важные сообщения или сохраняйте заметки, фото, музыку и видео — доступ есть только у вас."
                                                        conversation?.isGroup == false -> "Напишите первое сообщение, отправьте голосовую заметку, фото или видео — ключи хранятся только на устройствах."
                                                        else -> "Общайтесь в зашифрованной группе и обменивайтесь медиа без ограничений на качество."
                                                    },
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                    textAlign = TextAlign.Center
                                                )
                                            }
                                        }
                                    }
                                } else {
                                    val messageIndexById = remember(messages) {
                                        messages.withIndex().associate { it.value.id to it.index }
                                    }
                                    val maxOtherReadCursor = remember(conversation?.lastReadAtMillis, conversation?.memberUids, currentUserId) {
                                        conversation?.memberUids
                                            .orEmpty()
                                            .filter { it != currentUserId }
                                            .maxOfOrNull { otherUid -> conversation?.lastReadAtMillis?.get(otherUid) ?: 0L }
                                            ?: 0L
                                    }

                                    LazyColumn(
                                        state = listState,
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 14.dp),
                                        verticalArrangement = Arrangement.spacedBy(2.dp),
                                        modifier = Modifier.fillMaxSize()
                                    ) {
                                        itemsIndexed(messages, key = { _, item -> item.id }) { index, msg ->
                                            val prevMsg = messages.getOrNull(index - 1)
                                            val nextMsg = messages.getOrNull(index + 1)
                                            val showDateHeader = shouldShowDateHeader(prevMsg?.createdAt, msg.createdAt)
                                            val isFirstInCluster = showDateHeader || !areClusterNeighbors(prevMsg, msg)
                                            val nextStartsNewDay = nextMsg == null || shouldShowDateHeader(msg.createdAt, nextMsg.createdAt)
                                            val isLastInCluster = nextStartsNewDay || !areClusterNeighbors(msg, nextMsg)

                                            val isMine = msg.senderId == currentUserId
                                            val isThisPlaying = playbackState.activeMessageId == msg.id && playbackState.isPlaying
                                            val thisProgress = if (playbackState.activeMessageId == msg.id) playbackState.progress else 0f
                                            val msgTimeMs = msg.createdAt?.toDate()?.time
                                            val isReadByOther = isMine && !isSavedChat && (
                                                (msgTimeMs != null && maxOtherReadCursor >= msgTimeMs) ||
                                                    (msg == messages.lastOrNull() && conversation?.isLastMessageReadByOther(currentUserId) == true)
                                                )
                                            val isInteractive = msg.content !is DecryptedContent.Deleted &&
                                                msg.content !is DecryptedContent.KeyUnavailable &&
                                                msg.content !is DecryptedContent.CallEvent

                                            Column(modifier = Modifier.animateItem()) {
                                                if (showDateHeader) {
                                                    msg.createdAt?.let { ts ->
                                                        ChatDateDividerPill(timestamp = ts)
                                                    }
                                                } else if (isFirstInCluster && index > 0) {
                                                    Spacer(modifier = Modifier.height(7.dp))
                                                }

                                                MessageBubble(
                                                    item = msg,
                                                    isMine = isMine,
                                                    isGroup = conversation?.isGroup == true,
                                                    isFirstInCluster = isFirstInCluster,
                                                    isLastInCluster = isLastInCluster,
                                                    isSavedChat = isSavedChat,
                                                    isInteractive = isInteractive,
                                                    isReadByOther = isReadByOther,
                                                    isPlayingVoice = isThisPlaying,
                                                    voiceProgress = thisProgress,
                                                    activeAudioTrackId = audioUiState?.activeTrack?.id,
                                                    isAudioTrackPlaying = audioUiState?.isPlaying == true,
                                                    downloadProgress = downloadProgress[msg.id],
                                                    isDownloadCompleted = msg.id in completedDownloads,
                                                    onToggleVoice = { bytes ->
                                                        audioPlayer?.pauseIfPlaying()
                                                        voicePlayer.togglePlay(msg.id, bytes, scope)
                                                    },
                                                    onOpenImage = { bytes -> previewImageBytes = bytes },
                                                    onDownloadImage = { file ->
                                                        viewModel.prepareMediaFileForPlayback(context, msg, file) { cachedFile ->
                                                            val ok = FileAttachmentHelper.openCachedFileWithSystem(
                                                                context = context,
                                                                file = cachedFile,
                                                                fileName = file.fileName,
                                                                mimeType = file.mimeType
                                                            )
                                                            if (!ok) previewImageBytes = file.bytes
                                                        }
                                                    },
                                                    onOpenFile = { file ->
                                                        val mediaKind = FileAttachmentHelper.classifyMediaKind(file.mimeType, file.fileName)
                                                        val badge = FileAttachmentHelper.formatBadge(file.fileName, file.mimeType)
                                                        viewModel.prepareMediaFileForPlayback(context, msg, file) { cachedFile ->
                                                            when (mediaKind) {
                                                                MediaKind.VIDEO -> {
                                                                    voicePlayer.stop()
                                                                    audioPlayer?.pauseIfPlaying()
                                                                    activeVideoRequest = SpoxVideoRequest(
                                                                        id = msg.id,
                                                                        uri = Uri.fromFile(cachedFile),
                                                                        title = file.fileName,
                                                                        formatBadge = badge,
                                                                        mimeType = file.mimeType,
                                                                        sizeBytes = file.sizeBytes
                                                                    )
                                                                }
                                                                MediaKind.AUDIO -> {
                                                                    voicePlayer.stop()
                                                                    val tappedTrack = SpoxAudioTrack(
                                                                        id = msg.id,
                                                                        uri = Uri.fromFile(cachedFile),
                                                                        title = file.fileName.substringBeforeLast('.').ifBlank { file.fileName },
                                                                        subtitle = msg.senderName.ifBlank { "Аудио из чата" },
                                                                        formatBadge = badge,
                                                                        mimeType = file.mimeType,
                                                                        sizeBytes = file.sizeBytes
                                                                    )
                                                                    val queue = messages.mapNotNull { candidate ->
                                                                        val f = candidate.content as? DecryptedContent.FileAttachment ?: return@mapNotNull null
                                                                        if (FileAttachmentHelper.classifyMediaKind(f.mimeType, f.fileName) != MediaKind.AUDIO) {
                                                                            return@mapNotNull null
                                                                        }
                                                                        if (candidate.id == msg.id) return@mapNotNull tappedTrack
                                                                        val siblingFile = if (f.isChunked) {
                                                                            FileAttachmentHelper.getCachedMediaFileIfReady(context, candidate.id, f.fileName, f.sizeBytes)
                                                                        } else {
                                                                            FileAttachmentHelper.writeDecryptedMediaToCache(context, candidate.id, f.fileName, f.bytes)
                                                                        }
                                                                        siblingFile?.let { readySibling ->
                                                                            SpoxAudioTrack(
                                                                                id = candidate.id,
                                                                                uri = Uri.fromFile(readySibling),
                                                                                title = f.fileName.substringBeforeLast('.').ifBlank { f.fileName },
                                                                                subtitle = candidate.senderName.ifBlank { "Аудио из чата" },
                                                                                formatBadge = FileAttachmentHelper.formatBadge(f.fileName, f.mimeType),
                                                                                mimeType = f.mimeType,
                                                                                sizeBytes = f.sizeBytes
                                                                            )
                                                                        }
                                                                    }.ifEmpty { listOf(tappedTrack) }
                                                                    val startIdx = queue.indexOfFirst { it.id == msg.id }.coerceAtLeast(0)
                                                                    audioPlayer?.playQueue(queue, startIdx)
                                                                }
                                                                else -> {
                                                                    val ok = FileAttachmentHelper.openCachedFileWithSystem(
                                                                        context = context,
                                                                        file = cachedFile,
                                                                        fileName = file.fileName,
                                                                        mimeType = file.mimeType
                                                                    )
                                                                    if (!ok) {
                                                                        viewModel.showError("Не найдено приложение для открытия ${file.fileName}")
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    },
                                                    onQuoteClick = { quotedId ->
                                                        val targetIdx = messageIndexById[quotedId]
                                                        if (targetIdx != null && targetIdx >= 0) {
                                                            scope.launch {
                                                                listState.animateScrollToItem(targetIdx)
                                                            }
                                                        }
                                                    },
                                                    onQuickReply = {
                                                        if (isInteractive) {
                                                            viewModel.startReply(msg)
                                                        }
                                                    },
                                                    onOpenActions = {
                                                        if (isInteractive) {
                                                            selectedMessageForActions = msg
                                                        }
                                                    }
                                                )
                                            }
                                        }
                                    }
                                }
                            }

                            AnimatedVisibility(
                                visible = showScrollToBottom,
                                enter = fadeIn(tween(180)) + scaleIn(initialScale = 0.8f),
                                exit = fadeOut(tween(150)) + scaleOut(targetScale = 0.8f),
                                modifier = Modifier
                                    .align(Alignment.BottomEnd)
                                    .padding(end = 16.dp, bottom = 14.dp)
                            ) {
                                Surface(
                                    shape = CircleShape,
                                    color = MaterialTheme.colorScheme.surface.copy(alpha = 0.94f),
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f)),
                                    shadowElevation = 6.dp,
                                    modifier = Modifier
                                        .size(44.dp)
                                        .clickable {
                                            if (messages.isNotEmpty()) {
                                                scope.launch {
                                                    listState.animateScrollToItem(messages.lastIndex)
                                                }
                                            }
                                        }
                                        .testTag("scroll_to_bottom_button")
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = Icons.Filled.KeyboardArrowDown,
                                            contentDescription = "Вниз к новым сообщениям",
                                            tint = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                }
                            }

                            MediaUploadBanner(
                                transfer = activeUpload,
                                modifier = Modifier.align(Alignment.TopCenter)
                            )
                        }
                    }
                }
            }
        }
    }
    }

    if (showAttachSheet) {
        ModalBottomSheet(onDismissRequest = { showAttachSheet = false }) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .navigationBarsPadding()
                    .padding(horizontal = 20.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("Отправить зашифрованный медиафайл", style = MaterialTheme.typography.titleLarge)
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surfaceContainer,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            showAttachSheet = false
                            photoPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        }
                        .testTag("pick_photo_option")
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.Image, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text("Фото из галереи", style = MaterialTheme.typography.titleSmall)
                            Text("Сжимается и шифруется AES-256-GCM", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surfaceContainer,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            showAttachSheet = false
                            videoPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                            )
                        }
                        .testTag("pick_video_option")
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.VideoFile, contentDescription = null, tint = MaterialTheme.colorScheme.tertiary)
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text("Видео из галереи", style = MaterialTheme.typography.titleSmall)
                            Text("До 25 МБ • MP4, MOV, MKV, WebM • E2EE", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surfaceContainer,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            showAttachSheet = false
                            documentPickerLauncher.launch(
                                arrayOf("video/*", "application/x-matroska", "application/ogg", "*/*")
                            )
                        }
                        .testTag("pick_video_file_option")
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.FolderOpen, contentDescription = null, tint = MaterialTheme.colorScheme.tertiary)
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text("Видеофайл (MKV, AVI, WebM, TS...)", style = MaterialTheme.typography.titleSmall)
                            Text("До 25 МБ • воспроизведение во встроенном плеере", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surfaceContainer,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            showAttachSheet = false
                            documentPickerLauncher.launch(arrayOf("audio/*", "application/ogg", "*/*"))
                        }
                        .testTag("pick_audio_option")
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.MusicNote, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text("Музыка и аудио", style = MaterialTheme.typography.titleSmall)
                            Text("MP3, FLAC, OPUS, OGG, WAV, M4A до 25 МБ", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surfaceContainer,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            showAttachSheet = false
                            documentPickerLauncher.launch(arrayOf("*/*"))
                        }
                        .testTag("pick_document_option")
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.Description, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text("Документ или любой файл", style = MaterialTheme.typography.titleSmall)
                            Text("До 10 МБ • сквозное шифрование", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
            }
        }
    }

    if (showSecuritySheet && roomData != null) {
        ModalBottomSheet(onDismissRequest = { showSecuritySheet = false }) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(horizontal = 20.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.VerifiedUser, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.width(10.dp))
                    Text("Проверка сквозного шифрования", style = MaterialTheme.typography.titleLarge)
                }
                Text(
                    text = "Сообщения, голосовые заметки и файлы шифруются ключом комнаты AES-256-GCM. Ключ комнаты передаётся участникам через ECDH P-256 + HKDF-SHA256.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.4f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Номер безопасности чата (SHA-256)", style = MaterialTheme.typography.labelMedium)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = roomData.safetyNumber,
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
                Text("Ключи участников", style = MaterialTheme.typography.titleSmall)
                roomData.memberProfiles.forEach { member ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .clickable {
                                showSecuritySheet = false
                                inspectedMemberProfile = member
                            }
                            .padding(vertical = 6.dp, horizontal = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        UserAvatar(
                            name = member.displayName,
                            avatarBase64 = member.avatarBase64,
                            colorIndex = member.avatarColorIndex.toInt(),
                            size = 36.dp
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            val label = if (member.handle.isNotBlank()) "${member.displayName} (${member.handle})" else member.displayName
                            Text(label, style = MaterialTheme.typography.titleSmall)
                            Text(member.keyFingerprint, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
            }
        }
    }

    if (showPeerProfileSheet && directPeer != null && conversation != null && roomData != null) {
        UserProfileSheet(
            displayName = directPeer.displayName.ifBlank { title },
            handle = directPeer.handle,
            avatarBase64 = directPeer.avatarBase64,
            avatarColorIndex = directPeer.avatarColorIndex.toInt(),
            keyFingerprint = directPeer.keyFingerprint,
            safetyNumber = roomData.safetyNumber,
            role = UserRole.fromWire(directPeer.role),
            presenceStatus = peerPresence,
            isSelf = directPeer.userId == currentUserId,
            isMuted = roomData.isCurrentUserMuted,
            onDismiss = { showPeerProfileSheet = false },
            onAudioCall = { viewModel.startOrJoinCall("audio", onOpenCall) },
            onVideoCall = { viewModel.startOrJoinCall("video", onOpenCall) },
            onOpenFullSecurity = {
                showPeerProfileSheet = false
                showSecuritySheet = true
            },
            onCopied = { msg -> viewModel.showError(msg) }
        )
    }

    inspectedMemberProfile?.let { member ->
        UserProfileSheet(
            displayName = member.displayName,
            handle = member.handle,
            avatarBase64 = member.avatarBase64,
            avatarColorIndex = member.avatarColorIndex.toInt(),
            keyFingerprint = member.keyFingerprint,
            safetyNumber = roomData?.safetyNumber,
            role = UserRole.fromWire(member.role),
            presenceStatus = if (member.userId == currentUserId) null else member.presenceStatus(presenceNowMs),
            isSelf = member.userId == currentUserId,
            onDismiss = { inspectedMemberProfile = null },
            onCopied = { msg -> viewModel.showError(msg) }
        )
    }

    if (showGroupInfoSheet && conversation != null && conversation.isGroup) {
        GroupSettingsSheet(
            conversation = conversation,
            currentUserId = currentUserId,
            membersById = membersById,
            directoryUsers = directoryUsers,
            serverSearchResults = memberSearchResults,
            isSearchingMembers = isSearchingMembers,
            hasRoomKey = roomData.hasRoomKey,
            isBusy = isGroupActionBusy,
            presenceNowMs = presenceNowMs,
            initialShowAddMembers = openAddMembersInGroupSheet,
            onDismiss = {
                showGroupInfoSheet = false
                openAddMembersInGroupSheet = false
                viewModel.clearMemberSearch()
            },
            onOpenSecuritySheet = { showSecuritySheet = true },
            onSaveGroupSettings = { newTitle, newDescription ->
                viewModel.updateGroupSettings(newTitle, newDescription)
            },
            onSearchUsers = { query ->
                viewModel.searchAddableUsers(query, conversation.memberUids)
            },
            onAddMembers = { chosen ->
                viewModel.addMembersToGroup(chosen)
            },
            onRemoveMember = { targetUid, targetName ->
                viewModel.removeMemberFromGroup(targetUid, targetName)
            },
            onLeaveGroup = {
                viewModel.leaveGroup {
                    showGroupInfoSheet = false
                    voicePlayer.stop()
                    onBack()
                }
            },
            onDeleteGroup = {
                viewModel.deleteCurrentChat {
                    showGroupInfoSheet = false
                    voicePlayer.stop()
                    onBack()
                }
            }
        )
    }

    if (showDmAddParticipantsSheet && conversation != null && !conversation.isGroup && !isSavedChat) {
        AddParticipantsFromDmSheet(
            existingPeerName = title,
            existingMemberUids = conversation.memberUids,
            directoryUsers = directoryUsers,
            serverSearchResults = memberSearchResults,
            isSearching = isSearchingMembers,
            isBusy = isGroupActionBusy,
            onDismiss = {
                showDmAddParticipantsSheet = false
                viewModel.clearMemberSearch()
            },
            onSearchUsers = { query ->
                viewModel.searchAddableUsers(query, conversation.memberUids)
            },
            onCreateGroup = { groupTitle, selectedMembers ->
                viewModel.createGroupFromDirectChat(selectedMembers, groupTitle) { newGroupId ->
                    showDmAddParticipantsSheet = false
                    voicePlayer.stop()
                    onOpenChat(newGroupId)
                }
            }
        )
    }

    if (showConfirmDeleteChat && conversation != null) {
        ConfirmDeleteChatDialog(
            conversation = conversation,
            currentUserId = currentUserId,
            resolvedTitle = title,
            onDismiss = { showConfirmDeleteChat = false },
            onConfirm = {
                showConfirmDeleteChat = false
                viewModel.deleteCurrentChat {
                    voicePlayer.stop()
                    onBack()
                }
            }
        )
    }

    if (showConfirmLeaveGroup && conversation != null) {
        ConfirmLeaveGroupDialog(
            groupTitle = title,
            onDismiss = { showConfirmLeaveGroup = false },
            onConfirm = {
                showConfirmLeaveGroup = false
                viewModel.leaveGroup {
                    voicePlayer.stop()
                    onBack()
                }
            }
        )
    }

    previewImageBytes?.let { imgBytes ->
        val fullBmp by produceState<ImageBitmap?>(initialValue = null, key1 = imgBytes) {
            value = BitmapMemoryCache.decodeFullImage(imgBytes)
        }
        Dialog(onDismissRequest = { previewImageBytes = null }) {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = MaterialTheme.colorScheme.surface
            ) {
                Box(modifier = Modifier.padding(8.dp)) {
                    if (fullBmp != null) {
                        Image(
                            bitmap = fullBmp!!,
                            contentDescription = "Расшифрованное изображение",
                            contentScale = ContentScale.Fit,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                        )
                    }
                    IconButton(
                        onClick = { previewImageBytes = null },
                        modifier = Modifier.align(Alignment.TopEnd)
                    ) {
                        Icon(Icons.Filled.Close, contentDescription = "Закрыть")
                    }
                }
            }
        }
    }

    messagePendingDelete?.let { target ->
        AlertDialog(
            onDismissRequest = { messagePendingDelete = null },
            title = { Text("Удалить сообщение?") },
            text = { Text("Сообщение будет заменено на метку удаления для всех участников чата.") },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.deleteOwnMessage(target.id)
                    messagePendingDelete = null
                }) {
                    Icon(Icons.Filled.Delete, contentDescription = null)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Удалить")
                }
            },
            dismissButton = {
                TextButton(onClick = { messagePendingDelete = null }) {
                    Text("Отмена")
                }
            }
        )
    }

    selectedMessageForActions?.let { target ->
        MessageActionsSheet(
            item = target,
            isMine = target.senderId == currentUserId,
            isSavedChat = isSavedChat,
            onDismiss = { selectedMessageForActions = null },
            onReply = { viewModel.startReply(target) },
            onForwardToSaved = { viewModel.forwardMessageToSaved(target) },
            onForwardToChat = { messagePendingForward = target },
            onCopyText = { text ->
                val clipboard = context.getSystemService(ClipboardManager::class.java)
                clipboard?.setPrimaryClip(ClipData.newPlainText("SpoX", text))
                viewModel.showError("Текст скопирован")
            },
            onDelete = { messagePendingDelete = target }
        )
    }

    messagePendingForward?.let { target ->
        val usersById = remember(directoryUsers, roomData?.memberProfiles) {
            buildMap {
                directoryUsers.forEach { put(it.userId, it) }
                roomData?.memberProfiles.orEmpty().forEach { put(it.userId, it) }
            }
        }
        ForwardTargetSheet(
            conversations = userConversations,
            directoryUsers = directoryUsers,
            currentUserId = currentUserId,
            isForwarding = isForwarding,
            resolveTitle = { conv ->
                resolveDirectPeer(conv, currentUserId, usersById)?.displayName?.ifBlank { null }
                    ?: resolveConversationTitle(conv, currentUserId)
            },
            resolveDirectPeer = { conv -> resolveDirectPeer(conv, currentUserId, usersById) },
            onDismiss = { if (!isForwarding) messagePendingForward = null },
            onSelectSaved = {
                viewModel.forwardMessageToSaved(target) {
                    messagePendingForward = null
                }
            },
            onSelectConversation = { conv, convTitle ->
                viewModel.forwardMessageToConversation(target, conv, convTitle) {
                    messagePendingForward = null
                }
            },
            onSelectUser = { peer ->
                viewModel.forwardMessageToUser(target, peer) {
                    messagePendingForward = null
                }
            }
        )
    }

    activeVideoRequest?.let { videoReq ->
        SpoxVideoPlayerDialog(
            request = videoReq,
            onDismiss = { activeVideoRequest = null }
        )
    }

    if (showInlineAudioSheet && audioPlayer != null) {
        SpoxAudioPlayerSheet(
            manager = audioPlayer,
            onDismiss = { showInlineAudioSheet = false }
        )
    }
}

@Composable
private fun ChatDateDividerPill(timestamp: Timestamp) {
    val label = remember(timestamp.seconds) {
        val date = timestamp.toDate()
        val msgCal = Calendar.getInstance().apply { time = date }
        val today = Calendar.getInstance()
        val yesterday = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -1) }
        when {
            msgCal.get(Calendar.YEAR) == today.get(Calendar.YEAR) &&
                msgCal.get(Calendar.DAY_OF_YEAR) == today.get(Calendar.DAY_OF_YEAR) -> "Сегодня"
            msgCal.get(Calendar.YEAR) == yesterday.get(Calendar.YEAR) &&
                msgCal.get(Calendar.DAY_OF_YEAR) == yesterday.get(Calendar.DAY_OF_YEAR) -> "Вчера"
            msgCal.get(Calendar.YEAR) == today.get(Calendar.YEAR) ->
                SimpleDateFormat("d MMMM", Locale("ru")).format(date)
            else -> SimpleDateFormat("d MMMM yyyy", Locale("ru")).format(date)
        }
    }
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            shape = RoundedCornerShape(50),
            color = MaterialTheme.colorScheme.surface.copy(alpha = 0.80f),
            border = BorderStroke(
                1.dp,
                MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.48f)
            ),
            shadowElevation = 1.dp
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
            )
        }
    }
}

private fun shouldShowDateHeader(previous: Timestamp?, current: Timestamp?): Boolean {
    if (current == null) return false
    if (previous == null) return true
    val c1 = Calendar.getInstance().apply { time = previous.toDate() }
    val c2 = Calendar.getInstance().apply { time = current.toDate() }
    return c1.get(Calendar.YEAR) != c2.get(Calendar.YEAR) ||
        c1.get(Calendar.DAY_OF_YEAR) != c2.get(Calendar.DAY_OF_YEAR)
}

private fun areClusterNeighbors(a: DecryptedMessageItem?, b: DecryptedMessageItem?): Boolean {
    if (a == null || b == null) return false
    if (a.content is DecryptedContent.CallEvent || b.content is DecryptedContent.CallEvent) return false
    if (a.senderId != b.senderId) return false
    val t1 = a.createdAt?.toDate()?.time ?: return false
    val t2 = b.createdAt?.toDate()?.time ?: return false
    return kotlin.math.abs(t2 - t1) <= 5 * 60_000L
}

@Composable
private fun VoiceRecordingComposerBar(
    elapsedMs: Long,
    liveBars: List<Int>,
    onCancel: () -> Unit,
    onSend: () -> Unit
) {
    val pulseTransition = rememberInfiniteTransition(label = "voice_rec_pulse")
    val dotAlpha by pulseTransition.animateFloat(
        initialValue = 1f,
        targetValue = 0.25f,
        animationSpec = infiniteRepeatable(
            animation = tween(550),
            repeatMode = RepeatMode.Reverse
        ),
        label = "rec_dot_alpha"
    )
    val bars = remember(liveBars) {
        if (liveBars.isEmpty()) List(14) { 16 } else liveBars.takeLast(14)
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 10.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(
            onClick = onCancel,
            colors = IconButtonDefaults.iconButtonColors(
                containerColor = MaterialTheme.colorScheme.error.copy(alpha = 0.16f),
                contentColor = MaterialTheme.colorScheme.error
            ),
            modifier = Modifier
                .size(48.dp)
                .testTag("cancel_voice_button")
        ) {
            Icon(Icons.Filled.Close, contentDescription = "Отменить запись")
        }

        Spacer(modifier = Modifier.width(8.dp))

        Surface(
            shape = RoundedCornerShape(22.dp),
            color = MaterialTheme.colorScheme.surfaceContainerHigh,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.28f)),
            modifier = Modifier.weight(1f)
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 11.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.error.copy(alpha = dotAlpha))
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = formatDurationMillis(elapsedMs),
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(2.5.dp),
                    modifier = Modifier.height(18.dp)
                ) {
                    bars.forEach { level ->
                        val frac = (level / 100f).coerceIn(0.18f, 1f)
                        Box(
                            modifier = Modifier
                                .width(3.dp)
                                .height((18f * frac).dp)
                                .clip(RoundedCornerShape(50))
                                .background(MaterialTheme.colorScheme.primary)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.width(8.dp))

        IconButton(
            onClick = onSend,
            modifier = Modifier
                .size(48.dp)
                .testTag("send_voice_button")
        ) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.linearGradient(
                            listOf(
                                MaterialTheme.colorScheme.primary,
                                MaterialTheme.colorScheme.secondary
                            )
                        )
                    )
            ) {
                Icon(
                    Icons.Filled.Stop,
                    contentDescription = "Остановить и отправить голосовое",
                    tint = MaterialTheme.colorScheme.onPrimary,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun MessageBubble(
    item: DecryptedMessageItem,
    isMine: Boolean,
    isGroup: Boolean,
    isFirstInCluster: Boolean,
    isLastInCluster: Boolean,
    isSavedChat: Boolean,
    isInteractive: Boolean,
    isReadByOther: Boolean,
    isPlayingVoice: Boolean,
    voiceProgress: Float,
    activeAudioTrackId: String?,
    isAudioTrackPlaying: Boolean,
    downloadProgress: Float?,
    isDownloadCompleted: Boolean,
    onToggleVoice: (ByteArray) -> Unit,
    onOpenImage: (ByteArray) -> Unit,
    onDownloadImage: (DecryptedContent.FileAttachment) -> Unit,
    onOpenFile: (DecryptedContent.FileAttachment) -> Unit,
    onQuoteClick: (String) -> Unit,
    onQuickReply: () -> Unit,
    onOpenActions: () -> Unit
) {
    if (item.content is DecryptedContent.CallEvent) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            contentAlignment = Alignment.Center
        ) {
            Surface(
                shape = RoundedCornerShape(50),
                color = MaterialTheme.colorScheme.surface.copy(alpha = 0.84f),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.45f))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Filled.Call,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.secondary,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "${item.senderName}: ${item.content.text}",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
        return
    }

    val appearance = LocalChatAppearance.current
    val outgoingPalette = resolveOutgoingBubblePalette(appearance.outgoingBubbleStyle)
    val isCustomOutgoing = isMine && appearance.outgoingBubbleStyle != OutgoingBubbleStyle.THEME_AUTO

    val surfaceContainer = MaterialTheme.colorScheme.surfaceContainer.copy(alpha = 0.96f)
    val surfaceContainerHigh = MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.96f)
    val bubbleGradient = remember(
        isMine,
        outgoingPalette.startColor,
        outgoingPalette.endColor,
        surfaceContainer,
        surfaceContainerHigh
    ) {
        if (isMine) {
            Brush.linearGradient(listOf(outgoingPalette.startColor, outgoingPalette.endColor))
        } else {
            Brush.linearGradient(listOf(surfaceContainer, surfaceContainerHigh))
        }
    }
    val textColor = if (isMine) outgoingPalette.contentColor else MaterialTheme.colorScheme.onSurface
    val bubbleAccentColor = if (isCustomOutgoing) outgoingPalette.contentColor else MaterialTheme.colorScheme.primary

    val bubbleShape = remember(isMine, isFirstInCluster, isLastInCluster) {
        if (isMine) {
            RoundedCornerShape(
                topStart = 20.dp,
                topEnd = if (isFirstInCluster) 20.dp else 10.dp,
                bottomStart = 20.dp,
                bottomEnd = if (isLastInCluster) 5.dp else 10.dp
            )
        } else {
            RoundedCornerShape(
                topStart = if (isFirstInCluster) 20.dp else 10.dp,
                topEnd = 20.dp,
                bottomStart = if (isLastInCluster) 5.dp else 10.dp,
                bottomEnd = 20.dp
            )
        }
    }

    val scope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current
    val density = LocalDensity.current
    val maxReplyDragPx = with(density) { 68.dp.toPx() }
    val replyTriggerPx = with(density) { 42.dp.toPx() }
    var replySwipePx by remember(item.id) { mutableFloatStateOf(0f) }
    val replyReturnAnim = remember(item.id) { Animatable(0f) }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .pointerInput(item.id, isInteractive) {
                if (!isInteractive) return@pointerInput
                val touchSlop = viewConfiguration.touchSlop
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    var lockedLeftSwipe = false
                    var lastX = down.position.x
                    var crossedTrigger = false

                    while (true) {
                        val event = awaitPointerEvent()
                        val change = event.changes.firstOrNull { it.id == down.id } ?: event.changes.firstOrNull() ?: break
                        if (!change.pressed) {
                            if (lockedLeftSwipe) {
                                val triggered = kotlin.math.abs(replySwipePx) >= replyTriggerPx
                                val startOffset = replySwipePx
                                scope.launch {
                                    replyReturnAnim.snapTo(startOffset)
                                    replyReturnAnim.animateTo(
                                        targetValue = 0f,
                                        animationSpec = spring(
                                            dampingRatio = 0.78f,
                                            stiffness = Spring.StiffnessMedium
                                        )
                                    ) {
                                        replySwipePx = value
                                    }
                                }
                                if (triggered) {
                                    onQuickReply()
                                }
                            }
                            break
                        }

                        val dxStep = change.position.x - lastX
                        lastX = change.position.x
                        val totalDx = change.position.x - down.position.x
                        val totalDy = change.position.y - down.position.y

                        if (!lockedLeftSwipe) {
                            val absDx = kotlin.math.abs(totalDx)
                            val absDy = kotlin.math.abs(totalDy)
                            if (absDy > touchSlop && absDy * 1.05f >= absDx) {
                                break
                            }
                            if (totalDx > touchSlop && totalDx > absDy * 1.15f) {
                                break
                            }
                            if (totalDx < -touchSlop && absDx > absDy * 1.35f) {
                                lockedLeftSwipe = true
                                change.consume()
                                val initial = (totalDx + touchSlop).coerceIn(-maxReplyDragPx, 0f)
                                replySwipePx = initial
                            }
                        } else {
                            change.consume()
                            val dampedStep = dxStep * 0.72f
                            val next = (replySwipePx + dampedStep).coerceIn(-maxReplyDragPx, 0f)
                            replySwipePx = next
                            if (!crossedTrigger && kotlin.math.abs(next) >= replyTriggerPx) {
                                crossedTrigger = true
                                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            }
                        }
                    }
                }
            }
    ) {
        Surface(
            shape = CircleShape,
            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.92f),
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .padding(end = 8.dp)
                .size(34.dp)
                .graphicsLayer {
                    val progress = (kotlin.math.abs(replySwipePx) / replyTriggerPx).coerceIn(0f, 1.15f)
                    alpha = (kotlin.math.abs(replySwipePx) / 18f).coerceIn(0f, 1f)
                    val s = 0.65f + (progress.coerceAtMost(1f) * 0.4f)
                    scaleX = s
                    scaleY = s
                }
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.Reply,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(18.dp)
                )
            }
        }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .graphicsLayer {
                translationX = replySwipePx
            },
        horizontalAlignment = if (isMine) Alignment.End else Alignment.Start
    ) {
        Surface(
            shape = bubbleShape,
            shadowElevation = if (isMine) 2.dp else 1.dp,
            border = BorderStroke(
                1.dp,
                if (isMine) outgoingPalette.borderColor
                else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.55f)
            ),
            color = Color.Transparent,
            modifier = Modifier
                .widthIn(max = 314.dp)
                .combinedClickable(
                    onClick = onOpenActions,
                    onLongClick = onOpenActions
                )
                .testTag("message_bubble_${item.id}")
        ) {
            Box(
                modifier = Modifier
                    .background(bubbleGradient)
                    .padding(horizontal = 13.dp, vertical = 9.dp)
            ) {
                Column {
                    if (isGroup && !isMine && isFirstInCluster) {
                        Text(
                            text = item.senderName,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(3.dp))
                    }

                    item.forwardedFrom?.let { origin ->
                        ForwardedHeaderLabel(
                            origin = origin,
                            accentColor = bubbleAccentColor,
                            textColor = textColor
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                    }

                    item.replyTo?.let { quote ->
                        MessageQuoteBlock(
                            replyTo = quote,
                            isMine = isMine,
                            accentColor = bubbleAccentColor,
                            textColor = textColor,
                            onClick = { onQuoteClick(quote.messageId) }
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                    }

                    when (val content = item.content) {
                        is DecryptedContent.Text -> {
                            Text(
                                text = content.text,
                                style = MaterialTheme.typography.bodyLarge,
                                color = textColor
                            )
                        }

                        is DecryptedContent.Voice -> {
                            VoiceWaveformRow(
                                bars = content.waveform,
                                progress = voiceProgress,
                                isPlaying = isPlayingVoice,
                                onTogglePlay = { onToggleVoice(content.audioBytes) },
                                durationLabel = formatDurationMillis(content.durationMs),
                                accentColor = bubbleAccentColor,
                                trackColor = textColor.copy(alpha = 0.25f),
                                textColor = textColor,
                                modifier = Modifier.width(234.dp)
                            )
                        }

                        is DecryptedContent.FileAttachment -> {
                            if (content.isImage) {
                                val bmp by produceState<ImageBitmap?>(
                                    initialValue = BitmapMemoryCache.getCachedMediaThumb(item.id, content.bytes.size),
                                    key1 = item.id,
                                    key2 = content.bytes.size
                                ) {
                                    value = BitmapMemoryCache.decodeMediaThumb(item.id, content.bytes)
                                }
                                if (bmp != null) {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(190.dp)
                                            .clip(RoundedCornerShape(14.dp))
                                            .combinedClickable(
                                                onClick = { onOpenImage(content.bytes) },
                                                onLongClick = onOpenActions
                                            )
                                    ) {
                                        Image(
                                            bitmap = bmp!!,
                                            contentDescription = content.fileName,
                                            contentScale = ContentScale.Crop,
                                            modifier = Modifier.fillMaxSize()
                                        )
                                        Surface(
                                            shape = CircleShape,
                                            color = Color.Black.copy(alpha = 0.56f),
                                            modifier = Modifier
                                                .align(Alignment.BottomEnd)
                                                .padding(8.dp)
                                                .clickable { onDownloadImage(content) }
                                                .testTag("download_media_button_${item.id}")
                                        ) {
                                            Box(modifier = Modifier.padding(4.dp)) {
                                                MediaDownloadBadge(
                                                    progress = downloadProgress,
                                                    isCompleted = isDownloadCompleted,
                                                    tint = Color.White,
                                                    size = 30.dp
                                                )
                                            }
                                        }
                                    }
                                } else {
                                    Text(content.fileName, color = textColor)
                                }
                            } else {
                                val kind = remember(content.mimeType, content.fileName) {
                                    FileAttachmentHelper.classifyMediaKind(content.mimeType, content.fileName)
                                }
                                val badge = remember(content.fileName, content.mimeType) {
                                    FileAttachmentHelper.formatBadge(content.fileName, content.mimeType)
                                }
                                val isCurrentAudioTrack = kind == MediaKind.AUDIO && activeAudioTrackId == item.id
                                val isPlayingThisAudio = isCurrentAudioTrack && isAudioTrackPlaying
                                Column(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(12.dp))
                                        .combinedClickable(
                                            onClick = { onOpenFile(content) },
                                            onLongClick = onOpenActions
                                        )
                                        .padding(vertical = 2.dp)
                                        .testTag("media_file_card_${item.id}")
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Box(
                                            contentAlignment = Alignment.Center,
                                            modifier = Modifier
                                                .size(46.dp)
                                                .clip(RoundedCornerShape(12.dp))
                                                .background(
                                                    Brush.linearGradient(
                                                        listOf(
                                                            bubbleAccentColor.copy(alpha = 0.24f),
                                                            bubbleAccentColor.copy(alpha = 0.12f)
                                                        )
                                                    )
                                                )
                                        ) {
                                            Icon(
                                                imageVector = when {
                                                    isPlayingThisAudio -> Icons.Filled.GraphicEq
                                                    kind == MediaKind.VIDEO -> Icons.Filled.PlayArrow
                                                    else -> mediaKindIcon(kind)
                                                },
                                                contentDescription = kind.label,
                                                tint = bubbleAccentColor,
                                                modifier = Modifier.size(24.dp)
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = content.fileName,
                                                style = MaterialTheme.typography.titleSmall,
                                                fontWeight = FontWeight.SemiBold,
                                                color = textColor,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            val sizeStr = FileAttachmentHelper.formatSize(content.sizeBytes)
                                            val subtitle = when {
                                                downloadProgress != null -> "Расшифровка и загрузка... ${(downloadProgress * 100).toInt()}%"
                                                kind == MediaKind.VIDEO -> "Видео $badge • $sizeStr • Плеер SpoX"
                                                kind == MediaKind.AUDIO -> if (isPlayingThisAudio) {
                                                    "Аудио $badge • $sizeStr • Играет"
                                                } else {
                                                    "Аудио $badge • $sizeStr • Слушать"
                                                }
                                                isDownloadCompleted -> "${kind.label} • $sizeStr • Готово"
                                                else -> "${kind.label} • $sizeStr • Открыть"
                                            }
                                            Text(
                                                text = subtitle,
                                                style = MaterialTheme.typography.labelSmall,
                                                color = textColor.copy(alpha = 0.8f),
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(8.dp))
                                        if (kind == MediaKind.VIDEO || kind == MediaKind.AUDIO) {
                                            Surface(
                                                shape = RoundedCornerShape(8.dp),
                                                color = bubbleAccentColor.copy(alpha = 0.18f),
                                                border = BorderStroke(1.dp, bubbleAccentColor.copy(alpha = 0.25f))
                                            ) {
                                                Text(
                                                    text = badge,
                                                    style = MaterialTheme.typography.labelSmall,
                                                    fontWeight = FontWeight.Bold,
                                                    color = bubbleAccentColor,
                                                    modifier = Modifier.padding(horizontal = 7.dp, vertical = 4.dp)
                                                )
                                            }
                                        } else {
                                            MediaDownloadBadge(
                                                progress = downloadProgress,
                                                isCompleted = isDownloadCompleted,
                                                tint = bubbleAccentColor,
                                                size = 34.dp
                                            )
                                        }
                                    }
                                    if (downloadProgress != null) {
                                        val animBar by animateFloatAsState(
                                            targetValue = downloadProgress,
                                            animationSpec = tween(220),
                                            label = "file_dl_bar"
                                        )
                                        Spacer(modifier = Modifier.height(6.dp))
                                        LinearProgressIndicator(
                                            progress = { animBar },
                                            color = bubbleAccentColor,
                                            trackColor = textColor.copy(alpha = 0.2f),
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(4.dp)
                                                .clip(RoundedCornerShape(50))
                                        )
                                    }
                                }
                            }
                        }

                        DecryptedContent.Deleted -> {
                            Text(
                                text = "Сообщение удалено",
                                style = MaterialTheme.typography.bodyMedium,
                                fontStyle = FontStyle.Italic,
                                color = textColor.copy(alpha = 0.65f)
                            )
                        }

                        DecryptedContent.KeyUnavailable -> {
                            Text(
                                text = "Зашифровано для другого ключа устройства",
                                style = MaterialTheme.typography.bodySmall,
                                fontStyle = FontStyle.Italic,
                                color = textColor.copy(alpha = 0.7f)
                            )
                        }

                        is DecryptedContent.CallEvent -> Unit
                    }

                    Spacer(modifier = Modifier.height(3.dp))
                    Row(
                        modifier = Modifier.align(Alignment.End),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (item.isEncryptedVerified) {
                            Icon(
                                imageVector = Icons.Filled.Lock,
                                contentDescription = "E2EE",
                                tint = textColor.copy(alpha = 0.62f),
                                modifier = Modifier.size(10.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                        }
                        Text(
                            text = formatChatTime(item.createdAt),
                            style = MaterialTheme.typography.labelSmall,
                            color = textColor.copy(alpha = 0.72f)
                        )
                        if (isMine && !isSavedChat) {
                            Spacer(modifier = Modifier.width(4.dp))
                            ReadReceiptIcon(
                                isRead = isReadByOther,
                                tint = textColor.copy(alpha = 0.78f),
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }
                }
            }
        }
    }
    }
}
