package com.example.crypto

import com.example.data.model.Conversation
import com.example.data.model.ForwardOriginInfo
import com.example.data.model.ReplyQuoteInfo
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class CryptoManagerTest {

    @Test
    fun ecdhWrapUnwrap_andAesGcmRoundTrip_succeedsAndIsolatesWrongKeys() {
        val alice = CryptoManager()
        val bob = CryptoManager()
        val mallory = CryptoManager()

        val roomKey = alice.generateRoomKey()
        val bobPub = bob.getPublicKeyBase64()
        val envelopeForBob = alice.wrapRoomKeyForMember(roomKey, bobPub)

        val unwrappedByBob = bob.unwrapRoomKey(envelopeForBob)
        assertNotNull(unwrappedByBob)
        assertArrayEquals(roomKey, unwrappedByBob)

        // Mallory cannot unwrap Bob's envelope
        assertNull(mallory.unwrapRoomKey(envelopeForBob))

        // Text E2EE round-trip
        val msg = "Секретное сообщение 🔐"
        val blob = alice.encryptText(roomKey, msg)
        assertNotEquals(msg, blob.ciphertextBase64)
        assertEquals(msg, bob.decryptText(unwrappedByBob!!, blob.ivBase64, blob.ciphertextBase64))

        // Voice payload E2EE round-trip
        val fakeAudio = byteArrayOf(1, 2, 3, 4, 5, 42, 99)
        val voiceBlob = alice.encryptVoicePayload(roomKey, 3500L, listOf(12, 45, 80, 30), fakeAudio)
        val decodedVoice = bob.decryptVoicePayload(unwrappedByBob, voiceBlob.ivBase64, voiceBlob.ciphertextBase64)
        assertNotNull(decodedVoice)
        assertEquals(3500L, decodedVoice!!.durationMs)
        assertArrayEquals(fakeAudio, decodedVoice.audioBytes)

        // File payload E2EE round-trip
        val fileBytes = "PDF-secret-content".toByteArray()
        val fileBlob = alice.encryptFilePayload(roomKey, "contract.pdf", "application/pdf", fileBytes)
        val decodedFile = bob.decryptFilePayload(unwrappedByBob, fileBlob.ivBase64, fileBlob.ciphertextBase64)
        assertNotNull(decodedFile)
        assertEquals("contract.pdf", decodedFile!!.fileName)
        assertArrayEquals(fileBytes, decodedFile.bytes)
    }

    @Test
    fun richTextVoiceAndFile_preserveEncryptedReplyAndForwardMetadata() {
        val alice = CryptoManager()
        val bob = CryptoManager()
        val roomKey = alice.generateRoomKey()
        val bobKey = bob.unwrapRoomKey(alice.wrapRoomKeyForMember(roomKey, bob.getPublicKeyBase64()))!!

        val reply = ReplyQuoteInfo(
            messageId = "msg_42",
            senderName = "Алиса",
            previewText = "Встречаемся в 18:00",
            messageType = "text"
        )
        val forwarded = ForwardOriginInfo(
            originalSenderId = "uid_alice",
            originalSenderName = "Алиса"
        )

        // Plain legacy text still decodes seamlessly through decryptRichText
        val plainBlob = alice.encryptRichText(roomKey, "Без метаданных")
        val decodedPlain = bob.decryptRichText(bobKey, plainBlob.ivBase64, plainBlob.ciphertextBase64)
        assertNotNull(decodedPlain)
        assertEquals("Без метаданных", decodedPlain!!.text)
        assertNull(decodedPlain.replyTo)
        assertNull(decodedPlain.forwardedFrom)

        // Rich text with reply + forward metadata round-trips under E2EE
        val richBlob = alice.encryptRichText(
            roomKey = roomKey,
            plaintext = "Пересланный ответ",
            replyTo = reply,
            forwardedFrom = forwarded
        )
        val decodedRich = bob.decryptRichText(bobKey, richBlob.ivBase64, richBlob.ciphertextBase64)
        assertNotNull(decodedRich)
        assertEquals("Пересланный ответ", decodedRich!!.text)
        assertEquals(reply, decodedRich.replyTo)
        assertEquals(forwarded, decodedRich.forwardedFrom)

        // Voice payload preserves reply + forward metadata
        val voiceBytes = byteArrayOf(7, 8, 9, 10)
        val voiceBlob = alice.encryptVoicePayload(
            roomKey = roomKey,
            durationMs = 2100L,
            waveform = listOf(10, 40, 20),
            audioBytes = voiceBytes,
            replyTo = reply,
            forwardedFrom = forwarded
        )
        val decodedVoice = bob.decryptVoicePayload(bobKey, voiceBlob.ivBase64, voiceBlob.ciphertextBase64)
        assertNotNull(decodedVoice)
        assertEquals(reply, decodedVoice!!.replyTo)
        assertEquals(forwarded, decodedVoice.forwardedFrom)
        assertArrayEquals(voiceBytes, decodedVoice.audioBytes)

        // File payload preserves reply + forward metadata
        val fileBytes = "note-content".toByteArray()
        val fileBlob = alice.encryptFilePayload(
            roomKey = roomKey,
            fileName = "notes.txt",
            mimeType = "text/plain",
            bytes = fileBytes,
            replyTo = reply,
            forwardedFrom = forwarded
        )
        val decodedFile = bob.decryptFilePayload(bobKey, fileBlob.ivBase64, fileBlob.ciphertextBase64)
        assertNotNull(decodedFile)
        assertEquals(reply, decodedFile!!.replyTo)
        assertEquals(forwarded, decodedFile.forwardedFrom)
        assertArrayEquals(fileBytes, decodedFile.bytes)
    }

    @Test
    fun savedMessagesHelper_identifiesPersonalSavedChatAccurately() {
        val uid = "user_123"
        val savedId = Conversation.savedConversationId(uid)
        assertEquals("saved_user_123", savedId)

        val savedChat = Conversation(
            id = savedId,
            title = "Избранное",
            isGroup = false,
            memberUids = listOf(uid)
        )
        assertTrue(savedChat.isSavedMessages(uid))
        assertFalse(savedChat.isSavedMessages("other_user"))

        val directChat = Conversation(
            id = "dm_user_123_other",
            title = "Direct",
            isGroup = false,
            memberUids = listOf(uid, "other")
        )
        assertFalse(directChat.isSavedMessages(uid))

        val singlePersonGroup = Conversation(
            id = "grp_solo",
            title = "Solo Group",
            isGroup = true,
            memberUids = listOf(uid)
        )
        assertFalse(singlePersonGroup.isSavedMessages(uid))
    }

    @Test
    fun chunkedMediaManifestAndChunks_encryptDecryptRoundTrip() {
        val alice = CryptoManager()
        val bob = CryptoManager()
        val roomKey = alice.generateRoomKey()
        val bobKey = bob.unwrapRoomKey(alice.wrapRoomKeyForMember(roomKey, bob.getPublicKeyBase64()))!!

        val reply = ReplyQuoteInfo(
            messageId = "msg_prev",
            senderName = "Алиса",
            previewText = "Посмотри видео",
            messageType = "file"
        )
        val manifestBlob = alice.encryptChunkedFileManifest(
            roomKey = roomKey,
            fileName = "concert_4k.mkv",
            mimeType = "video/x-matroska",
            sizeBytes = 12_582_912L,
            chunkCount = 26,
            replyTo = reply
        )
        val manifest = bob.decryptFilePayload(bobKey, manifestBlob.ivBase64, manifestBlob.ciphertextBase64)
        assertNotNull(manifest)
        assertTrue(manifest!!.isChunked)
        assertEquals(26, manifest.chunkCount)
        assertEquals("concert_4k.mkv", manifest.fileName)
        assertEquals("video/x-matroska", manifest.mimeType)
        assertEquals(12_582_912L, manifest.sizeBytes)
        assertTrue(manifest.bytes.isEmpty())
        assertEquals(reply, manifest.replyTo)

        val chunkData = ByteArray(1024 * 64) { idx -> (idx % 251).toByte() }
        val chunkBlob = alice.encryptMediaChunk(roomKey, chunkData)
        val decryptedChunk = bob.decryptMediaChunk(bobKey, chunkBlob.ivBase64, chunkBlob.ciphertextBase64)
        assertNotNull(decryptedChunk)
        assertArrayEquals(chunkData, decryptedChunk)
    }

    @Test
    fun multiAccountScopes_isolateIdentityKeysAndMigrateLegacyOnlyForFirstAccount() {
        val context = androidx.test.core.app.ApplicationProvider.getApplicationContext<android.content.Context>()
        val prefs = context.getSharedPreferences("cipherchat_e2ee_identity", android.content.Context.MODE_PRIVATE)
        prefs.edit().clear().commit()

        // Seed legacy unscoped keypair
        val legacySource = CryptoManager()
        val legacyPair = legacySource.getOrCreateIdentityKeyPair()
        val legacyPrivB64 = android.util.Base64.encodeToString(legacyPair.private.encoded, android.util.Base64.NO_WRAP)
        val legacyPubB64 = android.util.Base64.encodeToString(legacyPair.public.encoded, android.util.Base64.NO_WRAP)
        prefs.edit()
            .putString("ecdh_priv_b64", legacyPrivB64)
            .putString("ecdh_pub_b64", legacyPubB64)
            .commit()

        val account1 = CryptoManager(context, accountScope = "uid_first")
        val account2 = CryptoManager(context, accountScope = "uid_second")
        val account3 = CryptoManager(context, accountScope = "uid_third")

        val pub1 = account1.getPublicKeyBase64()
        val pub2 = account2.getPublicKeyBase64()
        val pub3 = account3.getPublicKeyBase64()

        // First account inherits legacy key; subsequent accounts MUST generate distinct keys
        assertEquals(legacyPubB64, pub1)
        assertNotEquals(pub1, pub2)
        assertNotEquals(pub1, pub3)
        assertNotEquals(pub2, pub3)
        assertNotEquals(account1.getKeyFingerprint(), account2.getKeyFingerprint())

        // Cross-account unwrapping fails (account2 cannot decrypt envelope wrapped for account1)
        val sender = CryptoManager()
        val roomKey = sender.generateRoomKey()
        val envelopeForAcc1 = sender.wrapRoomKeyForMember(roomKey, pub1)
        assertNotNull(account1.unwrapRoomKey(envelopeForAcc1))
        assertNull(account2.unwrapRoomKey(envelopeForAcc1))
    }

    @Test
    fun getKeyFingerprintAsync_cachesFingerprintAndMatchesSyncValue() = runBlocking {
        val context = androidx.test.core.app.ApplicationProvider.getApplicationContext<android.content.Context>()
        val manager = CryptoManager(context, accountScope = "uid_async_fp_test")
        assertNull(manager.getCachedKeyFingerprint())

        val asyncFingerprint = manager.getKeyFingerprintAsync()
        assertTrue(asyncFingerprint.isNotBlank())
        assertEquals(asyncFingerprint, manager.getCachedKeyFingerprint())
        assertEquals(asyncFingerprint, manager.getKeyFingerprint())
    }
}

