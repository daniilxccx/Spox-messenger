package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Done
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.data.model.CallSession
import com.example.data.model.ModerationStatus
import com.example.data.model.UserPresenceStatus
import com.example.data.model.UserRole
import com.example.ui.theme.AvatarPalette
import com.example.ui.theme.LocalPresenceColors
import kotlin.math.abs

@Composable
fun UserAvatar(
    name: String,
    avatarBase64: String = "",
    colorIndex: Int = abs(name.hashCode()) % AvatarPalette.size,
    isGroup: Boolean = false,
    size: Dp = 46.dp,
    showOnlineDot: Boolean = false,
    presenceStatus: UserPresenceStatus? = null
) {
    val bgColor = AvatarPalette[abs(colorIndex) % AvatarPalette.size]
    val secondaryTint = AvatarPalette[(abs(colorIndex) + 2) % AvatarPalette.size]
    val initials = remember(name) {
        name.trim()
            .split(Regex("\\s+"))
            .filter { it.isNotBlank() }
            .take(2)
            .joinToString("") { it.first().uppercaseChar().toString() }
            .ifBlank { "?" }
    }

    val avatarBitmap by produceState<ImageBitmap?>(
        initialValue = if (isGroup || avatarBase64.isBlank()) null else BitmapMemoryCache.getCachedAvatar(avatarBase64),
        key1 = avatarBase64,
        key2 = isGroup
    ) {
        value = if (isGroup || avatarBase64.isBlank()) {
            null
        } else {
            BitmapMemoryCache.decodeAvatar(avatarBase64)
        }
    }

    val effectivePresence = presenceStatus ?: if (showOnlineDot) UserPresenceStatus.ONLINE else null
    val presenceColors = LocalPresenceColors.current
    val avatarBrush = remember(bgColor, secondaryTint) {
        Brush.linearGradient(
            listOf(
                bgColor.copy(alpha = 0.28f),
                secondaryTint.copy(alpha = 0.16f)
            )
        )
    }

    Box(modifier = Modifier.size(size)) {
        Surface(
            shape = CircleShape,
            color = Color.Transparent,
            border = BorderStroke(
                width = if (effectivePresence == UserPresenceStatus.ONLINE) 1.5.dp else 1.dp,
                color = if (effectivePresence == UserPresenceStatus.ONLINE) {
                    presenceColors.online.copy(alpha = 0.65f)
                } else {
                    bgColor.copy(alpha = 0.38f)
                }
            ),
            modifier = Modifier.size(size)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(avatarBrush),
                contentAlignment = Alignment.Center
            ) {
                when {
                    isGroup -> {
                        Icon(
                            imageVector = Icons.Filled.Groups,
                            contentDescription = "Групповой чат",
                            tint = bgColor,
                            modifier = Modifier.size(size * 0.52f)
                        )
                    }
                    else -> {
                        val resolvedAvatar = avatarBitmap
                        if (resolvedAvatar != null) {
                            Image(
                                bitmap = resolvedAvatar,
                                contentDescription = "Аватар $name",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .fillMaxSize()
                                    .clip(CircleShape)
                            )
                        } else {
                            Text(
                                text = initials,
                                style = if (size >= 64.dp) MaterialTheme.typography.headlineSmall else MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = bgColor
                            )
                        }
                    }
                }
            }
        }
        if (effectivePresence != null) {
            val targetDotColor = when (effectivePresence) {
                UserPresenceStatus.ONLINE -> presenceColors.online
                UserPresenceStatus.RECENTLY -> presenceColors.recent
                UserPresenceStatus.OFFLINE -> presenceColors.offline
            }
            val dotColor by animateColorAsState(
                targetValue = targetDotColor,
                animationSpec = tween(280),
                label = "avatar_presence_color"
            )
            val dotSize = if (size >= 48.dp) 14.dp else 11.dp
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(dotSize)
                    .align(Alignment.BottomEnd)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.background)
                    .padding(2.dp)
                    .clip(CircleShape)
                    .background(dotColor)
                    .testTag("avatar_presence_${effectivePresence.name.lowercase()}")
            ) {}
        }
    }
}

@Composable
fun UserPresenceIndicator(
    status: UserPresenceStatus,
    compact: Boolean = false,
    modifier: Modifier = Modifier
) {
    val presenceColors = LocalPresenceColors.current
    val targetColor = when (status) {
        UserPresenceStatus.ONLINE -> presenceColors.online
        UserPresenceStatus.RECENTLY -> presenceColors.recent
        UserPresenceStatus.OFFLINE -> presenceColors.offline
    }
    val dotColor by animateColorAsState(
        targetValue = targetColor,
        animationSpec = tween(280),
        label = "presence_dot_color"
    )
    val labelColor by animateColorAsState(
        targetValue = when (status) {
            UserPresenceStatus.ONLINE -> presenceColors.online
            UserPresenceStatus.RECENTLY -> presenceColors.recent
            UserPresenceStatus.OFFLINE -> MaterialTheme.colorScheme.onSurfaceVariant
        },
        animationSpec = tween(280),
        label = "presence_label_color"
    )

    val pulseAlpha = if (status == UserPresenceStatus.ONLINE) {
        val pulse = rememberInfiniteTransition(label = "online_dot_pulse")
        val anim by pulse.animateFloat(
            initialValue = 0.28f,
            targetValue = 0.72f,
            animationSpec = infiniteRepeatable(tween(900), RepeatMode.Reverse),
            label = "online_pulse_alpha"
        )
        anim
    } else {
        0f
    }

    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = modifier.testTag("presence_indicator_${status.name.lowercase()}")
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.size(if (compact) 10.dp else 12.dp)
        ) {
            if (status == UserPresenceStatus.ONLINE) {
                Box(
                    modifier = Modifier
                        .size(if (compact) 10.dp else 12.dp)
                        .clip(CircleShape)
                        .background(dotColor.copy(alpha = pulseAlpha))
                )
            }
            Box(
                modifier = Modifier
                    .size(if (compact) 6.dp else 7.dp)
                    .clip(CircleShape)
                    .background(dotColor)
            )
        }
        Spacer(modifier = Modifier.width(if (compact) 4.dp else 5.dp))
        Text(
            text = status.labelRu,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = if (status == UserPresenceStatus.ONLINE) FontWeight.SemiBold else FontWeight.Medium,
            color = labelColor,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun EncryptionBadge(
    label: String = "E2EE",
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(50),
        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.14f),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.38f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Filled.Lock,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(11.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.primary,
                maxLines = 1,
                softWrap = false
            )
        }
    }
}

@Composable
fun RoleBadge(
    role: UserRole,
    compact: Boolean = false,
    modifier: Modifier = Modifier
) {
    if (role == UserRole.USER) return
    val isDev = role == UserRole.DEVELOPER
    val containerColor = if (isDev) {
        MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.85f)
    } else {
        MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.85f)
    }
    val contentColor = if (isDev) {
        MaterialTheme.colorScheme.onPrimaryContainer
    } else {
        MaterialTheme.colorScheme.onTertiaryContainer
    }
    val accentColor = if (isDev) {
        MaterialTheme.colorScheme.primary
    } else {
        MaterialTheme.colorScheme.tertiary
    }
    Surface(
        modifier = modifier.testTag("role_badge_${role.wireValue}"),
        shape = RoundedCornerShape(50),
        color = containerColor,
        border = BorderStroke(1.dp, accentColor.copy(alpha = 0.45f))
    ) {
        Row(
            modifier = Modifier.padding(
                horizontal = if (compact) 6.dp else 8.dp,
                vertical = if (compact) 2.dp else 3.dp
            ),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = if (isDev) Icons.Filled.Code else Icons.Filled.BugReport,
                contentDescription = role.labelRu,
                tint = accentColor,
                modifier = Modifier.size(if (compact) 11.dp else 13.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = if (compact) role.shortBadge else role.labelRu,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.SemiBold,
                color = contentColor,
                maxLines = 1,
                softWrap = false
            )
        }
    }
}

@Composable
fun VoiceWaveformRow(
    bars: List<Int>,
    progress: Float,
    isPlaying: Boolean,
    onTogglePlay: () -> Unit,
    durationLabel: String,
    accentColor: Color,
    trackColor: Color,
    textColor: Color,
    modifier: Modifier = Modifier
) {
    val safeBars = if (bars.isEmpty()) List(24) { 25 } else bars
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(
            onClick = onTogglePlay,
            colors = IconButtonDefaults.iconButtonColors(
                containerColor = accentColor,
                contentColor = MaterialTheme.colorScheme.onPrimary
            ),
            modifier = Modifier
                .size(48.dp)
                .testTag("voice_play_button")
        ) {
            Icon(
                imageVector = if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                contentDescription = if (isPlaying) "Пауза" else "Воспроизвести"
            )
        }
        Spacer(modifier = Modifier.width(10.dp))
        Column(modifier = Modifier.weight(1f)) {
            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(28.dp)
            ) {
                val count = safeBars.size.coerceAtLeast(1)
                val gap = 3.dp.toPx()
                val totalGap = gap * (count - 1)
                val barW = ((size.width - totalGap) / count).coerceAtLeast(2.dp.toPx())
                safeBars.forEachIndexed { idx, amp ->
                    val frac = idx.toFloat() / count.toFloat()
                    val active = frac <= progress && (isPlaying || progress > 0f)
                    val h = (size.height * (amp.coerceIn(12, 100) / 100f)).coerceAtLeast(4.dp.toPx())
                    val x = idx * (barW + gap)
                    val y = (size.height - h) / 2f
                    drawRoundRect(
                        color = if (active) accentColor else trackColor,
                        topLeft = Offset(x, y),
                        size = Size(barW, h),
                        cornerRadius = CornerRadius(barW / 2f, barW / 2f)
                    )
                }
            }
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = durationLabel,
                style = MaterialTheme.typography.labelSmall,
                color = textColor.copy(alpha = 0.8f)
            )
        }
    }
}

@Composable
fun IncomingOrActiveCallBanner(
    call: CallSession,
    currentUserId: String,
    onAcceptOrJoin: () -> Unit,
    onDecline: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isAlreadyIn = currentUserId in call.activeParticipantUids
    val pulse = rememberInfiniteTransition(label = "call_pulse")
    val alpha by pulse.animateFloat(
        initialValue = 0.7f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(750), RepeatMode.Reverse),
        label = "pulse_alpha"
    )
    val bgColor by animateColorAsState(
        targetValue = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = alpha),
        label = "banner_bg"
    )

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .testTag("incoming_call_banner"),
        shape = RoundedCornerShape(20.dp),
        color = bgColor,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.secondary.copy(alpha = 0.55f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Surface(
                    shape = CircleShape,
                    color = MaterialTheme.colorScheme.secondary,
                    modifier = Modifier.size(40.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = if (call.callType == "video") Icons.Filled.Videocam else Icons.Filled.Call,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSecondary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = if (call.isGroupCall) "Групповой звонок • ${call.conversationTitle}" else call.callerName,
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.onSecondaryContainer,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = if (call.status == "ringing" && !isAlreadyIn) {
                            if (call.callType == "video") "Входящий видеозвонок" else "Входящий аудиозвонок"
                        } else {
                            "Активный звонок • участников: ${call.activeParticipantUids.size}"
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.85f)
                    )
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (!isAlreadyIn && call.callerId != currentUserId) {
                    IconButton(
                        onClick = onDecline,
                        colors = IconButtonDefaults.iconButtonColors(
                            containerColor = MaterialTheme.colorScheme.error,
                            contentColor = MaterialTheme.colorScheme.onError
                        ),
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("decline_call_button")
                    ) {
                        Icon(Icons.Filled.CallEnd, contentDescription = "Отклонить звонок")
                    }
                }
                Button(
                    onClick = onAcceptOrJoin,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    ),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .height(48.dp)
                        .testTag("accept_call_button")
                ) {
                    Text(
                        text = if (isAlreadyIn) "Вернуться" else "Ответить",
                        style = MaterialTheme.typography.labelLarge
                    )
                }
            }
        }
    }
}

fun formatDurationMillis(ms: Long): String {
    val totalSec = (ms / 1000L).coerceAtLeast(0L)
    val mins = totalSec / 60L
    val secs = totalSec % 60L
    return "%d:%02d".format(mins, secs)
}

fun formatMuteRemaining(mutedUntilEpochMs: Long, nowMs: Long = System.currentTimeMillis()): String {
    if (mutedUntilEpochMs <= 0L) return "бессрочно"
    val diffMs = (mutedUntilEpochMs - nowMs).coerceAtLeast(0L)
    if (diffMs == 0L) return "истёк"
    val totalMin = (diffMs / 60_000L).coerceAtLeast(1L)
    return when {
        totalMin >= 1440L -> "${totalMin / 1440L} дн."
        totalMin >= 60L -> "${totalMin / 60L} ч."
        else -> "$totalMin мин."
    }
}

@Composable
fun ModerationStatusChip(
    status: ModerationStatus,
    mutedUntilEpochMs: Long = 0L,
    compact: Boolean = false,
    modifier: Modifier = Modifier
) {
    if (status == ModerationStatus.ACTIVE) return
    val isBanned = status == ModerationStatus.BANNED
    val containerColor = if (isBanned) {
        MaterialTheme.colorScheme.errorContainer
    } else {
        MaterialTheme.colorScheme.tertiaryContainer
    }
    val contentColor = if (isBanned) {
        MaterialTheme.colorScheme.onErrorContainer
    } else {
        MaterialTheme.colorScheme.onTertiaryContainer
    }
    val accentColor = if (isBanned) {
        MaterialTheme.colorScheme.error
    } else {
        MaterialTheme.colorScheme.tertiary
    }
    val label = if (isBanned) {
        "Заблокирован"
    } else if (compact) {
        "Мут"
    } else {
        "Мут (${formatMuteRemaining(mutedUntilEpochMs)})"
    }

    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(50),
        color = containerColor,
        border = BorderStroke(1.dp, accentColor.copy(alpha = 0.5f))
    ) {
        Row(
            modifier = Modifier.padding(
                horizontal = if (compact) 6.dp else 8.dp,
                vertical = if (compact) 2.dp else 3.dp
            ),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = if (isBanned) Icons.Filled.Block else Icons.Filled.VolumeOff,
                contentDescription = label,
                tint = accentColor,
                modifier = Modifier.size(if (compact) 11.dp else 13.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.SemiBold,
                color = contentColor,
                maxLines = 1
            )
        }
    }
}

@Composable
fun UnreadCountBadge(
    count: Int,
    modifier: Modifier = Modifier
) {
    if (count <= 0) return
    val text = if (count > 99) "99+" else count.toString()
    Surface(
        modifier = modifier.testTag("unread_count_badge"),
        shape = RoundedCornerShape(50),
        color = MaterialTheme.colorScheme.primary
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.padding(horizontal = if (text.length == 1) 7.dp else 6.dp, vertical = 2.dp)
        ) {
            Text(
                text = text,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onPrimary,
                maxLines = 1
            )
        }
    }
}

@Composable
fun ReadReceiptIcon(
    isRead: Boolean,
    tint: Color,
    modifier: Modifier = Modifier
) {
    Icon(
        imageVector = if (isRead) Icons.Filled.DoneAll else Icons.Filled.Done,
        contentDescription = if (isRead) "Прочитано" else "Доставлено, не прочитано",
        tint = if (isRead) MaterialTheme.colorScheme.primary else tint,
        modifier = modifier.size(15.dp)
    )
}

@Composable
fun InAppMessageAlertBanner(
    title: String,
    body: String,
    unreadCount: Int,
    onOpen: () -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .statusBarsPadding()
            .padding(horizontal = 14.dp, vertical = 8.dp)
            .widthIn(max = 560.dp)
            .fillMaxWidth()
            .clickable(onClick = onOpen)
            .testTag("in_app_message_alert_banner"),
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surfaceContainerHigh,
        tonalElevation = 8.dp,
        shadowElevation = 8.dp,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.55f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                shape = CircleShape,
                color = MaterialTheme.colorScheme.primaryContainer,
                modifier = Modifier.size(38.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Filled.NotificationsActive,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    if (unreadCount > 0) {
                        UnreadCountBadge(count = unreadCount)
                    }
                }
                Text(
                    text = body,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            IconButton(
                onClick = onDismiss,
                modifier = Modifier.size(40.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.Close,
                    contentDescription = "Закрыть уведомление",
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

@Composable
fun AccountRestrictedScreen(
    isDeleted: Boolean,
    reason: String,
    onSignOut: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .navigationBarsPadding()
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.surfaceContainer,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.5f)),
            modifier = Modifier.widthIn(max = 460.dp)
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Surface(
                    shape = CircleShape,
                    color = MaterialTheme.colorScheme.errorContainer,
                    modifier = Modifier.size(68.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = if (isDeleted) Icons.Filled.DeleteForever else Icons.Filled.Block,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(34.dp)
                        )
                    }
                }
                Text(
                    text = if (isDeleted) "Аккаунт удалён" else "Аккаунт заблокирован",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
                Text(
                    text = if (isDeleted) {
                        "Администратор SpoX удалил ваш аккаунт. Доступ к чатам и отправке сообщений закрыт."
                    } else {
                        "Администратор SpoX ограничил доступ к вашему аккаунту."
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )
                if (reason.isNotBlank()) {
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.4f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "Причина: $reason",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onErrorContainer,
                            modifier = Modifier.padding(12.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
                Button(
                    onClick = onSignOut,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.error,
                        contentColor = MaterialTheme.colorScheme.onError
                    ),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("restricted_sign_out_button")
                ) {
                    Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Выйти из аккаунта")
                }
            }
        }
    }
}

