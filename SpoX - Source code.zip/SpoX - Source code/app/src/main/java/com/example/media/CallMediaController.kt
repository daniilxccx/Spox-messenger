package com.example.media

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioFocusRequest
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.ToneGenerator
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.AutomaticGainControl
import android.media.audiofx.NoiseSuppressor
import android.os.Build
import android.os.Process
import android.util.Base64
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * Full-duplex voice call media engine:
 * - Captures 16 kHz mono PCM with hardware AcousticEchoCanceler / NoiseSuppressor / AGC
 * - Compresses speech chunks (240 ms) via IMA-ADPCM with sensitive VAD + hangover
 * - Plays incoming peer audio through a jitter-buffered multi-speaker AudioTrack mixer
 */
class CallMediaController(private val context: Context) {

    companion object {
        const val SAMPLE_RATE = 16_000
        private const val CHUNK_SAMPLES = 3_840 // 240 ms @ 16 kHz
        private const val SUB_READ_SAMPLES = 320 // 20 ms capture ticks for fast mute/level response
        private const val PLAYBACK_TICK_SAMPLES = 320 // 20 ms playback mix frames
        private const val JITTER_PREROLL_SAMPLES = 1_280 // 80 ms low-latency jitter cushion
        private const val JITTER_MAX_SAMPLES = 9_600 // 600 ms real-time cap
        private const val VOICE_PEAK_THRESHOLD = 160
        private const val HANGOVER_CHUNKS = 3 // ~720 ms voice tail before pausing TX to save game bandwidth
    }

    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private var audioFocusRequest: AudioFocusRequest? = null
    private var toneGenerator: ToneGenerator? = null

    private var audioRecord: AudioRecord? = null
    private var echoCanceler: AcousticEchoCanceler? = null
    private var noiseSuppressor: NoiseSuppressor? = null
    private var gainControl: AutomaticGainControl? = null
    private var captureJob: Job? = null

    private var audioTrack: AudioTrack? = null
    private var playbackThread: Thread? = null
    private val isPlaybackRunning = AtomicBoolean(false)

    private class SpeakerJitterBuffer {
        val lock = Any()
        val chunks = ArrayDeque<ShortArray>()
        var headOffset = 0
        var totalSamples = 0
        var lastSeq = -1L
        var primed = false
    }

    private val speakerBuffers = ConcurrentHashMap<String, SpeakerJitterBuffer>()

    fun hasConnectedHeadset(): Boolean {
        return runCatching {
            val outputs = audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
            outputs.any { device ->
                device.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO ||
                    device.type == AudioDeviceInfo.TYPE_BLE_HEADSET ||
                    device.type == AudioDeviceInfo.TYPE_WIRED_HEADSET ||
                    device.type == AudioDeviceInfo.TYPE_WIRED_HEADPHONES ||
                    device.type == AudioDeviceInfo.TYPE_USB_HEADSET
            }
        }.getOrDefault(false)
    }

    fun enterCallAudioMode(speakerOn: Boolean) {
        runCatching {
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                // MAY_DUCK keeps game audio playing smoothly alongside voice call
                val focusReq = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                    .setAudioAttributes(attrs)
                    .setAcceptsDelayedFocusGain(true)
                    .setOnAudioFocusChangeListener { }
                    .build()
                audioFocusRequest = focusReq
                audioManager.requestAudioFocus(focusReq)
            } else {
                @Suppress("DEPRECATION")
                audioManager.requestAudioFocus(
                    null,
                    AudioManager.STREAM_VOICE_CALL,
                    AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK
                )
            }
            audioManager.mode = AudioManager.MODE_IN_COMMUNICATION
            setSpeakerphone(speakerOn)
        }
    }

    fun setSpeakerphone(enabled: Boolean) {
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val devices = audioManager.availableCommunicationDevices
                val targetDevice = if (enabled) {
                    devices.firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER }
                } else {
                    devices.firstOrNull {
                        it.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO ||
                            it.type == AudioDeviceInfo.TYPE_BLE_HEADSET ||
                            it.type == AudioDeviceInfo.TYPE_WIRED_HEADSET ||
                            it.type == AudioDeviceInfo.TYPE_WIRED_HEADPHONES
                    } ?: devices.firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_EARPIECE }
                }
                if (targetDevice != null) {
                    audioManager.setCommunicationDevice(targetDevice)
                } else if (!enabled) {
                    audioManager.clearCommunicationDevice()
                }
            }
            @Suppress("DEPRECATION")
            audioManager.isSpeakerphoneOn = enabled
        }
    }

    fun playRingTonePulse() {
        runCatching {
            if (toneGenerator == null) {
                toneGenerator = ToneGenerator(AudioManager.STREAM_VOICE_CALL, 55)
            }
            toneGenerator?.startTone(ToneGenerator.TONE_SUP_RINGTONE, 350)
        }
    }

    fun playEndCallTone() {
        runCatching {
            ToneGenerator(AudioManager.STREAM_VOICE_CALL, 60).apply {
                startTone(ToneGenerator.TONE_PROP_PROMPT, 220)
            }
        }
    }

    fun startAudioPlayback() {
        if (isPlaybackRunning.getAndSet(true)) return

        val minTrackBuf = AudioTrack.getMinBufferSize(
            SAMPLE_RATE,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        ).coerceAtLeast(PLAYBACK_TICK_SAMPLES * 2 * 4)

        val track = runCatching {
            val builder = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(SAMPLE_RATE)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(minTrackBuf)
                .setTransferMode(AudioTrack.MODE_STREAM)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                builder.setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
            }
            builder.build()
        }.getOrNull()

        if (track == null || track.state != AudioTrack.STATE_INITIALIZED) {
            runCatching { track?.release() }
            isPlaybackRunning.set(false)
            return
        }

        audioTrack = track
        runCatching {
            track.setVolume(AudioTrack.getMaxVolume())
            track.play()
        }

        playbackThread = Thread({
            Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO)
            val mixAccum = IntArray(PLAYBACK_TICK_SAMPLES)
            val mixOut = ShortArray(PLAYBACK_TICK_SAMPLES)

            while (isPlaybackRunning.get()) {
                mixAccum.fill(0)
                var hasAnyAudio = false

                for ((_, buf) in speakerBuffers) {
                    synchronized(buf.lock) {
                        if (!buf.primed) return@synchronized
                        if (buf.totalSamples <= 0) {
                            buf.primed = false
                            return@synchronized
                        }
                        var outIdx = 0
                        while (outIdx < PLAYBACK_TICK_SAMPLES && buf.chunks.isNotEmpty()) {
                            val head = buf.chunks.first()
                            val available = head.size - buf.headOffset
                            val take = minOf(PLAYBACK_TICK_SAMPLES - outIdx, available)
                            for (k in 0 until take) {
                                mixAccum[outIdx + k] += head[buf.headOffset + k].toInt()
                            }
                            buf.headOffset += take
                            buf.totalSamples -= take
                            outIdx += take
                            if (buf.headOffset >= head.size) {
                                buf.chunks.removeFirst()
                                buf.headOffset = 0
                            }
                        }
                        if (outIdx > 0) hasAnyAudio = true
                        if (buf.totalSamples == 0) {
                            buf.primed = false
                        }
                    }
                }

                if (hasAnyAudio) {
                    for (i in 0 until PLAYBACK_TICK_SAMPLES) {
                        mixOut[i] = mixAccum[i].coerceIn(-32768, 32767).toShort()
                    }
                    val written = runCatching {
                        track.write(mixOut, 0, PLAYBACK_TICK_SAMPLES, AudioTrack.WRITE_BLOCKING)
                    }.getOrDefault(-1)

                    if (written < 0) {
                        break
                    }
                } else {
                    // Light idle sleep while no remote speaker is active to preserve game CPU/FPS
                    runCatching { Thread.sleep(16L) }
                }
            }
        }, "SpoX-CallPlayback").apply {
            isDaemon = true
            start()
        }
    }

    fun enqueueIncomingAudio(senderId: String, seq: Long, payloadBase64: String) {
        if (senderId.isBlank() || payloadBase64.isBlank()) return
        val encoded = runCatching { Base64.decode(payloadBase64, Base64.DEFAULT) }.getOrNull() ?: return
        val pcm = ImaAdpcmCodec.decode(encoded)
        if (pcm.isEmpty()) return

        val buf = speakerBuffers.getOrPut(senderId) { SpeakerJitterBuffer() }
        synchronized(buf.lock) {
            if (buf.lastSeq >= 0L && seq <= buf.lastSeq) {
                // Allow sequence reset if peer rejoined the call (seq jumped far back)
                if (buf.lastSeq - seq < 10L) {
                    return
                }
                buf.chunks.clear()
                buf.headOffset = 0
                buf.totalSamples = 0
                buf.primed = false
            }
            buf.lastSeq = seq

            // Trim excessive backlog so voice stays real-time even after brief network stalls
            while (buf.totalSamples + pcm.size > JITTER_MAX_SAMPLES && buf.chunks.isNotEmpty()) {
                val dropped = buf.chunks.removeFirst()
                buf.totalSamples -= (dropped.size - buf.headOffset)
                buf.headOffset = 0
            }

            buf.chunks.addLast(pcm)
            buf.totalSamples += pcm.size
            if (!buf.primed && buf.totalSamples >= JITTER_PREROLL_SAMPLES) {
                buf.primed = true
            }
        }
    }

    fun stopAudioPlayback() {
        isPlaybackRunning.set(false)
        runCatching { audioTrack?.pause() }
        runCatching { audioTrack?.flush() }
        runCatching { playbackThread?.join(350) }
        playbackThread = null
        runCatching { audioTrack?.stop() }
        runCatching { audioTrack?.release() }
        audioTrack = null
        speakerBuffers.clear()
    }

    @SuppressLint("MissingPermission")
    fun startMicCapture(
        scope: CoroutineScope,
        isMutedProvider: () -> Boolean,
        canTransmitProvider: () -> Boolean,
        onLevelSampled: (Int, Boolean) -> Unit,
        onEncodedFrameCaptured: (seq: Long, payloadBase64: String) -> Unit
    ) {
        stopMicCapture()

        val minRecBuf = AudioRecord.getMinBufferSize(
            SAMPLE_RATE,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        ).coerceAtLeast(CHUNK_SAMPLES * 2 * 2)

        val record = runCatching {
            AudioRecord(
                MediaRecorder.AudioSource.VOICE_COMMUNICATION,
                SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                minRecBuf
            )
        }.getOrNull() ?: return

        if (record.state != AudioRecord.STATE_INITIALIZED) {
            record.release()
            return
        }

        // Bind hardware acoustic echo canceler, noise suppressor, and AGC
        runCatching {
            if (AcousticEchoCanceler.isAvailable()) {
                echoCanceler = AcousticEchoCanceler.create(record.audioSessionId)?.apply {
                    enabled = true
                }
            }
            if (NoiseSuppressor.isAvailable()) {
                noiseSuppressor = NoiseSuppressor.create(record.audioSessionId)?.apply {
                    enabled = true
                }
            }
            if (AutomaticGainControl.isAvailable()) {
                gainControl = AutomaticGainControl.create(record.audioSessionId)?.apply {
                    enabled = true
                }
            }
        }

        audioRecord = record
        runCatching { record.startRecording() }

        captureJob = scope.launch(Dispatchers.IO) {
            Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO)
            val subBuf = ShortArray(SUB_READ_SAMPLES)
            val chunkBuf = ShortArray(CHUNK_SAMPLES)
            var chunkOffset = 0
            var chunkPeak = 0
            var seq = 0L
            var hangoverRemaining = 0
            var lastLevelUiAt = 0L

            while (isActive) {
                val read = runCatching {
                    record.read(subBuf, 0, SUB_READ_SAMPLES, AudioRecord.READ_BLOCKING)
                }.getOrDefault(-1)

                if (read <= 0) {
                    if (read < 0) break
                    continue
                }

                val muted = isMutedProvider()
                if (muted) {
                    chunkOffset = 0
                    chunkPeak = 0
                    hangoverRemaining = 0
                    val now = System.currentTimeMillis()
                    if (now - lastLevelUiAt >= 200L) {
                        lastLevelUiAt = now
                        onLevelSampled(0, false)
                    }
                    continue
                }

                var subPeak = 0
                for (i in 0 until read) {
                    val sample = subBuf[i]
                    val absVal = abs(sample.toInt())
                    if (absVal > subPeak) subPeak = absVal
                    if (chunkOffset < CHUNK_SAMPLES) {
                        chunkBuf[chunkOffset++] = sample
                    }
                }
                if (subPeak > chunkPeak) chunkPeak = subPeak

                val now = System.currentTimeMillis()
                if (now - lastLevelUiAt >= 180L) {
                    lastLevelUiAt = now
                    val level = ((chunkPeak / 14000f) * 100f).roundToInt().coerceIn(0, 100)
                    onLevelSampled(level, chunkPeak >= VOICE_PEAK_THRESHOLD)
                }

                if (chunkOffset >= CHUNK_SAMPLES) {
                    val hasSpeech = chunkPeak >= VOICE_PEAK_THRESHOLD
                    if (hasSpeech) {
                        hangoverRemaining = HANGOVER_CHUNKS
                    } else if (hangoverRemaining > 0) {
                        hangoverRemaining--
                    }

                    if (canTransmitProvider() && (hasSpeech || hangoverRemaining > 0)) {
                        val compressed = ImaAdpcmCodec.encode(chunkBuf, CHUNK_SAMPLES)
                        if (compressed.isNotEmpty()) {
                            val b64 = Base64.encodeToString(compressed, Base64.NO_WRAP)
                            onEncodedFrameCaptured(seq++, b64)
                        }
                    }

                    chunkOffset = 0
                    chunkPeak = 0
                }
            }
        }
    }

    fun stopMicCapture() {
        captureJob?.cancel()
        captureJob = null
        runCatching { echoCanceler?.release() }
        echoCanceler = null
        runCatching { noiseSuppressor?.release() }
        noiseSuppressor = null
        runCatching { gainControl?.release() }
        gainControl = null
        runCatching { audioRecord?.stop() }
        runCatching { audioRecord?.release() }
        audioRecord = null
    }

    fun release() {
        stopMicCapture()
        stopAudioPlayback()
        runCatching {
            toneGenerator?.release()
            toneGenerator = null
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                audioManager.clearCommunicationDevice()
            }
            @Suppress("DEPRECATION")
            audioManager.isSpeakerphoneOn = false
            audioManager.mode = AudioManager.MODE_NORMAL
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                audioFocusRequest?.let { audioManager.abandonAudioFocusRequest(it) }
                audioFocusRequest = null
            } else {
                @Suppress("DEPRECATION")
                audioManager.abandonAudioFocus(null)
            }
        }
    }
}
