package com.example.data.model

import com.google.firebase.Timestamp
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ConversationModelTest {

    @Test
    fun isCreator_matchesCreatedByUidOnly() {
        val conv = Conversation(
            id = "grp_1",
            isGroup = true,
            title = "Команда",
            description = "Рабочий чат",
            createdBy = "uid_alice",
            memberUids = listOf("uid_alice", "uid_bob")
        )
        assertTrue(conv.isCreator("uid_alice"))
        assertFalse(conv.isCreator("uid_bob"))
        assertFalse(conv.isCreator(""))
    }

    @Test
    fun unreadAndReadReceipt_trackCountsAndTimestampsPerMember() {
        val conv = Conversation(
            id = "dm_1",
            isGroup = false,
            memberUids = listOf("uid_alice", "uid_bob"),
            unreadCounts = mapOf("uid_alice" to 0L, "uid_bob" to 3L),
            lastMessageSenderId = "uid_alice",
            lastMessageType = "text",
            updatedAt = Timestamp(1_700_000_010L, 0),
            lastReadAtMillis = mapOf("uid_alice" to 1_700_000_010_000L, "uid_bob" to 1_700_000_005_000L)
        )

        assertEquals(0, conv.unreadCountFor("uid_alice"))
        assertEquals(3, conv.unreadCountFor("uid_bob"))
        assertFalse(conv.isLastMessageReadByOther("uid_alice"))

        val afterBobReads = conv.copy(
            unreadCounts = mapOf("uid_alice" to 0L, "uid_bob" to 0L),
            lastReadAtMillis = mapOf("uid_alice" to 1_700_000_010_000L, "uid_bob" to 1_700_000_012_000L)
        )
        assertTrue(afterBobReads.isLastMessageReadByOther("uid_alice"))
    }

    @Test
    fun isSavedMessages_detectsSelfChatOrSavedId() {
        val byId = Conversation(id = "saved_uid_alice", isGroup = false, memberUids = listOf("uid_alice"))
        val byMembers = Conversation(id = "custom_1", isGroup = false, memberUids = listOf("uid_alice"))
        val regularDm = Conversation(id = "dm_ab", isGroup = false, memberUids = listOf("uid_alice", "uid_bob"))

        assertTrue(byId.isSavedMessages("uid_alice"))
        assertTrue(byMembers.isSavedMessages("uid_alice"))
        assertFalse(regularDm.isSavedMessages("uid_alice"))
    }
}
