package com.example.security

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class AppLockManagerTest {

    private lateinit var manager: AppLockManager

    @Before
    fun setUp() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        context.getSharedPreferences("spox_app_lock_prefs", Context.MODE_PRIVATE)
            .edit()
            .clear()
            .commit()
        manager = AppLockManager(context)
    }

    @Test
    fun pinLifecycle_setVerifyAndDisable() {
        val uid = "user_alpha"
        assertFalse(manager.isPinEnabled(uid))
        assertFalse(manager.hasAnyLockEnabled(uid))

        manager.setPin(uid, "2580")

        assertTrue(manager.isPinEnabled(uid))
        assertTrue(manager.hasAnyLockEnabled(uid))
        assertTrue(manager.verifyPin(uid, "2580"))
        assertFalse(manager.verifyPin(uid, "0000"))
        assertFalse(manager.verifyPin(uid, "258"))
        assertFalse(manager.verifyPin(uid, "25801"))

        manager.disablePin(uid)
        assertFalse(manager.isPinEnabled(uid))
        assertFalse(manager.verifyPin(uid, "2580"))
        assertFalse(manager.hasAnyLockEnabled(uid))
    }

    @Test
    fun perUserIsolation_andBiometricFlag() {
        manager.setPin("user_1", "1379")
        manager.setBiometricEnabled("user_2", true)

        assertTrue(manager.isPinEnabled("user_1"))
        assertFalse(manager.isBiometricEnabled("user_1"))
        assertTrue(manager.verifyPin("user_1", "1379"))

        assertFalse(manager.isPinEnabled("user_2"))
        assertTrue(manager.isBiometricEnabled("user_2"))
        assertTrue(manager.hasAnyLockEnabled("user_2"))
        assertFalse(manager.verifyPin("user_2", "1379"))

        manager.clearAllForUser("user_1")
        assertFalse(manager.hasAnyLockEnabled("user_1"))
        assertTrue(manager.hasAnyLockEnabled("user_2"))
    }

    @Test
    fun invalidPinFormat_isRejected() {
        assertThrows(IllegalArgumentException::class.java) {
            manager.setPin("user_x", "12a4")
        }
        assertThrows(IllegalArgumentException::class.java) {
            manager.setPin("user_x", "123")
        }
    }

    @Test
    fun loadUserLockStateAsync_and_getBiometricCapabilityAsync_returnValidResults() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        manager.setPin("async_user", "4321")
        manager.setBiometricEnabled("async_user", true)

        val state = manager.loadUserLockStateAsync("async_user")
        assertEquals(true to true, state)

        val capability = manager.getBiometricCapabilityAsync(context)
        assertNotNull(capability)
    }
}
