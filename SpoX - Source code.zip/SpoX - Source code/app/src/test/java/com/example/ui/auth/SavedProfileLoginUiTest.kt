package com.example.ui.auth

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import com.example.data.model.AppThemeMode
import com.example.data.repository.SavedAccount
import com.example.ui.screens.AccountSwitcherSheet
import com.example.ui.theme.CipherChatTheme
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class SavedProfileLoginUiTest {

    @get:Rule
    val composeRule = createComposeRule()

    @Test
    fun authScreen_showsEmailAlongsideHandleAndEntersImmediatelyOnLiveSavedProfile() {
        val accLive = SavedAccount(
            uid = "uid_live",
            email = "alex.work@gmail.com",
            displayName = "Alex Work",
            handle = "alex_w"
        )
        val accSignedOut = SavedAccount(
            uid = "uid_out",
            email = "alex.personal@gmail.com",
            displayName = "Alex Personal",
            handle = "@alex_p"
        )
        var quickSelectedUid: String? = null
        var authSucceeded = false

        composeRule.setContent {
            CipherChatTheme(themeMode = AppThemeMode.DARK) {
                AuthScreen(
                    themeMode = AppThemeMode.DARK,
                    onToggleTheme = {},
                    savedAccounts = listOf(accLive, accSignedOut),
                    skipAutoSignIn = true,
                    canAutoSignIn = false,
                    hasLiveSession = { it.uid == accLive.uid },
                    onQuickSelectSavedAccount = { acc, onDone, _ ->
                        quickSelectedUid = acc.uid
                        onDone()
                    },
                    onAuthSuccess = { authSucceeded = true }
                )
            }
        }

        // Both @handle and Google email must be visible on AuthScreen cards
        composeRule.onNodeWithText("@alex_w • alex.work@gmail.com").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithText("Сессия активна • вход сразу").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithText("@alex_p • alex.personal@gmail.com").performScrollTo().assertIsDisplayed()

        // Tapping the live saved profile enters immediately without Google chooser
        composeRule.onNodeWithTag("auth_saved_account_uid_live").performScrollTo().performClick()
        composeRule.waitForIdle()

        assertEquals("uid_live", quickSelectedUid)
        assertTrue(authSucceeded)
    }

    @Test
    fun accountSwitcherSheet_displaysInstantSwitchHintAndCallsOnSwitchAccount() {
        val current = SavedAccount(
            uid = "uid_1",
            email = "one@gmail.com",
            displayName = "Profile One",
            handle = "@one"
        )
        val other = SavedAccount(
            uid = "uid_2",
            email = "two@gmail.com",
            displayName = "Profile Two",
            handle = "@two"
        )
        var switchedTargetUid: String? = null
        var dismissed = false

        composeRule.setContent {
            CipherChatTheme(themeMode = AppThemeMode.DARK) {
                AccountSwitcherSheet(
                    accounts = listOf(current, other),
                    currentUserId = current.uid,
                    isSwitching = false,
                    hasLiveSession = { it.uid == other.uid },
                    onDismiss = { dismissed = true },
                    onSwitchAccount = { acc, onDone, _ ->
                        switchedTargetUid = acc.uid
                        onDone()
                    },
                    onAddAccount = { _, _ -> },
                    onRemoveAccount = {},
                    onSignOutCurrent = {}
                )
            }
        }

        composeRule.onNodeWithText("@two • two@gmail.com").assertIsDisplayed()
        composeRule.onNodeWithText("Вход сразу • без выбора Google").assertIsDisplayed()

        composeRule.onNodeWithTag("switch_account_card_uid_2").performClick()
        composeRule.waitForIdle()

        assertEquals("uid_2", switchedTargetUid)
        assertTrue(dismissed)
    }
}
