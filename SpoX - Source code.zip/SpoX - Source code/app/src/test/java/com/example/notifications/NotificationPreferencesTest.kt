package com.example.notifications

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class NotificationPreferencesTest {

    private lateinit var context: Context

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        context.getSharedPreferences("spox_notification_prefs", Context.MODE_PRIVATE)
            .edit()
            .clear()
            .commit()
        ActiveChatTracker.isAppInForeground = false
        ActiveChatTracker.activeChatId = null
    }

    @Test
    fun pushTogglesAndTokenPersistence() {
        assertTrue(NotificationPreferences.isMessagePushEnabled(context))
        assertTrue(NotificationPreferences.isCallPushEnabled(context))

        NotificationPreferences.setMessagePushEnabled(context, false)
        NotificationPreferences.setCallPushEnabled(context, false)
        assertFalse(NotificationPreferences.isMessagePushEnabled(context))
        assertFalse(NotificationPreferences.isCallPushEnabled(context))

        NotificationPreferences.saveFcmToken(context, "fcm_token_sample_123")
        assertEquals("fcm_token_sample_123", NotificationPreferences.getFcmToken(context))
    }

    @Test
    fun notifiedTimestampCursorIsMonotonicPerUserAndChat() {
        val uid = "uid_1"
        val chatId = "dm_1_2"
        assertEquals(0L, NotificationPreferences.getLastNotifiedMs(context, uid, chatId))

        NotificationPreferences.markChatNotified(context, uid, chatId, 2000L)
        assertEquals(2000L, NotificationPreferences.getLastNotifiedMs(context, uid, chatId))

        // Older timestamps must not regress the deduplication cursor
        NotificationPreferences.markChatNotified(context, uid, chatId, 1500L)
        assertEquals(2000L, NotificationPreferences.getLastNotifiedMs(context, uid, chatId))

        NotificationPreferences.markChatNotified(context, uid, chatId, 3500L)
        assertEquals(3500L, NotificationPreferences.getLastNotifiedMs(context, uid, chatId))
        assertEquals(0L, NotificationPreferences.getLastNotifiedMs(context, "uid_2", chatId))
    }

    @Test
    fun activeChatTrackerDetectsForegroundViewing() {
        assertFalse(ActiveChatTracker.isActivelyViewingChat("chat_a"))

        ActiveChatTracker.activeChatId = "chat_a"
        assertFalse(ActiveChatTracker.isActivelyViewingChat("chat_a"))

        ActiveChatTracker.isAppInForeground = true
        assertTrue(ActiveChatTracker.isActivelyViewingChat("chat_a"))
        assertFalse(ActiveChatTracker.isActivelyViewingChat("chat_b"))
    }
}
