package com.example.ui

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithText
import com.example.ui.components.TopNetworkStatusHeaderContent
import com.example.ui.components.TopRoomNetworkStatusPill
import com.example.ui.theme.CipherChatTheme
import com.example.ui.viewmodel.NetworkSyncPhase
import com.example.ui.viewmodel.TopStatusUiState
import com.example.ui.viewmodel.resolveTopStatusUiState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class TopNetworkStatusTest {

    @get:Rule
    val composeRule = createComposeRule()

    @Test
    fun resolveTopStatusUiState_returnsWaitingForNetworkWheneverOffline() {
        val offlineWhileCached = resolveTopStatusUiState(
            isNetworkConnected = false,
            isVerifyingAccount = false,
            isConversationsFromCache = false,
            isRefreshingOnReconnect = false,
            isConversationsLoading = false
        )
        assertEquals(NetworkSyncPhase.WAITING_FOR_NETWORK, offlineWhileCached.phase)
        assertFalse(offlineWhileCached.isNetworkConnected)

        val offlineWhileVerifying = resolveTopStatusUiState(
            isNetworkConnected = false,
            isVerifyingAccount = true,
            isConversationsFromCache = true,
            isRefreshingOnReconnect = true,
            isConversationsLoading = true
        )
        assertEquals(NetworkSyncPhase.WAITING_FOR_NETWORK, offlineWhileVerifying.phase)
        assertTrue(offlineWhileVerifying.isVerifyingAccount)
    }

    @Test
    fun resolveTopStatusUiState_returnsUpdatingWhileVerifyingOrSyncing() {
        val verifyingOnline = resolveTopStatusUiState(
            isNetworkConnected = true,
            isVerifyingAccount = true,
            isConversationsFromCache = false,
            isRefreshingOnReconnect = false,
            isConversationsLoading = false
        )
        assertEquals(NetworkSyncPhase.UPDATING, verifyingOnline.phase)
        assertTrue(verifyingOnline.isVerifyingAccount)

        val refreshingReconnect = resolveTopStatusUiState(
            isNetworkConnected = true,
            isVerifyingAccount = false,
            isConversationsFromCache = false,
            isRefreshingOnReconnect = true,
            isConversationsLoading = false
        )
        assertEquals(NetworkSyncPhase.UPDATING, refreshingReconnect.phase)

        val cacheWarming = resolveTopStatusUiState(
            isNetworkConnected = true,
            isVerifyingAccount = false,
            isConversationsFromCache = true,
            isRefreshingOnReconnect = false,
            isConversationsLoading = false
        )
        assertEquals(NetworkSyncPhase.UPDATING, cacheWarming.phase)
    }

    @Test
    fun resolveTopStatusUiState_returnsSyncedWhenOnlineAndFresh() {
        val synced = resolveTopStatusUiState(
            isNetworkConnected = true,
            isVerifyingAccount = false,
            isConversationsFromCache = false,
            isRefreshingOnReconnect = false,
            isConversationsLoading = false
        )
        assertEquals(NetworkSyncPhase.SYNCED, synced.phase)
        assertTrue(synced.isNetworkConnected)
        assertFalse(synced.isVerifyingAccount)
    }

    @Test
    fun topNetworkStatusHeader_displaysWaitingUpdatingAndAppName() {
        var currentState = TopStatusUiState(
            phase = NetworkSyncPhase.WAITING_FOR_NETWORK,
            isVerifyingAccount = true,
            isNetworkConnected = false
        )
        val stateHolder = androidx.compose.runtime.mutableStateOf(currentState)

        composeRule.setContent {
            CipherChatTheme {
                TopNetworkStatusHeaderContent(
                    topStatus = stateHolder.value,
                    isLiquidGlass = true
                )
            }
        }

        composeRule.onNodeWithText("Ожидание сети").assertIsDisplayed()
        composeRule.onNodeWithText("Проверка после подключения").assertIsDisplayed()

        stateHolder.value = TopStatusUiState(
            phase = NetworkSyncPhase.UPDATING,
            isVerifyingAccount = true,
            isNetworkConnected = true
        )
        composeRule.waitForIdle()
        composeRule.onNodeWithText("Обновление").assertIsDisplayed()
        composeRule.onNodeWithText("Проверка профиля...").assertIsDisplayed()

        stateHolder.value = TopStatusUiState(
            phase = NetworkSyncPhase.SYNCED,
            isVerifyingAccount = false,
            isNetworkConnected = true
        )
        composeRule.waitForIdle()
        composeRule.onNodeWithText("SpoX").assertIsDisplayed()
    }

    @Test
    fun topRoomNetworkStatusPill_displaysAllThreeNetworkPhases() {
        val stateHolder = androidx.compose.runtime.mutableStateOf(
            TopStatusUiState(
                phase = NetworkSyncPhase.WAITING_FOR_NETWORK,
                isVerifyingAccount = false,
                isNetworkConnected = false
            )
        )

        composeRule.setContent {
            CipherChatTheme {
                TopRoomNetworkStatusPill(
                    topStatus = stateHolder.value,
                    visible = true
                )
            }
        }

        composeRule.onNodeWithText("Ожидание сети").assertIsDisplayed()

        stateHolder.value = TopStatusUiState(
            phase = NetworkSyncPhase.UPDATING,
            isVerifyingAccount = false,
            isNetworkConnected = true
        )
        composeRule.waitForIdle()
        composeRule.onNodeWithText("Обновление").assertIsDisplayed()

        stateHolder.value = TopStatusUiState(
            phase = NetworkSyncPhase.SYNCED,
            isVerifyingAccount = false,
            isNetworkConnected = true
        )
        composeRule.waitForIdle()
        composeRule.onNodeWithText("SpoX").assertIsDisplayed()
    }
}
