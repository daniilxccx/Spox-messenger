package com.example

import android.content.Context
import android.content.Intent
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onAllNodesWithText
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.performClick
import androidx.test.core.app.ApplicationProvider
import androidx.work.Configuration
import com.example.data.model.AppThemeMode
import com.example.data.repository.ThemePreferenceStore
import com.example.ui.call.IncomingCallActivity
import com.google.firebase.FirebaseApp
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class MainActivityStartupTest {

    @get:Rule
    val composeRule = createAndroidComposeRule<MainActivity>()

    @Test
    fun spoXApplicationProvidesOnDemandWorkManagerConfiguration() {
        val app = ApplicationProvider.getApplicationContext<Context>()
        assertTrue(app is SpoXApplication)
        assertTrue(app is Configuration.Provider)
        val config = (app as Configuration.Provider).workManagerConfiguration
        assertNotNull(config)
    }

    @Test
    fun mainActivityStartsAndRendersWithoutCrashing() {
        val activity = composeRule.activity
        assertNotNull(activity)
        assertNotNull(FirebaseApp.getInstance())

        // Advance beyond the 800ms launch splash overlay
        composeRule.mainClock.advanceTimeBy(1200L)
        composeRule.waitForIdle()

        val spoxNodes = composeRule.onAllNodesWithText("SpoX").fetchSemanticsNodes()
        assert(spoxNodes.isNotEmpty())
    }

    @Test
    fun mainActivityAuthThemeTogglePersistsThemeSwitchEvenFromSystemMode() {
        val activity = composeRule.activity
        val store = ThemePreferenceStore(activity)
        runBlocking { store.setThemeMode(AppThemeMode.SYSTEM) }
        composeRule.waitForIdle()

        composeRule.onNodeWithTag("auth_theme_toggle_button")
            .assertIsDisplayed()
            .performClick()

        composeRule.waitUntil(timeoutMillis = 5_000L) {
            runBlocking { store.themeMode.first() != AppThemeMode.SYSTEM }
        }
        val firstMode = runBlocking { store.themeMode.first() }
        // Default Robolectric configuration is light mode, so SYSTEM -> DARK
        assertEquals(AppThemeMode.DARK, firstMode)

        composeRule.onNodeWithTag("auth_theme_toggle_button").performClick()
        composeRule.waitUntil(timeoutMillis = 5_000L) {
            runBlocking { store.themeMode.first() == AppThemeMode.LIGHT }
        }
        assertEquals(AppThemeMode.LIGHT, runBlocking { store.themeMode.first() })
    }

    @Test
    fun incomingCallActivityHandlesMissingExtrasGracefully() {
        val intent = Intent(
            ApplicationProvider.getApplicationContext(),
            IncomingCallActivity::class.java
        )
        val controller = Robolectric.buildActivity(IncomingCallActivity::class.java, intent).create()
        assertTrue(controller.get().isFinishing)
    }
}
