package com.example.ui.screens

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.assertIsSelected
import androidx.compose.ui.test.hasTestTag
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.test.performScrollToNode
import androidx.compose.ui.unit.dp
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.AppThemeMode
import com.example.data.model.CallSession
import com.example.data.model.ChatAppearanceConfig
import com.example.data.model.Conversation
import com.example.data.model.PublicUserProfile
import com.example.data.model.UserPrivateProfile
import com.example.security.AppLockManager
import com.example.security.BiometricCapability
import com.example.ui.components.MainBottomTab
import com.example.ui.components.SpoXBottomNavigationBar
import com.example.ui.theme.CipherChatTheme
import com.google.firebase.Timestamp
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class MainBottomNavAndCallsUiTest {

    @get:Rule
    val composeRule = createComposeRule()

    @Test
    fun bottomNavigationBar_displaysAllThreeSectionsAndSwitchesSelection_standardAndLiquidGlass() {
        var currentTab = MainBottomTab.CHATS
        var liquidGlass by mutableStateOf(false)

        composeRule.setContent {
            var selected by remember { mutableStateOf(MainBottomTab.CHATS) }
            CipherChatTheme(
                themeMode = AppThemeMode.DARK,
                appearanceConfig = ChatAppearanceConfig(liquidGlassEnabled = liquidGlass)
            ) {
                SpoXBottomNavigationBar(
                    selectedTab = selected,
                    onSelectTab = {
                        selected = it
                        currentTab = it
                    },
                    activeCallsCount = 1,
                    unreadChatsCount = 4,
                    hasAvailableUpdate = true
                )
            }
        }

        composeRule.waitForIdle()
        composeRule.onNodeWithTag("bottom_nav_bar").assertIsDisplayed()
        composeRule.onNodeWithText("Звонки").assertIsDisplayed()
        composeRule.onNodeWithText("Чаты").assertIsDisplayed()
        composeRule.onNodeWithText("Настройки").assertIsDisplayed()
        composeRule.onNodeWithTag("bottom_tab_chats").assertIsSelected()

        composeRule.onNodeWithTag("bottom_tab_calls").performClick()
        composeRule.waitForIdle()
        assertEquals(MainBottomTab.CALLS, currentTab)
        composeRule.onNodeWithTag("bottom_tab_calls").assertIsSelected()

        composeRule.onNodeWithTag("bottom_tab_settings").performClick()
        composeRule.waitForIdle()
        assertEquals(MainBottomTab.SETTINGS, currentTab)
        composeRule.onNodeWithTag("bottom_tab_settings").assertIsSelected()

        liquidGlass = true
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("bottom_nav_bar").assertIsDisplayed()
        composeRule.onNodeWithTag("bottom_tab_chats").performClick()
        composeRule.waitForIdle()
        assertEquals(MainBottomTab.CHATS, currentTab)
    }

    @Test
    fun callsTabContent_rendersActiveAndHistoryAndTriggersCallbacks() {
        val myUid = "user_me"
        val peer = PublicUserProfile(
            userId = "user_alex",
            displayName = "Алексей Смирнов",
            handle = "alex_sm",
            isOnline = true
        )
        val conv = Conversation(
            id = "dm_me_alex",
            isGroup = false,
            title = "Алексей Смирнов",
            memberUids = listOf(myUid, "user_alex")
        )
        val activeCall = CallSession(
            id = "call_live_1",
            conversationId = conv.id,
            conversationTitle = "Алексей Смирнов",
            callerId = "user_alex",
            callerName = "Алексей Смирнов",
            callType = "audio",
            status = "ringing",
            memberUids = listOf(myUid, "user_alex")
        )
        val endedVideoCall = CallSession(
            id = "call_hist_2",
            conversationId = conv.id,
            conversationTitle = "Алексей Смирнов",
            callerId = myUid,
            callerName = "Я",
            callType = "video",
            status = "ended",
            memberUids = listOf(myUid, "user_alex"),
            createdAt = Timestamp.now()
        )

        var joinedCallId: String? = null
        var startedConvCall: Pair<String, String>? = null
        var startedPeerCall: Pair<String, String>? = null
        var openedPicker = false

        composeRule.setContent {
            CipherChatTheme(themeMode = AppThemeMode.DARK, appearanceConfig = ChatAppearanceConfig()) {
                CallsTabContent(
                    currentUserId = myUid,
                    activeCalls = listOf(activeCall),
                    callHistory = listOf(activeCall, endedVideoCall),
                    conversations = listOf(conv),
                    directoryUsers = listOf(peer),
                    chatPeersMap = mapOf(peer.userId to peer),
                    presenceNowMs = System.currentTimeMillis(),
                    isBusy = false,
                    topPadding = 8.dp,
                    bottomPadding = 24.dp,
                    horizontalPadding = 16.dp,
                    smoothAppearance = false,
                    onJoinCall = { joinedCallId = it.id },
                    onDeclineCall = {},
                    onStartCallWithConversation = { c, type -> startedConvCall = c.id to type },
                    onStartCallWithPeer = { p, type -> startedPeerCall = p.userId to type },
                    onOpenStartCallSheet = { openedPicker = true }
                )
            }
        }

        composeRule.waitForIdle()
        composeRule.onNodeWithTag("calls_tab_content").assertIsDisplayed()
        composeRule.onNodeWithText("Звонки").assertIsDisplayed()
        composeRule.onNodeWithTag("call_history_card_call_hist_2").assertIsDisplayed()

        composeRule.onNodeWithTag("call_history_video_call_hist_2").performClick()
        assertEquals("dm_me_alex" to "video", startedConvCall)

        composeRule.onNodeWithTag("calls_filter_outgoing").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("call_history_card_call_hist_2").assertIsDisplayed()

        composeRule.onNodeWithTag("calls_filter_all").performClick()
        composeRule.onNodeWithTag("call_history_audio_call_live_1").performClick()
        assertEquals("call_live_1", joinedCallId)

        composeRule.onNodeWithTag("calls_tab_content")
            .performScrollToNode(hasTestTag("quick_call_peer_user_alex"))
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("quick_call_audio_user_alex").performClick()
        assertEquals("user_alex" to "audio", startedPeerCall)

        composeRule.onNodeWithTag("calls_tab_content")
            .performScrollToNode(hasTestTag("calls_header_new_call_button"))
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("calls_header_new_call_button").performClick()
        assertTrue(openedPicker)
    }

    @Test
    fun settingsTabContent_rendersProfileShortcutsAndControls() {
        val appContext = ApplicationProvider.getApplicationContext<android.content.Context>()
        val appLockManager = AppLockManager(appContext)
        var openedEditor = false
        var openedCustomization = false
        var openedPlugins = false
        var openedUpdates = false
        var discoverableChanged: Boolean? = null
        var signedOut = false

        composeRule.setContent {
            CipherChatTheme(themeMode = AppThemeMode.DARK, appearanceConfig = ChatAppearanceConfig()) {
                SettingsTabContent(
                    privateProfile = UserPrivateProfile(
                        userId = "u1",
                        displayName = "Даниил",
                        handle = "daniil",
                        email = "daniil@example.com"
                    ),
                    publicProfile = PublicUserProfile(
                        userId = "u1",
                        displayName = "Даниил",
                        handle = "daniil",
                        isDiscoverable = true
                    ),
                    fallbackEmail = "daniil@example.com",
                    fallbackDisplayName = "Даниил",
                    isPinEnabled = false,
                    isBiometricEnabled = false,
                    biometricCapability = BiometricCapability.NO_HARDWARE,
                    appLockManager = appLockManager,
                    isResourceSavingEnabled = false,
                    savedAccountsCount = 1,
                    activePluginsCount = 2,
                    hasAvailableUpdate = true,
                    latestUpdateVersion = "2.1",
                    canOpenModerationPanel = false,
                    isDeveloper = false,
                    adminUsersCount = 0,
                    customRolesCount = 0,
                    topPadding = 8.dp,
                    bottomPadding = 24.dp,
                    horizontalPadding = 16.dp,
                    smoothAppearance = false,
                    onOpenOwnProfile = {},
                    onOpenEditProfile = {},
                    onOpenAccountSwitcher = {},
                    onOpenMessengerEditor = { openedEditor = true },
                    onOpenCustomization = { openedCustomization = true },
                    onOpenPlugins = { openedPlugins = true },
                    onOpenUpdates = { openedUpdates = true },
                    onOpenModerationPanel = {},
                    onOpenCustomRoles = {},
                    onSetDiscoverable = { discoverableChanged = it },
                    onSetResourceSavingEnabled = {},
                    onSetPin = {},
                    onDisablePin = {},
                    onSetBiometricEnabled = {},
                    onLockAppNow = {},
                    onShowMessage = {},
                    onBiometricError = {},
                    onSignOut = { signedOut = true }
                )
            }
        }

        composeRule.waitForIdle()
        composeRule.onNodeWithTag("settings_profile_hero_card").assertIsDisplayed()
        composeRule.onNodeWithText("Даниил").assertIsDisplayed()

        composeRule.onNodeWithTag("settings_tab_messenger_editor_button").performScrollTo().performClick()
        assertTrue(openedEditor)

        composeRule.onNodeWithTag("settings_tab_customization_button").performScrollTo().performClick()
        assertTrue(openedCustomization)

        composeRule.onNodeWithTag("settings_tab_plugins_button").performScrollTo().performClick()
        assertTrue(openedPlugins)

        composeRule.onNodeWithTag("settings_tab_updates_button").performScrollTo().performClick()
        assertTrue(openedUpdates)

        composeRule.onNodeWithTag("discoverable_switch").performScrollTo().performClick()
        assertEquals(false, discoverableChanged)

        composeRule.onNodeWithTag("settings_tab_sign_out_button").performScrollTo().performClick()
        assertTrue(signedOut)
    }
}
