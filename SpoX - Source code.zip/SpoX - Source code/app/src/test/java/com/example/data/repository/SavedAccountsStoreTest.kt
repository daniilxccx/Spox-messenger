package com.example.data.repository

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class SavedAccountsStoreTest {

    private lateinit var context: Context

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        context.getSharedPreferences("spox_saved_accounts", Context.MODE_PRIVATE)
            .edit()
            .clear()
            .commit()
    }

    @Test
    fun savedAccountsStore_enforcesMaxFourAccountsAndPersistsState() {
        val store = SavedAccountsStore(context)
        assertTrue(store.accounts.value.isEmpty())
        assertTrue(store.canAddAnotherAccount())

        repeat(4) { idx ->
            store.upsertAccount(
                SavedAccount(
                    uid = "uid_${idx + 1}",
                    email = "user${idx + 1}@example.com",
                    displayName = "User ${idx + 1}",
                    handle = "@user_${idx + 1}",
                    lastActiveAtMs = (idx + 1) * 1000L
                )
            )
        }

        assertEquals(4, store.accounts.value.size)
        assertFalse(store.canAddAnotherAccount())
        assertEquals(listOf("uid_4", "uid_3", "uid_2", "uid_1"), store.accounts.value.map { it.uid })
        assertTrue(store.hasAccountForEmail("USER2@example.com"))
        assertFalse(store.hasAccountForEmail("user5@example.com"))

        // Re-instantiating reads persisted accounts
        val reloaded = SavedAccountsStore(context)
        assertEquals(4, reloaded.accounts.value.size)
        assertEquals("User 4", reloaded.accounts.value.first().displayName)

        // Updating an existing account keeps size at 4 and promotes it to top
        reloaded.upsertAccount(
            SavedAccount(
                uid = "uid_1",
                email = "user1@example.com",
                displayName = "User 1 Updated",
                lastActiveAtMs = 9000L
            )
        )
        assertEquals(4, reloaded.accounts.value.size)
        assertEquals("uid_1", reloaded.accounts.value.first().uid)
        assertEquals("User 1 Updated", reloaded.accounts.value.first().displayName)

        // Upserting a 5th distinct account never exceeds MAX_ACCOUNTS (4)
        reloaded.upsertAccount(
            SavedAccount(
                uid = "uid_5",
                email = "user5@example.com",
                displayName = "User 5",
                lastActiveAtMs = 10_000L
            )
        )
        assertEquals(SavedAccountsStore.MAX_ACCOUNTS, reloaded.accounts.value.size)
        assertFalse(reloaded.accounts.value.any { it.uid == "uid_2" }) // oldest (2000L) evicted
        assertTrue(reloaded.accounts.value.any { it.uid == "uid_5" })

        // Removing an account frees a slot
        reloaded.removeAccount("uid_3")
        assertEquals(3, reloaded.accounts.value.size)
        assertTrue(reloaded.canAddAnotherAccount())
    }

    @Test
    fun lazyLoading_defersPrefsReadUntilEnsureLoadedAsyncAndPreservesExistingAccounts() = runBlocking {
        val seedStore = SavedAccountsStore(context)
        seedStore.upsertAccount(
            SavedAccount(
                uid = "uid_existing",
                email = "existing@example.com",
                displayName = "Existing User",
                lastActiveAtMs = 1000L
            )
        )

        val lazyStore = SavedAccountsStore(context, eagerLoad = false)
        assertTrue(lazyStore.accounts.value.isEmpty())

        lazyStore.ensureLoadedAsync()
        assertEquals(listOf("uid_existing"), lazyStore.accounts.value.map { it.uid })

        // Calling upsert on a fresh lazy instance before ensureLoadedAsync must still merge persisted accounts
        val secondLazy = SavedAccountsStore(context, eagerLoad = false)
        secondLazy.upsertAccount(
            SavedAccount(
                uid = "uid_new",
                email = "new@example.com",
                displayName = "New User",
                lastActiveAtMs = 2000L
            )
        )
        assertEquals(listOf("uid_new", "uid_existing"), secondLazy.accounts.value.map { it.uid })
    }
}
