# Keep Firestore models and annotations for reflection-based deserialization
-keepattributes Signature,InnerClasses,EnclosingMethod,*Annotation*,RuntimeVisibleAnnotations,RuntimeVisibleParameterAnnotations
-keepclassmembers class com.example.data.model.** { *; }
-keep class com.example.data.model.** { *; }

# Keep Firebase, Play Services & AndroidX reflection entrypoints
-keepclassmembers class * {
    @com.google.firebase.firestore.PropertyName <methods>;
    @com.google.firebase.firestore.PropertyName <fields>;
    @com.google.firebase.firestore.DocumentId <fields>;
    @com.google.firebase.firestore.ServerTimestamp <fields>;
}

-keepclassmembers class * {
    @androidx.annotation.Keep <fields>;
    @androidx.annotation.Keep <methods>;
    @androidx.annotation.Keep <init>(...);
}

# Preserve WorkManager Workers (instantiated by reflection on launch & update)
-keep class * extends androidx.work.ListenableWorker {
    public <init>(android.content.Context, androidx.work.WorkerParameters);
}
-keep class * extends androidx.work.Worker {
    public <init>(android.content.Context, androidx.work.WorkerParameters);
}
-keep class * extends androidx.work.CoroutineWorker {
    public <init>(android.content.Context, androidx.work.WorkerParameters);
}
-keep class com.example.notifications.MessagePushWorker { *; }

# Preserve Android components and notification helpers
-keep class com.example.SpoXApplication { *; }
-keep class com.example.MainActivity
-keep class com.example.ui.call.IncomingCallActivity
-keep class com.example.media.OngoingCallService
-keep class com.example.notifications.CallActionReceiver
-keep class com.example.notifications.SpoXFirebaseMessagingService

# Preserve DataStore Preferences & Protobuf reflection classes
-keep class androidx.datastore.preferences.** { *; }
-keepclassmembers class * extends androidx.datastore.preferences.protobuf.GeneratedMessageLite {
    <fields>;
    *** parseFrom(...);
}

# Preserve Credential Manager & Google Identity reflection classes
-keep class androidx.credentials.** { *; }
-keep class com.google.android.libraries.identity.googleid.** { *; }
-keepnames class * implements android.os.Parcelable
-keepclassmembers class * implements android.os.Parcelable {
    public static final ** CREATOR;
}
-keep class * implements com.google.android.gms.common.internal.safeparcel.SafeParcelable {
    public static final *** CREATOR;
}
-keepclassmembers class * {
    @com.google.android.gms.common.annotation.KeepName <fields>;
    @com.google.android.gms.common.annotation.KeepName <methods>;
}

# Strip verbose/debug logs in release builds
-assumenosideeffects class android.util.Log {
    public static boolean isLoggable(java.lang.String, int);
    public static int v(...);
    public static int d(...);
}
