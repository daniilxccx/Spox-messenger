package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Obsidian Cipher (Dark Theme - Primary Evening Aesthetic)
val DarkBackground = Color(0xFF090D16)
val DarkSurface = Color(0xFF101724)
val DarkSurfaceVariant = Color(0xFF172235)
val DarkSurfaceContainerLow = Color(0xFF111927)
val DarkSurfaceContainer = Color(0xFF162133)
val DarkSurfaceContainerHigh = Color(0xFF1E2C42)

val DarkPrimary = Color(0xFF2DD4BF)
val DarkOnPrimary = Color(0xFF03231E)
val DarkPrimaryContainer = Color(0xFF0F4C45)
val DarkOnPrimaryContainer = Color(0xFFA7F3D0)

val DarkSecondary = Color(0xFF38BDF8)
val DarkOnSecondary = Color(0xFF042030)
val DarkSecondaryContainer = Color(0xFF0E3B59)
val DarkOnSecondaryContainer = Color(0xFFBAE6FD)

val DarkTertiary = Color(0xFFA78BFA)
val DarkOnTertiary = Color(0xFF211047)
val DarkTertiaryContainer = Color(0xFF362266)
val DarkOnTertiaryContainer = Color(0xFFDDD6FE)

val DarkOnBackground = Color(0xFFF1F5F9)
val DarkOnSurface = Color(0xFFE2E8F0)
val DarkOnSurfaceVariant = Color(0xFF94A3B8)
val DarkOutline = Color(0xFF2D3E58)
val DarkOutlineVariant = Color(0xFF1C283C)
val DarkError = Color(0xFFFB7185)
val DarkOnError = Color(0xFF4C0519)

// Daylight Frost (Light Theme)
val LightBackground = Color(0xFFF3F6FA)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFE6EEF6)
val LightSurfaceContainerLow = Color(0xFFF8FAFC)
val LightSurfaceContainer = Color(0xFFEDF2F7)
val LightSurfaceContainerHigh = Color(0xFFE2E8F0)

val LightPrimary = Color(0xFF0D9488)
val LightOnPrimary = Color(0xFFFFFFFF)
val LightPrimaryContainer = Color(0xFFCCFBF1)
val LightOnPrimaryContainer = Color(0xFF042F2E)

val LightSecondary = Color(0xFF0284C7)
val LightOnSecondary = Color(0xFFFFFFFF)
val LightSecondaryContainer = Color(0xFFE0F2FE)
val LightOnSecondaryContainer = Color(0xFF082F49)

val LightTertiary = Color(0xFF7C3AED)
val LightOnTertiary = Color(0xFFFFFFFF)
val LightTertiaryContainer = Color(0xFFEDE9FE)
val LightOnTertiaryContainer = Color(0xFF2E1065)

val LightOnBackground = Color(0xFF0F172A)
val LightOnSurface = Color(0xFF1E293B)
val LightOnSurfaceVariant = Color(0xFF64748B)
val LightOutline = Color(0xFFCBD5E1)
val LightOutlineVariant = Color(0xFFE2E8F0)
val LightError = Color(0xFFE11D48)
val LightOnError = Color(0xFFFFFFFF)

// Avatar palette
val AvatarPalette = listOf(
    Color(0xFF0D9488),
    Color(0xFF0284C7),
    Color(0xFF7C3AED),
    Color(0xFFDB2777),
    Color(0xFFD97706),
    Color(0xFF059669),
    Color(0xFF4F46E5),
    Color(0xFF0891B2)
)

// Real-time presence indicator colors
val DarkPresenceOnline = Color(0xFF22C55E)
val DarkPresenceRecent = Color(0xFFF59E0B)
val DarkPresenceOffline = Color(0xFF64748B)

val LightPresenceOnline = Color(0xFF16A34A)
val LightPresenceRecent = Color(0xFFD97706)
val LightPresenceOffline = Color(0xFF94A3B8)

