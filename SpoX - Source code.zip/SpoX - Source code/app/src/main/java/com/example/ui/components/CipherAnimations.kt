package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.media.MediaKind

data class MediaTransferUiState(
    val id: String,
    val fileName: String,
    val mediaKind: MediaKind,
    val progress: Float,
    val phaseLabel: String,
    val isUpload: Boolean = true
)

@Composable
fun CipherLaunchSplashOverlay(
    visible: Boolean,
    versionName: String = com.example.BuildConfig.VERSION_NAME
) {
    val isResourceSaving = com.example.ui.theme.LocalChatAppearance.current.resourceSavingMode
    AnimatedVisibility(
        visible = visible,
        enter = if (isResourceSaving) fadeIn(tween(1)) else fadeIn(tween(200)),
        exit = if (isResourceSaving) fadeOut(tween(1)) else fadeOut(tween(420)) + scaleOut(targetScale = 1.06f, animationSpec = tween(420))
    ) {
        val logoScale = remember { Animatable(if (isResourceSaving) 1f else 0.65f) }
        val textAlpha = remember { Animatable(if (isResourceSaving) 1f else 0f) }
        val progressAnim = remember { Animatable(if (isResourceSaving) 1f else 0f) }

        LaunchedEffect(isResourceSaving) {
            if (!isResourceSaving) {
                logoScale.animateTo(
                    targetValue = 1f,
                    animationSpec = spring(
                        dampingRatio = Spring.DampingRatioMediumBouncy,
                        stiffness = Spring.StiffnessLow
                    )
                )
            }
        }
        LaunchedEffect(isResourceSaving) {
            if (!isResourceSaving) {
                textAlpha.animateTo(1f, tween(550, easing = FastOutSlowInEasing))
            }
        }
        LaunchedEffect(isResourceSaving) {
            if (!isResourceSaving) {
                progressAnim.animateTo(1f, tween(1000, easing = FastOutSlowInEasing))
            }
        }

        val orbitAngle: Float
        val pulseScale: Float
        if (isResourceSaving) {
            orbitAngle = 45f
            pulseScale = 1f
        } else {
            val infinite = rememberInfiniteTransition(label = "splash_orbit")
            val animOrbit by infinite.animateFloat(
                initialValue = 0f,
                targetValue = 360f,
                animationSpec = infiniteRepeatable(tween(2400, easing = LinearEasing)),
                label = "orbit_angle"
            )
            val animPulse by infinite.animateFloat(
                initialValue = 0.88f,
                targetValue = 1.18f,
                animationSpec = infiniteRepeatable(tween(1100, easing = FastOutSlowInEasing), RepeatMode.Reverse),
                label = "pulse_scale"
            )
            orbitAngle = animOrbit
            pulseScale = animPulse
        }

        val primaryColor = MaterialTheme.colorScheme.primary
        val secondaryColor = MaterialTheme.colorScheme.secondary

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            primaryColor.copy(alpha = 0.16f),
                            MaterialTheme.colorScheme.background,
                            MaterialTheme.colorScheme.background
                        )
                    )
                )
                .testTag("app_launch_splash"),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(32.dp)
            ) {
                Box(
                    modifier = Modifier.size(152.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val center = Offset(size.width / 2f, size.height / 2f)
                        val baseRadius = size.minDimension / 2f
                        drawCircle(
                            color = primaryColor.copy(alpha = 0.14f),
                            radius = baseRadius * pulseScale * 0.85f,
                            center = center
                        )
                        drawArc(
                            brush = Brush.sweepGradient(
                                listOf(
                                    Color.Transparent,
                                    primaryColor,
                                    secondaryColor,
                                    Color.Transparent
                                )
                            ),
                            startAngle = orbitAngle,
                            sweepAngle = 220f,
                            useCenter = false,
                            style = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round)
                        )
                    }

                    val context = LocalContext.current
                    val logoBitmap by produceState<ImageBitmap?>(
                        initialValue = BitmapMemoryCache.getCachedDrawable(R.drawable.ic_spox_logo, 256),
                        key1 = context
                    ) {
                        if (value == null) {
                            value = BitmapMemoryCache.decodeDrawable(context, R.drawable.ic_spox_logo, 256)
                        }
                    }

                    Surface(
                        shape = CircleShape,
                        color = Color(0xFF101010),
                        border = BorderStroke(1.5.dp, primaryColor.copy(alpha = 0.55f)),
                        shadowElevation = if (isResourceSaving) 0.dp else 12.dp,
                        modifier = Modifier
                            .size(98.dp)
                            .scale(logoScale.value)
                    ) {
                        val resolvedLogo = logoBitmap
                        if (resolvedLogo != null) {
                            Image(
                                bitmap = resolvedLogo,
                                contentDescription = "SpoX",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .fillMaxSize()
                                    .clip(CircleShape)
                            )
                        } else {
                            Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                                Icon(
                                    imageVector = Icons.Filled.Lock,
                                    contentDescription = "SpoX",
                                    tint = primaryColor,
                                    modifier = Modifier.size(38.dp)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(22.dp))

                Text(
                    text = "SpoX",
                    style = MaterialTheme.typography.headlineLarge,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.alpha(textAlpha.value)
                )

                Spacer(modifier = Modifier.height(6.dp))

                Surface(
                    shape = RoundedCornerShape(50),
                    color = primaryColor.copy(alpha = 0.14f),
                    border = BorderStroke(1.dp, primaryColor.copy(alpha = 0.35f)),
                    modifier = Modifier.alpha(textAlpha.value)
                ) {
                    Text(
                        text = "E2EE • Версия $versionName",
                        style = MaterialTheme.typography.labelMedium,
                        color = primaryColor,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                    )
                }

                Spacer(modifier = Modifier.height(24.dp))

                LinearProgressIndicator(
                    progress = { progressAnim.value },
                    color = primaryColor,
                    trackColor = MaterialTheme.colorScheme.surfaceContainerHighest,
                    modifier = Modifier
                        .width(190.dp)
                        .height(5.dp)
                        .clip(RoundedCornerShape(50))
                )

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "Инициализация защищённого канала...",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.alpha(textAlpha.value)
                )
            }
        }
    }
}

@Composable
fun CipherLoadingStateView(
    label: String = "Расшифровка данных...",
    modifier: Modifier = Modifier
) {
    val isResourceSaving = com.example.ui.theme.LocalChatAppearance.current.resourceSavingMode
    val ring1: Float
    val rotation: Float
    if (isResourceSaving) {
        ring1 = 0.72f
        rotation = 30f
    } else {
        val infinite = rememberInfiniteTransition(label = "radar_loader")
        val animRing by infinite.animateFloat(
            initialValue = 0.35f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(tween(1200, easing = FastOutSlowInEasing)),
            label = "ring_1"
        )
        val animRot by infinite.animateFloat(
            initialValue = 0f,
            targetValue = 360f,
            animationSpec = infiniteRepeatable(tween(1500, easing = LinearEasing)),
            label = "ring_rot"
        )
        ring1 = animRing
        rotation = animRot
    }
    val primary = MaterialTheme.colorScheme.primary
    val secondary = MaterialTheme.colorScheme.secondary

    Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(modifier = Modifier.size(84.dp), contentAlignment = Alignment.Center) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val c = Offset(size.width / 2f, size.height / 2f)
                    drawCircle(
                        color = primary.copy(alpha = (1f - ring1) * 0.45f),
                        radius = (size.minDimension / 2f) * ring1,
                        center = c,
                        style = Stroke(width = 2.dp.toPx())
                    )
                    drawArc(
                        brush = Brush.sweepGradient(listOf(Color.Transparent, primary, secondary)),
                        startAngle = rotation,
                        sweepAngle = 210f,
                        useCenter = false,
                        style = Stroke(width = 3.5.dp.toPx(), cap = StrokeCap.Round)
                    )
                }
                Icon(
                    imageVector = Icons.Filled.Lock,
                    contentDescription = null,
                    tint = primary,
                    modifier = Modifier.size(26.dp)
                )
            }
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun MediaUploadBanner(
    transfer: MediaTransferUiState?,
    modifier: Modifier = Modifier
) {
    val isResourceSaving = com.example.ui.theme.LocalChatAppearance.current.resourceSavingMode
    AnimatedVisibility(
        visible = transfer != null,
        enter = if (isResourceSaving) EnterTransition.None else slideInVertically { -it } + fadeIn(tween(220)),
        exit = if (isResourceSaving) ExitTransition.None else slideOutVertically { -it } + fadeOut(tween(220)),
        modifier = modifier
    ) {
        transfer?.let { item ->
            val targetProg = item.progress.coerceIn(0f, 1f)
            val animatedProgress: Float
            val arrowShift: Float
            if (isResourceSaving) {
                animatedProgress = targetProg
                arrowShift = 0f
            } else {
                val animProg by animateFloatAsState(
                    targetValue = targetProg,
                    animationSpec = tween(260, easing = FastOutSlowInEasing),
                    label = "upload_progress"
                )
                val infinite = rememberInfiniteTransition(label = "upload_arrow_bounce")
                val animShift by infinite.animateFloat(
                    initialValue = -2f,
                    targetValue = 2f,
                    animationSpec = infiniteRepeatable(tween(450), RepeatMode.Reverse),
                    label = "arrow_shift"
                )
                animatedProgress = animProg
                arrowShift = animShift
            }
            val icon = mediaKindIcon(item.mediaKind)

            Surface(
                shape = RoundedCornerShape(18.dp),
                color = MaterialTheme.colorScheme.surfaceContainerHigh,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.45f)),
                shadowElevation = if (isResourceSaving) 0.dp else 6.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 6.dp)
                    .testTag("media_upload_progress_banner")
            ) {
                Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.16f),
                                modifier = Modifier.size(34.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = icon,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "${item.mediaKind.label}: ${item.fileName}",
                                    style = MaterialTheme.typography.titleSmall,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = item.phaseLabel,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Filled.ArrowUpward,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier
                                    .size(16.dp)
                                    .padding(top = (arrowShift + 2f).coerceAtLeast(0f).dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "${(animatedProgress * 100).toInt()}%",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    LinearProgressIndicator(
                        progress = { animatedProgress },
                        color = MaterialTheme.colorScheme.primary,
                        trackColor = MaterialTheme.colorScheme.surfaceContainer,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(5.dp)
                            .clip(RoundedCornerShape(50))
                    )
                }
            }
        }
    }
}

@Composable
fun MediaDownloadBadge(
    progress: Float?,
    isCompleted: Boolean,
    tint: Color,
    size: Dp = 34.dp
) {
    Box(
        modifier = Modifier.size(size),
        contentAlignment = Alignment.Center
    ) {
        when {
            progress != null -> {
                val isResourceSaving = com.example.ui.theme.LocalChatAppearance.current.resourceSavingMode
                val targetVal = progress.coerceIn(0.08f, 1f)
                val animated = if (isResourceSaving) {
                    targetVal
                } else {
                    val animVal by animateFloatAsState(
                        targetValue = targetVal,
                        animationSpec = tween(220),
                        label = "download_ring"
                    )
                    animVal
                }
                CircularProgressIndicator(
                    progress = { animated },
                    strokeWidth = 2.5.dp,
                    color = tint,
                    trackColor = tint.copy(alpha = 0.2f),
                    modifier = Modifier.size(size)
                )
                Text(
                    text = "${(animated * 100).toInt()}",
                    style = MaterialTheme.typography.labelSmall,
                    color = tint
                )
            }
            isCompleted -> {
                Surface(
                    shape = CircleShape,
                    color = tint.copy(alpha = 0.18f),
                    modifier = Modifier.size(size)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Filled.Check,
                            contentDescription = "Загружено",
                            tint = tint,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
            else -> {
                Surface(
                    shape = CircleShape,
                    color = tint.copy(alpha = 0.14f),
                    modifier = Modifier.size(size)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Filled.ArrowDownward,
                            contentDescription = "Скачать и открыть",
                            tint = tint,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }
}

fun mediaKindIcon(kind: MediaKind) = when (kind) {
    MediaKind.PHOTO -> Icons.Filled.Image
    MediaKind.VIDEO -> Icons.Filled.Videocam
    MediaKind.AUDIO -> Icons.Filled.MusicNote
    MediaKind.VOICE -> Icons.Filled.Mic
    MediaKind.FILE -> Icons.Filled.Description
}

@Composable
fun Modifier.smoothAppear(
    enabled: Boolean,
    key: Any? = Unit,
    delayMillis: Int = 0,
    durationMillis: Int = 240,
    initialTranslationXDp: Float = 0f,
    initialTranslationYDp: Float = 10f,
    initialScale: Float = 0.985f
): Modifier {
    val isResourceSaving = com.example.ui.theme.LocalChatAppearance.current.resourceSavingMode
    val effectiveEnabled = enabled && !isResourceSaving
    if (!effectiveEnabled) return this

    val progress = remember(key, effectiveEnabled) { Animatable(0f) }
    LaunchedEffect(key, effectiveEnabled) {
        progress.snapTo(0f)
        progress.animateTo(
            targetValue = 1f,
            animationSpec = tween(
                durationMillis = durationMillis,
                delayMillis = delayMillis,
                easing = FastOutSlowInEasing
            )
        )
    }

    return this.graphicsLayer {
        val p = progress.value
        val scale = initialScale + (1f - initialScale) * p
        alpha = p
        translationX = initialTranslationXDp.dp.toPx() * (1f - p)
        translationY = initialTranslationYDp.dp.toPx() * (1f - p)
        scaleX = scale
        scaleY = scale
    }
}
