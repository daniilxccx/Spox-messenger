package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.unit.dp
import com.example.data.model.AppThemeMode
import com.example.data.model.AppVisualTheme
import com.example.data.model.ChatAppearanceConfig

@Immutable
data class SpoXPresenceColors(
    val online: Color,
    val recent: Color,
    val offline: Color
)

val LocalPresenceColors = staticCompositionLocalOf {
    SpoXPresenceColors(
        online = DarkPresenceOnline,
        recent = DarkPresenceRecent,
        offline = DarkPresenceOffline
    )
}

val LocalChatAppearance = staticCompositionLocalOf {
    ChatAppearanceConfig()
}

private val CipherDarkColorScheme = darkColorScheme(
    primary = DarkPrimary,
    onPrimary = DarkOnPrimary,
    primaryContainer = DarkPrimaryContainer,
    onPrimaryContainer = DarkOnPrimaryContainer,
    secondary = DarkSecondary,
    onSecondary = DarkOnSecondary,
    secondaryContainer = DarkSecondaryContainer,
    onSecondaryContainer = DarkOnSecondaryContainer,
    tertiary = DarkTertiary,
    onTertiary = DarkOnTertiary,
    tertiaryContainer = DarkTertiaryContainer,
    onTertiaryContainer = DarkOnTertiaryContainer,
    background = DarkBackground,
    onBackground = DarkOnBackground,
    surface = DarkSurface,
    onSurface = DarkOnSurface,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = DarkOnSurfaceVariant,
    surfaceContainerLow = DarkSurfaceContainerLow,
    surfaceContainer = DarkSurfaceContainer,
    surfaceContainerHigh = DarkSurfaceContainerHigh,
    outline = DarkOutline,
    outlineVariant = DarkOutlineVariant,
    error = DarkError,
    onError = DarkOnError
)

private val CipherLightColorScheme = lightColorScheme(
    primary = LightPrimary,
    onPrimary = LightOnPrimary,
    primaryContainer = LightPrimaryContainer,
    onPrimaryContainer = LightOnPrimaryContainer,
    secondary = LightSecondary,
    onSecondary = LightOnSecondary,
    secondaryContainer = LightSecondaryContainer,
    onSecondaryContainer = LightOnSecondaryContainer,
    tertiary = LightTertiary,
    onTertiary = LightOnTertiary,
    tertiaryContainer = LightTertiaryContainer,
    onTertiaryContainer = LightOnTertiaryContainer,
    background = LightBackground,
    onBackground = LightOnBackground,
    surface = LightSurface,
    onSurface = LightOnSurface,
    surfaceVariant = LightSurfaceVariant,
    onSurfaceVariant = LightOnSurfaceVariant,
    surfaceContainerLow = LightSurfaceContainerLow,
    surfaceContainer = LightSurfaceContainer,
    surfaceContainerHigh = LightSurfaceContainerHigh,
    outline = LightOutline,
    outlineVariant = LightOutlineVariant,
    error = LightError,
    onError = LightOnError
)

private fun buildDynamicThemeColorScheme(
    visualTheme: AppVisualTheme,
    isDark: Boolean
): ColorScheme {
    if (visualTheme == AppVisualTheme.SPOX_CYBER) {
        return if (isDark) CipherDarkColorScheme else CipherLightColorScheme
    }

    return if (isDark) {
        val bg = visualTheme.darkBackground
        val surf = visualTheme.darkSurface
        val pri = visualTheme.darkPrimary
        val sec = visualTheme.darkSecondary
        val ter = visualTheme.darkTertiary
        val isMono = visualTheme == AppVisualTheme.MONO_SLATE
        val onPri = if (isMono) Color(0xFF0A0A0C) else lerp(bg, Color.Black, 0.45f)
        val priContainer = if (isMono) Color(0xFF27272F) else lerp(surf, pri, 0.26f)
        val onPriContainer = if (isMono) Color(0xFFF8FAFC) else lerp(pri, Color.White, 0.65f)
        val secContainer = if (isMono) Color(0xFF1F242D) else lerp(surf, sec, 0.24f)
        val onSecContainer = if (isMono) Color(0xFFE2E8F0) else lerp(sec, Color.White, 0.65f)
        val terContainer = lerp(surf, ter, 0.24f)
        val onTerContainer = lerp(ter, Color.White, 0.65f)

        darkColorScheme(
            primary = pri,
            onPrimary = onPri,
            primaryContainer = priContainer,
            onPrimaryContainer = onPriContainer,
            secondary = sec,
            onSecondary = lerp(bg, Color.Black, 0.4f),
            secondaryContainer = secContainer,
            onSecondaryContainer = onSecContainer,
            tertiary = ter,
            onTertiary = lerp(bg, Color.Black, 0.4f),
            tertiaryContainer = terContainer,
            onTertiaryContainer = onTerContainer,
            background = bg,
            onBackground = Color(0xFFF1F5F9),
            surface = surf,
            onSurface = Color(0xFFE2E8F0),
            surfaceVariant = lerp(surf, pri, 0.08f),
            onSurfaceVariant = Color(0xFF94A3B8),
            surfaceContainerLow = lerp(bg, surf, 0.65f),
            surfaceContainer = lerp(surf, pri, 0.06f),
            surfaceContainerHigh = lerp(surf, pri, 0.13f),
            outline = lerp(surf, Color.White, 0.18f),
            outlineVariant = lerp(surf, Color.White, 0.10f),
            error = DarkError,
            onError = DarkOnError
        )
    } else {
        val bg = visualTheme.lightBackground
        val pri = visualTheme.lightPrimary
        val sec = visualTheme.lightSecondary
        val ter = visualTheme.darkTertiary
        val priContainer = lerp(Color.White, pri, 0.16f)
        val onPriContainer = lerp(pri, Color.Black, 0.45f)
        val secContainer = lerp(Color.White, sec, 0.16f)
        val onSecContainer = lerp(sec, Color.Black, 0.45f)

        lightColorScheme(
            primary = pri,
            onPrimary = Color.White,
            primaryContainer = priContainer,
            onPrimaryContainer = onPriContainer,
            secondary = sec,
            onSecondary = Color.White,
            secondaryContainer = secContainer,
            onSecondaryContainer = onSecContainer,
            tertiary = ter,
            onTertiary = Color.White,
            tertiaryContainer = lerp(Color.White, ter, 0.16f),
            onTertiaryContainer = lerp(ter, Color.Black, 0.45f),
            background = bg,
            onBackground = Color(0xFF0F172A),
            surface = Color.White,
            onSurface = Color(0xFF1E293B),
            surfaceVariant = lerp(bg, pri, 0.08f),
            onSurfaceVariant = Color(0xFF64748B),
            surfaceContainerLow = lerp(Color.White, bg, 0.45f),
            surfaceContainer = lerp(bg, pri, 0.06f),
            surfaceContainerHigh = lerp(bg, pri, 0.12f),
            outline = Color(0xFFCBD5E1),
            outlineVariant = Color(0xFFE2E8F0),
            error = LightError,
            onError = LightOnError
        )
    }
}

val CipherShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun CipherChatTheme(
    themeMode: AppThemeMode = AppThemeMode.DARK,
    appearanceConfig: ChatAppearanceConfig = ChatAppearanceConfig(themeMode = themeMode),
    content: @Composable () -> Unit
) {
    val isDark = when (appearanceConfig.themeMode) {
        AppThemeMode.DARK -> true
        AppThemeMode.LIGHT -> false
        AppThemeMode.SYSTEM -> isSystemInDarkTheme()
    }

    val colorScheme = buildDynamicThemeColorScheme(
        visualTheme = appearanceConfig.visualTheme,
        isDark = isDark
    )
    val presenceColors = if (isDark) {
        SpoXPresenceColors(
            online = DarkPresenceOnline,
            recent = DarkPresenceRecent,
            offline = DarkPresenceOffline
        )
    } else {
        SpoXPresenceColors(
            online = LightPresenceOnline,
            recent = LightPresenceRecent,
            offline = LightPresenceOffline
        )
    }

    CompositionLocalProvider(
        LocalPresenceColors provides presenceColors,
        LocalChatAppearance provides appearanceConfig
    ) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = Typography,
            shapes = CipherShapes,
            content = content
        )
    }
}
