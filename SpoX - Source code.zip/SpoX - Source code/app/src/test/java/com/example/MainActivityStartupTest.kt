package com.example

import android.content.Context
import android.content.Intent
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onAllNodesWithText
import androidx.test.core.app.ApplicationProvider
import androidx.work.Configuration
import com.example.ui.call.IncomingCallActivity
import com.google.firebase.FirebaseApp
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class MainActivityStartupTest {

    @get:Rule
    val composeRule = createAndroidComposeRule<MainActivity>()

    @Test
    fun spoXApplicationProvidesOnDemandWorkManagerConfiguration() {
        val app = ApplicationProvider.getApplicationContext<Context>()
        assertTrue(app is SpoXApplication)
        assertTrue(app is Configuration.Provider)
        val config = (app as Configuration.Provider).workManagerConfiguration
        assertNotNull(config)
    }

    @Test
    fun mainActivityStartsAndRendersWithoutCrashing() {
        val activity = composeRule.activity
        assertNotNull(activity)
        assertNotNull(FirebaseApp.getInstance())

        // Advance beyond the 800ms launch splash overlay
        composeRule.mainClock.advanceTimeBy(1200L)
        composeRule.waitForIdle()

        val spoxNodes = composeRule.onAllNodesWithText("SpoX").fetchSemanticsNodes()
        assert(spoxNodes.isNotEmpty())
    }

    @Test
    fun incomingCallActivityHandlesMissingExtrasGracefully() {
        val intent = Intent(
            ApplicationProvider.getApplicationContext(),
            IncomingCallActivity::class.java
        )
        val controller = Robolectric.buildActivity(IncomingCallActivity::class.java, intent).create()
        assertTrue(controller.get().isFinishing)
    }
}
