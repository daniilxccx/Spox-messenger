package com.example.ui.auth

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.util.Log
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Login
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Mail
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.zIndex
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.credentials.exceptions.GetCredentialException
import androidx.credentials.exceptions.NoCredentialException
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.repeatOnLifecycle
import com.example.R
import com.example.data.model.AppThemeMode
import com.example.data.repository.FirebaseSessionManager
import com.example.data.repository.SavedAccount
import com.example.data.repository.SavedAccountsStore
import com.example.ui.components.BitmapMemoryCache
import com.example.ui.components.UserAvatar
import com.example.ui.theme.isLiquidGlassActive
import com.example.ui.theme.liquidGlassSurface
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential.Companion.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.auth
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AuthScreen(
    themeMode: AppThemeMode,
    onToggleTheme: () -> Unit,
    savedAccounts: List<SavedAccount> = emptyList(),
    skipAutoSignIn: Boolean = false,
    canAutoSignIn: Boolean = true,
    hasLiveSession: (SavedAccount) -> Boolean = { false },
    onQuickSelectSavedAccount: (SavedAccount, onSuccess: () -> Unit, onError: (String) -> Unit) -> Unit = { _, _, onErr ->
        onErr("Не удалось быстро переключиться на профиль")
    },
    onRemoveSavedAccount: (String) -> Unit = {},
    onAuthSuccess: () -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val coroutineScope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }

    var loadingMode by remember { mutableStateOf<String?>(null) }
    val isLoading = loadingMode != null
    var errorText by remember { mutableStateOf<String?>(null) }
    var autoSignInAttempted by remember(skipAutoSignIn) { mutableStateOf(false) }

    LaunchedEffect(skipAutoSignIn, canAutoSignIn, lifecycleOwner) {
        if (!skipAutoSignIn && canAutoSignIn && !autoSignInAttempted) {
            lifecycleOwner.lifecycle.repeatOnLifecycle(Lifecycle.State.RESUMED) {
                if (!autoSignInAttempted) {
                    autoSignInAttempted = true
                    delay(160L)
                    attemptAutoSignIn(
                        context = context,
                        credentialManager = credentialManager,
                        savedAccounts = savedAccounts,
                        onAuthSuccess = onAuthSuccess,
                        onUnauthenticated = {},
                        scope = coroutineScope
                    )
                }
            }
        }
    }

    val glassActive = isLiquidGlassActive()
    val isCurrentlyDark = when (themeMode) {
        AppThemeMode.DARK -> true
        AppThemeMode.LIGHT -> false
        AppThemeMode.SYSTEM -> isSystemInDarkTheme()
    }
    Box(
        modifier = Modifier
            .fillMaxSize()
            .then(
                if (glassActive) {
                    Modifier
                } else {
                    Modifier.background(
                        Brush.verticalGradient(
                            colors = listOf(
                                MaterialTheme.colorScheme.background,
                                MaterialTheme.colorScheme.surfaceContainerLow,
                                MaterialTheme.colorScheme.background
                            )
                        )
                    )
                }
            )
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(start = 24.dp, end = 24.dp, top = 64.dp, bottom = 20.dp)
                .widthIn(max = 520.dp)
                .align(Alignment.Center),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(210.dp),
                shape = RoundedCornerShape(28.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)
            ) {
                val heroBitmap by produceState<ImageBitmap?>(
                    initialValue = BitmapMemoryCache.getCachedDrawable(R.drawable.img_cipher_hero_1794657919868, 960),
                    key1 = context
                ) {
                    if (value == null) {
                        value = BitmapMemoryCache.decodeDrawable(
                            context = context,
                            resId = R.drawable.img_cipher_hero_1794657919868,
                            maxDimensionPx = 960
                        )
                    }
                }
                Box(modifier = Modifier.fillMaxSize()) {
                    val resolvedHero = heroBitmap
                    if (resolvedHero != null) {
                        Image(
                            bitmap = resolvedHero,
                            contentDescription = "Символ сквозного шифрования SpoX",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.linearGradient(
                                        colors = listOf(
                                            MaterialTheme.colorScheme.primary.copy(alpha = 0.25f),
                                            MaterialTheme.colorScheme.secondary.copy(alpha = 0.20f),
                                            MaterialTheme.colorScheme.surfaceContainerHigh
                                        )
                                    )
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Lock,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.45f),
                                modifier = Modifier.size(48.dp)
                            )
                        }
                    }
                    Surface(
                        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.86f),
                        shape = RoundedCornerShape(50),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.4f)),
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(14.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Filled.VerifiedUser,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "ECDH P-256 + AES-256-GCM",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = "SpoX",
                style = MaterialTheme.typography.displaySmall,
                color = MaterialTheme.colorScheme.onBackground,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Защищённый мессенджер со сквозным шифрованием переписки, файлов, голосовых сообщений и звонков.",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(20.dp))

            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                FeaturePill(Icons.Filled.Lock, "Сквозное E2EE")
                FeaturePill(Icons.Filled.Groups, "Групповые чаты")
                FeaturePill(Icons.Filled.Call, "Аудио и видео")
            }

            Spacer(modifier = Modifier.height(24.dp))

            if (savedAccounts.isNotEmpty()) {
                val savedCardShape = RoundedCornerShape(22.dp)
                Surface(
                    shape = savedCardShape,
                    color = if (glassActive) Color.Transparent else MaterialTheme.colorScheme.surfaceContainerLow,
                    border = if (glassActive) null else BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    modifier = Modifier
                        .fillMaxWidth()
                        .then(if (glassActive) Modifier.liquidGlassSurface(shape = savedCardShape) else Modifier)
                        .testTag("auth_saved_accounts_card")
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "Сохранённые аккаунты",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.SemiBold
                            )
                            Surface(
                                shape = RoundedCornerShape(50),
                                color = MaterialTheme.colorScheme.primaryContainer
                            ) {
                                Text(
                                    text = "${savedAccounts.size} / ${SavedAccountsStore.MAX_ACCOUNTS}",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }
                        }

                        savedAccounts.forEach { acc ->
                            val isSessionLive = hasLiveSession(acc)
                            val normalizedHandle = remember(acc.handle) {
                                val trimmed = acc.handle.trim()
                                when {
                                    trimmed.isBlank() -> ""
                                    trimmed.startsWith("@") -> trimmed
                                    else -> "@$trimmed"
                                }
                            }
                            val accountIdentityLine = remember(normalizedHandle, acc.email) {
                                listOf(normalizedHandle, acc.email.trim())
                                    .filter { it.isNotBlank() }
                                    .joinToString(" • ")
                            }
                            val savedAccShape = RoundedCornerShape(14.dp)
                            Surface(
                                shape = savedAccShape,
                                color = if (glassActive) Color.Transparent else MaterialTheme.colorScheme.surfaceContainer,
                                border = if (glassActive) null else BorderStroke(
                                    width = if (isSessionLive) 1.25.dp else 1.dp,
                                    color = if (isSessionLive) {
                                        MaterialTheme.colorScheme.primary.copy(alpha = 0.55f)
                                    } else {
                                        MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.7f)
                                    }
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .then(
                                        if (glassActive) Modifier.liquidGlassSurface(
                                            shape = savedAccShape,
                                            isHighlighted = isSessionLive
                                        )
                                        else Modifier.clip(savedAccShape)
                                    )
                                    .clickable(enabled = !isLoading) {
                                        errorText = null
                                        loadingMode = "saved_${acc.uid}"
                                        if (isSessionLive) {
                                            onQuickSelectSavedAccount(
                                                acc,
                                                {
                                                    loadingMode = null
                                                    onAuthSuccess()
                                                },
                                                { msg ->
                                                    loadingMode = null
                                                    errorText = msg
                                                }
                                            )
                                        } else {
                                            signInToSavedGoogleAccount(
                                                context = context,
                                                credentialManager = credentialManager,
                                                targetAccount = acc,
                                                savedAccounts = savedAccounts,
                                                onAuthSuccess = {
                                                    loadingMode = null
                                                    onAuthSuccess()
                                                },
                                                onAuthError = { msg ->
                                                    loadingMode = null
                                                    errorText = msg
                                                },
                                                onAuthCancelled = { loadingMode = null },
                                                scope = coroutineScope
                                            )
                                        }
                                    }
                                    .testTag("auth_saved_account_${acc.uid}")
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(start = 10.dp, end = 4.dp, top = 8.dp, bottom = 8.dp)
                                ) {
                                    UserAvatar(
                                        name = acc.displayName.ifBlank { acc.email.ifBlank { "SpoX" } },
                                        avatarBase64 = acc.avatarBase64,
                                        colorIndex = acc.avatarColorIndex,
                                        size = 40.dp
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = acc.displayName.ifBlank { acc.email.ifBlank { "SpoX" } },
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.SemiBold,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        if (accountIdentityLine.isNotBlank()) {
                                            Text(
                                                text = accountIdentityLine,
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                        Text(
                                            text = if (isSessionLive) {
                                                "Сессия активна • вход сразу"
                                            } else {
                                                "Нажмите для входа через Google"
                                            },
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = if (isSessionLive) FontWeight.Medium else FontWeight.Normal,
                                            color = if (isSessionLive) {
                                                MaterialTheme.colorScheme.primary
                                            } else {
                                                MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.85f)
                                            },
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                    if (loadingMode == "saved_${acc.uid}") {
                                        CircularProgressIndicator(
                                            strokeWidth = 2.dp,
                                            modifier = Modifier
                                                .padding(horizontal = 12.dp)
                                                .size(18.dp)
                                        )
                                    } else {
                                        Icon(
                                            imageVector = if (isSessionLive) {
                                                Icons.AutoMirrored.Filled.Login
                                            } else {
                                                Icons.Filled.SwapHoriz
                                            },
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        IconButton(
                                            onClick = { onRemoveSavedAccount(acc.uid) },
                                            enabled = !isLoading,
                                            modifier = Modifier
                                                .size(48.dp)
                                                .testTag("auth_remove_saved_${acc.uid}")
                                        ) {
                                            Icon(
                                                imageVector = Icons.Filled.Close,
                                                contentDescription = "Убрать сохранённый аккаунт",
                                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
            }

            val authCardShape = RoundedCornerShape(22.dp)
            Surface(
                shape = authCardShape,
                color = if (glassActive) Color.Transparent else MaterialTheme.colorScheme.surfaceContainerLow,
                border = if (glassActive) null else BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                modifier = Modifier
                    .fillMaxWidth()
                    .then(if (glassActive) Modifier.liquidGlassSurface(shape = authCardShape) else Modifier)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Filled.Mail,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.secondary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Способы входа в аккаунт",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Выберите вход через Google (выбор учётной записи) или быстрый системный вход One Tap (с автопереходом к выбору аккаунта). После входа можно включить PIN-код и биометрию.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = {
                            errorText = null
                            loadingMode = "google"
                            switchOrAddGoogleAccount(
                                context = context,
                                credentialManager = credentialManager,
                                enforceMaxAccounts = savedAccounts.isNotEmpty(),
                                existingAccountEmails = savedAccounts.map { it.email },
                                savedAccounts = savedAccounts,
                                onAuthSuccess = {
                                    loadingMode = null
                                    onAuthSuccess()
                                },
                                onAuthError = { msg ->
                                    loadingMode = null
                                    errorText = msg
                                },
                                scope = coroutineScope,
                                onAuthCancelled = { loadingMode = null }
                            )
                        },
                        enabled = !isLoading,
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary,
                            contentColor = MaterialTheme.colorScheme.onPrimary
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp)
                            .testTag("google_sign_in_button")
                    ) {
                        if (loadingMode == "google") {
                            CircularProgressIndicator(
                                modifier = Modifier.size(22.dp),
                                strokeWidth = 2.5.dp,
                                color = MaterialTheme.colorScheme.onPrimary
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Filled.Mail,
                                contentDescription = null,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "Войти через Google (Email)",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedButton(
                        onClick = {
                            errorText = null
                            loadingMode = "onetap"
                            onOneTapSignInClicked(
                                context = context,
                                credentialManager = credentialManager,
                                enforceMaxAccounts = savedAccounts.isNotEmpty(),
                                existingAccountEmails = savedAccounts.map { it.email },
                                savedAccounts = savedAccounts,
                                onAuthSuccess = {
                                    loadingMode = null
                                    onAuthSuccess()
                                },
                                onAuthError = { msg ->
                                    loadingMode = null
                                    errorText = msg
                                },
                                scope = coroutineScope,
                                onAuthCancelled = { loadingMode = null }
                            )
                        },
                        enabled = !isLoading,
                        shape = RoundedCornerShape(16.dp),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("one_tap_sign_in_button")
                    ) {
                        if (loadingMode == "onetap") {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                strokeWidth = 2.5.dp,
                                color = MaterialTheme.colorScheme.primary
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Filled.AccountCircle,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "Быстрый вход (One Tap)",
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surfaceContainer,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Fingerprint,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.secondary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "В профиле можно дополнительно включить вход по PIN-коду и отпечатку / Face ID.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    if (!errorText.isNullOrBlank()) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = errorText!!,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.testTag("auth_error_text")
                        )
                    }
                }
            }
        }

        Surface(
            shape = CircleShape,
            color = if (glassActive) Color.Transparent else MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.88f),
            border = if (glassActive) null else BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(12.dp)
                .zIndex(2f)
                .size(48.dp)
                .then(if (glassActive) Modifier.liquidGlassSurface(shape = CircleShape) else Modifier)
        ) {
            IconButton(
                onClick = onToggleTheme,
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("auth_theme_toggle_button")
            ) {
                Icon(
                    imageVector = if (isCurrentlyDark) Icons.Filled.LightMode else Icons.Filled.DarkMode,
                    contentDescription = "Переключить тему",
                    tint = MaterialTheme.colorScheme.onSurface
                )
            }
        }
    }
}

@Composable
private fun FeaturePill(icon: ImageVector, label: String) {
    val glassActive = isLiquidGlassActive()
    val pillShape = RoundedCornerShape(50)
    Surface(
        shape = pillShape,
        color = if (glassActive) Color.Transparent else MaterialTheme.colorScheme.surfaceContainer,
        border = if (glassActive) null else BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        modifier = if (glassActive) Modifier.liquidGlassSurface(shape = pillShape) else Modifier
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(15.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

private suspend fun signInCredentialIntoManagedSession(
    context: Context,
    googleEmail: String,
    idToken: String,
    savedAccounts: List<SavedAccount>,
    onBeforeCredentialSwap: suspend () -> Unit = {}
) {
    val targetApp = FirebaseSessionManager.resolveTargetAppForGoogleEmail(
        context = context,
        googleEmail = googleEmail,
        savedAccounts = savedAccounts
    )
    val currentActiveAppName = FirebaseSessionManager.getActiveApp(context)?.name
    val authCredential = GoogleAuthProvider.getCredential(idToken, null)

    if (targetApp != null) {
        val targetAuth = FirebaseAuth.getInstance(targetApp)
        val sameSlotAsActive = targetApp.name == currentActiveAppName
        if (sameSlotAsActive) {
            withContext(NonCancellable) {
                onBeforeCredentialSwap()
            }
        }
        targetAuth.signInWithCredential(authCredential).await()
        if (!sameSlotAsActive) {
            withContext(NonCancellable) {
                onBeforeCredentialSwap()
            }
        }
        FirebaseSessionManager.activateApp(context, targetApp.name)
    } else {
        withContext(NonCancellable) {
            onBeforeCredentialSwap()
        }
        Firebase.auth.signInWithCredential(authCredential).await()
    }
}

fun attemptAutoSignIn(
    context: Context,
    credentialManager: CredentialManager,
    savedAccounts: List<SavedAccount> = emptyList(),
    onAuthSuccess: () -> Unit,
    onUnauthenticated: () -> Unit,
    scope: CoroutineScope
) {
    val activeAuth = FirebaseSessionManager.getActiveAuth(context) ?: runCatching { Firebase.auth }.getOrNull()
    if (runCatching { activeAuth?.currentUser != null }.getOrDefault(false)) {
        onAuthSuccess()
        return
    }
    val clientId = try {
        context.getString(R.string.default_web_client_id)
    } catch (e: Exception) {
        onUnauthenticated()
        return
    }

    val googleIdOption = GetGoogleIdOption.Builder()
        .setFilterByAuthorizedAccounts(true)
        .setServerClientId(clientId)
        .setAutoSelectEnabled(true)
        .build()

    val request = GetCredentialRequest.Builder()
        .addCredentialOption(googleIdOption)
        .build()

    scope.launch {
        try {
            val targetContext = context.findActivity() ?: context
            val result = credentialManager.getCredential(targetContext, request)
            val credential = result.credential
            if (credential is CustomCredential && credential.type == TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                val googleCred = GoogleIdTokenCredential.createFrom(credential.data)
                signInCredentialIntoManagedSession(
                    context = context,
                    googleEmail = googleCred.id,
                    idToken = googleCred.idToken,
                    savedAccounts = savedAccounts
                )
                onAuthSuccess()
            } else {
                onUnauthenticated()
            }
        } catch (e: CancellationException) {
            throw e
        } catch (t: Throwable) {
            onUnauthenticated()
        }
    }
}

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

fun onGoogleSignInClicked(
    context: Context,
    credentialManager: CredentialManager,
    savedAccounts: List<SavedAccount> = emptyList(),
    onAuthSuccess: () -> Unit,
    onAuthError: (String) -> Unit,
    scope: CoroutineScope,
    onAuthCancelled: () -> Unit = {}
) {
    val clientId = try {
        context.getString(R.string.default_web_client_id)
    } catch (e: Exception) {
        onAuthError("Конфигурация Google Sign-In отсутствует: default_web_client_id не найден")
        return
    }

    val signInOption = GetSignInWithGoogleOption.Builder(serverClientId = clientId).build()
    val request = GetCredentialRequest.Builder()
        .addCredentialOption(signInOption)
        .build()

    scope.launch {
        try {
            val activity = context.findActivity()
                ?: throw IllegalStateException("Требуется Activity контекст для входа")
            val result = credentialManager.getCredential(activity, request)
            val credential = result.credential
            if (credential is CustomCredential && credential.type == TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                val googleCred = GoogleIdTokenCredential.createFrom(credential.data)
                signInCredentialIntoManagedSession(
                    context = context,
                    googleEmail = googleCred.id,
                    idToken = googleCred.idToken,
                    savedAccounts = savedAccounts
                )
                onAuthSuccess()
            } else {
                onAuthError("Неожиданный тип учётных данных")
            }
        } catch (e: GetCredentialCancellationException) {
            Log.w("Auth", "Google Sign-In flow cancelled or dismissed: ${e.message}", e)
            onAuthCancelled()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e("Auth", "Google Sign-In failed", e)
            onAuthError(e.localizedMessage ?: "Не удалось выполнить вход")
        }
    }
}

fun onOneTapSignInClicked(
    context: Context,
    credentialManager: CredentialManager,
    enforceMaxAccounts: Boolean = false,
    existingAccountEmails: List<String> = emptyList(),
    savedAccounts: List<SavedAccount> = emptyList(),
    onAuthSuccess: () -> Unit,
    onAuthError: (String) -> Unit,
    scope: CoroutineScope,
    onAuthCancelled: () -> Unit = {}
) {
    val clientId = try {
        context.getString(R.string.default_web_client_id)
    } catch (e: Exception) {
        onAuthError("Конфигурация Google Sign-In отсутствует: default_web_client_id не найден")
        return
    }

    val googleIdOption = GetGoogleIdOption.Builder()
        .setFilterByAuthorizedAccounts(false)
        .setServerClientId(clientId)
        .setAutoSelectEnabled(false)
        .build()

    val oneTapRequest = GetCredentialRequest.Builder()
        .addCredentialOption(googleIdOption)
        .build()

    scope.launch {
        try {
            val activity = context.findActivity()
                ?: throw IllegalStateException("Требуется Activity контекст для входа")
            val result = try {
                credentialManager.getCredential(activity, oneTapRequest)
            } catch (e: GetCredentialCancellationException) {
                throw e
            } catch (e: NoCredentialException) {
                Log.w("Auth", "One Tap has no available credentials, falling back to Google Sign-In sheet", e)
                val fallbackOption = GetSignInWithGoogleOption.Builder(serverClientId = clientId).build()
                val fallbackRequest = GetCredentialRequest.Builder()
                    .addCredentialOption(fallbackOption)
                    .build()
                credentialManager.getCredential(activity, fallbackRequest)
            } catch (e: GetCredentialException) {
                Log.w("Auth", "One Tap failed (${e.type}), falling back to Google Sign-In sheet", e)
                val fallbackOption = GetSignInWithGoogleOption.Builder(serverClientId = clientId).build()
                val fallbackRequest = GetCredentialRequest.Builder()
                    .addCredentialOption(fallbackOption)
                    .build()
                credentialManager.getCredential(activity, fallbackRequest)
            }

            val credential = result.credential
            if (credential is CustomCredential && credential.type == TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                val googleCred = GoogleIdTokenCredential.createFrom(credential.data)
                val googleEmail = googleCred.id
                if (enforceMaxAccounts &&
                    existingAccountEmails.size >= SavedAccountsStore.MAX_ACCOUNTS &&
                    existingAccountEmails.none { it.equals(googleEmail, ignoreCase = true) }
                ) {
                    onAuthError(
                        "Достигнут лимит: не более ${SavedAccountsStore.MAX_ACCOUNTS} аккаунтов. " +
                            "Удалите один из сохранённых аккаунтов."
                    )
                    return@launch
                }
                signInCredentialIntoManagedSession(
                    context = context,
                    googleEmail = googleEmail,
                    idToken = googleCred.idToken,
                    savedAccounts = savedAccounts
                )
                onAuthSuccess()
            } else {
                onAuthError("Неожиданный тип учётных данных")
            }
        } catch (e: GetCredentialCancellationException) {
            Log.w("Auth", "One Tap flow cancelled: ${e.message}", e)
            onAuthCancelled()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e("Auth", "One Tap Sign-In failed", e)
            onAuthError("Не удалось выполнить вход через Google: ${e.localizedMessage ?: "попробуйте кнопку выше"}")
        }
    }
}

/**
 * Fast re-entry for a tapped saved profile whose Firebase session is signed out:
 * tries authorized-only Google auto-select first so the user doesn't have to remember
 * or pick their Google account when possible, and falls back to the Google Sign-In sheet.
 */
fun signInToSavedGoogleAccount(
    context: Context,
    credentialManager: CredentialManager,
    targetAccount: SavedAccount,
    savedAccounts: List<SavedAccount> = emptyList(),
    onBeforeCredentialSwap: suspend () -> Unit = {},
    onAuthSuccess: () -> Unit,
    onAuthError: (String) -> Unit,
    scope: CoroutineScope,
    onAuthCancelled: () -> Unit = {}
) {
    val clientId = try {
        context.getString(R.string.default_web_client_id)
    } catch (e: Exception) {
        onAuthError("Конфигурация Google Sign-In отсутствует: default_web_client_id не найден")
        return
    }

    val authorizedOption = GetGoogleIdOption.Builder()
        .setFilterByAuthorizedAccounts(true)
        .setServerClientId(clientId)
        .setAutoSelectEnabled(true)
        .build()
    val authorizedRequest = GetCredentialRequest.Builder()
        .addCredentialOption(authorizedOption)
        .build()

    scope.launch {
        try {
            val activity = context.findActivity()
                ?: throw IllegalStateException("Требуется Activity контекст для входа")
            val result = try {
                credentialManager.getCredential(activity, authorizedRequest)
            } catch (e: GetCredentialCancellationException) {
                throw e
            } catch (e: GetCredentialException) {
                Log.w("Auth", "Authorized fast re-auth unavailable (${e.type}), falling back to Google Sign-In sheet", e)
                val fallbackOption = GetSignInWithGoogleOption.Builder(serverClientId = clientId).build()
                val fallbackRequest = GetCredentialRequest.Builder()
                    .addCredentialOption(fallbackOption)
                    .build()
                credentialManager.getCredential(activity, fallbackRequest)
            }

            val credential = result.credential
            if (credential is CustomCredential && credential.type == TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                val googleCred = GoogleIdTokenCredential.createFrom(credential.data)
                val googleEmail = googleCred.id
                val existingEmails = savedAccounts.map { it.email }
                if (existingEmails.size >= SavedAccountsStore.MAX_ACCOUNTS &&
                    existingEmails.none { it.equals(googleEmail, ignoreCase = true) }
                ) {
                    val expectedHint = targetAccount.email.takeIf { it.isNotBlank() }?.let { " ($it)" }.orEmpty()
                    onAuthError(
                        "Профиль «${targetAccount.displayName}» привязан к аккаунту Google$expectedHint, а выбран $googleEmail. " +
                            "Удалите один из сохранённых аккаунтов или выберите нужную почту."
                    )
                    return@launch
                }
                signInCredentialIntoManagedSession(
                    context = context,
                    googleEmail = googleEmail,
                    idToken = googleCred.idToken,
                    savedAccounts = savedAccounts,
                    onBeforeCredentialSwap = onBeforeCredentialSwap
                )
                onAuthSuccess()
            } else {
                onAuthError("Неожиданный тип учётных данных")
            }
        } catch (e: GetCredentialCancellationException) {
            Log.w("Auth", "Saved account re-auth cancelled: ${e.message}", e)
            onAuthCancelled()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e("Auth", "Saved account re-auth failed", e)
            onAuthError(e.localizedMessage ?: "Не удалось войти в профиль")
        }
    }
}

fun switchOrAddGoogleAccount(
    context: Context,
    credentialManager: CredentialManager,
    enforceMaxAccounts: Boolean = true,
    existingAccountEmails: List<String> = emptyList(),
    savedAccounts: List<SavedAccount> = emptyList(),
    onBeforeCredentialSwap: suspend () -> Unit = {},
    onAuthSuccess: () -> Unit,
    onAuthError: (String) -> Unit,
    scope: CoroutineScope,
    onAuthCancelled: () -> Unit = {}
) {
    val clientId = try {
        context.getString(R.string.default_web_client_id)
    } catch (e: Exception) {
        onAuthError("Конфигурация Google Sign-In отсутствует: default_web_client_id не найден")
        return
    }

    val signInOption = GetSignInWithGoogleOption.Builder(serverClientId = clientId).build()
    val request = GetCredentialRequest.Builder()
        .addCredentialOption(signInOption)
        .build()

    scope.launch {
        try {
            val activity = context.findActivity()
                ?: throw IllegalStateException("Требуется Activity контекст для входа")
            val result = credentialManager.getCredential(activity, request)
            val credential = result.credential
            if (credential is CustomCredential && credential.type == TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                val googleCred = GoogleIdTokenCredential.createFrom(credential.data)
                val googleEmail = googleCred.id
                if (enforceMaxAccounts &&
                    existingAccountEmails.size >= SavedAccountsStore.MAX_ACCOUNTS &&
                    existingAccountEmails.none { it.equals(googleEmail, ignoreCase = true) }
                ) {
                    onAuthError(
                        "Достигнут лимит: не более ${SavedAccountsStore.MAX_ACCOUNTS} аккаунтов. " +
                            "Удалите один из сохранённых аккаунтов."
                    )
                    return@launch
                }
                signInCredentialIntoManagedSession(
                    context = context,
                    googleEmail = googleEmail,
                    idToken = googleCred.idToken,
                    savedAccounts = savedAccounts,
                    onBeforeCredentialSwap = onBeforeCredentialSwap
                )
                onAuthSuccess()
            } else {
                onAuthError("Неожиданный тип учётных данных")
            }
        } catch (e: GetCredentialCancellationException) {
            Log.w("Auth", "Account switch / Google Sign-In cancelled: ${e.message}", e)
            onAuthCancelled()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e("Auth", "Account switch / Google Sign-In failed", e)
            onAuthError(e.localizedMessage ?: "Не удалось переключить аккаунт")
        }
    }
}

fun signOutUser(
    credentialManager: CredentialManager,
    scope: CoroutineScope,
    authToSignOut: FirebaseAuth? = null,
    onSignOutComplete: () -> Unit = {}
) {
    scope.launch {
        withContext(NonCancellable) {
            try {
                credentialManager.clearCredentialState(ClearCredentialStateRequest())
            } catch (e: Exception) {
                Log.w("Auth", "Failed to clear credential state: ${e.message}")
            } finally {
                (authToSignOut ?: FirebaseSessionManager.activeAuthOrDefault()).signOut()
                onSignOutComplete()
            }
        }
    }
}
