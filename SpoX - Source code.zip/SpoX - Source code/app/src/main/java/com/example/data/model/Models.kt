package com.example.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.PropertyName
import com.google.firebase.firestore.ServerTimestamp

enum class AppThemeMode(val wireValue: String) {
    DARK("dark"),
    LIGHT("light"),
    SYSTEM("system");

    companion object {
        fun fromWire(value: String?): AppThemeMode =
            entries.firstOrNull { it.wireValue == value } ?: DARK
    }
}

enum class UserRole(val wireValue: String, val labelRu: String, val shortBadge: String) {
    USER("user", "Пользователь", ""),
    TESTER("tester", "Тестировщик", "TESTER"),
    DEVELOPER("developer", "Разработчик", "DEV");

    companion object {
        fun fromWire(value: String?): UserRole =
            entries.firstOrNull { it.wireValue == value?.lowercase() } ?: USER
    }
}

enum class ModerationStatus(val wireValue: String, val labelRu: String) {
    ACTIVE("active", "Активен"),
    MUTED("muted", "В муте"),
    BANNED("banned", "Заблокирован");

    companion object {
        fun fromWire(value: String?): ModerationStatus =
            entries.firstOrNull { it.wireValue == value?.lowercase() } ?: ACTIVE
    }
}

enum class UserPresenceStatus(val labelRu: String) {
    ONLINE("в сети"),
    RECENTLY("был в сети недавно"),
    OFFLINE("не в сети")
}

@IgnoreExtraProperties
data class UserPrivateProfile(
    @DocumentId val id: String = "",
    val userId: String = "",
    val email: String = "",
    val displayName: String = "",
    val handle: String = "",
    val avatarBase64: String = "",
    val preferredTheme: String = "dark",
    val keyFingerprint: String = "",
    val role: String = "user",
    val redeemedCodeHash: String = "",
    val moderationStatus: String = "active",
    val mutedUntilEpochMs: Long = 0L,
    val moderationReason: String = "",
    val moderatedBy: String = "",
    @ServerTimestamp val moderatedAt: Timestamp? = null,
    val fcmToken: String = "",
    @ServerTimestamp val fcmUpdatedAt: Timestamp? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun isCurrentlyMuted(nowMs: Long = System.currentTimeMillis()): Boolean {
        if (ModerationStatus.fromWire(moderationStatus) != ModerationStatus.MUTED) return false
        return mutedUntilEpochMs == 0L || nowMs < mutedUntilEpochMs
    }

    fun isBanned(): Boolean = ModerationStatus.fromWire(moderationStatus) == ModerationStatus.BANNED
}

@IgnoreExtraProperties
data class PublicUserProfile(
    @DocumentId val id: String = "",
    val userId: String = "",
    val displayName: String = "",
    val handle: String = "",
    val avatarBase64: String = "",
    val emailHash: String = "",
    val publicKeyBase64: String = "",
    val keyFingerprint: String = "",
    val avatarColorIndex: Long = 0L,
    @get:PropertyName("isDiscoverable")
    val isDiscoverable: Boolean = true,
    @get:PropertyName("isOnline")
    val isOnline: Boolean = true,
    val role: String = "user",
    val moderationStatus: String = "active",
    val mutedUntilEpochMs: Long = 0L,
    val moderationReason: String = "",
    @ServerTimestamp val lastSeenAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun isCurrentlyMuted(nowMs: Long = System.currentTimeMillis()): Boolean {
        if (ModerationStatus.fromWire(moderationStatus) != ModerationStatus.MUTED) return false
        return mutedUntilEpochMs == 0L || nowMs < mutedUntilEpochMs
    }

    fun isBanned(): Boolean = ModerationStatus.fromWire(moderationStatus) == ModerationStatus.BANNED

    fun presenceStatus(nowMs: Long = System.currentTimeMillis()): UserPresenceStatus {
        if (isBanned()) return UserPresenceStatus.OFFLINE
        val tsMs = (lastSeenAt ?: updatedAt)?.toDate()?.time
        val elapsedMs = if (tsMs != null) (nowMs - tsMs).coerceAtLeast(0L) else null
        return if (isOnline) {
            when {
                elapsedMs == null || elapsedMs <= HEARTBEAT_ONLINE_WINDOW_MS -> UserPresenceStatus.ONLINE
                elapsedMs <= RECENTLY_ONLINE_WINDOW_MS -> UserPresenceStatus.RECENTLY
                else -> UserPresenceStatus.OFFLINE
            }
        } else {
            if (elapsedMs != null && elapsedMs <= RECENTLY_ONLINE_WINDOW_MS) {
                UserPresenceStatus.RECENTLY
            } else {
                UserPresenceStatus.OFFLINE
            }
        }
    }

    companion object {
        const val HEARTBEAT_ONLINE_WINDOW_MS = 120_000L
        const val RECENTLY_ONLINE_WINDOW_MS = 15 * 60_000L
    }
}

@IgnoreExtraProperties
data class DeletedAccountRecord(
    @DocumentId val id: String = "",
    val userId: String = "",
    val deletedBy: String = "",
    val reason: String = "",
    @ServerTimestamp val deletedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class RoleCodeRecord(
    @DocumentId val id: String = "",
    val codeHash: String = "",
    val codePreview: String = "",
    val targetRole: String = "tester",
    val createdBy: String = "",
    @get:PropertyName("isUsed")
    val isUsed: Boolean = false,
    val usedBy: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val usedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class Conversation(
    @DocumentId val id: String = "",
    val title: String = "",
    val description: String = "",
    @get:PropertyName("isGroup")
    val isGroup: Boolean = false,
    val createdBy: String = "",
    val memberUids: List<String> = emptyList(),
    val memberNames: Map<String, String> = emptyMap(),
    val memberKeyEnvelopes: Map<String, String> = emptyMap(),
    val lastMessagePreview: String = "",
    val lastMessageType: String = "none",
    val lastMessageSenderId: String = "",
    val activeCallId: String = "",
    val unreadCounts: Map<String, Long> = emptyMap(),
    val lastReadAtMillis: Map<String, Long> = emptyMap(),
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun isCreator(uid: String): Boolean = createdBy == uid

    fun unreadCountFor(uid: String): Int =
        (unreadCounts[uid] ?: 0L).coerceAtLeast(0L).toInt()

    fun isLastMessageReadByOther(senderUid: String): Boolean {
        if (lastMessageSenderId != senderUid || lastMessageType == "none") return false
        val msgTimeMs = updatedAt?.toDate()?.time ?: return false
        val others = memberUids.filter { it != senderUid }
        if (others.isEmpty()) return true
        return others.any { otherUid ->
            (lastReadAtMillis[otherUid] ?: 0L) >= msgTimeMs
        }
    }

    fun isSavedMessages(currentUserId: String): Boolean =
        !isGroup && (id == savedConversationId(currentUserId) ||
            (memberUids.size == 1 && memberUids.firstOrNull() == currentUserId))

    companion object {
        fun savedConversationId(uid: String): String = "saved_$uid"
    }
}

@IgnoreExtraProperties
data class EncryptedMessage(
    @DocumentId val id: String = "",
    val conversationId: String = "",
    val senderId: String = "",
    val senderName: String = "",
    val memberUids: List<String> = emptyList(),
    val messageType: String = "text",
    val ivBase64: String = "",
    val encryptedPayload: String = "",
    val keyVersion: Long = 1L,
    @get:PropertyName("isDeleted")
    val isDeleted: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class EncryptedMediaChunk(
    @DocumentId val id: String = "",
    val conversationId: String = "",
    val messageId: String = "",
    val senderId: String = "",
    val memberUids: List<String> = emptyList(),
    val chunkIndex: Long = 0L,
    val ivBase64: String = "",
    val encryptedPayload: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null
)

@IgnoreExtraProperties
data class CallSession(
    @DocumentId val id: String = "",
    val conversationId: String = "",
    val conversationTitle: String = "",
    val callerId: String = "",
    val callerName: String = "",
    @get:PropertyName("isGroupCall")
    val isGroupCall: Boolean = false,
    val callType: String = "audio",
    val status: String = "ringing",
    val memberUids: List<String> = emptyList(),
    val activeParticipantUids: List<String> = emptyList(),
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class CallParticipant(
    @DocumentId val id: String = "",
    val callId: String = "",
    val userId: String = "",
    val displayName: String = "",
    val memberUids: List<String> = emptyList(),
    @get:PropertyName("isMuted")
    val isMuted: Boolean = false,
    @get:PropertyName("isCameraOn")
    val isCameraOn: Boolean = false,
    @get:PropertyName("isSpeaking")
    val isSpeaking: Boolean = false,
    val audioLevel: Long = 0L,
    @ServerTimestamp val joinedAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class CallAudioFrame(
    @DocumentId val id: String = "",
    val callId: String = "",
    val senderId: String = "",
    val seq: Long = 0L,
    val sampleRate: Long = 16000L,
    val codec: String = "ima_adpcm",
    val payloadBase64: String = "",
    val memberUids: List<String> = emptyList(),
    @ServerTimestamp val createdAt: Timestamp? = null
)

data class ReplyQuoteInfo(
    val messageId: String = "",
    val senderName: String = "",
    val previewText: String = "",
    val messageType: String = "text"
)

data class ForwardOriginInfo(
    val originalSenderId: String = "",
    val originalSenderName: String = ""
)

sealed interface DecryptedContent {
    data class Text(val text: String) : DecryptedContent
    data class Voice(
        val durationMs: Long,
        val waveform: List<Int>,
        val audioBytes: ByteArray
    ) : DecryptedContent
    data class FileAttachment(
        val fileName: String,
        val mimeType: String,
        val sizeBytes: Long,
        val bytes: ByteArray,
        val isImage: Boolean,
        val isChunked: Boolean = false,
        val chunkCount: Int = 0
    ) : DecryptedContent
    data class CallEvent(val text: String) : DecryptedContent
    data object Deleted : DecryptedContent
    data object KeyUnavailable : DecryptedContent
}

data class DecryptedMessageItem(
    val id: String,
    val conversationId: String,
    val senderId: String,
    val senderName: String,
    val messageType: String,
    val content: DecryptedContent,
    val createdAt: Timestamp?,
    val isEncryptedVerified: Boolean,
    val replyTo: ReplyQuoteInfo? = null,
    val forwardedFrom: ForwardOriginInfo? = null
)
