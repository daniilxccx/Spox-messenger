package com.example.data.repository

import android.content.Context
import android.graphics.Bitmap
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.AppThemeMode
import com.example.data.model.AppVisualTheme
import com.example.data.model.ChatWallpaperPreset
import com.example.data.model.OutgoingBubbleStyle
import com.example.ui.components.BitmapMemoryCache
import java.io.File
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ThemePreferenceStoreTest {

    private lateinit var context: Context
    private lateinit var store: ThemePreferenceStore

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        store = ThemePreferenceStore(context)
        BitmapMemoryCache.setResourceSavingMode(false)
        BitmapMemoryCache.clearAllCaches()
    }

    @Test
    fun appearanceCustomizationPersistsAndResets() = runBlocking {
        val initial = store.appearanceConfig.first()
        assertEquals(true, initial.showStories)
        assertEquals(true, initial.showFolders)
        assertEquals(false, initial.liquidGlassEnabled)
        assertEquals(true, initial.smoothStoriesAppearance)
        assertEquals(true, initial.smoothChatsAppearance)
        assertEquals(true, initial.smoothChatsPanelAppearance)
        assertEquals(true, initial.smoothChatMessagesAppearance)

        store.setThemeMode(AppThemeMode.LIGHT)
        store.setVisualTheme(AppVisualTheme.AMETHYST)
        store.setWallpaperPreset(ChatWallpaperPreset.AURORA_GLOW)
        store.setOutgoingBubbleStyle(OutgoingBubbleStyle.CRIMSON_ROSE)
        store.setShowStories(false)
        store.setShowFolders(false)
        store.setLiquidGlassEnabled(true)
        store.setSmoothStoriesAppearance(false)
        store.setSmoothChatsAppearance(false)
        store.setSmoothChatsPanelAppearance(false)
        store.setSmoothChatMessagesAppearance(false)

        val updated = store.appearanceConfig.first()
        assertEquals(AppThemeMode.LIGHT, updated.themeMode)
        assertEquals(AppVisualTheme.AMETHYST, updated.visualTheme)
        assertEquals(ChatWallpaperPreset.AURORA_GLOW, updated.wallpaperPreset)
        assertEquals(OutgoingBubbleStyle.CRIMSON_ROSE, updated.outgoingBubbleStyle)
        assertEquals(false, updated.showStories)
        assertEquals(false, updated.showFolders)
        assertEquals(true, updated.liquidGlassEnabled)
        assertEquals(false, updated.smoothStoriesAppearance)
        assertEquals(false, updated.smoothChatsAppearance)
        assertEquals(false, updated.smoothChatsPanelAppearance)
        assertEquals(false, updated.smoothChatMessagesAppearance)

        store.resetCustomization()

        val afterReset = store.appearanceConfig.first()
        assertEquals(AppVisualTheme.SPOX_CYBER, afterReset.visualTheme)
        assertEquals(ChatWallpaperPreset.THEME_DEFAULT, afterReset.wallpaperPreset)
        assertEquals(OutgoingBubbleStyle.THEME_AUTO, afterReset.outgoingBubbleStyle)
        assertEquals(true, afterReset.showStories)
        assertEquals(true, afterReset.showFolders)
        assertEquals(false, afterReset.liquidGlassEnabled)
        assertEquals(true, afterReset.smoothStoriesAppearance)
        assertEquals(true, afterReset.smoothChatsAppearance)
        assertEquals(true, afterReset.smoothChatsPanelAppearance)
        assertEquals(true, afterReset.smoothChatMessagesAppearance)
    }

    @Test
    fun customizationEnumsFallbackGracefullyOnUnknownWireValue() {
        assertEquals(AppVisualTheme.SPOX_CYBER, AppVisualTheme.fromWire("unknown_skin"))
        assertEquals(AppVisualTheme.OCEAN_NIGHT, AppVisualTheme.fromWire("ocean_night"))
        assertEquals(ChatWallpaperPreset.THEME_DEFAULT, ChatWallpaperPreset.fromWire(null))
        assertEquals(ChatWallpaperPreset.CYBER_GRID, ChatWallpaperPreset.fromWire("cyber_grid"))
        assertEquals(OutgoingBubbleStyle.THEME_AUTO, OutgoingBubbleStyle.fromWire(""))
        assertEquals(OutgoingBubbleStyle.EMERALD_MINT, OutgoingBubbleStyle.fromWire("emerald_mint"))
    }

    @Test
    fun corruptedDataStoreFileRecoversToDefaults() = runBlocking {
        val dsDir = File(context.filesDir, "datastore")
        dsDir.mkdirs()
        val prefsFile = File(dsDir, "cipherchat_prefs.preferences_pb")
        prefsFile.writeBytes(byteArrayOf(0x7F, 0x00, 0x13, 0x55, 0x22, 0x11))

        val recovered = store.appearanceConfig.first()
        assertEquals(AppVisualTheme.SPOX_CYBER, recovered.visualTheme)
        assertEquals(ChatWallpaperPreset.THEME_DEFAULT, recovered.wallpaperPreset)
        assertEquals(OutgoingBubbleStyle.THEME_AUTO, recovered.outgoingBubbleStyle)
    }

    @Test
    fun resourceSavingModePersistsAndSurvivesVisualReset() = runBlocking {
        assertFalse(store.appearanceConfig.first().resourceSavingMode)
        assertFalse(BitmapMemoryCache.isResourceSavingMode)

        store.setResourceSavingMode(true)
        assertTrue(store.appearanceConfig.first().resourceSavingMode)
        assertTrue(BitmapMemoryCache.isResourceSavingMode)

        // Resetting visual customization must preserve the device resource saving mode
        store.resetCustomization()
        assertTrue(store.appearanceConfig.first().resourceSavingMode)

        store.setResourceSavingMode(false)
        assertFalse(store.appearanceConfig.first().resourceSavingMode)
        assertFalse(BitmapMemoryCache.isResourceSavingMode)
    }

    @Test
    fun bitmapMemoryCacheResizesAndClearsAllEntries() = runBlocking {
        val sample = Bitmap.createBitmap(16, 16, Bitmap.Config.ARGB_8888)
        val out = java.io.ByteArrayOutputStream()
        sample.compress(Bitmap.CompressFormat.PNG, 100, out)
        val bytes = out.toByteArray()

        assertEquals(0, BitmapMemoryCache.cachedEntryCount())
        BitmapMemoryCache.decodeMediaThumb("msg_1", bytes, maxDimensionPx = 200)
        assertEquals(1, BitmapMemoryCache.cachedEntryCount())

        // Enabling resource saving mode immediately evicts heavy caches
        BitmapMemoryCache.setResourceSavingMode(true)
        assertEquals(0, BitmapMemoryCache.cachedEntryCount())

        BitmapMemoryCache.decodeMediaThumb("msg_1", bytes, maxDimensionPx = 200)
        assertEquals(1, BitmapMemoryCache.cachedEntryCount())

        BitmapMemoryCache.clearAllCaches()
        assertEquals(0, BitmapMemoryCache.cachedEntryCount())
    }
}
