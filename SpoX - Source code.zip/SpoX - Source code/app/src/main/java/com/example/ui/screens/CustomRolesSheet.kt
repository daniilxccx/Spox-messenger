package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PersonAddAlt1
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.CustomRolePalette
import com.example.data.model.CustomRolePermission
import com.example.data.model.CustomRoleRecord
import com.example.data.model.UserPrivateProfile
import com.example.data.model.UserRole
import com.example.ui.components.CustomRoleBadge
import com.example.ui.components.RoleBadge
import com.example.ui.components.UserAvatar
import com.example.ui.components.parseRoleColorHex
import com.example.ui.theme.ApplyLiquidGlassWindowBlur
import com.example.ui.theme.isLiquidGlassActive
import com.example.ui.theme.liquidGlassDialogContainerColor
import com.example.ui.theme.liquidGlassSheetContainerColor
import com.example.ui.theme.liquidGlassSheetScrimColor
import com.example.ui.theme.liquidGlassSurface
import kotlinx.coroutines.launch
import kotlin.math.abs

private enum class CustomRolesTab(val label: String) {
    ROLES("Роли"),
    ASSIGNMENTS("Выдача ролей")
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun CustomRolesSheet(
    customRoles: List<CustomRoleRecord>,
    users: List<UserPrivateProfile>,
    currentUserId: String,
    isBusy: Boolean,
    onDismiss: () -> Unit,
    onSaveCustomRole: (
        editingRoleId: String?,
        name: String,
        badgeText: String,
        colorHex: String,
        permissions: Set<CustomRolePermission>,
        onSuccess: () -> Unit
    ) -> Unit,
    onDeleteCustomRole: (roleId: String) -> Unit,
    onAssignCustomRole: (targetUid: String, role: CustomRoleRecord?) -> Unit
) {
    val scope = rememberCoroutineScope()
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val pagerState = rememberPagerState(
        initialPage = CustomRolesTab.ROLES.ordinal,
        pageCount = { CustomRolesTab.entries.size }
    )

    var showEditorDialog by remember { mutableStateOf(false) }
    var editingRole by remember { mutableStateOf<CustomRoleRecord?>(null) }
    var deleteCandidate by remember { mutableStateOf<CustomRoleRecord?>(null) }
    var assignTargetUser by remember { mutableStateOf<UserPrivateProfile?>(null) }
    var userSearchQuery by remember { mutableStateOf("") }
    val glassActive = isLiquidGlassActive()

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = liquidGlassSheetContainerColor(),
        scrimColor = liquidGlassSheetScrimColor()
    ) {
        ApplyLiquidGlassWindowBlur()
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 6.dp)
                .testTag("custom_roles_sheet"),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.primaryContainer,
                        modifier = Modifier.size(40.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Filled.Badge,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "Кастомные роли",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Ролей: ${customRoles.size} • Выдача всем, кроме других разработчиков",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Filled.Close, contentDescription = "Закрыть")
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                CustomRolesTab.entries.forEachIndexed { index, tab ->
                    FilterChip(
                        selected = pagerState.targetPage == index,
                        onClick = { scope.launch { pagerState.animateScrollToPage(index) } },
                        label = { Text(tab.label) },
                        modifier = Modifier.testTag("custom_roles_tab_${tab.name.lowercase()}")
                    )
                }
                Spacer(modifier = Modifier.weight(1f))
                Button(
                    onClick = {
                        editingRole = null
                        showEditorDialog = true
                    },
                    enabled = !isBusy,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .height(48.dp)
                        .testTag("create_custom_role_button")
                ) {
                    Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Создать", maxLines = 1)
                }
            }

            HorizontalDivider()

            HorizontalPager(
                state = pagerState,
                beyondViewportPageCount = 1,
                key = { CustomRolesTab.entries[it].name },
                modifier = Modifier.fillMaxWidth()
            ) { pageIndex ->
                when (CustomRolesTab.entries[pageIndex]) {
                    CustomRolesTab.ROLES -> {
                        if (customRoles.isEmpty()) {
                            Surface(
                                shape = RoundedCornerShape(18.dp),
                                color = MaterialTheme.colorScheme.surfaceContainer,
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(20.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.Security,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(34.dp)
                                    )
                                    Text(
                                        text = "Кастомных ролей пока нет",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Text(
                                        text = "Создайте первую роль с нужным цветом, значком и правами — затем её можно выдать любому пользователю или тестеру.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        } else {
                            LazyColumn(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .heightIn(min = 200.dp, max = 460.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                items(customRoles, key = { it.resolvedId() }) { role ->
                                    val perms = role.parsedPermissions()
                                    val assignedCount = remember(users, role.resolvedId()) {
                                        users.count { it.customRoleId == role.resolvedId() }
                                    }
                                    val accentColor = parseRoleColorHex(
                                        role.colorHex,
                                        MaterialTheme.colorScheme.primary
                                    )
                                    val roleCardShape = RoundedCornerShape(16.dp)
                                    Surface(
                                        shape = roleCardShape,
                                        color = if (glassActive) Color.Transparent else MaterialTheme.colorScheme.surfaceContainer,
                                        border = if (glassActive) null else BorderStroke(1.dp, accentColor.copy(alpha = 0.42f)),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .then(
                                                if (glassActive) {
                                                    Modifier.liquidGlassSurface(
                                                        shape = roleCardShape,
                                                        accentGlow = accentColor
                                                    )
                                                } else {
                                                    Modifier
                                                }
                                            )
                                            .testTag("custom_role_card_${role.resolvedId()}")
                                    ) {
                                        Column(
                                            modifier = Modifier.padding(14.dp),
                                            verticalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Row(
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                                    modifier = Modifier.weight(1f)
                                                ) {
                                                    Box(
                                                        modifier = Modifier
                                                            .size(14.dp)
                                                            .clip(CircleShape)
                                                            .background(accentColor)
                                                    )
                                                    Text(
                                                        text = role.name,
                                                        style = MaterialTheme.typography.titleMedium,
                                                        fontWeight = FontWeight.SemiBold,
                                                        maxLines = 1,
                                                        overflow = TextOverflow.Ellipsis,
                                                        modifier = Modifier.weight(1f, fill = false)
                                                    )
                                                    CustomRoleBadge(
                                                        name = role.name,
                                                        badgeText = role.badgeText,
                                                        colorHex = role.colorHex,
                                                        compact = true,
                                                        isPriority = CustomRolePermission.PRIORITY_BADGE in perms
                                                    )
                                                }
                                                Text(
                                                    text = "Участников: $assignedCount",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }

                                            if (perms.isEmpty()) {
                                                Text(
                                                    text = "Без дополнительных прав (только значок роли)",
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            } else {
                                                FlowRow(
                                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                                ) {
                                                    perms.forEach { perm ->
                                                        Surface(
                                                            shape = RoundedCornerShape(8.dp),
                                                            color = MaterialTheme.colorScheme.surfaceContainerHigh
                                                        ) {
                                                            Text(
                                                                text = perm.titleRu,
                                                                style = MaterialTheme.typography.labelSmall,
                                                                color = MaterialTheme.colorScheme.onSurface,
                                                                modifier = Modifier.padding(
                                                                    horizontal = 8.dp,
                                                                    vertical = 4.dp
                                                                )
                                                            )
                                                        }
                                                    }
                                                }
                                            }

                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                                            ) {
                                                OutlinedButton(
                                                    onClick = {
                                                        editingRole = role
                                                        showEditorDialog = true
                                                    },
                                                    enabled = !isBusy,
                                                    shape = RoundedCornerShape(12.dp),
                                                    modifier = Modifier
                                                        .weight(1f)
                                                        .height(48.dp)
                                                        .testTag("edit_custom_role_button_${role.resolvedId()}")
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Filled.Edit,
                                                        contentDescription = null,
                                                        modifier = Modifier.size(16.dp)
                                                    )
                                                    Spacer(modifier = Modifier.width(4.dp))
                                                    Text("Изменить", maxLines = 1)
                                                }
                                                Button(
                                                    onClick = {
                                                        scope.launch {
                                                            pagerState.animateScrollToPage(
                                                                CustomRolesTab.ASSIGNMENTS.ordinal
                                                            )
                                                        }
                                                    },
                                                    enabled = !isBusy,
                                                    shape = RoundedCornerShape(12.dp),
                                                    modifier = Modifier
                                                        .weight(1f)
                                                        .height(48.dp)
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Filled.PersonAddAlt1,
                                                        contentDescription = null,
                                                        modifier = Modifier.size(16.dp)
                                                    )
                                                    Spacer(modifier = Modifier.width(4.dp))
                                                    Text("Выдать", maxLines = 1)
                                                }
                                                OutlinedButton(
                                                    onClick = { deleteCandidate = role },
                                                    enabled = !isBusy,
                                                    shape = RoundedCornerShape(12.dp),
                                                    modifier = Modifier
                                                        .height(48.dp)
                                                        .testTag("delete_custom_role_button_${role.resolvedId()}")
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Filled.DeleteOutline,
                                                        contentDescription = "Удалить роль",
                                                        tint = MaterialTheme.colorScheme.error,
                                                        modifier = Modifier.size(18.dp)
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    CustomRolesTab.ASSIGNMENTS -> {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            OutlinedTextField(
                                value = userSearchQuery,
                                onValueChange = { userSearchQuery = it },
                                placeholder = { Text("Поиск пользователя (имя, @юзернейм, email)...") },
                                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                                trailingIcon = {
                                    if (userSearchQuery.isNotEmpty()) {
                                        IconButton(onClick = { userSearchQuery = "" }) {
                                            Icon(Icons.Filled.Close, contentDescription = "Очистить")
                                        }
                                    }
                                },
                                singleLine = true,
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("custom_roles_user_search_input")
                            )

                            val filteredUsers = remember(users, userSearchQuery) {
                                val q = userSearchQuery.trim().lowercase()
                                if (q.isEmpty()) users
                                else users.filter {
                                    it.displayName.lowercase().contains(q) ||
                                        it.handle.lowercase().contains(q) ||
                                        it.email.lowercase().contains(q) ||
                                        it.userId.lowercase().contains(q)
                                }
                            }

                            if (filteredUsers.isEmpty()) {
                                Text(
                                    text = "Пользователи не найдены.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(vertical = 20.dp)
                                )
                            } else {
                                LazyColumn(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .heightIn(min = 200.dp, max = 420.dp),
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    items(filteredUsers, key = { it.userId }) { user ->
                                        val isSelf = user.userId == currentUserId
                                        val sysRole = UserRole.fromWire(user.role)
                                        val isOtherDeveloper = !isSelf && sysRole == UserRole.DEVELOPER
                                        val hasCustom = user.hasCustomRole()
                                        val assignCardShape = RoundedCornerShape(16.dp)
                                        Surface(
                                            shape = assignCardShape,
                                            color = if (glassActive) Color.Transparent else MaterialTheme.colorScheme.surfaceContainer,
                                            border = if (glassActive) null else BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .then(
                                                    if (glassActive) Modifier.liquidGlassSurface(shape = assignCardShape)
                                                    else Modifier
                                                )
                                                .testTag("assign_role_user_card_${user.userId}")
                                        ) {
                                            Column(
                                                modifier = Modifier.padding(12.dp),
                                                verticalArrangement = Arrangement.spacedBy(8.dp)
                                            ) {
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    UserAvatar(
                                                        name = user.displayName.ifBlank { user.email },
                                                        avatarBase64 = user.avatarBase64,
                                                        colorIndex = abs(user.userId.hashCode()),
                                                        size = 42.dp
                                                    )
                                                    Spacer(modifier = Modifier.width(10.dp))
                                                    Column(modifier = Modifier.weight(1f)) {
                                                        Row(
                                                            verticalAlignment = Alignment.CenterVertically,
                                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                                        ) {
                                                            Text(
                                                                text = if (isSelf) "${user.displayName} (Вы)" else user.displayName,
                                                                style = MaterialTheme.typography.titleSmall,
                                                                fontWeight = FontWeight.SemiBold,
                                                                maxLines = 1,
                                                                overflow = TextOverflow.Ellipsis,
                                                                modifier = Modifier.weight(1f, fill = false)
                                                            )
                                                            RoleBadge(role = sysRole, compact = true)
                                                            if (hasCustom) {
                                                                CustomRoleBadge(
                                                                    name = user.customRoleName,
                                                                    badgeText = user.customRoleBadge,
                                                                    colorHex = user.customRoleColorHex,
                                                                    compact = true,
                                                                    isPriority = user.hasPermission(CustomRolePermission.PRIORITY_BADGE)
                                                                )
                                                            }
                                                        }
                                                        Text(
                                                            text = if (user.handle.isNotBlank()) "${user.handle} • ${user.email}" else user.email,
                                                            style = MaterialTheme.typography.bodySmall,
                                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                            maxLines = 1,
                                                            overflow = TextOverflow.Ellipsis
                                                        )
                                                    }
                                                }

                                                if (isOtherDeveloper) {
                                                    Surface(
                                                        shape = RoundedCornerShape(10.dp),
                                                        color = MaterialTheme.colorScheme.surfaceContainerHigh,
                                                        modifier = Modifier
                                                            .fillMaxWidth()
                                                            .testTag("locked_other_dev_${user.userId}")
                                                    ) {
                                                        Row(
                                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                                                            verticalAlignment = Alignment.CenterVertically,
                                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                                        ) {
                                                            Icon(
                                                                imageVector = Icons.Filled.Lock,
                                                                contentDescription = null,
                                                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                                                modifier = Modifier.size(15.dp)
                                                            )
                                                            Text(
                                                                text = "Другой разработчик — выдача кастомных ролей недоступна",
                                                                style = MaterialTheme.typography.labelSmall,
                                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                                            )
                                                        }
                                                    }
                                                } else {
                                                    Row(
                                                        modifier = Modifier.fillMaxWidth(),
                                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                                    ) {
                                                        Button(
                                                            onClick = { assignTargetUser = user },
                                                            enabled = !isBusy,
                                                            shape = RoundedCornerShape(12.dp),
                                                            modifier = Modifier
                                                                .weight(1f)
                                                                .height(48.dp)
                                                                .testTag("open_assign_role_dialog_${user.userId}")
                                                        ) {
                                                            Icon(
                                                                imageVector = Icons.Filled.Badge,
                                                                contentDescription = null,
                                                                modifier = Modifier.size(16.dp)
                                                            )
                                                            Spacer(modifier = Modifier.width(6.dp))
                                                            Text(if (hasCustom) "Сменить роль" else "Выдать роль", maxLines = 1)
                                                        }
                                                        if (hasCustom) {
                                                            OutlinedButton(
                                                                onClick = { onAssignCustomRole(user.userId, null) },
                                                                enabled = !isBusy,
                                                                shape = RoundedCornerShape(12.dp),
                                                                modifier = Modifier
                                                                    .height(48.dp)
                                                                    .testTag("revoke_custom_role_${user.userId}")
                                                            ) {
                                                                Text("Снять", color = MaterialTheme.colorScheme.error)
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))
        }
    }

    if (showEditorDialog) {
        CustomRoleEditorDialog(
            initialRole = editingRole,
            isBusy = isBusy,
            onDismiss = {
                showEditorDialog = false
                editingRole = null
            },
            onSave = { name, badge, colorHex, permissions ->
                onSaveCustomRole(
                    editingRole?.resolvedId(),
                    name,
                    badge,
                    colorHex,
                    permissions
                ) {
                    showEditorDialog = false
                    editingRole = null
                }
            }
        )
    }

    deleteCandidate?.let { role ->
        AlertDialog(
            onDismissRequest = { deleteCandidate = null },
            containerColor = liquidGlassDialogContainerColor(),
            title = { Text("Удалить роль «${role.name}»?") },
            text = {
                Text("Роль и связанные с ней права будут сняты со всех пользователей, которым она была выдана.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        onDeleteCustomRole(role.resolvedId())
                        deleteCandidate = null
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.error,
                        contentColor = MaterialTheme.colorScheme.onError
                    )
                ) {
                    Text("Удалить")
                }
            },
            dismissButton = {
                TextButton(onClick = { deleteCandidate = null }) {
                    Text("Отмена")
                }
            }
        )
    }

    assignTargetUser?.let { target ->
        AssignCustomRoleDialog(
            targetUser = target,
            customRoles = customRoles,
            isBusy = isBusy,
            onDismiss = { assignTargetUser = null },
            onSelectRole = { chosenRole ->
                onAssignCustomRole(target.userId, chosenRole)
                assignTargetUser = null
            }
        )
    }
}

@Composable
private fun CustomRoleEditorDialog(
    initialRole: CustomRoleRecord?,
    isBusy: Boolean,
    onDismiss: () -> Unit,
    onSave: (name: String, badgeText: String, colorHex: String, permissions: Set<CustomRolePermission>) -> Unit
) {
    var nameDraft by remember(initialRole?.resolvedId()) { mutableStateOf(initialRole?.name.orEmpty()) }
    var badgeDraft by remember(initialRole?.resolvedId()) { mutableStateOf(initialRole?.badgeText.orEmpty()) }
    var colorHex by remember(initialRole?.resolvedId()) {
        mutableStateOf(initialRole?.colorHex?.ifBlank { null } ?: CustomRolePalette.DEFAULT_COLOR_HEX)
    }
    var selectedPermissions by remember(initialRole?.resolvedId()) {
        mutableStateOf(initialRole?.parsedPermissions() ?: setOf(CustomRolePermission.PRIORITY_BADGE))
    }

    val scrollState = rememberScrollState()
    val previewName = nameDraft.trim().ifBlank { "Новая роль" }
    val previewBadge = badgeDraft.trim().ifBlank { previewName.take(6).uppercase() }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = liquidGlassDialogContainerColor(),
        title = {
            Text(if (initialRole == null) "Создать кастомную роль" else "Редактировать роль")
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 440.dp)
                    .verticalScroll(scrollState),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surfaceContainerHigh,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Предпросмотр:",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        CustomRoleBadge(
                            name = previewName,
                            badgeText = previewBadge,
                            colorHex = colorHex,
                            compact = false,
                            isPriority = CustomRolePermission.PRIORITY_BADGE in selectedPermissions
                        )
                    }
                }

                OutlinedTextField(
                    value = nameDraft,
                    onValueChange = { if (it.length <= 32) nameDraft = it },
                    label = { Text("Название роли") },
                    placeholder = { Text("Например: Модератор") },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("custom_role_name_input")
                )

                OutlinedTextField(
                    value = badgeDraft,
                    onValueChange = { if (it.length <= 12) badgeDraft = it.uppercase() },
                    label = { Text("Короткий бейдж (до 12 симв.)") },
                    placeholder = { Text("MOD") },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("custom_role_badge_input")
                )

                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "Цвет роли",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        CustomRolePalette.PRESET_COLORS.forEach { presetHex ->
                            val selected = colorHex.equals(presetHex, ignoreCase = true)
                            val swatchColor = parseRoleColorHex(presetHex, MaterialTheme.colorScheme.primary)
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier
                                    .size(34.dp)
                                    .clip(CircleShape)
                                    .background(swatchColor)
                                    .then(
                                        if (selected) {
                                            Modifier.border(2.5.dp, MaterialTheme.colorScheme.onSurface, CircleShape)
                                        } else Modifier
                                    )
                                    .clickable { colorHex = presetHex }
                            ) {
                                if (selected) {
                                    Icon(
                                        imageVector = Icons.Filled.Check,
                                        contentDescription = "Выбран цвет $presetHex",
                                        tint = Color.White,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                HorizontalDivider()

                Text(
                    text = "Права роли (${selectedPermissions.size}/${CustomRolePermission.entries.size})",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold
                )

                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    CustomRolePermission.entries.forEach { perm ->
                        val checked = perm in selectedPermissions
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (checked) {
                                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)
                            } else {
                                MaterialTheme.colorScheme.surfaceContainerLow
                            },
                            border = BorderStroke(
                                1.dp,
                                if (checked) MaterialTheme.colorScheme.primary.copy(alpha = 0.45f)
                                else MaterialTheme.colorScheme.outlineVariant
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .defaultMinSize(minHeight = 48.dp)
                                .clickable {
                                    selectedPermissions = if (checked) {
                                        selectedPermissions - perm
                                    } else {
                                        selectedPermissions + perm
                                    }
                                }
                                .testTag("custom_role_perm_${perm.wireKey}")
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 10.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = checked,
                                    onCheckedChange = { isOn ->
                                        selectedPermissions = if (isOn) {
                                            selectedPermissions + perm
                                        } else {
                                            selectedPermissions - perm
                                        }
                                    }
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = perm.titleRu,
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.Medium
                                    )
                                    Text(
                                        text = perm.descriptionRu,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onSave(nameDraft, badgeDraft, colorHex, selectedPermissions) },
                enabled = !isBusy && nameDraft.trim().isNotEmpty(),
                modifier = Modifier.testTag("save_custom_role_button")
            ) {
                Text(if (initialRole == null) "Создать" else "Сохранить")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Отмена")
            }
        }
    )
}

@Composable
fun AssignCustomRoleDialog(
    targetUser: UserPrivateProfile,
    customRoles: List<CustomRoleRecord>,
    isBusy: Boolean,
    onDismiss: () -> Unit,
    onSelectRole: (CustomRoleRecord?) -> Unit
) {
    val scrollState = rememberScrollState()
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = liquidGlassDialogContainerColor(),
        title = { Text("Роль для ${targetUser.displayName}") },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 360.dp)
                    .verticalScroll(scrollState),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (customRoles.isEmpty()) {
                    Text(
                        text = "Сначала создайте хотя бы одну кастомную роль в конструкторе.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else {
                    customRoles.forEach { role ->
                        val isCurrent = targetUser.customRoleId == role.resolvedId()
                        val perms = role.parsedPermissions()
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = if (isCurrent) {
                                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
                            } else {
                                MaterialTheme.colorScheme.surfaceContainerLow
                            },
                            border = BorderStroke(
                                1.dp,
                                if (isCurrent) MaterialTheme.colorScheme.primary
                                else MaterialTheme.colorScheme.outlineVariant
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .defaultMinSize(minHeight = 48.dp)
                                .clickable(enabled = !isBusy) { onSelectRole(role) }
                                .testTag("pick_custom_role_${role.resolvedId()}")
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(
                                    modifier = Modifier.weight(1f),
                                    verticalArrangement = Arrangement.spacedBy(3.dp)
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Text(
                                            text = role.name,
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                        CustomRoleBadge(
                                            name = role.name,
                                            badgeText = role.badgeText,
                                            colorHex = role.colorHex,
                                            compact = true,
                                            isPriority = CustomRolePermission.PRIORITY_BADGE in perms
                                        )
                                    }
                                    Text(
                                        text = if (perms.isEmpty()) "Только бейдж"
                                        else "Прав: ${perms.size} (${perms.take(2).joinToString { it.titleRu }})",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                if (isCurrent) {
                                    Icon(
                                        imageVector = Icons.Filled.Check,
                                        contentDescription = "Текущая роль",
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }
                        }
                    }
                }

                if (targetUser.hasCustomRole()) {
                    OutlinedButton(
                        onClick = { onSelectRole(null) },
                        enabled = !isBusy,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("clear_assigned_custom_role_button")
                    ) {
                        Text("Снять кастомную роль", color = MaterialTheme.colorScheme.error)
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Закрыть")
            }
        }
    )
}
