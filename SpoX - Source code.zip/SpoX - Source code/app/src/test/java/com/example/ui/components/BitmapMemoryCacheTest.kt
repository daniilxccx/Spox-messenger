package com.example.ui.components

import android.graphics.Bitmap
import android.util.Base64
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertSame
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.ByteArrayOutputStream

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class BitmapMemoryCacheTest {

    private fun createPngBytes(width: Int, height: Int): ByteArray {
        val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        return ByteArrayOutputStream().use { out ->
            bmp.compress(Bitmap.CompressFormat.PNG, 100, out)
            bmp.recycle()
            out.toByteArray()
        }
    }

    @Test
    fun computeSampleSize_calculatesPowerOfTwoCorrectly() {
        assertEquals(1, BitmapMemoryCache.computeSampleSize(400, 300, 720))
        assertEquals(2, BitmapMemoryCache.computeSampleSize(1200, 800, 720))
        assertEquals(4, BitmapMemoryCache.computeSampleSize(1600, 1200, 400))
        assertEquals(1, BitmapMemoryCache.computeSampleSize(0, 0, 400))
    }

    @Test
    fun mediaThumb_decodesAndHitsLruCache() = runTest {
        val bytes = createPngBytes(64, 64)
        val first = BitmapMemoryCache.decodeMediaThumb("msg_thumb_test", bytes, maxDimensionPx = 400)
        assertNotNull(first)

        val cached = BitmapMemoryCache.getCachedMediaThumb("msg_thumb_test", bytes.size, maxDimensionPx = 400)
        assertNotNull(cached)
        assertSame(first, cached)
    }

    @Test
    fun avatar_cachesDecodedBitmap_andHandlesBlankOrMalformedBase64Safely() = runTest {
        assertNull(BitmapMemoryCache.decodeAvatar(""))
        assertNull(BitmapMemoryCache.decodeAvatar("===="))

        val bytes = createPngBytes(64, 64)
        val base64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
        val first = BitmapMemoryCache.decodeAvatar(base64)
        assertNotNull(first)

        val cached = BitmapMemoryCache.getCachedAvatar(base64)
        assertSame(first, cached)
    }

    @Test
    fun fullImage_handlesEmptySafely() = runTest {
        assertNull(BitmapMemoryCache.decodeFullImage(ByteArray(0)))
    }

    @Test
    fun artwork_decodesAndHitsLruCache() = runTest {
        BitmapMemoryCache.clearAllCaches()
        BitmapMemoryCache.setResourceSavingMode(false)
        val bytes = createPngBytes(96, 96)
        val decoded = BitmapMemoryCache.decodeArtworkBytes("track_1", bytes, maxDimensionPx = 128)
        assertNotNull(decoded)

        val cached = BitmapMemoryCache.getCachedArtwork("track_1", bytes.size, maxDimensionPx = 128)
        assertNotNull(cached)
        assertSame(decoded, cached)
        BitmapMemoryCache.clearAllCaches()
    }

    @Test
    fun resourceSavingMode_evictsHeavyCachesAndUsesRgb565() = runTest {
        BitmapMemoryCache.clearAllCaches()
        BitmapMemoryCache.setResourceSavingMode(false)

        val bytes = createPngBytes(128, 128)
        BitmapMemoryCache.decodeMediaThumb("media_1", bytes, maxDimensionPx = 400)
        BitmapMemoryCache.decodeArtworkBytes("track_2", bytes, maxDimensionPx = 200)
        assertNotNull(BitmapMemoryCache.getCachedMediaThumb("media_1", bytes.size, maxDimensionPx = 400))
        assertNotNull(BitmapMemoryCache.getCachedArtwork("track_2", bytes.size, maxDimensionPx = 200))

        // Enabling resource saving mode immediately evicts heavy caches
        BitmapMemoryCache.setResourceSavingMode(true)
        assertEquals(true, BitmapMemoryCache.isResourceSavingMode)
        assertNull(BitmapMemoryCache.getCachedMediaThumb("media_1", bytes.size, maxDimensionPx = 400))
        assertNull(BitmapMemoryCache.getCachedArtwork("track_2", bytes.size, maxDimensionPx = 200))

        // Newly decoded artwork in resource saving mode still caches cleanly
        val lowMemArt = BitmapMemoryCache.decodeArtworkBytes("track_low", bytes, maxDimensionPx = 512)
        assertNotNull(lowMemArt)
        assertNotNull(BitmapMemoryCache.getCachedArtwork("track_low", bytes.size, maxDimensionPx = 512))

        BitmapMemoryCache.setResourceSavingMode(false)
        BitmapMemoryCache.clearAllCaches()
    }
}
