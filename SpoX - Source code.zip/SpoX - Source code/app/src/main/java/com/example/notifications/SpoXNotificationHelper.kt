package com.example.notifications

import android.Manifest
import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import android.util.Base64
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.Person
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.IconCompat
import com.example.MainActivity
import com.example.R
import com.example.data.model.UserRole
import com.example.ui.call.IncomingCallActivity
import kotlin.math.abs

object SpoXNotificationHelper {

    const val CHANNEL_MESSAGES = "spox_messages"
    const val CHANNEL_CALLS = "spox_calls_v2"
    const val CHANNEL_ONGOING_CALL = "spox_ongoing_call"

    const val EXTRA_OPEN_CHAT_ID = "extra_open_chat_id"
    const val EXTRA_OPEN_CALL_ID = "extra_open_call_id"
    const val EXTRA_AUTO_ANSWER = "extra_auto_answer"
    const val ACTION_DECLINE_CALL = "com.example.notifications.ACTION_DECLINE_CALL"
    const val ACTION_TOGGLE_MUTE_CALL = "com.example.notifications.ACTION_TOGGLE_MUTE_CALL"
    const val ACTION_END_CALL = "com.example.notifications.ACTION_END_CALL"

    private const val NOTIFICATION_ACCENT_COLOR = 0xFF38BDF8.toInt()
    private const val TEST_PUSH_ID = 9001
    private const val AVATAR_BITMAP_SIZE_PX = 128

    private val AVATAR_BG_COLORS = intArrayOf(
        0xFF0D9488.toInt(),
        0xFF0284C7.toInt(),
        0xFF7C3AED.toInt(),
        0xFFDB2777.toInt(),
        0xFFD97706.toInt(),
        0xFF059669.toInt(),
        0xFF4F46E5.toInt(),
        0xFF0891B2.toInt()
    )

    fun formatNotificationRoleLabel(
        role: String,
        customRoleName: String = "",
        customRoleBadge: String = ""
    ): String {
        val customName = customRoleName.trim()
        if (customName.isNotEmpty()) return customName.take(28)
        val customBadge = customRoleBadge.trim()
        if (customBadge.isNotEmpty()) return customBadge.take(20)
        return UserRole.fromWire(role).labelRu
    }

    fun formatSenderWithRole(
        senderName: String,
        roleLabel: String
    ): String {
        val safeSender = senderName.trim().ifBlank { "SpoX" }
        val safeRole = roleLabel.trim()
        return if (safeRole.isNotEmpty()) "$safeSender • $safeRole" else safeSender
    }

    fun createCircularAvatarBitmap(
        name: String,
        avatarBase64: String = "",
        colorIndex: Int = abs(name.hashCode())
    ): Bitmap {
        val decoded = decodeAvatarBitmap(avatarBase64)
        if (decoded != null) {
            return cropToCircleBitmap(decoded, AVATAR_BITMAP_SIZE_PX)
        }
        return renderInitialsAvatarBitmap(name = name, colorIndex = colorIndex, sizePx = AVATAR_BITMAP_SIZE_PX)
    }

    private fun decodeAvatarBitmap(avatarBase64: String): Bitmap? {
        val trimmed = avatarBase64.trim()
        if (trimmed.isEmpty()) return null
        return runCatching {
            val payload = if (trimmed.startsWith("data:", ignoreCase = true) && trimmed.contains(',')) {
                trimmed.substringAfter(',')
            } else {
                trimmed
            }
            val bytes = Base64.decode(payload, Base64.DEFAULT)
            if (bytes.isEmpty()) return null
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
            val maxDim = maxOf(bounds.outWidth, bounds.outHeight)
            var sampleSize = 1
            while (maxDim / sampleSize > AVATAR_BITMAP_SIZE_PX * 2 && sampleSize < 32) {
                sampleSize *= 2
            }
            val opts = BitmapFactory.Options().apply {
                inSampleSize = sampleSize
                inPreferredConfig = Bitmap.Config.ARGB_8888
            }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
        }.getOrNull()
    }

    private fun cropToCircleBitmap(source: Bitmap, targetSizePx: Int): Bitmap {
        val output = Bitmap.createBitmap(targetSizePx, targetSizePx, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(output)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)

        val srcSize = minOf(source.width, source.height).coerceAtLeast(1)
        val srcLeft = (source.width - srcSize) / 2
        val srcTop = (source.height - srcSize) / 2
        val srcRect = Rect(srcLeft, srcTop, srcLeft + srcSize, srcTop + srcSize)
        val dstRect = RectF(0f, 0f, targetSizePx.toFloat(), targetSizePx.toFloat())

        canvas.drawARGB(0, 0, 0, 0)
        canvas.drawOval(dstRect, paint)
        paint.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_IN)
        canvas.drawBitmap(source, srcRect, dstRect, paint)
        paint.xfermode = null

        val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = targetSizePx * 0.03f
            color = 0x33FFFFFF
        }
        val inset = borderPaint.strokeWidth / 2f
        canvas.drawOval(
            RectF(inset, inset, targetSizePx - inset, targetSizePx - inset),
            borderPaint
        )
        return output
    }

    private fun renderInitialsAvatarBitmap(
        name: String,
        colorIndex: Int,
        sizePx: Int
    ): Bitmap {
        val output = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(output)
        val primaryColor = AVATAR_BG_COLORS[abs(colorIndex) % AVATAR_BG_COLORS.size]
        val secondaryColor = AVATAR_BG_COLORS[(abs(colorIndex) + 2) % AVATAR_BG_COLORS.size]

        val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(
                0f,
                0f,
                sizePx.toFloat(),
                sizePx.toFloat(),
                primaryColor,
                secondaryColor,
                Shader.TileMode.CLAMP
            )
        }
        val radius = sizePx / 2f
        canvas.drawCircle(radius, radius, radius, bgPaint)

        val initials = name.trim()
            .split(Regex("\\s+"))
            .filter { it.isNotBlank() }
            .take(2)
            .joinToString("") { it.first().uppercaseChar().toString() }
            .ifBlank { "?" }

        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textAlign = Paint.Align.CENTER
            textSize = if (initials.length > 1) sizePx * 0.40f else sizePx * 0.46f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val textBounds = Rect()
        textPaint.getTextBounds(initials, 0, initials.length, textBounds)
        val centerY = radius - textBounds.exactCenterY()
        canvas.drawText(initials, radius, centerY, textPaint)

        val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = sizePx * 0.03f
            color = 0x33FFFFFF
        }
        canvas.drawCircle(radius, radius, radius - ringPaint.strokeWidth / 2f, ringPaint)
        return output
    }

    fun ensureChannels(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = context.getSystemService(NotificationManager::class.java) ?: return

        val messagesChannel = NotificationChannel(
            CHANNEL_MESSAGES,
            "Сообщения SpoX",
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "Push-уведомления о новых зашифрованных сообщениях и медиафайлах"
            enableVibration(true)
            enableLights(true)
            lightColor = NOTIFICATION_ACCENT_COLOR
            setShowBadge(true)
        }

        val ringtoneUri = runCatching {
            RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
        }.getOrNull()
        val ringtoneAttrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()

        val callsChannel = NotificationChannel(
            CHANNEL_CALLS,
            "Входящие звонки SpoX",
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "Push-уведомления и экран блокировки для входящих аудио- и видеозвонков"
            enableVibration(true)
            vibrationPattern = longArrayOf(0L, 650L, 450L, 650L, 450L)
            enableLights(true)
            lightColor = NOTIFICATION_ACCENT_COLOR
            lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            if (ringtoneUri != null) {
                setSound(ringtoneUri, ringtoneAttrs)
            }
            setShowBadge(true)
        }

        val ongoingCallChannel = NotificationChannel(
            CHANNEL_ONGOING_CALL,
            "Активный звонок SpoX",
            NotificationManager.IMPORTANCE_DEFAULT
        ).apply {
            description = "Индикатор и быстрые кнопки управления звонком поверх игр и других приложений"
            enableVibration(false)
            setSound(null, null)
            lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            setShowBadge(false)
        }

        runCatching { manager.createNotificationChannel(messagesChannel) }
        runCatching { manager.createNotificationChannel(callsChannel) }
        runCatching { manager.createNotificationChannel(ongoingCallChannel) }
    }

    fun hasNotificationPermission(context: Context): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) return true
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.POST_NOTIFICATIONS
        ) == PackageManager.PERMISSION_GRANTED
    }

    fun canUseFullScreenIntent(context: Context): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.UPSIDE_DOWN_CAKE) return true
        val manager = context.getSystemService(NotificationManager::class.java) ?: return true
        return manager.canUseFullScreenIntent()
    }

    fun buildMessageNotification(
        context: Context,
        chatId: String,
        chatTitle: String,
        body: String,
        unreadCount: Int,
        senderName: String = chatTitle,
        senderRole: String = "user",
        customRoleName: String = "",
        customRoleBadge: String = "",
        senderAvatarBase64: String = "",
        senderAvatarColorIndex: Int = abs(senderName.hashCode()),
        isGroup: Boolean = chatTitle.isNotBlank() && senderName.isNotBlank() && chatTitle != senderName,
        timestampMs: Long = System.currentTimeMillis()
    ): Notification {
        ensureChannels(context)

        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra(EXTRA_OPEN_CHAT_ID, chatId)
        }
        val requestCode = ("msg_$chatId").hashCode()
        val pendingIntent = PendingIntent.getActivity(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val safeTitle = chatTitle.trim().ifBlank { "SpoX" }
        val safeSender = senderName.trim().ifBlank { safeTitle }
        val safeBody = body.trim().ifBlank { "Новое сообщение" }
        val roleLabel = formatNotificationRoleLabel(
            role = senderRole,
            customRoleName = customRoleName,
            customRoleBadge = customRoleBadge
        )
        val senderWithRole = formatSenderWithRole(safeSender, roleLabel)
        val isGroupConversation = isGroup || (safeTitle != safeSender && safeTitle != "SpoX")
        val collapsedTitle = if (isGroupConversation) {
            "$safeTitle • $senderWithRole"
        } else {
            senderWithRole
        }
        val subText = if (unreadCount > 1) {
            "$roleLabel • Непрочитано: $unreadCount"
        } else {
            roleLabel
        }

        val avatarBitmap = createCircularAvatarBitmap(
            name = safeSender,
            avatarBase64 = senderAvatarBase64,
            colorIndex = senderAvatarColorIndex
        )
        val avatarIcon = IconCompat.createWithBitmap(avatarBitmap)

        val senderPerson = Person.Builder()
            .setName(senderWithRole)
            .setIcon(avatarIcon)
            .setImportant(true)
            .build()
        val mePerson = Person.Builder()
            .setName("Вы")
            .build()

        val msgTimestamp = timestampMs.takeIf { it > 0L } ?: System.currentTimeMillis()
        val messagingStyle = NotificationCompat.MessagingStyle(mePerson)
            .setConversationTitle(if (isGroupConversation) safeTitle else null)
            .setGroupConversation(isGroupConversation)
            .addMessage(safeBody, msgTimestamp, senderPerson)

        return NotificationCompat.Builder(context, CHANNEL_MESSAGES)
            .setSmallIcon(R.drawable.ic_stat_spox_notification)
            .setLargeIcon(avatarBitmap)
            .setColor(NOTIFICATION_ACCENT_COLOR)
            .setContentTitle(collapsedTitle)
            .setContentText(safeBody)
            .setSubText(subText)
            .setStyle(messagingStyle)
            .addPerson(senderPerson)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setVisibility(NotificationCompat.VISIBILITY_PRIVATE)
            .setWhen(msgTimestamp)
            .setShowWhen(true)
            .setAutoCancel(true)
            .setNumber(unreadCount.coerceAtLeast(1))
            .setDefaults(NotificationCompat.DEFAULT_ALL)
            .setContentIntent(pendingIntent)
            .build()
    }

    @SuppressLint("MissingPermission")
    fun showMessageNotification(
        context: Context,
        chatId: String,
        chatTitle: String,
        body: String,
        unreadCount: Int,
        senderName: String = chatTitle,
        senderRole: String = "user",
        customRoleName: String = "",
        customRoleBadge: String = "",
        senderAvatarBase64: String = "",
        senderAvatarColorIndex: Int = abs(senderName.hashCode()),
        isGroup: Boolean = chatTitle.isNotBlank() && senderName.isNotBlank() && chatTitle != senderName,
        timestampMs: Long = System.currentTimeMillis(),
        force: Boolean = false
    ) {
        if (!hasNotificationPermission(context)) return
        if (!force && !NotificationPreferences.isMessagePushEnabled(context)) return

        val notification = buildMessageNotification(
            context = context,
            chatId = chatId,
            chatTitle = chatTitle,
            body = body,
            unreadCount = unreadCount,
            senderName = senderName,
            senderRole = senderRole,
            customRoleName = customRoleName,
            customRoleBadge = customRoleBadge,
            senderAvatarBase64 = senderAvatarBase64,
            senderAvatarColorIndex = senderAvatarColorIndex,
            isGroup = isGroup,
            timestampMs = timestampMs
        )
        val requestCode = ("msg_$chatId").hashCode()
        runCatching {
            NotificationManagerCompat.from(context).notify(requestCode, notification)
        }
    }

    fun buildIncomingCallNotification(
        context: Context,
        callId: String,
        callerName: String,
        conversationTitle: String,
        isGroupCall: Boolean,
        callType: String,
        callerRole: String = "user",
        customRoleName: String = "",
        customRoleBadge: String = "",
        callerAvatarBase64: String = "",
        callerAvatarColorIndex: Int = abs(callerName.hashCode())
    ): Notification {
        ensureChannels(context)

        val incomingUiIntent = Intent(context, IncomingCallActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                Intent.FLAG_ACTIVITY_SINGLE_TOP or
                Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra(EXTRA_OPEN_CALL_ID, callId)
            putExtra(EXTRA_AUTO_ANSWER, false)
        }
        val fullScreenPendingIntent = PendingIntent.getActivity(
            context,
            ("call_fs_$callId").hashCode(),
            incomingUiIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val answerIntent = Intent(context, IncomingCallActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                Intent.FLAG_ACTIVITY_SINGLE_TOP or
                Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra(EXTRA_OPEN_CALL_ID, callId)
            putExtra(EXTRA_AUTO_ANSWER, true)
        }
        val answerPendingIntent = PendingIntent.getActivity(
            context,
            ("call_ans_$callId").hashCode(),
            answerIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val declineIntent = Intent(context, CallActionReceiver::class.java).apply {
            action = ACTION_DECLINE_CALL
            putExtra(EXTRA_OPEN_CALL_ID, callId)
        }
        val declinePendingIntent = PendingIntent.getBroadcast(
            context,
            ("call_dec_$callId").hashCode(),
            declineIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val safeCaller = callerName.trim().ifBlank { "Входящий звонок" }
        val roleLabel = formatNotificationRoleLabel(
            role = callerRole,
            customRoleName = customRoleName,
            customRoleBadge = customRoleBadge
        )
        val callerWithRole = formatSenderWithRole(safeCaller, roleLabel)
        val displayTitle = if (isGroupCall) {
            conversationTitle.ifBlank { "Групповой звонок SpoX" }
        } else {
            callerWithRole
        }
        val kindText = when {
            isGroupCall && callType == "video" -> "Групповой видеозвонок • $callerWithRole"
            isGroupCall -> "Групповой аудиозвонок • $callerWithRole"
            callType == "video" -> "Входящий видеозвонок E2EE"
            else -> "Входящий аудиозвонок E2EE"
        }

        val avatarBitmap = createCircularAvatarBitmap(
            name = safeCaller,
            avatarBase64 = callerAvatarBase64,
            colorIndex = callerAvatarColorIndex
        )
        val avatarIcon = IconCompat.createWithBitmap(avatarBitmap)

        val callerPerson = Person.Builder()
            .setName(displayTitle)
            .setIcon(avatarIcon)
            .setImportant(true)
            .build()

        val callStyle = NotificationCompat.CallStyle
            .forIncomingCall(callerPerson, declinePendingIntent, answerPendingIntent)
            .setIsVideo(callType == "video")

        val ringtoneUri = runCatching {
            RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
        }.getOrNull()

        return NotificationCompat.Builder(context, CHANNEL_CALLS)
            .setSmallIcon(R.drawable.ic_stat_spox_notification)
            .setLargeIcon(avatarBitmap)
            .setColor(NOTIFICATION_ACCENT_COLOR)
            .setContentTitle(displayTitle)
            .setContentText(kindText)
            .setSubText(roleLabel)
            .setStyle(callStyle)
            .addPerson(callerPerson)
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOngoing(true)
            .setAutoCancel(false)
            .setTimeoutAfter(45_000L)
            .apply {
                if (ringtoneUri != null) setSound(ringtoneUri)
            }
            .setContentIntent(fullScreenPendingIntent)
            .setFullScreenIntent(fullScreenPendingIntent, true)
            .build()
    }

    @SuppressLint("MissingPermission")
    fun showIncomingCallNotification(
        context: Context,
        callId: String,
        callerName: String,
        conversationTitle: String,
        isGroupCall: Boolean,
        callType: String,
        callerRole: String = "user",
        customRoleName: String = "",
        customRoleBadge: String = "",
        callerAvatarBase64: String = "",
        callerAvatarColorIndex: Int = abs(callerName.hashCode()),
        force: Boolean = false
    ) {
        if (!hasNotificationPermission(context)) return
        if (!force && !NotificationPreferences.isCallPushEnabled(context)) return

        val notification = buildIncomingCallNotification(
            context = context,
            callId = callId,
            callerName = callerName,
            conversationTitle = conversationTitle,
            isGroupCall = isGroupCall,
            callType = callType,
            callerRole = callerRole,
            customRoleName = customRoleName,
            customRoleBadge = customRoleBadge,
            callerAvatarBase64 = callerAvatarBase64,
            callerAvatarColorIndex = callerAvatarColorIndex
        )
        val requestCode = ("call_$callId").hashCode()
        runCatching {
            NotificationManagerCompat.from(context).notify(requestCode, notification)
        }
    }

    fun buildOngoingCallNotification(
        context: Context,
        callId: String,
        title: String,
        startedAtMs: Long,
        isMuted: Boolean
    ): Notification {
        ensureChannels(context)

        val openCallIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra(EXTRA_OPEN_CALL_ID, callId)
            putExtra(EXTRA_AUTO_ANSWER, true)
        }
        val openPendingIntent = PendingIntent.getActivity(
            context,
            ("call_ongoing_open_$callId").hashCode(),
            openCallIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val hangUpIntent = Intent(context, CallActionReceiver::class.java).apply {
            action = ACTION_END_CALL
            putExtra(EXTRA_OPEN_CALL_ID, callId)
        }
        val hangUpPendingIntent = PendingIntent.getBroadcast(
            context,
            ("call_ongoing_end_$callId").hashCode(),
            hangUpIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val muteIntent = Intent(context, CallActionReceiver::class.java).apply {
            action = ACTION_TOGGLE_MUTE_CALL
            putExtra(EXTRA_OPEN_CALL_ID, callId)
        }
        val mutePendingIntent = PendingIntent.getBroadcast(
            context,
            ("call_ongoing_mute_$callId").hashCode(),
            muteIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val safeTitle = title.ifBlank { "Звонок SpoX" }
        val peerPerson = Person.Builder()
            .setName(safeTitle)
            .setImportant(true)
            .build()

        val callStyle = NotificationCompat.CallStyle
            .forOngoingCall(peerPerson, hangUpPendingIntent)

        val statusLabel = if (isMuted) {
            "Микрофон выкл. • Игровой режим E2EE"
        } else {
            "Голосовой канал E2EE активен в фоне"
        }

        return NotificationCompat.Builder(context, CHANNEL_ONGOING_CALL)
            .setSmallIcon(R.drawable.ic_stat_spox_notification)
            .setColor(NOTIFICATION_ACCENT_COLOR)
            .setContentTitle(safeTitle)
            .setContentText(statusLabel)
            .setStyle(callStyle)
            .addPerson(peerPerson)
            .addAction(
                0,
                if (isMuted) "Вкл. микрофон" else "Выкл. микрофон",
                mutePendingIntent
            )
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setUsesChronometer(true)
            .setWhen(startedAtMs)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .setContentIntent(openPendingIntent)
            .build()
    }

    @SuppressLint("MissingPermission")
    fun showTestPushNotification(context: Context): Boolean {
        if (!hasNotificationPermission(context)) return false
        val notification = buildMessageNotification(
            context = context,
            chatId = "spox_test_push",
            chatTitle = "Команда SpoX",
            body = "Push активен: видны текст сообщения, отправитель, его роль и аватарка.",
            unreadCount = 1,
            senderName = "SpoX Система",
            senderRole = UserRole.DEVELOPER.wireValue,
            senderAvatarColorIndex = 1,
            isGroup = false,
            timestampMs = System.currentTimeMillis()
        )

        return runCatching {
            NotificationManagerCompat.from(context).notify(TEST_PUSH_ID, notification)
        }.isSuccess
    }

    fun cancelChatNotification(context: Context, chatId: String) {
        runCatching {
            NotificationManagerCompat.from(context).cancel(("msg_$chatId").hashCode())
        }
    }

    fun cancelCallNotification(context: Context, callId: String) {
        runCatching {
            NotificationManagerCompat.from(context).cancel(("call_$callId").hashCode())
        }
    }
}
