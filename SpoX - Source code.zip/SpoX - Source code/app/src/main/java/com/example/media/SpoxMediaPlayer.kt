package com.example.media

import android.content.Context
import android.net.Uri
import androidx.annotation.OptIn
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.Tracks
import androidx.media3.common.VideoSize
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.extractor.DefaultExtractorsFactory
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.Locale

data class SpoxVideoRequest(
    val id: String,
    val uri: Uri,
    val title: String,
    val formatBadge: String,
    val mimeType: String,
    val sizeBytes: Long = 0L
)

data class SpoxAudioTrack(
    val id: String,
    val uri: Uri,
    val title: String,
    val subtitle: String,
    val formatBadge: String,
    val mimeType: String,
    val sizeBytes: Long = 0L
)

data class SpoxMediaHistoryItem(
    val id: String,
    val uri: Uri,
    val title: String,
    val mediaKind: MediaKind,
    val formatBadge: String,
    val sizeBytes: Long,
    val mimeType: String
)

data class SpoxTrackOption(
    val groupIndex: Int,
    val trackIndex: Int,
    val label: String,
    val isSelected: Boolean
)

data class SpoxAudioUiState(
    val activeTrack: SpoxAudioTrack? = null,
    val queue: List<SpoxAudioTrack> = emptyList(),
    val currentIndex: Int = -1,
    val isPlaying: Boolean = false,
    val isBuffering: Boolean = false,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    val playbackSpeed: Float = 1f,
    val repeatOne: Boolean = false,
    val artworkBytes: ByteArray? = null,
    val audioFormatSummary: String = "",
    val errorMessage: String? = null
)

object SpoxMediaEngine {

    @OptIn(UnstableApi::class)
    fun createExoPlayer(
        context: Context,
        trackSelector: DefaultTrackSelector = DefaultTrackSelector(context),
        isAudioOnly: Boolean = false
    ): ExoPlayer {
        val renderersFactory = DefaultRenderersFactory(context)
            .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER)
            .setEnableDecoderFallback(true)

        val extractorsFactory = DefaultExtractorsFactory()
            .setConstantBitrateSeekingEnabled(true)

        val mediaSourceFactory = DefaultMediaSourceFactory(context, extractorsFactory)

        val audioAttributes = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(
                if (isAudioOnly) C.AUDIO_CONTENT_TYPE_MUSIC else C.AUDIO_CONTENT_TYPE_MOVIE
            )
            .build()

        return ExoPlayer.Builder(context, renderersFactory)
            .setMediaSourceFactory(mediaSourceFactory)
            .setTrackSelector(trackSelector)
            .setAudioAttributes(audioAttributes, true)
            .setHandleAudioBecomingNoisy(true)
            .build()
    }

    fun formatMediaDuration(ms: Long): String {
        val safeMs = ms.coerceAtLeast(0L)
        val totalSeconds = safeMs / 1000L
        val hours = totalSeconds / 3600L
        val minutes = (totalSeconds % 3600L) / 60L
        val seconds = totalSeconds % 60L
        return if (hours > 0) {
            String.format(Locale.US, "%d:%02d:%02d", hours, minutes, seconds)
        } else {
            String.format(Locale.US, "%02d:%02d", minutes, seconds)
        }
    }

    fun describePlaybackError(error: PlaybackException): String {
        val codeName = error.errorCodeName
        return when (error.errorCode) {
            PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED,
            PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED ->
                "Контейнер не распознан или повреждён ($codeName). Попробуйте открыть внешним плеером."
            PlaybackException.ERROR_CODE_DECODING_FAILED,
            PlaybackException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED,
            PlaybackException.ERROR_CODE_DECODING_FORMAT_EXCEEDS_CAPABILITIES ->
                "Устройство не поддерживает аппаратное/системное декодирование этого кодека ($codeName)."
            PlaybackException.ERROR_CODE_IO_FILE_NOT_FOUND,
            PlaybackException.ERROR_CODE_IO_READ_POSITION_OUT_OF_RANGE,
            PlaybackException.ERROR_CODE_IO_UNSPECIFIED ->
                "Не удалось прочитать медиафайл ($codeName)."
            else -> "Ошибка воспроизведения ($codeName)"
        }
    }

    fun extractTrackOptions(tracks: Tracks, trackType: Int): List<SpoxTrackOption> {
        val result = mutableListOf<SpoxTrackOption>()
        var counter = 1
        tracks.groups.forEachIndexed { groupIndex, group ->
            if (group.type == trackType) {
                for (trackIndex in 0 until group.length) {
                    if (!group.isTrackSupported(trackIndex)) continue
                    val format = group.getTrackFormat(trackIndex)
                    val lang = format.language
                        ?.takeIf { it.isNotBlank() && it != C.LANGUAGE_UNDETERMINED }
                        ?.uppercase(Locale.ROOT)
                    val title = format.label?.takeIf { it.isNotBlank() }
                    val codec = shortCodecName(format.sampleMimeType)
                    val defaultPrefix = if (trackType == C.TRACK_TYPE_AUDIO) "Дорожка $counter" else "Субтитры $counter"
                    val label = listOfNotNull(
                        title ?: defaultPrefix,
                        lang,
                        codec
                    ).joinToString(" • ")
                    result.add(
                        SpoxTrackOption(
                            groupIndex = groupIndex,
                            trackIndex = trackIndex,
                            label = label,
                            isSelected = group.isTrackSelected(trackIndex)
                        )
                    )
                    counter++
                }
            }
        }
        return result
    }

    fun extractVideoSummary(tracks: Tracks, videoSize: VideoSize): String {
        val parts = mutableListOf<String>()
        if (videoSize.width > 0 && videoSize.height > 0) {
            parts.add("${videoSize.width}×${videoSize.height}")
        }
        var videoCodec: String? = null
        var audioCodec: String? = null
        for (group in tracks.groups) {
            if (!group.isSelected) continue
            for (i in 0 until group.length) {
                if (!group.isTrackSelected(i)) continue
                val fmt = group.getTrackFormat(i)
                if (group.type == C.TRACK_TYPE_VIDEO && videoCodec == null) {
                    videoCodec = shortCodecName(fmt.sampleMimeType)
                } else if (group.type == C.TRACK_TYPE_AUDIO && audioCodec == null) {
                    audioCodec = shortCodecName(fmt.sampleMimeType)
                }
            }
        }
        val codecs = listOfNotNull(videoCodec, audioCodec).joinToString(" / ")
        if (codecs.isNotBlank()) parts.add(codecs)
        return parts.joinToString(" • ")
    }

    @OptIn(UnstableApi::class)
    fun extractAudioSummary(tracks: Tracks): String {
        for (group in tracks.groups) {
            if (group.type != C.TRACK_TYPE_AUDIO) continue
            for (i in 0 until group.length) {
                if (!group.isTrackSelected(i)) continue
                val fmt = group.getTrackFormat(i)
                val parts = mutableListOf<String>()
                shortCodecName(fmt.sampleMimeType)?.let(parts::add)
                if (fmt.sampleRate > 0) {
                    val khz = fmt.sampleRate / 1000f
                    val khzStr = if (fmt.sampleRate % 1000 == 0) "${fmt.sampleRate / 1000} кГц"
                    else String.format(Locale.US, "%.1f кГц", khz)
                    parts.add(khzStr)
                }
                if (fmt.channelCount > 0) {
                    parts.add(if (fmt.channelCount == 1) "Моно" else if (fmt.channelCount == 2) "Стерео" else "${fmt.channelCount} кан.")
                }
                if (fmt.bitrate > 0) {
                    parts.add("${fmt.bitrate / 1000} кбит/с")
                }
                return parts.joinToString(" • ")
            }
        }
        return ""
    }

    private fun shortCodecName(mimeType: String?): String? {
        val lower = mimeType?.lowercase(Locale.ROOT) ?: return null
        return when {
            "avc" in lower || "h264" in lower -> "H.264"
            "hevc" in lower || "h265" in lower -> "HEVC"
            "av01" in lower || "av1" in lower -> "AV1"
            "vp9" in lower -> "VP9"
            "vp8" in lower -> "VP8"
            "mp4v" in lower -> "MPEG-4"
            "mp4a" in lower || "aac" in lower -> "AAC"
            "opus" in lower -> "Opus"
            "vorbis" in lower -> "Vorbis"
            "flac" in lower -> "FLAC"
            "mpeg" in lower && "audio" in lower -> "MP3"
            "ac3" in lower -> "AC-3"
            "eac3" in lower -> "E-AC-3"
            "raw" in lower || "pcm" in lower -> "PCM"
            "amr" in lower -> "AMR"
            "subrip" in lower || "srt" in lower -> "SRT"
            "vtt" in lower -> "WebVTT"
            "ssa" in lower || "ass" in lower -> "ASS/SSA"
            "ttml" in lower -> "TTML"
            else -> lower.substringAfter('/', "").uppercase(Locale.ROOT).takeIf { it.isNotBlank() }
        }
    }
}

class SpoxAudioPlayerManager(private val context: Context) {
    private val appContext = context.applicationContext
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var exoPlayer: ExoPlayer? = null
    private var tickerJob: Job? = null

    private val _uiState = MutableStateFlow(SpoxAudioUiState())
    val uiState: StateFlow<SpoxAudioUiState> = _uiState.asStateFlow()

    @OptIn(UnstableApi::class)
    private fun ensurePlayer(): ExoPlayer {
        exoPlayer?.let { return it }
        val trackSelector = DefaultTrackSelector(appContext)
        val player = SpoxMediaEngine.createExoPlayer(
            context = appContext,
            trackSelector = trackSelector,
            isAudioOnly = true
        )
        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                _uiState.value = _uiState.value.copy(isPlaying = isPlaying)
                if (isPlaying) startTicker() else stopTicker()
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                val buffering = playbackState == Player.STATE_BUFFERING
                val dur = player.duration.takeIf { it != C.TIME_UNSET && it > 0 } ?: _uiState.value.durationMs
                _uiState.value = _uiState.value.copy(
                    isBuffering = buffering,
                    durationMs = dur,
                    positionMs = player.currentPosition.coerceAtLeast(0L)
                )
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                val idx = player.currentMediaItemIndex
                val queue = _uiState.value.queue
                val track = queue.getOrNull(idx)
                _uiState.value = _uiState.value.copy(
                    currentIndex = idx,
                    activeTrack = track ?: _uiState.value.activeTrack,
                    positionMs = 0L,
                    durationMs = player.duration.takeIf { it != C.TIME_UNSET && it > 0 } ?: 0L,
                    artworkBytes = null,
                    errorMessage = null
                )
            }

            override fun onMediaMetadataChanged(mediaMetadata: MediaMetadata) {
                val track = _uiState.value.activeTrack
                val metaTitle = mediaMetadata.title?.toString()?.takeIf { it.isNotBlank() }
                val metaArtist = mediaMetadata.artist?.toString()?.takeIf { it.isNotBlank() }
                _uiState.value = _uiState.value.copy(
                    artworkBytes = mediaMetadata.artworkData ?: _uiState.value.artworkBytes,
                    activeTrack = track?.let {
                        it.copy(
                            title = metaTitle ?: it.title,
                            subtitle = metaArtist ?: it.subtitle
                        )
                    }
                )
            }

            override fun onTracksChanged(tracks: Tracks) {
                val summary = SpoxMediaEngine.extractAudioSummary(tracks)
                val dur = player.duration.takeIf { it != C.TIME_UNSET && it > 0 } ?: _uiState.value.durationMs
                _uiState.value = _uiState.value.copy(
                    audioFormatSummary = summary,
                    durationMs = dur
                )
            }

            override fun onPlayerError(error: PlaybackException) {
                _uiState.value = _uiState.value.copy(
                    isPlaying = false,
                    isBuffering = false,
                    errorMessage = SpoxMediaEngine.describePlaybackError(error)
                )
            }
        })
        exoPlayer = player
        return player
    }

    fun playTrack(track: SpoxAudioTrack, queue: List<SpoxAudioTrack> = listOf(track)) {
        val cleanQueue = queue.ifEmpty { listOf(track) }.distinctBy { it.id }
        val targetIndex = cleanQueue.indexOfFirst { it.id == track.id }.let { if (it >= 0) it else 0 }
        playQueue(cleanQueue, targetIndex)
    }

    fun playQueue(queue: List<SpoxAudioTrack>, startIndex: Int = 0) {
        if (queue.isEmpty()) return
        val safeIdx = startIndex.coerceIn(0, queue.lastIndex)
        val currentState = _uiState.value

        // Toggle play/pause if the exact same track is already loaded without error
        if (currentState.activeTrack?.id == queue[safeIdx].id &&
            currentState.errorMessage == null &&
            exoPlayer != null &&
            currentState.queue.map { it.id } == queue.map { it.id }
        ) {
            togglePlayPause()
            return
        }

        val player = ensurePlayer()
        val mediaItems = queue.map { item ->
            MediaItem.Builder()
                .setMediaId(item.id)
                .setUri(item.uri)
                .apply {
                    if (item.mimeType.isNotBlank() && item.mimeType != "application/octet-stream") {
                        setMimeType(item.mimeType)
                    }
                }
                .build()
        }

        _uiState.value = _uiState.value.copy(
            queue = queue,
            currentIndex = safeIdx,
            activeTrack = queue[safeIdx],
            isBuffering = true,
            positionMs = 0L,
            durationMs = 0L,
            artworkBytes = null,
            audioFormatSummary = "",
            errorMessage = null
        )

        player.repeatMode = if (_uiState.value.repeatOne) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF
        player.playbackParameters = PlaybackParameters(_uiState.value.playbackSpeed)
        player.setMediaItems(mediaItems, safeIdx, 0L)
        player.prepare()
        player.play()
    }

    fun togglePlayPause() {
        val player = exoPlayer ?: return
        if (player.playbackState == Player.STATE_ENDED) {
            player.seekTo(0L)
            player.play()
            return
        }
        if (player.isPlaying) {
            player.pause()
        } else {
            player.play()
        }
    }

    fun seekTo(positionMs: Long) {
        val player = exoPlayer ?: return
        val dur = _uiState.value.durationMs.coerceAtLeast(0L)
        val clamped = if (dur > 0) positionMs.coerceIn(0L, dur) else positionMs.coerceAtLeast(0L)
        player.seekTo(clamped)
        _uiState.value = _uiState.value.copy(positionMs = clamped)
    }

    fun seekBy(deltaMs: Long) {
        val player = exoPlayer ?: return
        seekTo(player.currentPosition + deltaMs)
    }

    fun skipNext() {
        val player = exoPlayer ?: return
        if (player.hasNextMediaItem()) {
            player.seekToNextMediaItem()
        } else {
            seekBy(10_000L)
        }
    }

    fun skipPrevious() {
        val player = exoPlayer ?: return
        if (player.currentPosition > 3_000L || !player.hasPreviousMediaItem()) {
            seekTo(0L)
        } else {
            player.seekToPreviousMediaItem()
        }
    }

    fun setSpeed(speed: Float) {
        val clamped = speed.coerceIn(0.5f, 2.0f)
        exoPlayer?.playbackParameters = PlaybackParameters(clamped)
        _uiState.value = _uiState.value.copy(playbackSpeed = clamped)
    }

    fun toggleRepeatOne() {
        val next = !_uiState.value.repeatOne
        exoPlayer?.repeatMode = if (next) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF
        _uiState.value = _uiState.value.copy(repeatOne = next)
    }

    fun pauseIfPlaying() {
        if (exoPlayer?.isPlaying == true) {
            exoPlayer?.pause()
        }
    }

    fun stopAndDismiss() {
        stopTicker()
        runCatching {
            exoPlayer?.stop()
            exoPlayer?.clearMediaItems()
        }
        _uiState.value = SpoxAudioUiState()
    }

    fun release() {
        stopTicker()
        runCatching { exoPlayer?.release() }
        exoPlayer = null
        _uiState.value = SpoxAudioUiState()
        scope.cancel()
    }

    private fun startTicker() {
        if (tickerJob?.isActive == true) return
        tickerJob = scope.launch {
            while (isActive) {
                val player = exoPlayer
                if (player != null) {
                    val dur = player.duration.takeIf { it != C.TIME_UNSET && it > 0 } ?: _uiState.value.durationMs
                    _uiState.value = _uiState.value.copy(
                        positionMs = player.currentPosition.coerceAtLeast(0L),
                        durationMs = dur,
                        isPlaying = player.isPlaying
                    )
                }
                delay(150L)
            }
        }
    }

    private fun stopTicker() {
        tickerJob?.cancel()
        tickerJob = null
    }
}

val LocalSpoxAudioPlayer = staticCompositionLocalOf<SpoxAudioPlayerManager?> { null }
