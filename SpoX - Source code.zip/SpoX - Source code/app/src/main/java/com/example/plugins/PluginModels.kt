package com.example.plugins

data class SpoXPlugin(
    val id: String,
    val name: String,
    val version: String = "1.0",
    val author: String = "SpoX Community",
    val description: String = "",
    val commands: List<String> = emptyList(),
    val sourceCode: String,
    val enabled: Boolean = true,
    val isBuiltIn: Boolean = false,
    val isModifiedBuiltIn: Boolean = false,
    val updatedAtMs: Long = System.currentTimeMillis(),
    val lastError: String? = null
)

data class SpoXPluginMetadata(
    val id: String,
    val name: String,
    val version: String,
    val author: String,
    val description: String,
    val commands: List<String>
)

data class PluginHookContext(
    val chatId: String = "",
    val chatTitle: String = "",
    val isGroup: Boolean = false,
    val senderName: String = "",
    val memberCount: Int = 0,
    val replyToText: String = ""
)

data class PluginCommandHint(
    val command: String,
    val pluginName: String,
    val description: String
)

sealed interface PluginCommandOutcome {
    data class HandledSend(
        val text: String,
        val notice: String? = null
    ) : PluginCommandOutcome

    data class HandledLocal(
        val message: String
    ) : PluginCommandOutcome

    data object NotHandled : PluginCommandOutcome
}

sealed interface OutgoingTransformResult {
    data class Proceed(
        val text: String,
        val notices: List<String> = emptyList()
    ) : OutgoingTransformResult

    data class Cancelled(
        val reason: String
    ) : OutgoingTransformResult
}

data class PluginTestRunResult(
    val success: Boolean,
    val metadata: SpoXPluginMetadata? = null,
    val commandOutcome: PluginCommandOutcome = PluginCommandOutcome.NotHandled,
    val transformedSendText: String? = null,
    val renderedDisplayText: String? = null,
    val logs: List<String> = emptyList(),
    val errorMessage: String? = null
)
