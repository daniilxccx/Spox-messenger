package com.example.notifications

import android.Manifest
import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.Person
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.R
import com.example.ui.call.IncomingCallActivity

object SpoXNotificationHelper {

    const val CHANNEL_MESSAGES = "spox_messages"
    const val CHANNEL_CALLS = "spox_calls_v2"
    const val CHANNEL_ONGOING_CALL = "spox_ongoing_call"

    const val EXTRA_OPEN_CHAT_ID = "extra_open_chat_id"
    const val EXTRA_OPEN_CALL_ID = "extra_open_call_id"
    const val EXTRA_AUTO_ANSWER = "extra_auto_answer"
    const val ACTION_DECLINE_CALL = "com.example.notifications.ACTION_DECLINE_CALL"
    const val ACTION_TOGGLE_MUTE_CALL = "com.example.notifications.ACTION_TOGGLE_MUTE_CALL"
    const val ACTION_END_CALL = "com.example.notifications.ACTION_END_CALL"

    private const val NOTIFICATION_ACCENT_COLOR = 0xFF38BDF8.toInt()
    private const val TEST_PUSH_ID = 9001

    fun ensureChannels(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = context.getSystemService(NotificationManager::class.java) ?: return

        val messagesChannel = NotificationChannel(
            CHANNEL_MESSAGES,
            "Сообщения SpoX",
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "Push-уведомления о новых зашифрованных сообщениях и медиафайлах"
            enableVibration(true)
            enableLights(true)
            lightColor = NOTIFICATION_ACCENT_COLOR
            setShowBadge(true)
        }

        val ringtoneUri = runCatching {
            RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
        }.getOrNull()
        val ringtoneAttrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()

        val callsChannel = NotificationChannel(
            CHANNEL_CALLS,
            "Входящие звонки SpoX",
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "Push-уведомления и экран блокировки для входящих аудио- и видеозвонков"
            enableVibration(true)
            vibrationPattern = longArrayOf(0L, 650L, 450L, 650L, 450L)
            enableLights(true)
            lightColor = NOTIFICATION_ACCENT_COLOR
            lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            if (ringtoneUri != null) {
                setSound(ringtoneUri, ringtoneAttrs)
            }
            setShowBadge(true)
        }

        val ongoingCallChannel = NotificationChannel(
            CHANNEL_ONGOING_CALL,
            "Активный звонок SpoX",
            NotificationManager.IMPORTANCE_DEFAULT
        ).apply {
            description = "Индикатор и быстрые кнопки управления звонком поверх игр и других приложений"
            enableVibration(false)
            setSound(null, null)
            lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            setShowBadge(false)
        }

        runCatching { manager.createNotificationChannel(messagesChannel) }
        runCatching { manager.createNotificationChannel(callsChannel) }
        runCatching { manager.createNotificationChannel(ongoingCallChannel) }
    }

    fun hasNotificationPermission(context: Context): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) return true
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.POST_NOTIFICATIONS
        ) == PackageManager.PERMISSION_GRANTED
    }

    fun canUseFullScreenIntent(context: Context): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.UPSIDE_DOWN_CAKE) return true
        val manager = context.getSystemService(NotificationManager::class.java) ?: return true
        return manager.canUseFullScreenIntent()
    }

    @SuppressLint("MissingPermission")
    fun showMessageNotification(
        context: Context,
        chatId: String,
        chatTitle: String,
        body: String,
        unreadCount: Int,
        senderName: String = chatTitle,
        force: Boolean = false
    ) {
        if (!hasNotificationPermission(context)) return
        if (!force && !NotificationPreferences.isMessagePushEnabled(context)) return
        ensureChannels(context)

        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra(EXTRA_OPEN_CHAT_ID, chatId)
        }
        val requestCode = ("msg_$chatId").hashCode()
        val pendingIntent = PendingIntent.getActivity(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val safeTitle = chatTitle.ifBlank { "SpoX" }
        val safeSender = senderName.ifBlank { safeTitle }
        val contentText = if (unreadCount > 1) {
            "$body • Непрочитано: $unreadCount"
        } else {
            body
        }

        val senderPerson = Person.Builder()
            .setName(safeSender)
            .build()
        val mePerson = Person.Builder()
            .setName("Вы")
            .build()

        val messagingStyle = NotificationCompat.MessagingStyle(mePerson)
            .setConversationTitle(if (safeTitle != safeSender) safeTitle else null)
            .setGroupConversation(safeTitle != safeSender)
            .addMessage(body, System.currentTimeMillis(), senderPerson)

        val notification = NotificationCompat.Builder(context, CHANNEL_MESSAGES)
            .setSmallIcon(R.drawable.ic_stat_spox_notification)
            .setColor(NOTIFICATION_ACCENT_COLOR)
            .setContentTitle(safeTitle)
            .setContentText(contentText)
            .setStyle(messagingStyle)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setVisibility(NotificationCompat.VISIBILITY_PRIVATE)
            .setAutoCancel(true)
            .setNumber(unreadCount.coerceAtLeast(1))
            .setDefaults(NotificationCompat.DEFAULT_ALL)
            .setContentIntent(pendingIntent)
            .build()

        runCatching {
            NotificationManagerCompat.from(context).notify(requestCode, notification)
        }
    }

    fun buildIncomingCallNotification(
        context: Context,
        callId: String,
        callerName: String,
        conversationTitle: String,
        isGroupCall: Boolean,
        callType: String
    ): Notification {
        ensureChannels(context)

        val incomingUiIntent = Intent(context, IncomingCallActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                Intent.FLAG_ACTIVITY_SINGLE_TOP or
                Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra(EXTRA_OPEN_CALL_ID, callId)
            putExtra(EXTRA_AUTO_ANSWER, false)
        }
        val fullScreenPendingIntent = PendingIntent.getActivity(
            context,
            ("call_fs_$callId").hashCode(),
            incomingUiIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val answerIntent = Intent(context, IncomingCallActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                Intent.FLAG_ACTIVITY_SINGLE_TOP or
                Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra(EXTRA_OPEN_CALL_ID, callId)
            putExtra(EXTRA_AUTO_ANSWER, true)
        }
        val answerPendingIntent = PendingIntent.getActivity(
            context,
            ("call_ans_$callId").hashCode(),
            answerIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val declineIntent = Intent(context, CallActionReceiver::class.java).apply {
            action = ACTION_DECLINE_CALL
            putExtra(EXTRA_OPEN_CALL_ID, callId)
        }
        val declinePendingIntent = PendingIntent.getBroadcast(
            context,
            ("call_dec_$callId").hashCode(),
            declineIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val displayTitle = if (isGroupCall) {
            conversationTitle.ifBlank { "Групповой звонок SpoX" }
        } else {
            callerName.ifBlank { "Входящий звонок" }
        }
        val kindText = when {
            isGroupCall && callType == "video" -> "Групповой видеозвонок • ${callerName.ifBlank { "SpoX" }}"
            isGroupCall -> "Групповой аудиозвонок • ${callerName.ifBlank { "SpoX" }}"
            callType == "video" -> "Входящий видеозвонок E2EE"
            else -> "Входящий аудиозвонок E2EE"
        }

        val callerPerson = Person.Builder()
            .setName(displayTitle)
            .setImportant(true)
            .build()

        val callStyle = NotificationCompat.CallStyle
            .forIncomingCall(callerPerson, declinePendingIntent, answerPendingIntent)
            .setIsVideo(callType == "video")

        val ringtoneUri = runCatching {
            RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
        }.getOrNull()

        return NotificationCompat.Builder(context, CHANNEL_CALLS)
            .setSmallIcon(R.drawable.ic_stat_spox_notification)
            .setColor(NOTIFICATION_ACCENT_COLOR)
            .setContentTitle(displayTitle)
            .setContentText(kindText)
            .setStyle(callStyle)
            .addPerson(callerPerson)
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOngoing(true)
            .setAutoCancel(false)
            .setTimeoutAfter(45_000L)
            .apply {
                if (ringtoneUri != null) setSound(ringtoneUri)
            }
            .setContentIntent(fullScreenPendingIntent)
            .setFullScreenIntent(fullScreenPendingIntent, true)
            .build()
    }

    @SuppressLint("MissingPermission")
    fun showIncomingCallNotification(
        context: Context,
        callId: String,
        callerName: String,
        conversationTitle: String,
        isGroupCall: Boolean,
        callType: String,
        force: Boolean = false
    ) {
        if (!hasNotificationPermission(context)) return
        if (!force && !NotificationPreferences.isCallPushEnabled(context)) return

        val notification = buildIncomingCallNotification(
            context = context,
            callId = callId,
            callerName = callerName,
            conversationTitle = conversationTitle,
            isGroupCall = isGroupCall,
            callType = callType
        )
        val requestCode = ("call_$callId").hashCode()
        runCatching {
            NotificationManagerCompat.from(context).notify(requestCode, notification)
        }
    }

    fun buildOngoingCallNotification(
        context: Context,
        callId: String,
        title: String,
        startedAtMs: Long,
        isMuted: Boolean
    ): Notification {
        ensureChannels(context)

        val openCallIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra(EXTRA_OPEN_CALL_ID, callId)
            putExtra(EXTRA_AUTO_ANSWER, true)
        }
        val openPendingIntent = PendingIntent.getActivity(
            context,
            ("call_ongoing_open_$callId").hashCode(),
            openCallIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val hangUpIntent = Intent(context, CallActionReceiver::class.java).apply {
            action = ACTION_END_CALL
            putExtra(EXTRA_OPEN_CALL_ID, callId)
        }
        val hangUpPendingIntent = PendingIntent.getBroadcast(
            context,
            ("call_ongoing_end_$callId").hashCode(),
            hangUpIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val muteIntent = Intent(context, CallActionReceiver::class.java).apply {
            action = ACTION_TOGGLE_MUTE_CALL
            putExtra(EXTRA_OPEN_CALL_ID, callId)
        }
        val mutePendingIntent = PendingIntent.getBroadcast(
            context,
            ("call_ongoing_mute_$callId").hashCode(),
            muteIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val safeTitle = title.ifBlank { "Звонок SpoX" }
        val peerPerson = Person.Builder()
            .setName(safeTitle)
            .setImportant(true)
            .build()

        val callStyle = NotificationCompat.CallStyle
            .forOngoingCall(peerPerson, hangUpPendingIntent)

        val statusLabel = if (isMuted) {
            "Микрофон выкл. • Игровой режим E2EE"
        } else {
            "Голосовой канал E2EE активен в фоне"
        }

        return NotificationCompat.Builder(context, CHANNEL_ONGOING_CALL)
            .setSmallIcon(R.drawable.ic_stat_spox_notification)
            .setColor(NOTIFICATION_ACCENT_COLOR)
            .setContentTitle(safeTitle)
            .setContentText(statusLabel)
            .setStyle(callStyle)
            .addPerson(peerPerson)
            .addAction(
                0,
                if (isMuted) "Вкл. микрофон" else "Выкл. микрофон",
                mutePendingIntent
            )
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setUsesChronometer(true)
            .setWhen(startedAtMs)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .setContentIntent(openPendingIntent)
            .build()
    }

    @SuppressLint("MissingPermission")
    fun showTestPushNotification(context: Context): Boolean {
        if (!hasNotificationPermission(context)) return false
        ensureChannels(context)

        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            TEST_PUSH_ID,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_MESSAGES)
            .setSmallIcon(R.drawable.ic_stat_spox_notification)
            .setColor(NOTIFICATION_ACCENT_COLOR)
            .setContentTitle("SpoX Push активен")
            .setContentText("Push-уведомления настроены и готовы доставлять новые сообщения.")
            .setStyle(
                NotificationCompat.BigTextStyle()
                    .bigText("Push-уведомления настроены и готовы доставлять новые зашифрованные сообщения даже в фоне.")
            )
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setDefaults(NotificationCompat.DEFAULT_ALL)
            .setContentIntent(pendingIntent)
            .build()

        return runCatching {
            NotificationManagerCompat.from(context).notify(TEST_PUSH_ID, notification)
        }.isSuccess
    }

    fun cancelChatNotification(context: Context, chatId: String) {
        runCatching {
            NotificationManagerCompat.from(context).cancel(("msg_$chatId").hashCode())
        }
    }

    fun cancelCallNotification(context: Context, callId: String) {
        runCatching {
            NotificationManagerCompat.from(context).cancel(("call_$callId").hashCode())
        }
    }
}
