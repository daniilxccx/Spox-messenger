package com.example.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.GroupAdd
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.PersonSearch
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.VideoFile
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.AppThemeMode
import com.example.data.model.AppVisualTheme
import com.example.data.model.ChatAppearanceConfig
import com.example.data.model.ChatWallpaperPreset
import com.example.data.model.Conversation
import com.example.data.model.ModerationStatus
import com.example.data.model.OutgoingBubbleStyle
import com.example.data.model.PublicUserProfile
import com.example.data.model.UserPresenceStatus
import com.example.data.model.UserRole
import com.example.data.repository.SavedAccount
import com.example.data.repository.SavedAccountsStore
import com.example.media.LocalSpoxAudioPlayer
import com.example.media.SpoxVideoRequest
import com.example.notifications.MessagePushWorker
import com.example.security.AppLockManager
import com.example.security.BiometricCapability
import com.example.ui.auth.signOutUser
import com.example.ui.components.CipherLoadingStateView
import com.example.ui.components.EncryptionBadge
import com.example.ui.components.IncomingOrActiveCallBanner
import com.example.ui.components.ModerationStatusChip
import com.example.ui.components.ReadReceiptIcon
import com.example.ui.components.RoleBadge
import com.example.ui.components.SavedMessagesAvatar
import com.example.ui.components.UnreadCountBadge
import com.example.ui.components.UserAvatar
import com.example.ui.components.UserPresenceIndicator
import com.example.ui.media.SpoxMediaHubTab
import com.example.ui.media.SpoxVideoPlayerDialog
import com.example.ui.viewmodel.ChatListViewModel
import com.example.ui.viewmodel.UiState
import com.google.firebase.Timestamp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

private enum class ChatFilter(val label: String) {
    ALL("Все"),
    DIRECT("Личные"),
    GROUPS("Группы"),
    PEOPLE("Люди"),
    PLAYER("Плеер")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatListScreen(
    viewModel: ChatListViewModel,
    currentUserId: String,
    userEmail: String,
    userDisplayName: String,
    keyFingerprint: String,
    themeMode: AppThemeMode,
    appearanceConfig: ChatAppearanceConfig,
    isPinEnabled: Boolean,
    isBiometricEnabled: Boolean,
    biometricCapability: BiometricCapability,
    appLockManager: AppLockManager,
    onSetPin: (String) -> Unit,
    onDisablePin: () -> Unit,
    onSetBiometricEnabled: (Boolean) -> Unit,
    onLockAppNow: () -> Unit,
    onChangeThemeMode: (AppThemeMode) -> Unit,
    onSelectVisualTheme: (AppVisualTheme) -> Unit,
    onSelectWallpaperPreset: (ChatWallpaperPreset) -> Unit,
    onPickCustomWallpaperUri: (android.net.Uri) -> Unit,
    onSelectOutgoingBubbleStyle: (OutgoingBubbleStyle) -> Unit,
    onSetShowStories: (Boolean) -> Unit = {},
    onSetShowFolders: (Boolean) -> Unit = {},
    onResetCustomization: () -> Unit,
    onOpenChat: (String) -> Unit,
    onOpenGroupSettings: (String) -> Unit = {},
    onOpenCall: (String) -> Unit,
    savedAccounts: List<SavedAccount> = emptyList(),
    isSwitchingAccount: Boolean = false,
    onSwitchAccount: (SavedAccount, onDone: () -> Unit, onError: (String) -> Unit) -> Unit = { _, onDone, _ -> onDone() },
    onAddAccount: (onDone: () -> Unit, onError: (String) -> Unit) -> Unit = { onDone, _ -> onDone() },
    onRemoveSavedAccount: (String) -> Unit = {},
    onSignOutTriggered: () -> Unit = {}
) {
    val conversationsState by viewModel.conversationsState.collectAsStateWithLifecycle()
    val directoryUsers by viewModel.directoryUsers.collectAsStateWithLifecycle()
    val chatPeersMap by viewModel.chatPeersMap.collectAsStateWithLifecycle()
    val privateProfile by viewModel.privateProfile.collectAsStateWithLifecycle()
    val activeCalls by viewModel.activeCalls.collectAsStateWithLifecycle()
    val actionMessage by viewModel.actionMessage.collectAsStateWithLifecycle()
    val isBusy by viewModel.isBusy.collectAsStateWithLifecycle()
    val peopleSearchQuery by viewModel.peopleSearchQuery.collectAsStateWithLifecycle()
    val peopleSearchResults by viewModel.peopleSearchResults.collectAsStateWithLifecycle()
    val isSearchingPeople by viewModel.isSearchingPeople.collectAsStateWithLifecycle()
    val peopleSearchError by viewModel.peopleSearchError.collectAsStateWithLifecycle()
    val roleCodes by viewModel.roleCodes.collectAsStateWithLifecycle()
    val allUsersForAdmin by viewModel.allUsersForAdmin.collectAsStateWithLifecycle()
    val lastGeneratedRoleCode by viewModel.lastGeneratedRoleCode.collectAsStateWithLifecycle()

    val isDeveloper = UserRole.fromWire(privateProfile?.role) == UserRole.DEVELOPER
    val snackbarHostState = remember { SnackbarHostState() }
    var searchQuery by remember { mutableStateOf("") }
    val pagerState = rememberPagerState(
        initialPage = ChatFilter.ALL.ordinal,
        pageCount = { ChatFilter.entries.size }
    )
    var showNewChatSheet by remember { mutableStateOf(false) }
    var showNewGroupSheet by remember { mutableStateOf(false) }
    var showFindPeopleDialog by remember { mutableStateOf(false) }
    var activeSettingsSection by remember { mutableStateOf<ProfileSettingsSection?>(null) }
    var showMainMoreMenu by remember { mutableStateOf(false) }
    var showMessengerEditorSheet by remember { mutableStateOf(false) }
    var showOwnProfileSheet by remember { mutableStateOf(false) }
    var showAccountSwitcherSheet by remember { mutableStateOf(false) }
    var inspectedPeerWithConvId by remember { mutableStateOf<Pair<PublicUserProfile, String?>?>(null) }
    var showAdminSheet by remember { mutableStateOf(false) }
    var selectedConvForActions by remember { mutableStateOf<Conversation?>(null) }
    var pendingDeleteConv by remember { mutableStateOf<Conversation?>(null) }
    var pendingLeaveConv by remember { mutableStateOf<Conversation?>(null) }
    var presenceNowMs by remember { mutableLongStateOf(System.currentTimeMillis()) }

    LaunchedEffect(appearanceConfig.showFolders) {
        if (!appearanceConfig.showFolders && pagerState.currentPage != ChatFilter.ALL.ordinal) {
            pagerState.animateScrollToPage(ChatFilter.ALL.ordinal)
        }
    }

    LaunchedEffect(Unit) {
        while (true) {
            delay(30_000L)
            presenceNowMs = System.currentTimeMillis()
        }
    }

    LaunchedEffect(actionMessage) {
        actionMessage?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearMessage()
        }
    }

    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }
    val audioPlayer = LocalSpoxAudioPlayer.current
    val audioUiState = audioPlayer?.uiState?.collectAsStateWithLifecycle()?.value
    val isAudioMiniBarVisible = audioUiState?.activeTrack != null
    var activeVideoRequest by remember { mutableStateOf<SpoxVideoRequest?>(null) }

    val primaryGlowColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.13f)
    val secondaryGlowColor = MaterialTheme.colorScheme.secondary.copy(alpha = 0.10f)

    Scaffold(
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        containerColor = Color.Transparent,
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .drawWithCache {
                val topGlow = Brush.radialGradient(
                    colors = listOf(primaryGlowColor, Color.Transparent),
                    center = Offset(size.width * 0.85f, size.height * 0.06f),
                    radius = (size.minDimension * 0.85f).coerceAtLeast(1f)
                )
                val sideGlow = Brush.radialGradient(
                    colors = listOf(secondaryGlowColor, Color.Transparent),
                    center = Offset(size.width * 0.12f, size.height * 0.24f),
                    radius = (size.minDimension * 0.65f).coerceAtLeast(1f)
                )
                onDrawBehind {
                    drawRect(brush = topGlow)
                    drawRect(brush = sideGlow)
                }
            },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.Transparent,
                    scrolledContainerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.92f)
                ),
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(RoundedCornerShape(11.dp))
                                .background(
                                    Brush.linearGradient(
                                        listOf(
                                            MaterialTheme.colorScheme.primary,
                                            MaterialTheme.colorScheme.secondary
                                        )
                                    )
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Shield,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onPrimary,
                                modifier = Modifier.size(19.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "SpoX",
                                    style = MaterialTheme.typography.headlineSmall,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    softWrap = false
                                )
                                Spacer(modifier = Modifier.width(7.dp))
                                EncryptionBadge(label = "E2EE")
                                val currentUserRole = UserRole.fromWire(privateProfile?.role)
                                if (currentUserRole != UserRole.USER) {
                                    Spacer(modifier = Modifier.width(5.dp))
                                    RoleBadge(role = currentUserRole, compact = true)
                                }
                            }
                        }
                    }
                },
                actions = {
                    val myAvatar = privateProfile?.avatarBase64.orEmpty()
                    val myColor = (directoryUsers.firstOrNull { it.userId == currentUserId }?.avatarColorIndex ?: 0L).toInt()
                    IconButton(
                        onClick = {
                            val next = if (themeMode == AppThemeMode.LIGHT) AppThemeMode.DARK else AppThemeMode.LIGHT
                            onChangeThemeMode(next)
                            viewModel.syncThemePreference(next)
                        },
                        modifier = Modifier.testTag("quick_theme_toggle_button")
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.7f),
                            modifier = Modifier.size(34.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = if (themeMode == AppThemeMode.LIGHT) Icons.Filled.DarkMode else Icons.Filled.LightMode,
                                    contentDescription = "Переключить тему",
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                    IconButton(
                        onClick = { showNewGroupSheet = true },
                        modifier = Modifier.testTag("create_group_top_button")
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.7f),
                            modifier = Modifier.size(34.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Filled.GroupAdd,
                                    contentDescription = "Создать групповой чат",
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                    if (isDeveloper) {
                        IconButton(
                            onClick = { showAdminSheet = true },
                            modifier = Modifier.testTag("open_admin_panel_button")
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.14f),
                                modifier = Modifier.size(34.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Filled.AdminPanelSettings,
                                        contentDescription = "Админ-панель модерации",
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }
                    }
                    Box {
                        IconButton(
                            onClick = { showMainMoreMenu = true },
                            modifier = Modifier.testTag("main_more_menu_button")
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.78f),
                                modifier = Modifier.size(34.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Filled.MoreVert,
                                        contentDescription = "Меню",
                                        modifier = Modifier.size(19.dp)
                                    )
                                }
                            }
                        }
                        DropdownMenu(
                            expanded = showMainMoreMenu,
                            onDismissRequest = { showMainMoreMenu = false },
                            shape = RoundedCornerShape(16.dp),
                            containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                            modifier = Modifier.testTag("main_more_menu")
                        ) {
                            DropdownMenuItem(
                                text = {
                                    Column {
                                        Text(
                                            text = "Мой профиль",
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                        Text(
                                            text = "Аватар, @юзернейм, код шифрования",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                },
                                leadingIcon = {
                                    UserAvatar(
                                        name = userDisplayName,
                                        avatarBase64 = myAvatar,
                                        colorIndex = myColor,
                                        size = 34.dp
                                    )
                                },
                                onClick = {
                                    showMainMoreMenu = false
                                    showOwnProfileSheet = true
                                },
                                modifier = Modifier.testTag("menu_view_profile")
                            )
                            HorizontalDivider(
                                color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.45f)
                            )
                            DropdownMenuItem(
                                text = {
                                    Column {
                                        Text(
                                            text = "Аккаунты (${savedAccounts.size.coerceAtLeast(1)}/${SavedAccountsStore.MAX_ACCOUNTS})",
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                        Text(
                                            text = "Сменить или добавить аккаунт",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                },
                                leadingIcon = {
                                    Surface(
                                        shape = CircleShape,
                                        color = MaterialTheme.colorScheme.tertiary.copy(alpha = 0.16f),
                                        modifier = Modifier.size(34.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon(
                                                imageVector = Icons.Filled.SwapHoriz,
                                                contentDescription = null,
                                                tint = MaterialTheme.colorScheme.tertiary,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }
                                },
                                onClick = {
                                    showMainMoreMenu = false
                                    showAccountSwitcherSheet = true
                                },
                                modifier = Modifier.testTag("menu_switch_accounts")
                            )
                            HorizontalDivider(
                                color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.45f)
                            )
                            DropdownMenuItem(
                                text = {
                                    Column {
                                        Text(
                                            text = "Настройки",
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                        Text(
                                            text = "Уведомления, приватность, PIN",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                },
                                leadingIcon = {
                                    Surface(
                                        shape = CircleShape,
                                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.14f),
                                        modifier = Modifier.size(34.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon(
                                                imageVector = Icons.Filled.Settings,
                                                contentDescription = null,
                                                tint = MaterialTheme.colorScheme.primary,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }
                                },
                                onClick = {
                                    showMainMoreMenu = false
                                    activeSettingsSection = ProfileSettingsSection.SETTINGS
                                },
                                modifier = Modifier.testTag("menu_open_settings")
                            )
                            HorizontalDivider(
                                color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.45f)
                            )
                            DropdownMenuItem(
                                text = {
                                    Column {
                                        Text(
                                            text = "Редактировать мессенджер",
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                        Text(
                                            text = "Скрыть или показать истории и папки",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                },
                                leadingIcon = {
                                    Surface(
                                        shape = CircleShape,
                                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.14f),
                                        modifier = Modifier.size(34.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon(
                                                imageVector = Icons.Filled.Tune,
                                                contentDescription = null,
                                                tint = MaterialTheme.colorScheme.primary,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }
                                },
                                onClick = {
                                    showMainMoreMenu = false
                                    showMessengerEditorSheet = true
                                },
                                modifier = Modifier.testTag("menu_edit_messenger")
                            )
                            HorizontalDivider(
                                color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.45f)
                            )
                            DropdownMenuItem(
                                text = {
                                    Column {
                                        Text(
                                            text = "Кастомизация",
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                        Text(
                                            text = "Темы, обои, истории и папки",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                },
                                leadingIcon = {
                                    Surface(
                                        shape = CircleShape,
                                        color = MaterialTheme.colorScheme.secondary.copy(alpha = 0.16f),
                                        modifier = Modifier.size(34.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon(
                                                imageVector = Icons.Filled.Palette,
                                                contentDescription = null,
                                                tint = MaterialTheme.colorScheme.secondary,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }
                                },
                                onClick = {
                                    showMainMoreMenu = false
                                    activeSettingsSection = ProfileSettingsSection.CUSTOMIZATION
                                },
                                modifier = Modifier.testTag("menu_open_customization")
                            )
                            HorizontalDivider(
                                color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.45f)
                            )
                            DropdownMenuItem(
                                text = {
                                    Column {
                                        Text(
                                            text = "Избранное",
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                        Text(
                                            text = "Личные заметки и пересланное",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                },
                                leadingIcon = {
                                    SavedMessagesAvatar(size = 34.dp)
                                },
                                enabled = !isBusy,
                                onClick = {
                                    showMainMoreMenu = false
                                    viewModel.openSavedMessages(onOpenChat)
                                },
                                modifier = Modifier.testTag("menu_open_saved_messages")
                            )
                            HorizontalDivider(
                                color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.45f)
                            )
                            DropdownMenuItem(
                                text = {
                                    Column {
                                        Text(
                                            text = "Изменение профиля",
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                        Text(
                                            text = userDisplayName.ifBlank { "Никнейм, юзернейм, фото" },
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                },
                                leadingIcon = {
                                    Box(contentAlignment = Alignment.BottomEnd) {
                                        UserAvatar(
                                            name = userDisplayName,
                                            avatarBase64 = myAvatar,
                                            colorIndex = myColor,
                                            size = 34.dp
                                        )
                                        Surface(
                                            shape = CircleShape,
                                            color = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(14.dp)
                                        ) {
                                            Box(contentAlignment = Alignment.Center) {
                                                Icon(
                                                    imageVector = Icons.Filled.Edit,
                                                    contentDescription = null,
                                                    tint = MaterialTheme.colorScheme.onPrimary,
                                                    modifier = Modifier.size(9.dp)
                                                )
                                            }
                                        }
                                    }
                                },
                                onClick = {
                                    showMainMoreMenu = false
                                    activeSettingsSection = ProfileSettingsSection.PROFILE
                                },
                                modifier = Modifier.testTag("menu_edit_profile")
                            )
                        }
                    }
                }
            )
        },
        floatingActionButton = {
            if (pagerState.currentPage != ChatFilter.PLAYER.ordinal) {
                ExtendedFloatingActionButton(
                    onClick = { showNewChatSheet = true },
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary,
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier
                        .navigationBarsPadding()
                        .padding(bottom = if (isAudioMiniBarVisible) 74.dp else 0.dp)
                        .testTag("new_chat_fab"),
                    icon = { Icon(Icons.AutoMirrored.Filled.Chat, contentDescription = null) },
                    text = {
                        Text(
                            text = "Новый чат",
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 700.dp)
                    .align(Alignment.TopCenter)
                    .padding(horizontal = 16.dp)
            ) {
                if (privateProfile?.isCurrentlyMuted() == true) {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.72f),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.tertiary.copy(alpha = 0.45f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 10.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            ModerationStatusChip(
                                status = ModerationStatus.MUTED,
                                mutedUntilEpochMs = privateProfile?.mutedUntilEpochMs ?: 0L,
                                compact = false
                            )
                            Text(
                                text = "Режим чтения: отправка сообщений отключена",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onTertiaryContainer,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }

                activeCalls.firstOrNull()?.let { liveCall ->
                    IncomingOrActiveCallBanner(
                        call = liveCall,
                        currentUserId = currentUserId,
                        onAcceptOrJoin = { onOpenCall(liveCall.id) },
                        onDecline = { viewModel.declineIncomingCall(liveCall) },
                        modifier = Modifier.padding(bottom = 12.dp)
                    )
                }

                AnimatedVisibility(visible = pagerState.targetPage != ChatFilter.PLAYER.ordinal) {
                    Column {
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            placeholder = {
                                Text(
                                    text = "Поиск чатов и людей (имя, @ник)...",
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Filled.Search,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            },
                            trailingIcon = {
                                if (searchQuery.isNotEmpty()) {
                                    IconButton(onClick = { searchQuery = "" }) {
                                        Icon(Icons.Filled.Close, contentDescription = "Очистить поиск")
                                    }
                                }
                            },
                            singleLine = true,
                            shape = RoundedCornerShape(20.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.85f),
                                unfocusedContainerColor = MaterialTheme.colorScheme.surfaceContainerLow.copy(alpha = 0.85f),
                                focusedBorderColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.65f),
                                unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.65f)
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("chat_search_input")
                        )

                        Spacer(modifier = Modifier.height(10.dp))
                    }
                }

                val allConversationsList = (conversationsState as? UiState.Success)?.data.orEmpty()
                val tabUnreadCounts = remember(allConversationsList, currentUserId) {
                    mapOf(
                        ChatFilter.ALL to allConversationsList.sumOf { it.unreadCountFor(currentUserId) },
                        ChatFilter.DIRECT to allConversationsList.filter { !it.isGroup && !it.isSavedMessages(currentUserId) }
                            .sumOf { it.unreadCountFor(currentUserId) },
                        ChatFilter.GROUPS to allConversationsList.filter { it.isGroup }
                            .sumOf { it.unreadCountFor(currentUserId) },
                        ChatFilter.PEOPLE to 0,
                        ChatFilter.PLAYER to 0
                    )
                }

                AnimatedVisibility(
                    visible = appearanceConfig.showFolders,
                    enter = expandVertically(tween(240)) + fadeIn(tween(220)),
                    exit = shrinkVertically(tween(220)) + fadeOut(tween(180))
                ) {
                    Column {
                        // Segmented glass capsule tab switcher with animated sliding pill
                        Surface(
                            shape = RoundedCornerShape(18.dp),
                            color = MaterialTheme.colorScheme.surfaceContainerLow.copy(alpha = 0.92f),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("chat_folders_bar")
                        ) {
                            BoxWithConstraints(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(4.dp)
                            ) {
                                val tabCount = ChatFilter.entries.size
                                val tabWidthDp = maxWidth / tabCount
                                val tabWidthPx = constraints.maxWidth.toFloat() / tabCount

                                Surface(
                                    shape = RoundedCornerShape(14.dp),
                                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.85f),
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.45f)),
                                    modifier = Modifier
                                        .width(tabWidthDp)
                                        .height(38.dp)
                                        .graphicsLayer {
                                            translationX =
                                                (pagerState.currentPage + pagerState.currentPageOffsetFraction) * tabWidthPx
                                        }
                                ) {}

                                Row(modifier = Modifier.fillMaxWidth()) {
                                    ChatFilter.entries.forEachIndexed { index, filter ->
                                        val tabUnread = tabUnreadCounts[filter] ?: 0
                                        val isSelected = pagerState.targetPage == index
                                        val contentColor by animateColorAsState(
                                            targetValue = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer
                                            else MaterialTheme.colorScheme.onSurfaceVariant,
                                            animationSpec = tween(220),
                                            label = "tab_fg_${filter.name}"
                                        )
                                        Box(
                                            contentAlignment = Alignment.Center,
                                            modifier = Modifier
                                                .weight(1f)
                                                .height(38.dp)
                                                .clip(RoundedCornerShape(14.dp))
                                                .clickable {
                                                    scope.launch { pagerState.animateScrollToPage(index) }
                                                }
                                                .testTag("filter_${filter.name.lowercase()}")
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(horizontal = 4.dp),
                                                horizontalArrangement = Arrangement.Center,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text(
                                                    text = filter.label,
                                                    style = MaterialTheme.typography.labelMedium,
                                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                                    color = contentColor,
                                                    maxLines = 1,
                                                    softWrap = false,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                                if (tabUnread > 0) {
                                                    Spacer(modifier = Modifier.width(3.dp))
                                                    Box(
                                                        modifier = Modifier
                                                            .clip(CircleShape)
                                                            .background(MaterialTheme.colorScheme.primary)
                                                            .padding(horizontal = 5.dp, vertical = 1.dp),
                                                        contentAlignment = Alignment.Center
                                                    ) {
                                                        Text(
                                                            text = if (tabUnread > 99) "99+" else tabUnread.toString(),
                                                            style = MaterialTheme.typography.labelSmall,
                                                            fontWeight = FontWeight.Bold,
                                                            color = MaterialTheme.colorScheme.onPrimary
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                    }
                }

                AnimatedContent(
                    targetState = conversationsState,
                    transitionSpec = {
                        fadeIn(tween(220)) togetherWith fadeOut(tween(160))
                    },
                    contentKey = { it::class },
                    label = "chats_loading_state"
                ) { state ->
                    when (state) {
                        is UiState.Loading -> {
                            CipherLoadingStateView(label = "Загрузка защищённых чатов...")
                        }

                        is UiState.Error -> {
                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = MaterialTheme.colorScheme.error.copy(alpha = 0.12f),
                                modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp)
                            ) {
                                Column(
                                    modifier = Modifier.padding(16.dp),
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Text(
                                        text = state.message,
                                        color = MaterialTheme.colorScheme.error,
                                        style = MaterialTheme.typography.bodyMedium
                                    )
                                    Button(
                                        onClick = { viewModel.retryLoadConversations() },
                                        modifier = Modifier.testTag("retry_conversations_button")
                                    ) {
                                        Text("Повторить")
                                    }
                                }
                            }
                        }

                        is UiState.Success -> {
                            val usersById = chatPeersMap
                            val trimmedSearch = searchQuery.trim()
                            val searchEmailHash = remember(trimmedSearch) {
                                viewModel.computeEmailHash(trimmedSearch)
                            }
                            val existingDirectPeerUids = remember(state.data, currentUserId) {
                                state.data
                                    .filter { !it.isGroup && !it.isSavedMessages(currentUserId) }
                                    .mapNotNull { conv -> conv.memberUids.firstOrNull { it != currentUserId } }
                                    .toSet()
                            }
                            val hasSavedConversation = remember(state.data, currentUserId) {
                                state.data.any { it.isSavedMessages(currentUserId) }
                            }
                            val presenceBucket = presenceNowMs / 30_000L
                            val sortedAllPeers = remember(directoryUsers, currentUserId, presenceBucket) {
                                viewModel.filterUsers(directoryUsers, "")
                                    .sortedWith(
                                        compareBy<PublicUserProfile> {
                                            when (it.presenceStatus(presenceNowMs)) {
                                                UserPresenceStatus.ONLINE -> 0
                                                UserPresenceStatus.RECENTLY -> 1
                                                UserPresenceStatus.OFFLINE -> 2
                                            }
                                        }.thenBy { it.displayName.lowercase() }
                                    )
                            }

                            HorizontalPager(
                                state = pagerState,
                                beyondViewportPageCount = 0,
                                userScrollEnabled = appearanceConfig.showFolders,
                                key = { ChatFilter.entries[it].name },
                                modifier = Modifier
                                    .fillMaxSize()
                                    .testTag("chat_tabs_pager")
                            ) { pageIndex ->
                                val activeTab = ChatFilter.entries[pageIndex]
                                if (activeTab == ChatFilter.PLAYER) {
                                    SpoxMediaHubTab(
                                        onOpenVideo = { request -> activeVideoRequest = request },
                                        onShowMessage = { msg -> viewModel.showMessage(msg) },
                                        extraBottomPaddingDp = if (isAudioMiniBarVisible) 104 else 32
                                    )
                                } else {
                                val tabListState = rememberLazyListState()

                                val filtered = remember(
                                    state.data,
                                    usersById,
                                    trimmedSearch,
                                    searchEmailHash,
                                    activeTab,
                                    currentUserId
                                ) {
                                    if (activeTab == ChatFilter.PEOPLE || activeTab == ChatFilter.PLAYER) {
                                        emptyList()
                                    } else {
                                        val qClean = trimmedSearch.removePrefix("@")
                                        val baseFiltered = state.data.filter { conv ->
                                            val isSaved = conv.isSavedMessages(currentUserId)
                                            val matchesType = when (activeTab) {
                                                ChatFilter.ALL -> true
                                                ChatFilter.DIRECT -> !conv.isGroup && !isSaved
                                                ChatFilter.GROUPS -> conv.isGroup
                                                ChatFilter.PEOPLE, ChatFilter.PLAYER -> false
                                            }
                                            if (!matchesType) return@filter false
                                            if (trimmedSearch.isEmpty()) return@filter true

                                            val peerProfile = if (isSaved) null else resolveDirectPeer(conv, currentUserId, usersById)
                                            val displayTitle = peerProfile?.displayName ?: resolveConversationTitle(conv, currentUserId)
                                            val peerHandle = peerProfile?.handle.orEmpty()
                                            val memberMatches = conv.memberUids.any { uid ->
                                                val member = usersById[uid]
                                                val memberName = member?.displayName ?: conv.memberNames[uid].orEmpty()
                                                val memberHandle = member?.handle.orEmpty()
                                                (memberName.isNotBlank() && memberName.contains(trimmedSearch, ignoreCase = true)) ||
                                                    (memberHandle.isNotBlank() && (
                                                        memberHandle.contains(trimmedSearch, ignoreCase = true) ||
                                                            (qClean.isNotEmpty() && memberHandle.removePrefix("@").contains(qClean, ignoreCase = true))
                                                        )) ||
                                                    (searchEmailHash != null && member?.emailHash.equals(searchEmailHash, ignoreCase = true))
                                            }
                                            val savedKeywordsMatch = isSaved && (
                                                "избранное".contains(trimmedSearch, ignoreCase = true) ||
                                                    "saved".contains(trimmedSearch, ignoreCase = true) ||
                                                    "заметки".contains(trimmedSearch, ignoreCase = true)
                                                )
                                            displayTitle.contains(trimmedSearch, ignoreCase = true) ||
                                                savedKeywordsMatch ||
                                                (peerHandle.isNotBlank() && (
                                                    peerHandle.contains(trimmedSearch, ignoreCase = true) ||
                                                        (qClean.isNotEmpty() && peerHandle.removePrefix("@").contains(qClean, ignoreCase = true))
                                                    )) ||
                                                (searchEmailHash != null && peerProfile?.emailHash.equals(searchEmailHash, ignoreCase = true)) ||
                                                memberMatches
                                        }
                                        baseFiltered.sortedByDescending { it.isSavedMessages(currentUserId) }
                                    }
                                }

                                val showSavedShortcutCard = remember(activeTab, hasSavedConversation, trimmedSearch) {
                                    activeTab == ChatFilter.ALL &&
                                        !hasSavedConversation &&
                                        (trimmedSearch.isEmpty() ||
                                            "избранное".contains(trimmedSearch, ignoreCase = true) ||
                                            "saved".contains(trimmedSearch, ignoreCase = true) ||
                                            "заметки".contains(trimmedSearch, ignoreCase = true))
                                }

                                val matchingPeople = remember(
                                    directoryUsers,
                                    sortedAllPeers,
                                    trimmedSearch,
                                    activeTab,
                                    existingDirectPeerUids,
                                    filtered.size
                                ) {
                                    when {
                                        activeTab == ChatFilter.GROUPS || activeTab == ChatFilter.PLAYER -> emptyList()
                                        activeTab == ChatFilter.PEOPLE -> {
                                            if (trimmedSearch.isEmpty()) sortedAllPeers
                                            else viewModel.filterUsers(directoryUsers, trimmedSearch)
                                        }
                                        trimmedSearch.isNotEmpty() -> {
                                            viewModel.filterUsers(directoryUsers, trimmedSearch)
                                                .filter { it.userId !in existingDirectPeerUids }
                                        }
                                        activeTab == ChatFilter.DIRECT -> {
                                            sortedAllPeers.filter { it.userId !in existingDirectPeerUids }
                                        }
                                        filtered.isEmpty() -> sortedAllPeers
                                        else -> emptyList()
                                    }
                                }

                                if (filtered.isEmpty() && matchingPeople.isEmpty() && !showSavedShortcutCard) {
                                    if (trimmedSearch.isNotEmpty()) {
                                        EmptySearchResultState(
                                            query = trimmedSearch,
                                            onOpenFindPeople = {
                                                viewModel.updatePeopleSearchQuery(trimmedSearch)
                                                showFindPeopleDialog = true
                                            },
                                            onClearSearch = { searchQuery = "" }
                                        )
                                    } else {
                                        EmptyChatsState(
                                            isGroupsTab = activeTab == ChatFilter.GROUPS,
                                            isPeopleTab = activeTab == ChatFilter.PEOPLE,
                                            onNewChat = { showNewChatSheet = true },
                                            onNewGroup = { showNewGroupSheet = true },
                                            onFindPeople = {
                                                viewModel.clearPeopleSearch()
                                                showFindPeopleDialog = true
                                            }
                                        )
                                    }
                                } else {
                                    LazyColumn(
                                        state = tabListState,
                                        contentPadding = PaddingValues(top = 2.dp, bottom = if (isAudioMiniBarVisible) 164.dp else 96.dp),
                                        verticalArrangement = Arrangement.spacedBy(10.dp),
                                        modifier = Modifier.fillMaxSize()
                                    ) {
                                        if (appearanceConfig.showStories && activeTab == ChatFilter.ALL && trimmedSearch.isEmpty()) {
                                            item(key = "quick_contacts_ribbon") {
                                                QuickContactsRibbon(
                                                    peers = sortedAllPeers.take(10),
                                                    presenceNowMs = presenceNowMs,
                                                    enabled = !isBusy,
                                                    onOpenSaved = { viewModel.openSavedMessages(onOpenChat) },
                                                    onSelectPeer = { person ->
                                                        viewModel.startDirectChat(person) { chatId ->
                                                            onOpenChat(chatId)
                                                        }
                                                    },
                                                    onEditMessenger = { showMessengerEditorSheet = true }
                                                )
                                            }
                                        }
                                        if (showSavedShortcutCard) {
                                            item(key = "saved_messages_shortcut") {
                                                SavedMessagesShortcutCard(
                                                    enabled = !isBusy,
                                                    onClick = {
                                                        viewModel.openSavedMessages(onOpenChat)
                                                    }
                                                )
                                            }
                                        }
                                        items(filtered, key = { it.id }) { conv ->
                                            val peerProfile = if (conv.isSavedMessages(currentUserId)) null else resolveDirectPeer(conv, currentUserId, usersById)
                                            val groupOnlineCount = remember(conv, usersById, presenceBucket) {
                                                if (!conv.isGroup) 0
                                                else conv.memberUids.count { uid ->
                                                    uid != currentUserId &&
                                                        usersById[uid]?.presenceStatus(presenceNowMs) == UserPresenceStatus.ONLINE
                                                }
                                            }
                                            Box(modifier = Modifier.animateItem()) {
                                                ConversationCard(
                                                    conversation = conv,
                                                    currentUserId = currentUserId,
                                                    peerProfile = peerProfile,
                                                    groupOnlineCount = groupOnlineCount,
                                                    presenceNowMs = presenceNowMs,
                                                    onClick = { onOpenChat(conv.id) },
                                                    onLongClick = { selectedConvForActions = conv },
                                                    onMoreClick = { selectedConvForActions = conv }
                                                )
                                            }
                                        }
                                        if (matchingPeople.isNotEmpty()) {
                                            item(key = "people_section_header") {
                                                Row(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .padding(top = if (filtered.isNotEmpty()) 8.dp else 2.dp, bottom = 2.dp),
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Text(
                                                        text = if (activeTab == ChatFilter.PEOPLE) {
                                                            "Люди в SpoX • нажмите для ЛС (${matchingPeople.size})"
                                                        } else {
                                                            "Написать в ЛС (${matchingPeople.size})"
                                                        },
                                                        style = MaterialTheme.typography.labelLarge,
                                                        color = MaterialTheme.colorScheme.primary
                                                    )
                                                }
                                            }
                                            items(matchingPeople, key = { "person_${it.userId}" }) { person ->
                                                Box(modifier = Modifier.animateItem()) {
                                                    DirectoryPersonCard(
                                                        person = person,
                                                        matchedByEmail = searchEmailHash != null && person.emailHash.equals(searchEmailHash, ignoreCase = true),
                                                        hasExistingChat = person.userId in existingDirectPeerUids,
                                                        presenceNowMs = presenceNowMs,
                                                        enabled = !isBusy,
                                                        onClick = {
                                                            viewModel.startDirectChat(person) { chatId ->
                                                                onOpenChat(chatId)
                                                            }
                                                        }
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    activeVideoRequest?.let { videoReq ->
        SpoxVideoPlayerDialog(
            request = videoReq,
            onDismiss = { activeVideoRequest = null }
        )
    }

    if (showNewChatSheet) {
        var sheetQuery by remember { mutableStateOf("") }
        val peers = remember(directoryUsers, sheetQuery, currentUserId) {
            viewModel.filterUsers(directoryUsers, sheetQuery)
        }
        val sheetEmailHash = remember(sheetQuery) { viewModel.computeEmailHash(sheetQuery) }
        val allConvs = (conversationsState as? UiState.Success)?.data.orEmpty()
        val sheetExistingPeerUids = remember(allConvs, currentUserId) {
            allConvs.filter { !it.isGroup }
                .mapNotNull { conv -> conv.memberUids.firstOrNull { it != currentUserId } }
                .toSet()
        }

        ModalBottomSheet(onDismissRequest = { showNewChatSheet = false }) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(horizontal = 20.dp, vertical = 8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Личное сообщение (ЛС)",
                            style = MaterialTheme.typography.titleLarge
                        )
                        Text(
                            text = "Нажмите на человека, чтобы сразу открыть чат",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    TextButton(
                        onClick = {
                            showNewChatSheet = false
                            viewModel.clearPeopleSearch()
                            showFindPeopleDialog = true
                        },
                        modifier = Modifier.testTag("find_people_button")
                    ) {
                        Icon(Icons.Filled.PersonSearch, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("По email")
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
                OutlinedTextField(
                    value = sheetQuery,
                    onValueChange = { sheetQuery = it },
                    placeholder = { Text("Имя, @юзернейм или email...") },
                    leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                    trailingIcon = {
                        if (sheetQuery.isNotEmpty()) {
                            IconButton(onClick = { sheetQuery = "" }) {
                                Icon(Icons.Filled.Close, contentDescription = "Очистить")
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("new_chat_people_search_input")
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = if (sheetQuery.isBlank()) "Пользователи (${peers.size})" else "Найдено (${peers.size})",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(8.dp))
                if (peers.isEmpty()) {
                    Text(
                        text = if (sheetQuery.isBlank()) {
                            "Пока нет других пользователей в открытом каталоге. Вы можете найти собеседника по точному email или @юзернейму."
                        } else {
                            "По запросу «$sheetQuery» никто не найден. Попробуйте ввести другое имя, @юзернейм или точный email."
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(vertical = 16.dp)
                    )
                } else {
                    LazyColumn(
                        modifier = Modifier.height(300.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(peers, key = { it.userId }) { peer ->
                            DirectoryPersonCard(
                                person = peer,
                                matchedByEmail = sheetEmailHash != null && peer.emailHash.equals(sheetEmailHash, ignoreCase = true),
                                hasExistingChat = peer.userId in sheetExistingPeerUids,
                                presenceNowMs = presenceNowMs,
                                enabled = !isBusy,
                                onClick = {
                                    viewModel.startDirectChat(peer) { chatId ->
                                        showNewChatSheet = false
                                        onOpenChat(chatId)
                                    }
                                },
                                modifier = Modifier.testTag("peer_item_${peer.userId}")
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }

    if (showNewGroupSheet) {
        val allPeers = remember(directoryUsers, currentUserId) {
            directoryUsers.filter { it.userId != currentUserId }
        }
        var groupTitle by remember { mutableStateOf("") }
        var memberFilterQuery by remember { mutableStateOf("") }
        val filteredGroupPeers = remember(allPeers, memberFilterQuery) {
            viewModel.filterUsers(allPeers, memberFilterQuery, excludeCurrentUser = false)
        }
        val selectedUids = remember { mutableStateListOf<String>() }

        ModalBottomSheet(onDismissRequest = { showNewGroupSheet = false }) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(horizontal = 20.dp, vertical = 8.dp)
            ) {
                Text(
                    text = "Создать групповой чат",
                    style = MaterialTheme.typography.titleLarge
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Для группы генерируется общий AES-256 ключ, зашифрованный персонально для каждого участника.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedTextField(
                    value = groupTitle,
                    onValueChange = { groupTitle = it },
                    label = { Text("Название группы") },
                    placeholder = { Text("Например: Команда разработки") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("group_title_input")
                )
                Spacer(modifier = Modifier.height(10.dp))
                OutlinedTextField(
                    value = memberFilterQuery,
                    onValueChange = { memberFilterQuery = it },
                    placeholder = { Text("Поиск участников (имя, @юзернейм, email)...") },
                    leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                    trailingIcon = {
                        if (memberFilterQuery.isNotEmpty()) {
                            IconButton(onClick = { memberFilterQuery = "" }) {
                                Icon(Icons.Filled.Close, contentDescription = "Очистить")
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("group_member_search_input")
                )
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "Участники (${selectedUids.size} выбрано)",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(8.dp))
                if (allPeers.isEmpty()) {
                    Text(
                        text = "Других контактов пока нет — вы можете создать группу сейчас и добавить участников позже.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(vertical = 8.dp)
                    )
                } else if (filteredGroupPeers.isEmpty()) {
                    Text(
                        text = "Участники по запросу «$memberFilterQuery» не найдены.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(vertical = 8.dp)
                    )
                } else {
                    LazyColumn(
                        modifier = Modifier.height(200.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(filteredGroupPeers, key = { it.userId }) { peer ->
                            val checked = peer.userId in selectedUids
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = if (checked) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
                                else MaterialTheme.colorScheme.surfaceContainer,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        if (checked) selectedUids.remove(peer.userId)
                                        else selectedUids.add(peer.userId)
                                    }
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    UserAvatar(
                                        name = peer.displayName,
                                        avatarBase64 = peer.avatarBase64,
                                        colorIndex = peer.avatarColorIndex.toInt(),
                                        size = 38.dp,
                                        presenceStatus = peer.presenceStatus(presenceNowMs)
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(peer.displayName, style = MaterialTheme.typography.titleSmall)
                                        if (peer.handle.isNotBlank()) {
                                            Text(
                                                text = peer.handle,
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                    Checkbox(
                                        checked = checked,
                                        onCheckedChange = {
                                            if (checked) selectedUids.remove(peer.userId)
                                            else selectedUids.add(peer.userId)
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(14.dp))
                Button(
                    onClick = {
                        val chosen = allPeers.filter { it.userId in selectedUids }
                        viewModel.createGroupChat(
                            title = groupTitle.ifBlank { "Защищённая группа" },
                            selectedMembers = chosen
                        ) { chatId ->
                            showNewGroupSheet = false
                            onOpenChat(chatId)
                        }
                    },
                    enabled = !isBusy,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("confirm_create_group_button")
                ) {
                    Icon(Icons.Filled.Check, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Создать группу")
                }
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }

    if (showFindPeopleDialog) {
        val dialogEmailHash = remember(peopleSearchQuery) { viewModel.computeEmailHash(peopleSearchQuery) }
        AlertDialog(
            onDismissRequest = {
                showFindPeopleDialog = false
                viewModel.clearPeopleSearch()
            },
            title = { Text("Поиск людей") },
            text = {
                Column {
                    Text(
                        text = "Ищите собеседников по имени, @юзернейму или точному email (проверяется через SHA-256).",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = peopleSearchQuery,
                        onValueChange = { viewModel.updatePeopleSearchQuery(it) },
                        label = { Text("Имя, @юзернейм или email") },
                        placeholder = { Text("Анна, @alex или name@gmail.com") },
                        leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                        trailingIcon = {
                            if (isSearchingPeople) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(18.dp),
                                    strokeWidth = 2.dp
                                )
                            } else if (peopleSearchQuery.isNotEmpty()) {
                                IconButton(onClick = { viewModel.clearPeopleSearch() }) {
                                    Icon(Icons.Filled.Close, contentDescription = "Очистить")
                                }
                            }
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("find_people_input")
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    if (peopleSearchError != null) {
                        Text(
                            text = peopleSearchError!!,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error
                        )
                    } else if (peopleSearchQuery.isBlank()) {
                        Text(
                            text = "Начните вводить имя, @username или адрес электронной почты.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else if (peopleSearchResults.isEmpty() && !isSearchingPeople) {
                        Text(
                            text = "Пользователи не найдены или скрыты настройками приватности.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else if (peopleSearchResults.isNotEmpty()) {
                        val dialogExistingPeerUids = (conversationsState as? UiState.Success)?.data
                            .orEmpty()
                            .filter { !it.isGroup }
                            .mapNotNull { conv -> conv.memberUids.firstOrNull { it != currentUserId } }
                            .toSet()
                        LazyColumn(
                            modifier = Modifier.height(210.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(peopleSearchResults, key = { it.userId }) { user ->
                                DirectoryPersonCard(
                                    person = user,
                                    matchedByEmail = dialogEmailHash != null && user.emailHash.equals(dialogEmailHash, ignoreCase = true),
                                    hasExistingChat = user.userId in dialogExistingPeerUids,
                                    presenceNowMs = presenceNowMs,
                                    enabled = !isBusy,
                                    onClick = {
                                        showFindPeopleDialog = false
                                        viewModel.clearPeopleSearch()
                                        viewModel.startDirectChat(user) { chatId ->
                                            onOpenChat(chatId)
                                        }
                                    },
                                    modifier = Modifier.testTag("find_people_result_${user.userId}")
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val querySnapshot = peopleSearchQuery
                        val firstMatch = peopleSearchResults.firstOrNull()
                        showFindPeopleDialog = false
                        viewModel.clearPeopleSearch()
                        if (firstMatch != null) {
                            viewModel.startDirectChat(firstMatch) { chatId ->
                                onOpenChat(chatId)
                            }
                        } else {
                            viewModel.findAndStartDirectChat(querySnapshot) { chatId ->
                                onOpenChat(chatId)
                            }
                        }
                    },
                    enabled = peopleSearchQuery.isNotBlank() && !isBusy,
                    modifier = Modifier.testTag("find_people_confirm_button")
                ) {
                    Text("Начать чат")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        showFindPeopleDialog = false
                        viewModel.clearPeopleSearch()
                    }
                ) {
                    Text("Отмена")
                }
            }
        )
    }

    activeSettingsSection?.let { section ->
        val mePublic = directoryUsers.firstOrNull { it.userId == currentUserId }
        ProfileSettingsSheet(
            privateProfile = privateProfile,
            publicProfile = mePublic,
            fallbackEmail = userEmail,
            fallbackDisplayName = userDisplayName,
            keyFingerprint = keyFingerprint,
            themeMode = themeMode,
            appearanceConfig = appearanceConfig,
            isBusy = isBusy,
            roleCodes = roleCodes,
            lastGeneratedRoleCode = lastGeneratedRoleCode,
            adminUsersCount = allUsersForAdmin.size,
            isPinEnabled = isPinEnabled,
            isBiometricEnabled = isBiometricEnabled,
            biometricCapability = biometricCapability,
            appLockManager = appLockManager,
            initialSection = section,
            onSwitchSection = { nextSection ->
                activeSettingsSection = nextSection
            },
            onDismiss = {
                viewModel.clearGeneratedRoleCode()
                activeSettingsSection = null
            },
            onSaveProfile = { name, username, avatar ->
                viewModel.updateProfile(name, username, avatar)
            },
            onDeleteUsername = { name, avatar ->
                viewModel.deleteUsername(name, avatar)
            },
            onAvatarError = { msg -> viewModel.showMessage(msg) },
            onRedeemRoleCode = { code, onRedeemed ->
                viewModel.redeemRoleCode(code) { onRedeemed() }
            },
            onGenerateRoleCode = { targetRole ->
                viewModel.generateRoleCode(targetRole)
            },
            onDeleteRoleCode = { codeHash ->
                viewModel.deleteRoleCode(codeHash)
            },
            onCodeCopied = { code ->
                viewModel.showMessage("Код $code скопирован")
            },
            onOpenModerationPanel = {
                activeSettingsSection = null
                showAdminSheet = true
            },
            onSetPin = { newPin ->
                onSetPin(newPin)
                viewModel.showMessage("PIN-код установлен")
            },
            onDisablePin = {
                onDisablePin()
                viewModel.showMessage("Вход по PIN-коду отключён")
            },
            onSetBiometricEnabled = { enabled ->
                onSetBiometricEnabled(enabled)
                viewModel.showMessage(if (enabled) "Вход по биометрии включён" else "Вход по биометрии отключён")
            },
            onLockAppNow = {
                activeSettingsSection = null
                onLockAppNow()
            },
            onShowMessage = { msg -> viewModel.showMessage(msg) },
            onChangeThemeMode = { mode ->
                onChangeThemeMode(mode)
                viewModel.syncThemePreference(mode)
            },
            onSelectVisualTheme = onSelectVisualTheme,
            onSelectWallpaperPreset = onSelectWallpaperPreset,
            onPickCustomWallpaperUri = onPickCustomWallpaperUri,
            onSelectOutgoingBubbleStyle = onSelectOutgoingBubbleStyle,
            onSetShowStories = onSetShowStories,
            onSetShowFolders = onSetShowFolders,
            onResetCustomization = onResetCustomization,
            onSetDiscoverable = { viewModel.setDiscoverable(it) },
            savedAccountsCount = savedAccounts.size.coerceAtLeast(1),
            onOpenAccountSwitcher = { showAccountSwitcherSheet = true },
            onSignOut = {
                viewModel.clearGeneratedRoleCode()
                activeSettingsSection = null
                onSignOutTriggered()
                val appCtx = context.applicationContext
                scope.launch {
                    withContext(Dispatchers.IO) {
                        MessagePushWorker.cancelAll(appCtx)
                    }
                    viewModel.markOfflineNow()
                    signOutUser(credentialManager, scope)
                }
            }
        )
    }

    if (showMessengerEditorSheet) {
        MessengerEditorSheet(
            appearance = appearanceConfig.copy(themeMode = themeMode),
            onSetShowStories = onSetShowStories,
            onSetShowFolders = onSetShowFolders,
            onOpenFullCustomization = {
                activeSettingsSection = ProfileSettingsSection.CUSTOMIZATION
            },
            onDismiss = { showMessengerEditorSheet = false }
        )
    }

    if (showAdminSheet && isDeveloper) {
        AdminModerationSheet(
            users = allUsersForAdmin,
            currentUserId = currentUserId,
            isBusy = isBusy,
            onDismiss = { showAdminSheet = false },
            onModerateUser = { targetUid, status, durationMs, reason ->
                viewModel.moderateUser(targetUid, status, durationMs, reason)
            },
            onDeleteUserAccount = { targetUid, reason ->
                viewModel.deleteUserAccount(targetUid, reason)
            }
        )
    }

    if (showOwnProfileSheet) {
        val mePublic = directoryUsers.firstOrNull { it.userId == currentUserId }
        val resolvedName = privateProfile?.displayName?.ifBlank { null }
            ?: mePublic?.displayName?.ifBlank { null }
            ?: userDisplayName
        val resolvedHandle = privateProfile?.handle?.ifBlank { null }
            ?: mePublic?.handle.orEmpty()
        val resolvedAvatar = privateProfile?.avatarBase64?.ifBlank { null }
            ?: mePublic?.avatarBase64.orEmpty()
        val resolvedFingerprint = privateProfile?.keyFingerprint?.ifBlank { null }
            ?: mePublic?.keyFingerprint?.ifBlank { null }
            ?: keyFingerprint
        UserProfileSheet(
            displayName = resolvedName,
            handle = resolvedHandle,
            avatarBase64 = resolvedAvatar,
            avatarColorIndex = (mePublic?.avatarColorIndex ?: 0L).toInt(),
            keyFingerprint = resolvedFingerprint,
            role = UserRole.fromWire(privateProfile?.role ?: mePublic?.role),
            isSelf = true,
            savedAccountsCount = savedAccounts.size.coerceAtLeast(1),
            onDismiss = { showOwnProfileSheet = false },
            onEditProfile = { activeSettingsSection = ProfileSettingsSection.PROFILE },
            onSwitchAccount = { showAccountSwitcherSheet = true },
            onCopied = { msg -> viewModel.showMessage(msg) }
        )
    }

    if (showAccountSwitcherSheet) {
        val displayAccounts = if (savedAccounts.isNotEmpty()) {
            savedAccounts
        } else {
            val mePublic = directoryUsers.firstOrNull { it.userId == currentUserId }
            listOf(
                SavedAccount(
                    uid = currentUserId,
                    email = userEmail,
                    displayName = privateProfile?.displayName?.ifBlank { null }
                        ?: mePublic?.displayName?.ifBlank { null }
                        ?: userDisplayName,
                    handle = privateProfile?.handle ?: mePublic?.handle.orEmpty(),
                    avatarBase64 = privateProfile?.avatarBase64 ?: mePublic?.avatarBase64.orEmpty(),
                    avatarColorIndex = (mePublic?.avatarColorIndex ?: 0L).toInt(),
                    role = privateProfile?.role ?: mePublic?.role ?: "user",
                    keyFingerprint = privateProfile?.keyFingerprint?.ifBlank { null } ?: keyFingerprint
                )
            )
        }
        AccountSwitcherSheet(
            accounts = displayAccounts,
            currentUserId = currentUserId,
            isSwitching = isSwitchingAccount,
            onDismiss = { showAccountSwitcherSheet = false },
            onSwitchAccount = onSwitchAccount,
            onAddAccount = onAddAccount,
            onRemoveAccount = onRemoveSavedAccount,
            onSignOutCurrent = {
                onSignOutTriggered()
                val appCtx = context.applicationContext
                scope.launch {
                    withContext(Dispatchers.IO) {
                        MessagePushWorker.cancelAll(appCtx)
                    }
                    viewModel.markOfflineNow()
                    signOutUser(credentialManager, scope)
                }
            }
        )
    }

    inspectedPeerWithConvId?.let { (peer, convId) ->
        UserProfileSheet(
            displayName = peer.displayName,
            handle = peer.handle,
            avatarBase64 = peer.avatarBase64,
            avatarColorIndex = peer.avatarColorIndex.toInt(),
            keyFingerprint = peer.keyFingerprint,
            role = UserRole.fromWire(peer.role),
            presenceStatus = peer.presenceStatus(presenceNowMs),
            isSelf = peer.userId == currentUserId,
            onDismiss = { inspectedPeerWithConvId = null },
            onMessageAction = convId?.let { targetConvId ->
                { onOpenChat(targetConvId) }
            },
            onCopied = { msg -> viewModel.showMessage(msg) }
        )
    }

    selectedConvForActions?.let { conv ->
        val peerProfile = if (conv.isSavedMessages(currentUserId)) null else resolveDirectPeer(conv, currentUserId, chatPeersMap)
        val convTitle = if (conv.isSavedMessages(currentUserId)) {
            "Избранное"
        } else {
            peerProfile?.displayName?.ifBlank { null } ?: resolveConversationTitle(conv, currentUserId)
        }
        ModalBottomSheet(onDismissRequest = { selectedConvForActions = null }) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(horizontal = 20.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = convTitle,
                    style = MaterialTheme.typography.titleLarge,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = when {
                        conv.isSavedMessages(currentUserId) -> "Избранное • личное хранилище E2EE"
                        conv.isGroup -> "Группа • участников: ${conv.memberUids.size}"
                        else -> "Личный чат • E2EE"
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(4.dp))
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surfaceContainer,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            selectedConvForActions = null
                            onOpenChat(conv.id)
                        }
                        .testTag("action_open_chat_${conv.id}")
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Chat, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(12.dp))
                        Text("Открыть чат", style = MaterialTheme.typography.titleSmall)
                    }
                }
                if (!conv.isGroup && !conv.isSavedMessages(currentUserId) && peerProfile != null) {
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = MaterialTheme.colorScheme.surfaceContainer,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                selectedConvForActions = null
                                inspectedPeerWithConvId = peerProfile to conv.id
                            }
                            .testTag("action_view_profile_${conv.id}")
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Filled.Person, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(12.dp))
                            Text("Профиль пользователя", style = MaterialTheme.typography.titleSmall)
                        }
                    }
                }
                if (conv.isGroup) {
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = MaterialTheme.colorScheme.surfaceContainer,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                selectedConvForActions = null
                                onOpenGroupSettings(conv.id)
                            }
                            .testTag("action_group_settings_${conv.id}")
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Filled.Settings, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(12.dp))
                            Text("Настройки группы и участники", style = MaterialTheme.typography.titleSmall)
                        }
                    }
                }
                if (conv.isGroup && !conv.isCreator(currentUserId)) {
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.45f),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                selectedConvForActions = null
                                pendingLeaveConv = conv
                            }
                            .testTag("action_leave_group_${conv.id}")
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.AutoMirrored.Filled.ExitToApp, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                            Spacer(modifier = Modifier.width(12.dp))
                            Text("Покинуть группу", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.error)
                        }
                    }
                } else {
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.45f),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                selectedConvForActions = null
                                pendingDeleteConv = conv
                            }
                            .testTag("action_delete_chat_${conv.id}")
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Filled.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = if (conv.isGroup) "Удалить группу" else "Удалить чат",
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.error
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
            }
        }
    }

    pendingDeleteConv?.let { conv ->
        val peerProfile = if (conv.isSavedMessages(currentUserId)) null else resolveDirectPeer(conv, currentUserId, chatPeersMap)
        val convTitle = if (conv.isSavedMessages(currentUserId)) {
            "Избранное"
        } else {
            peerProfile?.displayName?.ifBlank { null } ?: resolveConversationTitle(conv, currentUserId)
        }
        ConfirmDeleteChatDialog(
            conversation = conv,
            currentUserId = currentUserId,
            resolvedTitle = convTitle,
            onDismiss = { pendingDeleteConv = null },
            onConfirm = {
                pendingDeleteConv = null
                viewModel.deleteConversation(conv)
            }
        )
    }

    pendingLeaveConv?.let { conv ->
        ConfirmLeaveGroupDialog(
            groupTitle = resolveConversationTitle(conv, currentUserId),
            onDismiss = { pendingLeaveConv = null },
            onConfirm = {
                pendingLeaveConv = null
                viewModel.leaveGroup(conv)
            }
        )
    }
}

@Composable
private fun QuickContactsRibbon(
    peers: List<PublicUserProfile>,
    presenceNowMs: Long,
    enabled: Boolean,
    onOpenSaved: () -> Unit,
    onSelectPeer: (PublicUserProfile) -> Unit,
    onEditMessenger: () -> Unit = {}
) {
    val storyRingBrush = Brush.linearGradient(
        listOf(
            MaterialTheme.colorScheme.primary,
            MaterialTheme.colorScheme.secondary,
            MaterialTheme.colorScheme.tertiary
        )
    )
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("quick_contacts_ribbon")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 2.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Истории",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = "Изменить",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .clickable(onClick = onEditMessenger)
                    .padding(horizontal = 6.dp, vertical = 2.dp)
                    .testTag("stories_ribbon_edit_action")
            )
        }
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(horizontal = 2.dp, vertical = 4.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            item(key = "quick_saved") {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .width(64.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .clickable(enabled = enabled, onClick = onOpenSaved)
                        .padding(vertical = 4.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(52.dp)
                            .clip(CircleShape)
                            .border(2.dp, storyRingBrush, CircleShape)
                            .padding(3.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        SavedMessagesAvatar(size = 44.dp)
                    }
                    Spacer(modifier = Modifier.height(5.dp))
                    Text(
                        text = "Заметки",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
            items(peers, key = { "quick_${it.userId}" }) { person ->
                val firstName = person.displayName.trim().substringBefore(' ').ifBlank { person.displayName }
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .width(64.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .clickable(enabled = enabled) { onSelectPeer(person) }
                        .padding(vertical = 4.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(52.dp)
                            .clip(CircleShape)
                            .border(2.dp, storyRingBrush, CircleShape)
                            .padding(3.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        UserAvatar(
                            name = person.displayName,
                            avatarBase64 = person.avatarBase64,
                            colorIndex = person.avatarColorIndex.toInt(),
                            size = 44.dp,
                            presenceStatus = person.presenceStatus(presenceNowMs)
                        )
                    }
                    Spacer(modifier = Modifier.height(5.dp))
                    Text(
                        text = firstName,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

@Composable
private fun SavedMessagesShortcutCard(
    enabled: Boolean,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(22.dp),
        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.28f),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.42f)),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(enabled = enabled, onClick = onClick)
            .testTag("saved_messages_shortcut_card")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 13.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            SavedMessagesAvatar(size = 54.dp)
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "Избранное",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.16f)
                    ) {
                        Text(
                            text = "ЗАМЕТКИ",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Личное зашифрованное хранилище и заметки • E2EE",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ConversationCard(
    conversation: Conversation,
    currentUserId: String,
    peerProfile: PublicUserProfile?,
    groupOnlineCount: Int = 0,
    presenceNowMs: Long = System.currentTimeMillis(),
    onClick: () -> Unit,
    onLongClick: () -> Unit = {},
    onMoreClick: () -> Unit = {}
) {
    val isSavedChat = conversation.isSavedMessages(currentUserId)
    val displayTitle = if (isSavedChat) {
        "Избранное"
    } else {
        peerProfile?.displayName?.ifBlank { null }
            ?: resolveConversationTitle(conversation, currentUserId)
    }

    val peerUid = conversation.memberUids.firstOrNull { it != currentUserId } ?: currentUserId
    val isSelfChat = isSavedChat || (!conversation.isGroup && peerUid == currentUserId)
    val peerPresence = if (!conversation.isGroup && !isSelfChat) {
        peerProfile?.presenceStatus(presenceNowMs) ?: UserPresenceStatus.OFFLINE
    } else {
        null
    }

    val previewTextLower = conversation.lastMessagePreview.lowercase()
    val subtitle = when (conversation.lastMessageType) {
        "voice" -> "Голосовое сообщение"
        "image" -> "Фотография"
        "file" -> when {
            previewTextLower.startsWith("видео") -> conversation.lastMessagePreview
            previewTextLower.startsWith("музыка") || previewTextLower.startsWith("аудио") -> conversation.lastMessagePreview
            else -> conversation.lastMessagePreview.ifBlank { "Зашифрованный файл" }
        }
        "call_event" -> conversation.lastMessagePreview.ifBlank { "Звонок" }
        "text" -> conversation.lastMessagePreview.ifBlank { "Зашифрованное сообщение" }
        else -> when {
            isSavedChat -> "Личное хранилище и пересланное • E2EE"
            conversation.isGroup && groupOnlineCount > 0 -> "${conversation.memberUids.size} уч. • $groupOnlineCount в сети"
            conversation.isGroup -> "Группа • ${conversation.memberUids.size} уч."
            peerPresence != null -> peerPresence.labelRu
            else -> "Чат защищён E2EE"
        }
    }

    val previewIcon = when {
        conversation.lastMessageType == "voice" -> Icons.Filled.Mic
        conversation.lastMessageType == "image" -> Icons.Filled.Image
        conversation.lastMessageType == "file" && previewTextLower.startsWith("видео") -> Icons.Filled.VideoFile
        conversation.lastMessageType == "file" && (previewTextLower.startsWith("музыка") || previewTextLower.startsWith("аудио")) -> Icons.Filled.MusicNote
        conversation.lastMessageType == "file" -> Icons.Filled.AttachFile
        conversation.lastMessageType == "call_event" -> Icons.Filled.Call
        else -> Icons.Filled.Lock
    }

    val unreadCount = conversation.unreadCountFor(currentUserId)
    val showReadReceipt = !isSelfChat &&
        conversation.lastMessageSenderId == currentUserId &&
        conversation.lastMessageType != "none"
    val isLastMsgRead = conversation.isLastMessageReadByOther(currentUserId)

    val cardColor = when {
        unreadCount > 0 -> MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.96f)
        isSavedChat -> MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.24f)
        else -> MaterialTheme.colorScheme.surfaceContainerLow.copy(alpha = 0.90f)
    }
    val cardBorder = when {
        unreadCount > 0 -> MaterialTheme.colorScheme.primary.copy(alpha = 0.58f)
        isSavedChat -> MaterialTheme.colorScheme.primary.copy(alpha = 0.36f)
        else -> MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.65f)
    }

    Surface(
        shape = RoundedCornerShape(22.dp),
        color = cardColor,
        tonalElevation = if (unreadCount > 0) 4.dp else 1.dp,
        border = BorderStroke(1.dp, cardBorder),
        modifier = Modifier
            .fillMaxWidth()
            .combinedClickable(
                onClick = onClick,
                onLongClick = onLongClick
            )
            .testTag("conversation_card_${conversation.id}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 14.dp, end = 6.dp, top = 12.dp, bottom = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (isSavedChat) {
                SavedMessagesAvatar(size = 54.dp)
            } else {
                UserAvatar(
                    name = displayTitle,
                    avatarBase64 = if (conversation.isGroup) "" else peerProfile?.avatarBase64.orEmpty(),
                    colorIndex = peerProfile?.avatarColorIndex?.toInt() ?: kotlin.math.abs(displayTitle.hashCode()),
                    isGroup = conversation.isGroup,
                    size = 54.dp,
                    presenceStatus = peerPresence
                )
            }
            Spacer(modifier = Modifier.width(13.dp))
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        if (conversation.isGroup) {
                            Icon(
                                imageVector = Icons.Filled.Groups,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.tertiary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(5.dp))
                        }
                        Text(
                            text = displayTitle,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = if (unreadCount > 0 || isSavedChat) FontWeight.Bold else FontWeight.SemiBold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f, fill = false)
                        )
                        if (isSavedChat) {
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(
                                shape = RoundedCornerShape(7.dp),
                                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.16f)
                            ) {
                                Text(
                                    text = "ЗАМЕТКИ",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                        if (!conversation.isGroup && !isSavedChat && peerProfile != null) {
                            val peerRole = UserRole.fromWire(peerProfile.role)
                            if (peerRole != UserRole.USER) {
                                Spacer(modifier = Modifier.width(6.dp))
                                RoleBadge(role = peerRole, compact = true)
                            }
                        }
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        modifier = Modifier.padding(end = 6.dp)
                    ) {
                        if (showReadReceipt) {
                            ReadReceiptIcon(
                                isRead = isLastMsgRead,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Text(
                            text = formatChatListTimestamp(conversation.updatedAt ?: conversation.createdAt),
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = if (unreadCount > 0) FontWeight.Bold else FontWeight.Medium,
                            color = if (unreadCount > 0) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Spacer(modifier = Modifier.height(5.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.11f),
                            modifier = Modifier.size(20.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = previewIcon,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(12.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(7.dp))
                        Text(
                            text = subtitle,
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = if (unreadCount > 0) FontWeight.SemiBold else FontWeight.Normal,
                            color = if (unreadCount > 0) MaterialTheme.colorScheme.onSurface
                            else MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        if (conversation.activeCallId.isNotBlank()) {
                            Surface(
                                shape = RoundedCornerShape(50),
                                color = MaterialTheme.colorScheme.secondaryContainer
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        Icons.Filled.Call,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.secondary,
                                        modifier = Modifier.size(12.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        "Звонок",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSecondaryContainer
                                    )
                                }
                            }
                        }
                        if (unreadCount > 0) {
                            UnreadCountBadge(count = unreadCount)
                        }
                        IconButton(
                            onClick = onMoreClick,
                            modifier = Modifier
                                .size(48.dp)
                                .testTag("conversation_more_button_${conversation.id}")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.MoreVert,
                                contentDescription = "Действия с чатом",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DirectoryPersonCard(
    person: PublicUserProfile,
    matchedByEmail: Boolean,
    hasExistingChat: Boolean = false,
    presenceNowMs: Long = System.currentTimeMillis(),
    enabled: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val presence = person.presenceStatus(presenceNowMs)
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surfaceContainerLow.copy(alpha = 0.92f),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.65f)),
        modifier = modifier
            .fillMaxWidth()
            .defaultMinSize(minHeight = 48.dp)
            .clickable(enabled = enabled, onClick = onClick)
            .testTag("directory_person_card_${person.userId}")
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            UserAvatar(
                name = person.displayName,
                avatarBase64 = person.avatarBase64,
                colorIndex = person.avatarColorIndex.toInt(),
                size = 50.dp,
                presenceStatus = presence
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = person.displayName,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    val personRole = UserRole.fromWire(person.role)
                    if (personRole != UserRole.USER) {
                        RoleBadge(role = personRole, compact = true)
                    }
                }
                UserPresenceIndicator(
                    status = presence,
                    compact = true,
                    modifier = Modifier.padding(vertical = 2.dp)
                )
                val meta = buildString {
                    if (person.handle.isNotBlank()) {
                        append(person.handle)
                        append(" • ")
                    }
                    if (matchedByEmail) {
                        append("найден по email • ")
                    }
                    append("E2EE ${person.keyFingerprint.take(9)}")
                }
                Text(
                    text = meta,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Surface(
                shape = RoundedCornerShape(50),
                color = if (hasExistingChat) {
                    MaterialTheme.colorScheme.secondaryContainer
                } else {
                    MaterialTheme.colorScheme.primaryContainer
                },
                border = BorderStroke(
                    1.dp,
                    if (hasExistingChat) MaterialTheme.colorScheme.secondary.copy(alpha = 0.35f)
                    else MaterialTheme.colorScheme.primary.copy(alpha = 0.35f)
                )
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    Icon(
                        imageVector = if (hasExistingChat) {
                            Icons.AutoMirrored.Filled.Chat
                        } else {
                            Icons.AutoMirrored.Filled.Send
                        },
                        contentDescription = if (hasExistingChat) "Открыть личный чат" else "Написать в личные сообщения",
                        tint = if (hasExistingChat) {
                            MaterialTheme.colorScheme.onSecondaryContainer
                        } else {
                            MaterialTheme.colorScheme.primary
                        },
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        text = if (hasExistingChat) "Открыть" else "Написать",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = if (hasExistingChat) {
                            MaterialTheme.colorScheme.onSecondaryContainer
                        } else {
                            MaterialTheme.colorScheme.onPrimaryContainer
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun EmptySearchResultState(
    query: String,
    onOpenFindPeople: () -> Unit,
    onClearSearch: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Surface(
            shape = CircleShape,
            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.38f),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.35f)),
            modifier = Modifier.size(80.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    imageVector = Icons.Filled.PersonSearch,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(38.dp)
                )
            }
        }
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "Ничего не найдено",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = "По запросу «$query» нет совпадений среди чатов и открытых профилей.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(18.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(onClick = onOpenFindPeople, shape = RoundedCornerShape(16.dp)) {
                Icon(Icons.Filled.PersonSearch, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Расширенный поиск")
            }
            OutlinedButton(onClick = onClearSearch, shape = RoundedCornerShape(16.dp)) {
                Text("Сбросить")
            }
        }
    }
}

@Composable
private fun EmptyChatsState(
    isGroupsTab: Boolean = false,
    isPeopleTab: Boolean = false,
    onNewChat: () -> Unit,
    onNewGroup: () -> Unit,
    onFindPeople: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(contentAlignment = Alignment.Center) {
            Surface(
                shape = CircleShape,
                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.10f),
                modifier = Modifier.size(104.dp)
            ) {}
            Surface(
                shape = RoundedCornerShape(28.dp),
                color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.65f),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.45f)),
                modifier = Modifier.size(76.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = when {
                            isGroupsTab -> Icons.Filled.Groups
                            isPeopleTab -> Icons.Filled.PersonSearch
                            else -> Icons.AutoMirrored.Filled.Chat
                        },
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(36.dp)
                    )
                }
            }
        }
        Spacer(modifier = Modifier.height(18.dp))
        Text(
            text = when {
                isGroupsTab -> "Пока нет групповых чатов"
                isPeopleTab -> "В каталоге пока никого нет"
                else -> "Пока нет личных чатов"
            },
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = when {
                isGroupsTab -> "Создайте защищённую группу с несколькими участниками. Переписка и файлы шифруются на устройстве."
                isPeopleTab -> "Вы можете найти собеседника вручную по точному email или @юзернейму, если он открыт для поиска."
                else -> "Найдите человека по имени, @юзернейму или email, нажмите на него и сразу начните личную переписку."
            },
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(22.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            when {
                isGroupsTab -> {
                    Button(
                        onClick = onNewGroup,
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.height(48.dp)
                    ) {
                        Icon(Icons.Filled.GroupAdd, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Создать группу")
                    }
                }
                isPeopleTab -> {
                    Button(
                        onClick = onFindPeople,
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.height(48.dp)
                    ) {
                        Icon(Icons.Filled.PersonSearch, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Найти человека")
                    }
                }
                else -> {
                    Button(
                        onClick = onNewChat,
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.height(48.dp)
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Chat, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Написать в ЛС")
                    }
                    OutlinedButton(
                        onClick = onNewGroup,
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.height(48.dp)
                    ) {
                        Icon(Icons.Filled.GroupAdd, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Группа")
                    }
                }
            }
        }
        if (!isPeopleTab) {
            Spacer(modifier = Modifier.height(10.dp))
            TextButton(onClick = onFindPeople) {
                Icon(Icons.Filled.PersonSearch, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Найти по имени, @юзернейму или email")
            }
        }
    }
}

fun resolveDirectPeer(
    conversation: Conversation,
    currentUserId: String,
    usersById: Map<String, PublicUserProfile>
): PublicUserProfile? {
    if (conversation.isGroup || conversation.isSavedMessages(currentUserId)) return null
    val peerUid = conversation.memberUids.firstOrNull { it != currentUserId } ?: return null
    return usersById[peerUid]
}

fun resolveConversationTitle(conversation: Conversation, currentUserId: String): String {
    if (conversation.isSavedMessages(currentUserId)) return "Избранное"
    if (conversation.isGroup) return conversation.title
    val otherName = conversation.memberNames
        .entries
        .firstOrNull { it.key != currentUserId }
        ?.value
    return otherName ?: conversation.title.ifBlank { "Избранное" }
}

fun formatChatTime(timestamp: Timestamp?): String {
    if (timestamp == null) return ""
    val fmt = SimpleDateFormat("HH:mm", Locale.getDefault())
    return fmt.format(timestamp.toDate())
}

fun formatChatListTimestamp(timestamp: Timestamp?): String {
    if (timestamp == null) return ""
    val date = timestamp.toDate()
    val msgCal = Calendar.getInstance().apply { time = date }
    val nowCal = Calendar.getInstance()
    val isSameDay = msgCal.get(Calendar.YEAR) == nowCal.get(Calendar.YEAR) &&
        msgCal.get(Calendar.DAY_OF_YEAR) == nowCal.get(Calendar.DAY_OF_YEAR)
    if (isSameDay) {
        return SimpleDateFormat("HH:mm", Locale.getDefault()).format(date)
    }
    nowCal.add(Calendar.DAY_OF_YEAR, -1)
    val isYesterday = msgCal.get(Calendar.YEAR) == nowCal.get(Calendar.YEAR) &&
        msgCal.get(Calendar.DAY_OF_YEAR) == nowCal.get(Calendar.DAY_OF_YEAR)
    if (isYesterday) {
        return "Вчера"
    }
    return SimpleDateFormat("dd.MM", Locale.getDefault()).format(date)
}
