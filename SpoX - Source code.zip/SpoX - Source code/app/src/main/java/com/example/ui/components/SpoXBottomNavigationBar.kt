package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.automirrored.outlined.Chat
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.Call
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarDefaults
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.ui.theme.LocalChatAppearance
import com.example.ui.theme.isLiquidGlassActive
import com.example.ui.theme.liquidGlassEdgeScrim
import com.example.ui.theme.liquidGlassSurface

enum class MainBottomTab(
    val label: String,
    val testTagName: String
) {
    CALLS(label = "Звонки", testTagName = "bottom_tab_calls"),
    CHATS(label = "Чаты", testTagName = "bottom_tab_chats"),
    SETTINGS(label = "Настройки", testTagName = "bottom_tab_settings")
}

private fun MainBottomTab.iconFor(selected: Boolean): ImageVector = when (this) {
    MainBottomTab.CALLS -> if (selected) Icons.Filled.Call else Icons.Outlined.Call
    MainBottomTab.CHATS -> if (selected) Icons.AutoMirrored.Filled.Chat else Icons.AutoMirrored.Outlined.Chat
    MainBottomTab.SETTINGS -> if (selected) Icons.Filled.Settings else Icons.Outlined.Settings
}

@Composable
fun SpoXBottomNavigationBar(
    selectedTab: MainBottomTab,
    onSelectTab: (MainBottomTab) -> Unit,
    activeCallsCount: Int = 0,
    unreadChatsCount: Int = 0,
    hasAvailableUpdate: Boolean = false,
    modifier: Modifier = Modifier
) {
    val isResourceSaving = LocalChatAppearance.current.resourceSavingMode
    val isGlass = isLiquidGlassActive()

    if (isGlass) {
        Box(
            contentAlignment = Alignment.BottomCenter,
            modifier = modifier
                .fillMaxWidth()
                .liquidGlassEdgeScrim(
                    isTop = false,
                    scrimColor = MaterialTheme.colorScheme.background
                )
                .navigationBarsPadding()
                .padding(horizontal = 16.dp, vertical = 10.dp)
                .testTag("bottom_nav_bar")
        ) {
            val dockShape = RoundedCornerShape(28.dp)
            Surface(
                shape = dockShape,
                color = Color.Transparent,
                border = null,
                modifier = Modifier
                    .widthIn(max = 520.dp)
                    .fillMaxWidth()
                    .liquidGlassSurface(
                        shape = dockShape,
                        tintColor = MaterialTheme.colorScheme.surfaceContainerHigh
                    )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 6.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    MainBottomTab.entries.forEach { tab ->
                        val isSelected = tab == selectedTab
                        val itemShape = RoundedCornerShape(22.dp)
                        val targetFg = if (isSelected) {
                            MaterialTheme.colorScheme.primary
                        } else {
                            MaterialTheme.colorScheme.onSurfaceVariant
                        }
                        val fgColor = if (isResourceSaving) {
                            targetFg
                        } else {
                            animateColorAsState(
                                targetValue = targetFg,
                                animationSpec = tween(200),
                                label = "glass_tab_fg_${tab.name}"
                            ).value
                        }
                        val badgeCount = when (tab) {
                            MainBottomTab.CALLS -> activeCallsCount
                            MainBottomTab.CHATS -> unreadChatsCount
                            MainBottomTab.SETTINGS -> 0
                        }
                        val showDot = tab == MainBottomTab.SETTINGS && hasAvailableUpdate

                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .weight(1f)
                                .defaultMinSize(minHeight = 54.dp)
                                .clip(itemShape)
                                .then(
                                    if (isSelected) {
                                        Modifier.liquidGlassSurface(
                                            shape = itemShape,
                                            tintColor = MaterialTheme.colorScheme.primaryContainer,
                                            accentGlow = MaterialTheme.colorScheme.primary,
                                            isHighlighted = true
                                        )
                                    } else {
                                        Modifier
                                    }
                                )
                                .clickable(
                                    role = Role.Tab,
                                    onClick = { onSelectTab(tab) }
                                )
                                .semantics { this.selected = isSelected }
                                .padding(vertical = 6.dp, horizontal = 8.dp)
                                .testTag(tab.testTagName)
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                BottomTabBadgeIcon(
                                    icon = tab.iconFor(isSelected),
                                    contentDescription = tab.label,
                                    tint = fgColor,
                                    badgeCount = badgeCount,
                                    showDot = showDot
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = tab.label,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    color = fgColor,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }
        }
    } else {
        Surface(
            color = MaterialTheme.colorScheme.surfaceContainer,
            tonalElevation = if (isResourceSaving) 0.dp else 4.dp,
            shadowElevation = if (isResourceSaving) 0.dp else 6.dp,
            modifier = modifier
                .fillMaxWidth()
                .testTag("bottom_nav_bar")
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                HorizontalDivider(
                    color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.45f)
                )
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    NavigationBar(
                        containerColor = Color.Transparent,
                        tonalElevation = 0.dp,
                        windowInsets = NavigationBarDefaults.windowInsets,
                        modifier = Modifier.widthIn(max = 600.dp)
                    ) {
                        MainBottomTab.entries.forEach { tab ->
                            val isSelected = tab == selectedTab
                            val badgeCount = when (tab) {
                                MainBottomTab.CALLS -> activeCallsCount
                                MainBottomTab.CHATS -> unreadChatsCount
                                MainBottomTab.SETTINGS -> 0
                            }
                            val showDot = tab == MainBottomTab.SETTINGS && hasAvailableUpdate
                            NavigationBarItem(
                                selected = isSelected,
                                onClick = { onSelectTab(tab) },
                                alwaysShowLabel = true,
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = MaterialTheme.colorScheme.primary,
                                    selectedTextColor = MaterialTheme.colorScheme.primary,
                                    indicatorColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.85f),
                                    unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                    unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                                ),
                                icon = {
                                    BottomTabBadgeIcon(
                                        icon = tab.iconFor(isSelected),
                                        contentDescription = tab.label,
                                        tint = if (isSelected) {
                                            MaterialTheme.colorScheme.primary
                                        } else {
                                            MaterialTheme.colorScheme.onSurfaceVariant
                                        },
                                        badgeCount = badgeCount,
                                        showDot = showDot
                                    )
                                },
                                label = {
                                    Text(
                                        text = tab.label,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                },
                                modifier = Modifier.testTag(tab.testTagName)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun BottomTabBadgeIcon(
    icon: ImageVector,
    contentDescription: String,
    tint: Color,
    badgeCount: Int,
    showDot: Boolean
) {
    when {
        badgeCount > 0 -> {
            BadgedBox(
                badge = {
                    Badge(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    ) {
                        Text(
                            text = if (badgeCount > 99) "99+" else badgeCount.toString(),
                            maxLines = 1
                        )
                    }
                }
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = contentDescription,
                    tint = tint,
                    modifier = Modifier.size(22.dp)
                )
            }
        }

        showDot -> {
            Box(contentAlignment = Alignment.TopEnd) {
                Icon(
                    imageVector = icon,
                    contentDescription = contentDescription,
                    tint = tint,
                    modifier = Modifier.size(22.dp)
                )
                Box(
                    modifier = Modifier
                        .offset(x = 3.dp, y = (-2).dp)
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primary)
                )
            }
        }

        else -> {
            Icon(
                imageVector = icon,
                contentDescription = contentDescription,
                tint = tint,
                modifier = Modifier.size(22.dp)
            )
        }
    }
}
