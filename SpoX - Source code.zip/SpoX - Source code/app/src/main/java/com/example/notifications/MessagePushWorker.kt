package com.example.notifications

import android.content.Context
import android.util.Log
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.example.R
import com.example.crypto.CryptoManager
import com.example.data.model.CallSession
import com.example.data.model.Conversation
import com.example.data.model.PublicUserProfile
import com.example.data.repository.ChatRepository
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await
import java.util.concurrent.TimeUnit
import kotlin.math.abs

class MessagePushWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        val session = com.example.data.repository.FirebaseSessionManager.ensureInitialized(applicationContext)
        val activeAuth = session?.auth ?: Firebase.auth
        val uid = runCatching { activeAuth.currentUser?.uid }.getOrNull()
            ?: return Result.success()
        if (!SpoXNotificationHelper.hasNotificationPermission(applicationContext)) {
            return Result.success()
        }

        val checkMessages = NotificationPreferences.isMessagePushEnabled(applicationContext)
        val checkCalls = NotificationPreferences.isCallPushEnabled(applicationContext)
        if (!checkMessages && !checkCalls) {
            return Result.success()
        }

        return runCatching {
            val db = com.example.data.repository.FirebaseSessionManager.getActiveFirestore(applicationContext)
                ?: FirebaseFirestore.getInstance(applicationContext.getString(R.string.firestore_database_id))
            val crypto = CryptoManager(applicationContext, accountScope = uid)
            val chatRepository = ChatRepository(db = db, crypto = crypto, auth = activeAuth)
            val profileCache = mutableMapOf<String, PublicUserProfile?>()

            if (checkMessages) {
                val convSnapshot = db.collection("conversations")
                    .whereArrayContains("memberUids", uid)
                    .get()
                    .await()

                val conversations = convSnapshot.toObjects(Conversation::class.java)
                conversations.forEach { conv ->
                    val unread = conv.unreadCountFor(uid)
                    if (unread <= 0) return@forEach
                    if (conv.lastMessageSenderId.isBlank() || conv.lastMessageSenderId == uid) return@forEach
                    if (ActiveChatTracker.isActivelyViewingChat(conv.id)) return@forEach

                    val msgTimeMs = (conv.updatedAt ?: conv.createdAt)?.toDate()?.time ?: 0L
                    val lastNotifiedMs = NotificationPreferences.getLastNotifiedMs(
                        context = applicationContext,
                        uid = uid,
                        chatId = conv.id
                    )

                    if (msgTimeMs > lastNotifiedMs) {
                        val senderId = conv.lastMessageSenderId
                        val senderProfile = profileCache.getOrPut(senderId) {
                            runCatching { chatRepository.getPublicProfile(senderId) }.getOrNull()
                        }
                        val peerUid = conv.memberUids.firstOrNull { it != uid }
                        val peerName = peerUid?.let { conv.memberNames[it] }.orEmpty()
                        val chatTitle = if (conv.isGroup) {
                            conv.title.ifBlank { "Групповой чат" }
                        } else {
                            (if (peerUid == senderId) senderProfile?.displayName else null)
                                ?.ifBlank { null }
                                ?: peerName.ifBlank { conv.title.ifBlank { "SpoX" } }
                        }
                        val senderName = senderProfile?.displayName?.ifBlank { null }
                            ?: conv.memberNames[senderId]?.ifBlank { null }
                            ?: chatTitle
                        val fallbackBody = when (conv.lastMessageType) {
                            "voice" -> "Голосовое сообщение"
                            "image" -> "Зашифрованное фото"
                            "file" -> "Зашифрованный файл"
                            "call_event" -> conv.lastMessagePreview.ifBlank { "Событие звонка" }
                            else -> conv.lastMessagePreview.ifBlank { "Новое зашифрованное сообщение" }
                        }
                        val body = runCatching {
                            chatRepository.resolveLatestIncomingMessagePreview(
                                conversation = conv,
                                currentUserId = uid,
                                expectedSenderId = senderId
                            )
                        }.getOrNull()?.takeIf { it.isNotBlank() } ?: fallbackBody

                        NotificationPreferences.markChatNotified(
                            context = applicationContext,
                            uid = uid,
                            chatId = conv.id,
                            messageTimeMs = msgTimeMs
                        )
                        SpoXNotificationHelper.showMessageNotification(
                            context = applicationContext,
                            chatId = conv.id,
                            chatTitle = chatTitle,
                            body = body,
                            unreadCount = unread,
                            senderName = senderName,
                            senderRole = senderProfile?.role.orEmpty().ifBlank { "user" },
                            customRoleName = senderProfile?.customRoleName.orEmpty(),
                            customRoleBadge = senderProfile?.customRoleBadge.orEmpty(),
                            senderAvatarBase64 = senderProfile?.avatarBase64.orEmpty(),
                            senderAvatarColorIndex = senderProfile?.avatarColorIndex?.toInt()
                                ?: abs(senderName.hashCode()),
                            isGroup = conv.isGroup,
                            timestampMs = msgTimeMs
                        )
                    }
                }
            }

            if (checkCalls) {
                val callsSnapshot = db.collection("calls")
                    .whereArrayContains("memberUids", uid)
                    .get()
                    .await()
                val calls = callsSnapshot.toObjects(CallSession::class.java)
                calls.forEach { call ->
                    val isIncomingRinging = call.status == "ringing" &&
                        call.callerId != uid &&
                        uid !in call.activeParticipantUids
                    if (isIncomingRinging && !ActiveChatTracker.isAppInForeground) {
                        val callerProfile = if (call.callerId.isNotBlank()) {
                            profileCache.getOrPut(call.callerId) {
                                runCatching { chatRepository.getPublicProfile(call.callerId) }.getOrNull()
                            }
                        } else {
                            null
                        }
                        SpoXNotificationHelper.showIncomingCallNotification(
                            context = applicationContext,
                            callId = call.id,
                            callerName = callerProfile?.displayName?.ifBlank { null } ?: call.callerName,
                            conversationTitle = call.conversationTitle,
                            isGroupCall = call.isGroupCall,
                            callType = call.callType,
                            callerRole = callerProfile?.role.orEmpty().ifBlank { "user" },
                            customRoleName = callerProfile?.customRoleName.orEmpty(),
                            customRoleBadge = callerProfile?.customRoleBadge.orEmpty(),
                            callerAvatarBase64 = callerProfile?.avatarBase64.orEmpty(),
                            callerAvatarColorIndex = callerProfile?.avatarColorIndex?.toInt()
                                ?: abs(call.callerName.hashCode())
                        )
                    }
                }
            }

            Result.success()
        }.getOrElse { error ->
            Log.w(TAG, "Background message push sync failed: ${error.message}")
            Result.retry()
        }
    }

    companion object {
        private const val TAG = "MessagePushWorker"
        private const val PERIODIC_WORK_NAME = "spox_message_push_periodic"
        private const val IMMEDIATE_WORK_NAME = "spox_message_push_immediate"

        fun schedulePeriodicSync(context: Context) {
            val constraints = Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .build()

            val request = PeriodicWorkRequestBuilder<MessagePushWorker>(15, TimeUnit.MINUTES)
                .setConstraints(constraints)
                .build()

            runCatching {
                WorkManager.getInstance(context.applicationContext).enqueueUniquePeriodicWork(
                    PERIODIC_WORK_NAME,
                    ExistingPeriodicWorkPolicy.KEEP,
                    request
                )
            }
        }

        fun triggerBackgroundCheck(context: Context, delaySeconds: Long = 8L) {
            val constraints = Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .build()

            val request = OneTimeWorkRequestBuilder<MessagePushWorker>()
                .setInitialDelay(delaySeconds, TimeUnit.SECONDS)
                .setConstraints(constraints)
                .build()

            runCatching {
                WorkManager.getInstance(context.applicationContext).enqueueUniqueWork(
                    IMMEDIATE_WORK_NAME,
                    ExistingWorkPolicy.REPLACE,
                    request
                )
            }
        }

        fun cancelAll(context: Context) {
            runCatching {
                WorkManager.getInstance(context.applicationContext).cancelUniqueWork(PERIODIC_WORK_NAME)
                WorkManager.getInstance(context.applicationContext).cancelUniqueWork(IMMEDIATE_WORK_NAME)
            }
        }
    }
}
