package com.example.ui.components

import android.content.ComponentCallbacks2
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import android.util.LruCache
import androidx.annotation.DrawableRes
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Thread-safe in-memory LRU cache and background downsampling decoder for avatars,
 * inline image attachments, fullscreen previews, and custom chat wallpapers.
 * Prevents synchronous Main-thread BitmapFactory decoding during scroll and swipe gestures.
 */
object BitmapMemoryCache {

    private const val MAX_AVATAR_CACHE_ENTRIES = 64
    private const val MAX_MEDIA_CACHE_ENTRIES = 48
    private const val MAX_WALLPAPER_CACHE_ENTRIES = 4
    private const val MAX_DRAWABLE_CACHE_ENTRIES = 8
    private const val MAX_ARTWORK_CACHE_ENTRIES = 8

    private const val LOW_AVATAR_CACHE_ENTRIES = 16
    private const val LOW_MEDIA_CACHE_ENTRIES = 8
    private const val LOW_WALLPAPER_CACHE_ENTRIES = 1
    private const val LOW_DRAWABLE_CACHE_ENTRIES = 2
    private const val LOW_ARTWORK_CACHE_ENTRIES = 2

    @Volatile
    var isResourceSavingMode: Boolean = false
        private set

    private val avatarCache = object : LruCache<String, ImageBitmap>(MAX_AVATAR_CACHE_ENTRIES) {}
    private val mediaThumbCache = object : LruCache<String, ImageBitmap>(MAX_MEDIA_CACHE_ENTRIES) {}
    private val wallpaperCache = object : LruCache<String, ImageBitmap>(MAX_WALLPAPER_CACHE_ENTRIES) {}
    private val drawableCache = object : LruCache<String, ImageBitmap>(MAX_DRAWABLE_CACHE_ENTRIES) {}
    private val artworkCache = object : LruCache<String, ImageBitmap>(MAX_ARTWORK_CACHE_ENTRIES) {}

    fun setResourceSavingMode(enabled: Boolean) {
        val prev = isResourceSavingMode
        isResourceSavingMode = enabled
        if (enabled) {
            avatarCache.resize(LOW_AVATAR_CACHE_ENTRIES)
            mediaThumbCache.resize(LOW_MEDIA_CACHE_ENTRIES)
            wallpaperCache.resize(LOW_WALLPAPER_CACHE_ENTRIES)
            drawableCache.resize(LOW_DRAWABLE_CACHE_ENTRIES)
            artworkCache.resize(LOW_ARTWORK_CACHE_ENTRIES)
            if (!prev) {
                // Evict heavy higher-resolution cached bitmaps so RAM is freed immediately
                mediaThumbCache.evictAll()
                wallpaperCache.evictAll()
                drawableCache.evictAll()
                artworkCache.evictAll()
            }
        } else {
            avatarCache.resize(MAX_AVATAR_CACHE_ENTRIES)
            mediaThumbCache.resize(MAX_MEDIA_CACHE_ENTRIES)
            wallpaperCache.resize(MAX_WALLPAPER_CACHE_ENTRIES)
            drawableCache.resize(MAX_DRAWABLE_CACHE_ENTRIES)
            artworkCache.resize(MAX_ARTWORK_CACHE_ENTRIES)
        }
    }

    fun clearAllCaches() {
        avatarCache.evictAll()
        mediaThumbCache.evictAll()
        wallpaperCache.evictAll()
        drawableCache.evictAll()
        artworkCache.evictAll()
    }

    fun cachedEntryCount(): Int =
        avatarCache.size() + mediaThumbCache.size() + wallpaperCache.size() + drawableCache.size() + artworkCache.size()

    @Suppress("DEPRECATION")
    fun trimOnMemoryPressure(level: Int) {
        when {
            level >= ComponentCallbacks2.TRIM_MEMORY_RUNNING_CRITICAL ||
                level >= ComponentCallbacks2.TRIM_MEMORY_COMPLETE -> {
                clearAllCaches()
            }
            level >= ComponentCallbacks2.TRIM_MEMORY_MODERATE ||
                level >= ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW -> {
                mediaThumbCache.trimToSize(4)
                avatarCache.trimToSize(8)
                wallpaperCache.evictAll()
                drawableCache.evictAll()
                artworkCache.evictAll()
            }
            level >= ComponentCallbacks2.TRIM_MEMORY_BACKGROUND ||
                level >= ComponentCallbacks2.TRIM_MEMORY_UI_HIDDEN -> {
                mediaThumbCache.trimToSize(if (isResourceSavingMode) 4 else 16)
                wallpaperCache.evictAll()
                artworkCache.trimToSize(if (isResourceSavingMode) 1 else 4)
            }
        }
    }

    private fun effectiveAvatarDim(requested: Int): Int =
        if (isResourceSavingMode) minOf(requested, 96) else requested

    private fun effectiveMediaDim(requested: Int): Int =
        if (isResourceSavingMode) minOf(requested, 300) else requested

    private fun effectiveWallpaperDim(requested: Int): Int =
        if (isResourceSavingMode) minOf(requested, 640) else requested

    private fun effectiveDrawableDim(requested: Int): Int =
        if (isResourceSavingMode) minOf(requested, 360) else requested

    private fun effectiveArtworkDim(requested: Int): Int =
        if (isResourceSavingMode) minOf(requested, 256) else requested

    private fun avatarKey(avatarBase64: String, maxDim: Int): String =
        "${avatarBase64.length}_${avatarBase64.hashCode()}_${avatarBase64.take(24)}_$maxDim"

    private fun mediaKey(messageId: String, sizeBytes: Int, maxDim: Int): String =
        "${messageId}_${sizeBytes}_$maxDim"

    private fun artworkKey(trackId: String, sizeBytes: Int, maxDim: Int): String =
        "${trackId}_${sizeBytes}_$maxDim"

    private fun wallpaperKey(path: String, version: Long, maxDim: Int): String =
        "${path}_${version}_$maxDim"

    fun getCachedAvatar(avatarBase64: String, maxDimensionPx: Int = 256): ImageBitmap? {
        if (avatarBase64.isBlank()) return null
        val dim = effectiveAvatarDim(maxDimensionPx)
        return avatarCache.get(avatarKey(avatarBase64, dim))
    }

    suspend fun decodeAvatar(avatarBase64: String, maxDimensionPx: Int = 256): ImageBitmap? {
        if (avatarBase64.isBlank()) return null
        val dim = effectiveAvatarDim(maxDimensionPx)
        val key = avatarKey(avatarBase64, dim)
        avatarCache.get(key)?.let { return it }

        return withContext(Dispatchers.Default) {
            avatarCache.get(key)?.let { return@withContext it }
            runCatching {
                val bytes = Base64.decode(avatarBase64, Base64.DEFAULT)
                val decoded = decodeSampledFromBytes(
                    bytes = bytes,
                    maxDimensionPx = dim,
                    preferRgb565 = isResourceSavingMode
                )?.asImageBitmap()
                if (decoded != null) {
                    avatarCache.put(key, decoded)
                }
                decoded
            }.getOrNull()
        }
    }

    fun getCachedMediaThumb(messageId: String, bytesSize: Int, maxDimensionPx: Int = 720): ImageBitmap? {
        if (messageId.isBlank() || bytesSize <= 0) return null
        val dim = effectiveMediaDim(maxDimensionPx)
        return mediaThumbCache.get(mediaKey(messageId, bytesSize, dim))
    }

    suspend fun decodeMediaThumb(
        messageId: String,
        bytes: ByteArray,
        maxDimensionPx: Int = 720
    ): ImageBitmap? {
        if (bytes.isEmpty()) return null
        val dim = effectiveMediaDim(maxDimensionPx)
        val key = mediaKey(messageId, bytes.size, dim)
        mediaThumbCache.get(key)?.let { return it }

        return withContext(Dispatchers.Default) {
            mediaThumbCache.get(key)?.let { return@withContext it }
            runCatching {
                val decoded = decodeSampledFromBytes(
                    bytes = bytes,
                    maxDimensionPx = dim,
                    preferRgb565 = isResourceSavingMode
                )?.asImageBitmap()
                if (decoded != null) {
                    mediaThumbCache.put(key, decoded)
                }
                decoded
            }.getOrNull()
        }
    }

    fun getCachedArtwork(trackId: String, bytesSize: Int, maxDimensionPx: Int = 512): ImageBitmap? {
        if (trackId.isBlank() || bytesSize <= 0) return null
        val dim = effectiveArtworkDim(maxDimensionPx)
        return artworkCache.get(artworkKey(trackId, bytesSize, dim))
    }

    suspend fun decodeArtworkBytes(
        trackId: String,
        bytes: ByteArray,
        maxDimensionPx: Int = 512
    ): ImageBitmap? {
        if (bytes.isEmpty()) return null
        val dim = effectiveArtworkDim(maxDimensionPx)
        val key = artworkKey(trackId, bytes.size, dim)
        artworkCache.get(key)?.let { return it }

        return withContext(Dispatchers.Default) {
            artworkCache.get(key)?.let { return@withContext it }
            runCatching {
                val decoded = decodeSampledFromBytes(
                    bytes = bytes,
                    maxDimensionPx = dim,
                    preferRgb565 = isResourceSavingMode
                )?.asImageBitmap()
                if (decoded != null) {
                    artworkCache.put(key, decoded)
                }
                decoded
            }.getOrNull()
        }
    }

    suspend fun decodeFullImage(bytes: ByteArray, maxDimensionPx: Int = 1800): ImageBitmap? {
        if (bytes.isEmpty()) return null
        val dim = if (isResourceSavingMode) minOf(maxDimensionPx, 960) else maxDimensionPx
        return withContext(Dispatchers.Default) {
            runCatching {
                decodeSampledFromBytes(
                    bytes = bytes,
                    maxDimensionPx = dim,
                    preferRgb565 = isResourceSavingMode
                )?.asImageBitmap()
            }.getOrNull()
        }
    }

    fun getCachedWallpaper(path: String, version: Long, maxDimensionPx: Int = 1600): ImageBitmap? {
        if (path.isBlank()) return null
        val dim = effectiveWallpaperDim(maxDimensionPx)
        return wallpaperCache.get(wallpaperKey(path, version, dim))
    }

    suspend fun decodeWallpaper(
        path: String,
        version: Long,
        maxDimensionPx: Int = 1600
    ): ImageBitmap? {
        if (path.isBlank()) return null
        val dim = effectiveWallpaperDim(maxDimensionPx)
        val key = wallpaperKey(path, version, dim)
        wallpaperCache.get(key)?.let { return it }

        return withContext(Dispatchers.IO) {
            wallpaperCache.get(key)?.let { return@withContext it }
            runCatching {
                val file = File(path)
                if (!file.exists()) return@withContext null
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeFile(file.absolutePath, bounds)
                val opts = BitmapFactory.Options().apply {
                    inSampleSize = computeSampleSize(bounds.outWidth, bounds.outHeight, dim)
                    inPreferredConfig = Bitmap.Config.RGB_565
                }
                val bmp = BitmapFactory.decodeFile(file.absolutePath, opts) ?: return@withContext null
                bmp.asImageBitmap().also { wallpaperCache.put(key, it) }
            }.getOrNull()
        }
    }

    fun getCachedDrawable(@DrawableRes resId: Int, maxDimensionPx: Int = 960): ImageBitmap? {
        val dim = effectiveDrawableDim(maxDimensionPx)
        return drawableCache.get("${resId}_$dim")
    }

    suspend fun decodeDrawable(
        context: Context,
        @DrawableRes resId: Int,
        maxDimensionPx: Int = 960
    ): ImageBitmap? {
        val dim = effectiveDrawableDim(maxDimensionPx)
        val key = "${resId}_$dim"
        drawableCache.get(key)?.let { return it }

        val appContext = context.applicationContext
        return withContext(Dispatchers.Default) {
            drawableCache.get(key)?.let { return@withContext it }
            runCatching {
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeResource(appContext.resources, resId, bounds)
                val opts = BitmapFactory.Options().apply {
                    inSampleSize = computeSampleSize(bounds.outWidth, bounds.outHeight, dim)
                    if (isResourceSavingMode) {
                        inPreferredConfig = Bitmap.Config.RGB_565
                    }
                }
                val bmp = BitmapFactory.decodeResource(appContext.resources, resId, opts)
                    ?: return@withContext null
                bmp.asImageBitmap().also { drawableCache.put(key, it) }
            }.getOrNull()
        }
    }

    private fun decodeSampledFromBytes(
        bytes: ByteArray,
        maxDimensionPx: Int,
        preferRgb565: Boolean = false
    ): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        val opts = BitmapFactory.Options().apply {
            inSampleSize = computeSampleSize(bounds.outWidth, bounds.outHeight, maxDimensionPx)
            if (preferRgb565) {
                inPreferredConfig = Bitmap.Config.RGB_565
            }
        }
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
    }

    internal fun computeSampleSize(width: Int, height: Int, maxDim: Int): Int {
        if (width <= 0 || height <= 0 || maxDim <= 0) return 1
        var sample = 1
        val maxSide = maxOf(width, height)
        while ((maxSide / sample) > maxDim) {
            sample *= 2
        }
        return sample.coerceAtLeast(1)
    }
}
