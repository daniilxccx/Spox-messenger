const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_123";
const BOB_UID = "bob_456";
const CHARLIE_UID = "charlie_789";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

const ts = new Date();
const hash64 = "a".repeat(64);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated user: denied across all collections", async () => {
  const unauth = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauth.collection("users").doc(ALICE_UID).get());
  await assertFails(unauth.collection("users_public").where("isDiscoverable", "==", true).get());
  await assertFails(unauth.collection("conversations").where("memberUids", "array-contains", ALICE_UID).get());
  await assertFails(unauth.collection("calls").where("memberUids", "array-contains", ALICE_UID).get());
});

test("Private user PII: owner can create/read/edit profile, cross-user denied, ghost field rejected", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).set({
      userId: ALICE_UID,
      email: "alice@example.com",
      displayName: "Alice",
      handle: "@alice",
      avatarBase64: "",
      preferredTheme: "dark",
      keyFingerprint: "SHA256:ABCD1234",
      createdAt: ts,
      updatedAt: ts,
    })
  );

  // Owner can change nickname, upload avatar, and remove username (handle = "")
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).update({
      displayName: "Alice New",
      handle: "",
      avatarBase64: "ZmFrZWpwZWc=",
      updatedAt: ts,
    })
  );

  // Owner can set a valid username again
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).update({
      handle: "@alice_cipher.1",
      updatedAt: ts,
    })
  );

  // Invalid username without '@' or with spaces is rejected
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).update({
      handle: "invalid handle!",
      updatedAt: ts,
    })
  );

  await assertFails(bobDb.collection("users").doc(ALICE_UID).get());

  // Shadow update with ghost field
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).update({
      preferredTheme: "light",
      isAdmin: true,
      updatedAt: ts,
    })
  );
});

test("Public directory: requires isDiscoverable filter on list, allows profile updates, rejects spoofing", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();

  await assertSucceeds(
    aliceDb.collection("users_public").doc(ALICE_UID).set({
      userId: ALICE_UID,
      displayName: "Alice",
      handle: "@alice",
      avatarBase64: "",
      emailHash: hash64,
      publicKeyBase64: "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAE1234567890",
      keyFingerprint: "ABCD-1234-EFGH",
      avatarColorIndex: 2,
      isDiscoverable: true,
      isOnline: true,
      updatedAt: ts,
    })
  );

  // Owner can update nickname, avatarBase64, and delete handle ("")
  await assertSucceeds(
    aliceDb.collection("users_public").doc(ALICE_UID).update({
      displayName: "Alice Cipher",
      handle: "",
      avatarBase64: "ZmFrZWpwZWc=",
      updatedAt: ts,
    })
  );

  // Owner can update presence (isOnline + lastSeenAt)
  await assertSucceeds(
    aliceDb.collection("users_public").doc(ALICE_UID).update({
      isOnline: false,
      lastSeenAt: ts,
      updatedAt: ts,
    })
  );

  // Unfiltered list fails (rules are not filters)
  await assertFails(bobDb.collection("users_public").get());
  // Filtered list succeeds
  await assertSucceeds(bobDb.collection("users_public").where("isDiscoverable", "==", true).get());
  // Bob cannot write Alice's public profile or presence
  await assertFails(
    bobDb.collection("users_public").doc(ALICE_UID).update({
      displayName: "Hacked",
      updatedAt: ts,
    })
  );
  await assertFails(
    bobDb.collection("users_public").doc(ALICE_UID).update({
      isOnline: false,
      lastSeenAt: ts,
      updatedAt: ts,
    })
  );
});

test("Conversations & Messages: member-only access, parent verification, and cross-user isolation", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const charlieDb = testEnv.authenticatedContext(CHARLIE_UID).firestore();

  await assertSucceeds(
    aliceDb.collection("conversations").doc("chat_1").set({
      title: "Crypto Squad",
      isGroup: true,
      createdBy: ALICE_UID,
      memberUids: [ALICE_UID, BOB_UID],
      memberNames: { [ALICE_UID]: "Alice", [BOB_UID]: "Bob" },
      memberKeyEnvelopes: { [ALICE_UID]: "env1", [BOB_UID]: "env2" },
      lastMessagePreview: "enc_preview",
      lastMessageType: "text",
      lastMessageSenderId: ALICE_UID,
      activeCallId: "",
      createdAt: ts,
      updatedAt: ts,
    })
  );

  // Non-member Charlie cannot read or list
  await assertFails(charlieDb.collection("conversations").doc("chat_1").get());
  await assertFails(charlieDb.collection("conversations").where("memberUids", "array-contains", ALICE_UID).get());

  // Member Bob can list his conversations
  await assertSucceeds(bobDb.collection("conversations").where("memberUids", "array-contains", BOB_UID).get());

  // Member Bob can create an encrypted message in chat_1
  await assertSucceeds(
    bobDb.collection("conversations").doc("chat_1").collection("messages").doc("msg_1").set({
      conversationId: "chat_1",
      senderId: BOB_UID,
      senderName: "Bob",
      memberUids: [ALICE_UID, BOB_UID],
      messageType: "text",
      ivBase64: "MTIzNDU2Nzg5MDEy",
      encryptedPayload: "ZW5jcnlwdGVkX3BheWxvYWQ=",
      keyVersion: 1,
      isDeleted: false,
      createdAt: ts,
      updatedAt: ts,
    })
  );

  // Charlie cannot read messages or spoof senderId
  await assertFails(
    charlieDb.collection("conversations").doc("chat_1").collection("messages").doc("msg_1").get()
  );
  await assertFails(
    charlieDb.collection("conversations").doc("chat_1").collection("messages").doc("msg_2").set({
      conversationId: "chat_1",
      senderId: ALICE_UID,
      senderName: "Alice",
      memberUids: [ALICE_UID, BOB_UID, CHARLIE_UID],
      messageType: "text",
      ivBase64: "MTIzNDU2Nzg5MDEy",
      encryptedPayload: "ZmFrZQ==",
      keyVersion: 1,
      isDeleted: false,
      createdAt: ts,
      updatedAt: ts,
    })
  );
});

test("Calls & Participants: member creation, terminal state lock, and participant isolation", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const charlieDb = testEnv.authenticatedContext(CHARLIE_UID).firestore();

  await assertSucceeds(
    aliceDb.collection("conversations").doc("chat_call").set({
      title: "Direct Call",
      isGroup: false,
      createdBy: ALICE_UID,
      memberUids: [ALICE_UID, BOB_UID],
      memberNames: { [ALICE_UID]: "Alice", [BOB_UID]: "Bob" },
      memberKeyEnvelopes: { [ALICE_UID]: "env1", [BOB_UID]: "env2" },
      lastMessagePreview: "",
      lastMessageType: "none",
      lastMessageSenderId: "",
      activeCallId: "",
      createdAt: ts,
      updatedAt: ts,
    })
  );

  await assertSucceeds(
    aliceDb.collection("calls").doc("call_1").set({
      conversationId: "chat_call",
      conversationTitle: "Direct Call",
      callerId: ALICE_UID,
      callerName: "Alice",
      isGroupCall: false,
      callType: "video",
      status: "ringing",
      memberUids: [ALICE_UID, BOB_UID],
      activeParticipantUids: [ALICE_UID],
      createdAt: ts,
      updatedAt: ts,
    })
  );

  // Bob answers call and creates his participant doc
  await assertSucceeds(
    bobDb.collection("calls").doc("call_1").update({
      status: "active",
      activeParticipantUids: [ALICE_UID, BOB_UID],
      updatedAt: ts,
    })
  );

  await assertSucceeds(
    bobDb.collection("calls").doc("call_1").collection("participants").doc(BOB_UID).set({
      callId: "call_1",
      userId: BOB_UID,
      displayName: "Bob",
      memberUids: [ALICE_UID, BOB_UID],
      isMuted: false,
      isCameraOn: true,
      isSpeaking: true,
      audioLevel: 65,
      joinedAt: ts,
      updatedAt: ts,
    })
  );

  // Bob and Alice can stream and read audio frames while call is active
  await assertSucceeds(
    aliceDb.collection("calls").doc("call_1").collection("audio_frames").doc(`${ALICE_UID}_0`).set({
      callId: "call_1",
      senderId: ALICE_UID,
      seq: 0,
      sampleRate: 16000,
      codec: "ima_adpcm",
      payloadBase64: "AAAAZmFrZUFkcGNt",
      memberUids: [ALICE_UID, BOB_UID],
      createdAt: ts,
    })
  );
  await assertSucceeds(
    bobDb.collection("calls").doc("call_1").collection("audio_frames")
      .where("memberUids", "array-contains", BOB_UID)
      .get()
  );
  // Sender spoofing is blocked
  await assertFails(
    bobDb.collection("calls").doc("call_1").collection("audio_frames").doc("spoof_0").set({
      callId: "call_1",
      senderId: ALICE_UID,
      seq: 0,
      sampleRate: 16000,
      codec: "ima_adpcm",
      payloadBase64: "AAAAZmFrZUFkcGNt",
      memberUids: [ALICE_UID, BOB_UID],
      createdAt: ts,
    })
  );
  // Charlie cannot read or write audio frames
  await assertFails(
    charlieDb.collection("calls").doc("call_1").collection("audio_frames")
      .where("memberUids", "array-contains", ALICE_UID)
      .get()
  );

  // Charlie cannot join or read call
  await assertFails(charlieDb.collection("calls").doc("call_1").get());

  // Sender can delete old rolling audio frame
  await assertSucceeds(
    aliceDb.collection("calls").doc("call_1").collection("audio_frames").doc(`${ALICE_UID}_0`).delete()
  );

  // End call -> terminal state locking prevents reopening or sending audio
  await assertSucceeds(
    aliceDb.collection("calls").doc("call_1").update({
      status: "ended",
      activeParticipantUids: [],
      updatedAt: ts,
    })
  );

  await assertFails(
    bobDb.collection("calls").doc("call_1").collection("audio_frames").doc(`${BOB_UID}_1`).set({
      callId: "call_1",
      senderId: BOB_UID,
      seq: 1,
      sampleRate: 16000,
      codec: "ima_adpcm",
      payloadBase64: "AAAAZmFrZUFkcGNt",
      memberUids: [ALICE_UID, BOB_UID],
      createdAt: ts,
    })
  );

  await assertFails(
    bobDb.collection("calls").doc("call_1").update({
      status: "active",
      activeParticipantUids: [BOB_UID],
      updatedAt: ts,
    })
  );
});

test("Role codes: blocks self-escalation, allows single-use bootstrap & developer-issued codes", async () => {
  const crypto = require("node:crypto");
  const sha256 = (s) => crypto.createHash("sha256").update(s).digest("hex");

  const BOOTSTRAP_HASH = sha256("SPOX-DEV-8K4M-9X2Q");
  const TESTER_HASH = sha256("SPOX-TST-2233-4455");

  const unauthDb = testEnv.unauthenticatedContext().firestore();
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();

  // Unauthenticated cannot read or list role_codes
  await assertFails(unauthDb.collection("role_codes").doc(BOOTSTRAP_HASH).get());
  await assertFails(unauthDb.collection("role_codes").get());

  // Seed initial normal profiles for Alice and Bob
  const seedUser = async (db, uid, email, name) => {
    await assertSucceeds(
      db.collection("users").doc(uid).set({
        userId: uid,
        email,
        displayName: name,
        handle: `@${uid}`,
        avatarBase64: "",
        preferredTheme: "dark",
        keyFingerprint: "SHA256:ABCD1234",
        role: "user",
        redeemedCodeHash: "",
        createdAt: ts,
        updatedAt: ts,
      })
    );
    await assertSucceeds(
      db.collection("users_public").doc(uid).set({
        userId: uid,
        displayName: name,
        handle: `@${uid}`,
        avatarBase64: "",
        emailHash: hash64,
        publicKeyBase64: "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAE1234567890",
        keyFingerprint: "ABCD-1234-EFGH",
        avatarColorIndex: 1,
        isDiscoverable: true,
        isOnline: true,
        role: "user",
        updatedAt: ts,
      })
    );
  };

  await seedUser(aliceDb, ALICE_UID, "alice@example.com", "Alice");
  await seedUser(bobDb, BOB_UID, "bob@example.com", "Bob");

  // Direct role escalation without valid code fails
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).update({
      role: "developer",
      updatedAt: ts,
    })
  );
  await assertFails(
    aliceDb.collection("users_public").doc(ALICE_UID).update({
      role: "developer",
      updatedAt: ts,
    })
  );

  // Non-developer cannot list or create role_codes
  await assertFails(aliceDb.collection("role_codes").get());
  await assertFails(
    aliceDb.collection("role_codes").doc(TESTER_HASH).set({
      codeHash: TESTER_HASH,
      codePreview: "SPOX-TST-••••-4455",
      targetRole: "tester",
      createdBy: ALICE_UID,
      isUsed: false,
      usedBy: "",
      createdAt: ts,
    })
  );

  // Alice redeems the one-time bootstrap developer code via WriteBatch
  const bootstrapBatch = aliceDb.batch();
  bootstrapBatch.set(aliceDb.collection("role_codes").doc(BOOTSTRAP_HASH), {
    codeHash: BOOTSTRAP_HASH,
    codePreview: "SPOX-DEV-••••-9X2Q",
    targetRole: "developer",
    createdBy: ALICE_UID,
    isUsed: true,
    usedBy: ALICE_UID,
    createdAt: ts,
    usedAt: ts,
  });
  bootstrapBatch.update(aliceDb.collection("users").doc(ALICE_UID), {
    role: "developer",
    redeemedCodeHash: BOOTSTRAP_HASH,
    updatedAt: ts,
  });
  bootstrapBatch.update(aliceDb.collection("users_public").doc(ALICE_UID), {
    role: "developer",
    updatedAt: ts,
  });
  await assertSucceeds(bootstrapBatch.commit());

  // Bob CANNOT reuse the bootstrap developer code
  const secondBootstrapBatch = bobDb.batch();
  secondBootstrapBatch.set(bobDb.collection("role_codes").doc(BOOTSTRAP_HASH), {
    codeHash: BOOTSTRAP_HASH,
    codePreview: "SPOX-DEV-••••-9X2Q",
    targetRole: "developer",
    createdBy: BOB_UID,
    isUsed: true,
    usedBy: BOB_UID,
    createdAt: ts,
    usedAt: ts,
  });
  secondBootstrapBatch.update(bobDb.collection("users").doc(BOB_UID), {
    role: "developer",
    redeemedCodeHash: BOOTSTRAP_HASH,
    updatedAt: ts,
  });
  secondBootstrapBatch.update(bobDb.collection("users_public").doc(BOB_UID), {
    role: "developer",
    updatedAt: ts,
  });
  await assertFails(secondBootstrapBatch.commit());

  // Developer Alice CAN now list and create a tester code
  await assertSucceeds(
    aliceDb.collection("role_codes").doc(TESTER_HASH).set({
      codeHash: TESTER_HASH,
      codePreview: "SPOX-TST-••••-4455",
      targetRole: "tester",
      createdBy: ALICE_UID,
      isUsed: false,
      usedBy: "",
      createdAt: ts,
    })
  );
  await assertSucceeds(aliceDb.collection("role_codes").get());

  // Bob CANNOT spoof developer using a tester code
  const spoofBatch = bobDb.batch();
  spoofBatch.update(bobDb.collection("role_codes").doc(TESTER_HASH), {
    isUsed: true,
    usedBy: BOB_UID,
    usedAt: ts,
  });
  spoofBatch.update(bobDb.collection("users").doc(BOB_UID), {
    role: "developer",
    redeemedCodeHash: TESTER_HASH,
    updatedAt: ts,
  });
  spoofBatch.update(bobDb.collection("users_public").doc(BOB_UID), {
    role: "developer",
    updatedAt: ts,
  });
  await assertFails(spoofBatch.commit());

  // Bob validly redeems the tester code
  const testerBatch = bobDb.batch();
  testerBatch.update(bobDb.collection("role_codes").doc(TESTER_HASH), {
    isUsed: true,
    usedBy: BOB_UID,
    usedAt: ts,
  });
  testerBatch.update(bobDb.collection("users").doc(BOB_UID), {
    role: "tester",
    redeemedCodeHash: TESTER_HASH,
    updatedAt: ts,
  });
  testerBatch.update(bobDb.collection("users_public").doc(BOB_UID), {
    role: "tester",
    updatedAt: ts,
  });
  await assertSucceeds(testerBatch.commit());

  // Tester Bob still cannot create or list role_codes
  const extraHash = sha256("SPOX-TST-9999-8888");
  await assertFails(bobDb.collection("role_codes").get());
  await assertFails(
    bobDb.collection("role_codes").doc(extraHash).set({
      codeHash: extraHash,
      codePreview: "SPOX-TST-••••-8888",
      targetRole: "tester",
      createdBy: BOB_UID,
      isUsed: false,
      usedBy: "",
      createdAt: ts,
    })
  );

  // Developer Alice can delete/revoke a code
  await assertSucceeds(aliceDb.collection("role_codes").doc(TESTER_HASH).delete());
});

test("Admin moderation: developer can mute, ban, unban, and delete accounts; non-admin blocked; muted/banned restricted", async () => {
  const crypto = require("node:crypto");
  const sha256 = (s) => crypto.createHash("sha256").update(s).digest("hex");
  const BOOTSTRAP_HASH = sha256("SPOX-DEV-8K4M-9X2Q");

  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const charlieDb = testEnv.authenticatedContext(CHARLIE_UID).firestore();

  const createProfile = async (db, uid, email, name) => {
    await assertSucceeds(
      db.collection("users").doc(uid).set({
        userId: uid,
        email,
        displayName: name,
        handle: `@${uid}`,
        avatarBase64: "",
        preferredTheme: "dark",
        keyFingerprint: "SHA256:ABCD1234",
        role: "user",
        redeemedCodeHash: "",
        moderationStatus: "active",
        mutedUntilEpochMs: 0,
        moderationReason: "",
        moderatedBy: "",
        createdAt: ts,
        updatedAt: ts,
      })
    );
    await assertSucceeds(
      db.collection("users_public").doc(uid).set({
        userId: uid,
        displayName: name,
        handle: `@${uid}`,
        avatarBase64: "",
        emailHash: hash64,
        publicKeyBase64: "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAE1234567890",
        keyFingerprint: "ABCD-1234-EFGH",
        avatarColorIndex: 1,
        isDiscoverable: true,
        isOnline: true,
        role: "user",
        moderationStatus: "active",
        mutedUntilEpochMs: 0,
        moderationReason: "",
        updatedAt: ts,
      })
    );
  };

  await createProfile(aliceDb, ALICE_UID, "alice@example.com", "Alice");
  await createProfile(bobDb, BOB_UID, "bob@example.com", "Bob");
  await createProfile(charlieDb, CHARLIE_UID, "charlie@example.com", "Charlie");

  // Promote Alice to developer/admin via bootstrap code
  const devBatch = aliceDb.batch();
  devBatch.set(aliceDb.collection("role_codes").doc(BOOTSTRAP_HASH), {
    codeHash: BOOTSTRAP_HASH,
    codePreview: "SPOX-DEV-••••-9X2Q",
    targetRole: "developer",
    createdBy: ALICE_UID,
    isUsed: true,
    usedBy: ALICE_UID,
    createdAt: ts,
    usedAt: ts,
  });
  devBatch.update(aliceDb.collection("users").doc(ALICE_UID), {
    role: "developer",
    redeemedCodeHash: BOOTSTRAP_HASH,
    updatedAt: ts,
  });
  devBatch.update(aliceDb.collection("users_public").doc(ALICE_UID), {
    role: "developer",
    updatedAt: ts,
  });
  await assertSucceeds(devBatch.commit());

  // Non-admin Bob cannot list /users or mute Charlie
  await assertFails(bobDb.collection("users").get());
  await assertFails(
    bobDb.collection("users").doc(CHARLIE_UID).update({
      moderationStatus: "muted",
      mutedUntilEpochMs: 0,
      moderationReason: "spam",
      moderatedBy: BOB_UID,
      moderatedAt: ts,
      updatedAt: ts,
    })
  );

  // Admin Alice CAN list /users and create a conversation with Bob
  await assertSucceeds(aliceDb.collection("users").get());
  await assertSucceeds(
    aliceDb.collection("conversations").doc("dm_alice_bob").set({
      title: "Bob",
      isGroup: false,
      createdBy: ALICE_UID,
      memberUids: [ALICE_UID, BOB_UID],
      memberNames: { [ALICE_UID]: "Alice", [BOB_UID]: "Bob" },
      memberKeyEnvelopes: { [ALICE_UID]: "env1", [BOB_UID]: "env2" },
      lastMessagePreview: "",
      lastMessageType: "none",
      lastMessageSenderId: "",
      activeCallId: "",
      unreadCounts: { [ALICE_UID]: 0, [BOB_UID]: 0 },
      lastReadAtMillis: { [ALICE_UID]: 1, [BOB_UID]: 1 },
      createdAt: ts,
      updatedAt: ts,
    })
  );

  // Admin Alice mutes Bob permanently (mutedUntilEpochMs = 0)
  const muteBatch = aliceDb.batch();
  muteBatch.update(aliceDb.collection("users").doc(BOB_UID), {
    moderationStatus: "muted",
    mutedUntilEpochMs: 0,
    moderationReason: "Флуд в чате",
    moderatedBy: ALICE_UID,
    moderatedAt: ts,
    updatedAt: ts,
  });
  muteBatch.update(aliceDb.collection("users_public").doc(BOB_UID), {
    moderationStatus: "muted",
    mutedUntilEpochMs: 0,
    moderationReason: "Флуд в чате",
    updatedAt: ts,
  });
  await assertSucceeds(muteBatch.commit());

  // Muted Bob cannot send messages or start calls, nor self-unmute
  await assertFails(
    bobDb.collection("conversations").doc("dm_alice_bob").collection("messages").doc("m_muted").set({
      conversationId: "dm_alice_bob",
      senderId: BOB_UID,
      senderName: "Bob",
      memberUids: [ALICE_UID, BOB_UID],
      messageType: "text",
      ivBase64: "MTIzNDU2Nzg5MDEy",
      encryptedPayload: "ZW5jcnlwdGVk",
      keyVersion: 1,
      isDeleted: false,
      createdAt: ts,
      updatedAt: ts,
    })
  );
  await assertFails(
    bobDb.collection("calls").doc("call_muted").set({
      conversationId: "dm_alice_bob",
      conversationTitle: "Direct",
      callerId: BOB_UID,
      callerName: "Bob",
      isGroupCall: false,
      callType: "audio",
      status: "ringing",
      memberUids: [ALICE_UID, BOB_UID],
      activeParticipantUids: [BOB_UID],
      createdAt: ts,
      updatedAt: ts,
    })
  );
  await assertFails(
    bobDb.collection("users").doc(BOB_UID).update({
      moderationStatus: "active",
      updatedAt: ts,
    })
  );

  // Admin Alice unmutes Bob -> Bob can message & mark read & repair DM key envelopes
  const unmuteBatch = aliceDb.batch();
  unmuteBatch.update(aliceDb.collection("users").doc(BOB_UID), {
    moderationStatus: "active",
    mutedUntilEpochMs: 0,
    moderationReason: "",
    moderatedBy: ALICE_UID,
    moderatedAt: ts,
    updatedAt: ts,
  });
  unmuteBatch.update(aliceDb.collection("users_public").doc(BOB_UID), {
    moderationStatus: "active",
    mutedUntilEpochMs: 0,
    moderationReason: "",
    updatedAt: ts,
  });
  await assertSucceeds(unmuteBatch.commit());

  await assertSucceeds(
    bobDb.collection("conversations").doc("dm_alice_bob").collection("messages").doc("m_ok").set({
      conversationId: "dm_alice_bob",
      senderId: BOB_UID,
      senderName: "Bob",
      memberUids: [ALICE_UID, BOB_UID],
      messageType: "text",
      ivBase64: "MTIzNDU2Nzg5MDEy",
      encryptedPayload: "ZW5jcnlwdGVk",
      keyVersion: 1,
      isDeleted: false,
      createdAt: ts,
      updatedAt: ts,
    })
  );
  await assertSucceeds(
    aliceDb.collection("conversations").doc("dm_alice_bob").update({
      unreadCounts: { [ALICE_UID]: 0, [BOB_UID]: 0 },
      lastReadAtMillis: { [ALICE_UID]: 123456, [BOB_UID]: 1 },
    })
  );
  await assertSucceeds(
    bobDb.collection("conversations").doc("dm_alice_bob").update({
      memberKeyEnvelopes: { [ALICE_UID]: "env1_new", [BOB_UID]: "env2_new" },
      updatedAt: ts,
    })
  );

  // Admin Alice bans Charlie -> Charlie cannot create chats or update his profile
  const banBatch = aliceDb.batch();
  banBatch.update(aliceDb.collection("users").doc(CHARLIE_UID), {
    moderationStatus: "banned",
    mutedUntilEpochMs: 0,
    moderationReason: "Нарушение правил",
    moderatedBy: ALICE_UID,
    moderatedAt: ts,
    updatedAt: ts,
  });
  banBatch.update(aliceDb.collection("users_public").doc(CHARLIE_UID), {
    moderationStatus: "banned",
    mutedUntilEpochMs: 0,
    moderationReason: "Нарушение правил",
    updatedAt: ts,
  });
  await assertSucceeds(banBatch.commit());

  await assertFails(
    charlieDb.collection("users").doc(CHARLIE_UID).update({
      displayName: "New Charlie",
      updatedAt: ts,
    })
  );

  // Admin Alice deletes Charlie's account (tombstone + delete users & users_public)
  const delBatch = aliceDb.batch();
  delBatch.set(aliceDb.collection("deleted_accounts").doc(CHARLIE_UID), {
    userId: CHARLIE_UID,
    deletedBy: ALICE_UID,
    reason: "Удалён администратором",
    deletedAt: ts,
  });
  delBatch.delete(aliceDb.collection("users").doc(CHARLIE_UID));
  delBatch.delete(aliceDb.collection("users_public").doc(CHARLIE_UID));
  await assertSucceeds(delBatch.commit());

  // Deleted Charlie cannot recreate profile, and cannot self-delete admin Alice
  await assertFails(createProfile(charlieDb, CHARLIE_UID, "charlie@example.com", "Charlie Reborn"));
});

test("Chat management: group settings, add/remove members, non-creator leave, and DM/group deletion", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const charlieDb = testEnv.authenticatedContext(CHARLIE_UID).firestore();

  // 1. Alice creates a group with Bob
  await assertSucceeds(
    aliceDb.collection("conversations").doc("grp_manage_1").set({
      title: "Команда SpoX",
      description: "Рабочий чат команды",
      isGroup: true,
      createdBy: ALICE_UID,
      memberUids: [ALICE_UID, BOB_UID],
      memberNames: { [ALICE_UID]: "Alice", [BOB_UID]: "Bob" },
      memberKeyEnvelopes: { [ALICE_UID]: "envA", [BOB_UID]: "envB" },
      lastMessagePreview: "",
      lastMessageType: "none",
      lastMessageSenderId: "",
      activeCallId: "",
      unreadCounts: { [ALICE_UID]: 0, [BOB_UID]: 0 },
      lastReadAtMillis: { [ALICE_UID]: 1, [BOB_UID]: 1 },
      createdAt: ts,
      updatedAt: ts,
    })
  );

  // 2. Creator updates title & description
  await assertSucceeds(
    aliceDb.collection("conversations").doc("grp_manage_1").update({
      title: "Команда SpoX Core",
      description: "Обсуждение релизов и обновлений",
      updatedAt: ts,
    })
  );

  // 3. Add Charlie to the group
  await assertSucceeds(
    aliceDb.collection("conversations").doc("grp_manage_1").update({
      memberUids: [ALICE_UID, BOB_UID, CHARLIE_UID],
      memberNames: { [ALICE_UID]: "Alice", [BOB_UID]: "Bob", [CHARLIE_UID]: "Charlie" },
      memberKeyEnvelopes: { [ALICE_UID]: "envA", [BOB_UID]: "envB", [CHARLIE_UID]: "envC" },
      unreadCounts: { [ALICE_UID]: 0, [BOB_UID]: 0, [CHARLIE_UID]: 0 },
      lastReadAtMillis: { [ALICE_UID]: 1, [BOB_UID]: 1, [CHARLIE_UID]: 1 },
      updatedAt: ts,
    })
  );

  // Charlie and Alice send messages in the group
  await assertSucceeds(
    aliceDb.collection("conversations").doc("grp_manage_1").collection("messages").doc("gm_1").set({
      conversationId: "grp_manage_1",
      senderId: ALICE_UID,
      senderName: "Alice",
      memberUids: [ALICE_UID, BOB_UID, CHARLIE_UID],
      messageType: "text",
      ivBase64: "MTIzNDU2Nzg5MDEy",
      encryptedPayload: "ZW5jcnlwdGVk",
      keyVersion: 1,
      isDeleted: false,
      createdAt: ts,
      updatedAt: ts,
    })
  );
  await assertSucceeds(
    charlieDb.collection("conversations").doc("grp_manage_1").collection("messages").doc("gm_2").set({
      conversationId: "grp_manage_1",
      senderId: CHARLIE_UID,
      senderName: "Charlie",
      memberUids: [ALICE_UID, BOB_UID, CHARLIE_UID],
      messageType: "text",
      ivBase64: "MTIzNDU2Nzg5MDEy",
      encryptedPayload: "ZW5jcnlwdGVk",
      keyVersion: 1,
      isDeleted: false,
      createdAt: ts,
      updatedAt: ts,
    })
  );

  // 4. Non-creator Bob CANNOT kick Charlie
  await assertFails(
    bobDb.collection("conversations").doc("grp_manage_1").update({
      memberUids: [ALICE_UID, BOB_UID],
      memberNames: { [ALICE_UID]: "Alice", [BOB_UID]: "Bob" },
      memberKeyEnvelopes: { [ALICE_UID]: "envA2", [BOB_UID]: "envB2" },
      updatedAt: ts,
    })
  );

  // 5. Non-creator Bob CAN leave the group cleanly (removing only Bob + key rotation)
  await assertSucceeds(
    bobDb.collection("conversations").doc("grp_manage_1").update({
      memberUids: [ALICE_UID, CHARLIE_UID],
      memberNames: { [ALICE_UID]: "Alice", [CHARLIE_UID]: "Charlie" },
      memberKeyEnvelopes: { [ALICE_UID]: "envA2", [CHARLIE_UID]: "envC2" },
      unreadCounts: { [ALICE_UID]: 0, [CHARLIE_UID]: 0 },
      lastReadAtMillis: { [ALICE_UID]: 1, [CHARLIE_UID]: 1 },
      updatedAt: ts,
    })
  );

  // 6. Creator Alice adds Bob back, then removes Charlie
  await assertSucceeds(
    aliceDb.collection("conversations").doc("grp_manage_1").update({
      memberUids: [ALICE_UID, CHARLIE_UID, BOB_UID],
      memberNames: { [ALICE_UID]: "Alice", [CHARLIE_UID]: "Charlie", [BOB_UID]: "Bob" },
      memberKeyEnvelopes: { [ALICE_UID]: "envA2", [CHARLIE_UID]: "envC2", [BOB_UID]: "envB3" },
      updatedAt: ts,
    })
  );
  await assertSucceeds(
    aliceDb.collection("conversations").doc("grp_manage_1").update({
      memberUids: [ALICE_UID, BOB_UID],
      memberNames: { [ALICE_UID]: "Alice", [BOB_UID]: "Bob" },
      memberKeyEnvelopes: { [ALICE_UID]: "envA3", [BOB_UID]: "envB4" },
      unreadCounts: { [ALICE_UID]: 0, [BOB_UID]: 0 },
      lastReadAtMillis: { [ALICE_UID]: 1, [BOB_UID]: 1 },
      updatedAt: ts,
    })
  );

  // 7. Non-creator Bob CANNOT delete the group or Alice's group message
  await assertFails(bobDb.collection("conversations").doc("grp_manage_1").delete());
  await assertFails(bobDb.collection("conversations").doc("grp_manage_1").collection("messages").doc("gm_1").delete());

  // 8. Creator Alice CAN delete Charlie's message, her message, and the group document
  await assertSucceeds(aliceDb.collection("conversations").doc("grp_manage_1").collection("messages").doc("gm_2").delete());
  await assertSucceeds(aliceDb.collection("conversations").doc("grp_manage_1").collection("messages").doc("gm_1").delete());
  await assertSucceeds(aliceDb.collection("conversations").doc("grp_manage_1").delete());

  // 9. DM chat: Alice creates DM with Bob and sends a message; non-creator Bob CAN delete both the message and DM!
  await assertSucceeds(
    aliceDb.collection("conversations").doc("dm_alice_bob_del").set({
      title: "Bob",
      isGroup: false,
      createdBy: ALICE_UID,
      memberUids: [ALICE_UID, BOB_UID],
      memberNames: { [ALICE_UID]: "Alice", [BOB_UID]: "Bob" },
      memberKeyEnvelopes: { [ALICE_UID]: "envA", [BOB_UID]: "envB" },
      lastMessagePreview: "",
      lastMessageType: "none",
      lastMessageSenderId: "",
      activeCallId: "",
      createdAt: ts,
      updatedAt: ts,
    })
  );
  await assertSucceeds(
    aliceDb.collection("conversations").doc("dm_alice_bob_del").collection("messages").doc("dm_msg_1").set({
      conversationId: "dm_alice_bob_del",
      senderId: ALICE_UID,
      senderName: "Alice",
      memberUids: [ALICE_UID, BOB_UID],
      messageType: "text",
      ivBase64: "MTIzNDU2Nzg5MDEy",
      encryptedPayload: "ZW5jcnlwdGVk",
      keyVersion: 1,
      isDeleted: false,
      createdAt: ts,
      updatedAt: ts,
    })
  );
  // Charlie outside DM cannot delete DM
  await assertFails(charlieDb.collection("conversations").doc("dm_alice_bob_del").delete());
  // Peer Bob can delete Alice's message inside DM then delete DM
  await assertSucceeds(bobDb.collection("conversations").doc("dm_alice_bob_del").collection("messages").doc("dm_msg_1").delete());
  await assertSucceeds(bobDb.collection("conversations").doc("dm_alice_bob_del").delete());
});

test("Chunked E2EE media attachments: member access, validation limits, and outsider isolation", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const charlieDb = testEnv.authenticatedContext(CHARLIE_UID).firestore();

  await assertSucceeds(
    aliceDb.collection("conversations").doc("chat_media_chunks").set({
      title: "Медиа чат",
      isGroup: true,
      createdBy: ALICE_UID,
      memberUids: [ALICE_UID, BOB_UID],
      memberNames: { [ALICE_UID]: "Alice", [BOB_UID]: "Bob" },
      memberKeyEnvelopes: { [ALICE_UID]: "envA", [BOB_UID]: "envB" },
      lastMessagePreview: "",
      lastMessageType: "none",
      lastMessageSenderId: "",
      activeCallId: "",
      createdAt: ts,
      updatedAt: ts,
    })
  );

  const msgRef = aliceDb
    .collection("conversations")
    .doc("chat_media_chunks")
    .collection("messages")
    .doc("msg_video_1");

  // 1. Alice uploads two encrypted media chunks
  await assertSucceeds(
    msgRef.collection("chunks").doc("chunk_0000").set({
      conversationId: "chat_media_chunks",
      messageId: "msg_video_1",
      senderId: ALICE_UID,
      memberUids: [ALICE_UID, BOB_UID],
      chunkIndex: 0,
      ivBase64: "MTIzNDU2Nzg5MDEy",
      encryptedPayload: "Y2h1bmtfMF9wYXlsb2Fk",
      createdAt: ts,
    })
  );
  await assertSucceeds(
    msgRef.collection("chunks").doc("chunk_0001").set({
      conversationId: "chat_media_chunks",
      messageId: "msg_video_1",
      senderId: ALICE_UID,
      memberUids: [ALICE_UID, BOB_UID],
      chunkIndex: 1,
      ivBase64: "MTIzNDU2Nzg5MDEy",
      encryptedPayload: "Y2h1bmtfMV9wYXlsb2Fk",
      createdAt: ts,
    })
  );

  // Oversized chunk payload (> 920000 chars) is rejected
  await assertFails(
    msgRef.collection("chunks").doc("chunk_0002").set({
      conversationId: "chat_media_chunks",
      messageId: "msg_video_1",
      senderId: ALICE_UID,
      memberUids: [ALICE_UID, BOB_UID],
      chunkIndex: 2,
      ivBase64: "MTIzNDU2Nzg5MDEy",
      encryptedPayload: "A".repeat(920001),
      createdAt: ts,
    })
  );

  // Chunks are immutable (update denied)
  await assertFails(
    msgRef.collection("chunks").doc("chunk_0000").update({
      encryptedPayload: "dGFtcGVyZWQ=",
    })
  );

  // Member Bob can read/list chunks
  await assertSucceeds(
    bobDb
      .collection("conversations")
      .doc("chat_media_chunks")
      .collection("messages")
      .doc("msg_video_1")
      .collection("chunks")
      .doc("chunk_0000")
      .get()
  );

  // Outsider Charlie cannot read or create chunks
  await assertFails(
    charlieDb
      .collection("conversations")
      .doc("chat_media_chunks")
      .collection("messages")
      .doc("msg_video_1")
      .collection("chunks")
      .doc("chunk_0000")
      .get()
  );
  await assertFails(
    charlieDb
      .collection("conversations")
      .doc("chat_media_chunks")
      .collection("messages")
      .doc("msg_video_1")
      .collection("chunks")
      .doc("chunk_evil")
      .set({
        conversationId: "chat_media_chunks",
        messageId: "msg_video_1",
        senderId: CHARLIE_UID,
        memberUids: [ALICE_UID, BOB_UID, CHARLIE_UID],
        chunkIndex: 0,
        ivBase64: "MTIzNDU2Nzg5MDEy",
        encryptedPayload: "ZXZpbA==",
        createdAt: ts,
      })
  );

  // Creator Alice can delete chunks
  await assertSucceeds(msgRef.collection("chunks").doc("chunk_0000").delete());
  await assertSucceeds(msgRef.collection("chunks").doc("chunk_0001").delete());
});

test("Developer account login: users_public create/sync preserves pre-assigned developer role and blocks self-escalation", async () => {
  const DEV_UID = "dev_account_001";
  const BANNED_DEV_UID = "dev_banned_002";

  // Seed pre-existing developer private docs via security-rules-disabled admin context
  await testEnv.withSecurityRulesDisabled(async (ctx) => {
    const adminDb = ctx.firestore();
    await adminDb.collection("users").doc(DEV_UID).set({
      userId: DEV_UID,
      email: "watsapp23032010@gmail.com",
      displayName: "Developer",
      handle: "@dev_admin",
      avatarBase64: "",
      preferredTheme: "dark",
      keyFingerprint: "SHA256:OLDKEY01",
      role: "developer",
      moderationStatus: "active",
      mutedUntilEpochMs: 0,
      moderationReason: "",
      moderatedBy: "",
      createdAt: ts,
      updatedAt: ts,
    });
    await adminDb.collection("users").doc(BANNED_DEV_UID).set({
      userId: BANNED_DEV_UID,
      email: "banned_dev@example.com",
      displayName: "Banned Dev",
      handle: "@banned_dev",
      avatarBase64: "",
      preferredTheme: "dark",
      keyFingerprint: "SHA256:BANNED01",
      role: "developer",
      moderationStatus: "banned",
      mutedUntilEpochMs: 0,
      moderationReason: "policy",
      moderatedBy: DEV_UID,
      createdAt: ts,
      updatedAt: ts,
    });
  });

  const devDb = testEnv.authenticatedContext(DEV_UID).firestore();
  const bannedDevDb = testEnv.authenticatedContext(BANNED_DEV_UID).firestore();
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();

  // 1. Developer can create users_public/{DEV_UID} with role='developer' when users/{DEV_UID} already has role='developer'
  await assertSucceeds(
    devDb.collection("users_public").doc(DEV_UID).set({
      userId: DEV_UID,
      displayName: "Developer",
      handle: "@dev_admin",
      avatarBase64: "",
      emailHash: hash64,
      publicKeyBase64: "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAE1234567890",
      keyFingerprint: "SHA256:NEWKEY01",
      avatarColorIndex: 1,
      isDiscoverable: true,
      isOnline: true,
      lastSeenAt: ts,
      role: "developer",
      moderationStatus: "active",
      mutedUntilEpochMs: 0,
      moderationReason: "",
      updatedAt: ts,
    })
  );

  // 2. Developer can update users/{DEV_UID} fingerprint while preserving developer role
  await assertSucceeds(
    devDb.collection("users").doc(DEV_UID).update({
      keyFingerprint: "SHA256:NEWKEY01",
      updatedAt: ts,
    })
  );

  // 3. If users_public/{DEV_UID} previously drifted to 'user', developer can sync presence + role='developer'
  await testEnv.withSecurityRulesDisabled(async (ctx) => {
    await ctx.firestore().collection("users_public").doc(DEV_UID).update({
      role: "user",
      updatedAt: ts,
    });
  });
  await assertSucceeds(
    devDb.collection("users_public").doc(DEV_UID).update({
      isOnline: true,
      lastSeenAt: ts,
      role: "developer",
      updatedAt: ts,
    })
  );

  // 4. Developer can list users and role_codes
  await assertSucceeds(devDb.collection("users").get());
  await assertSucceeds(devDb.collection("role_codes").get());

  // 5. Normal user Alice CANNOT self-escalate on users_public create or update
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).set({
      userId: ALICE_UID,
      email: "alice@example.com",
      displayName: "Alice",
      handle: "@alice",
      avatarBase64: "",
      preferredTheme: "dark",
      keyFingerprint: "SHA256:ALICE001",
      createdAt: ts,
      updatedAt: ts,
    })
  );
  await assertFails(
    aliceDb.collection("users_public").doc(ALICE_UID).set({
      userId: ALICE_UID,
      displayName: "Alice",
      handle: "@alice",
      avatarBase64: "",
      emailHash: hash64,
      publicKeyBase64: "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAE1234567890",
      keyFingerprint: "SHA256:ALICE001",
      avatarColorIndex: 2,
      isDiscoverable: true,
      isOnline: true,
      role: "developer",
      updatedAt: ts,
    })
  );
  // Bob (without private doc) also cannot create users_public with role='developer'
  await assertFails(
    bobDb.collection("users_public").doc(BOB_UID).set({
      userId: BOB_UID,
      displayName: "Bob",
      handle: "@bob",
      avatarBase64: "",
      emailHash: hash64,
      publicKeyBase64: "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAE1234567890",
      keyFingerprint: "SHA256:BOB00001",
      avatarColorIndex: 3,
      isDiscoverable: true,
      isOnline: true,
      role: "developer",
      updatedAt: ts,
    })
  );
  // Alice creates valid normal users_public doc, then tries to update role to developer -> fails
  await assertSucceeds(
    aliceDb.collection("users_public").doc(ALICE_UID).set({
      userId: ALICE_UID,
      displayName: "Alice",
      handle: "@alice",
      avatarBase64: "",
      emailHash: hash64,
      publicKeyBase64: "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAE1234567890",
      keyFingerprint: "SHA256:ALICE001",
      avatarColorIndex: 2,
      isDiscoverable: true,
      isOnline: true,
      role: "user",
      updatedAt: ts,
    })
  );
  await assertFails(
    aliceDb.collection("users_public").doc(ALICE_UID).update({
      isOnline: true,
      role: "developer",
      updatedAt: ts,
    })
  );

  // 6. Banned developer CANNOT create users_public
  await assertFails(
    bannedDevDb.collection("users_public").doc(BANNED_DEV_UID).set({
      userId: BANNED_DEV_UID,
      displayName: "Banned Dev",
      handle: "@banned_dev",
      avatarBase64: "",
      emailHash: hash64,
      publicKeyBase64: "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAE1234567890",
      keyFingerprint: "SHA256:BANNED01",
      avatarColorIndex: 4,
      isDiscoverable: true,
      isOnline: true,
      role: "developer",
      updatedAt: ts,
    })
  );
});



