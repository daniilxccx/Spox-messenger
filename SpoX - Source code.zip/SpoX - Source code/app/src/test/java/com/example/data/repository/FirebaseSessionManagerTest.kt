package com.example.data.repository

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.google.firebase.FirebaseApp
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class FirebaseSessionManagerTest {

    private lateinit var context: Context

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        context.getSharedPreferences("spox_active_session", Context.MODE_PRIVATE)
            .edit()
            .clear()
            .commit()
    }

    @Test
    fun resolveTargetAppForGoogleEmail_assignsDistinctSlotsPerSavedAccountAndActivatesCleanly() {
        val defaultSession = FirebaseSessionManager.ensureInitialized(context)
        assertNotNull(defaultSession)

        val acc1 = SavedAccount(
            uid = "uid_one",
            email = "alice@gmail.com",
            displayName = "Alice",
            handle = "@alice",
            sessionAppName = FirebaseSessionManager.DEFAULT_SESSION_NAME
        )

        // Existing saved account reuses its own assigned slot
        val targetForAcc1 = FirebaseSessionManager.resolveTargetAppForGoogleEmail(
            context = context,
            googleEmail = "ALICE@gmail.com",
            savedAccounts = listOf(acc1)
        )
        assertEquals(FirebaseApp.DEFAULT_APP_NAME, targetForAcc1?.name)

        // Adding a second Google account gets an isolated slot instead of clobbering [DEFAULT]
        val targetForAcc2 = FirebaseSessionManager.resolveTargetAppForGoogleEmail(
            context = context,
            googleEmail = "bob@gmail.com",
            savedAccounts = listOf(acc1)
        )
        assertNotNull(targetForAcc2)
        assertNotEquals(FirebaseApp.DEFAULT_APP_NAME, targetForAcc2!!.name)

        // Switching active session updates activeSession state flow cleanly
        val activated = FirebaseSessionManager.activateApp(context, targetForAcc2.name)
        assertEquals(targetForAcc2.name, activated?.appName)
        assertEquals(targetForAcc2.name, FirebaseSessionManager.activeSession.value?.appName)

        // Unauthenticated slots return false for live session lookup
        assertFalse(FirebaseSessionManager.hasLiveSessionForAccount(context, acc1))
        assertTrue(FirebaseSessionManager.getActiveAuth(context) != null)
    }
}
