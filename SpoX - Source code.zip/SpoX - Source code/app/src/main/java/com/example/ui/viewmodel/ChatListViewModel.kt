package com.example.ui.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.AppThemeMode
import com.example.data.model.CallSession
import com.example.data.model.Conversation
import com.example.data.model.CustomRolePermission
import com.example.data.model.CustomRoleRecord
import com.example.data.model.DeletedAccountRecord
import com.example.data.model.ModerationStatus
import com.example.data.model.PublicUserProfile
import com.example.data.model.RoleCodeRecord
import com.example.data.model.UserPrivateProfile
import com.example.data.model.UserRole
import com.example.data.repository.CallRepository
import com.example.data.repository.ChatRepository
import com.example.notifications.ActiveChatTracker
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}

data class GeneratedRoleCode(
    val plainCode: String,
    val targetRole: UserRole
)

enum class RegistrationStatus {
    CHECKING,
    NEEDS_PROFILE_SETUP,
    COMPLETED
}

enum class NetworkSyncPhase {
    WAITING_FOR_NETWORK,
    UPDATING,
    SYNCED
}

data class TopStatusUiState(
    val phase: NetworkSyncPhase = NetworkSyncPhase.UPDATING,
    val isVerifyingAccount: Boolean = false,
    val isNetworkConnected: Boolean = true
)

fun resolveTopStatusUiState(
    isNetworkConnected: Boolean,
    isVerifyingAccount: Boolean,
    isConversationsFromCache: Boolean,
    isRefreshingOnReconnect: Boolean,
    isConversationsLoading: Boolean
): TopStatusUiState {
    val phase = when {
        !isNetworkConnected -> NetworkSyncPhase.WAITING_FOR_NETWORK
        isVerifyingAccount || isConversationsFromCache || isRefreshingOnReconnect || isConversationsLoading ->
            NetworkSyncPhase.UPDATING
        else -> NetworkSyncPhase.SYNCED
    }
    return TopStatusUiState(
        phase = phase,
        isVerifyingAccount = isVerifyingAccount,
        isNetworkConnected = isNetworkConnected
    )
}

data class IncomingMessageAlert(
    val chatId: String,
    val title: String,
    val senderId: String = "",
    val senderName: String,
    val senderRole: String = "user",
    val customRoleName: String = "",
    val customRoleBadge: String = "",
    val customRoleColorHex: String = "",
    val senderAvatarBase64: String = "",
    val senderAvatarColorIndex: Int = 0,
    val isGroup: Boolean = false,
    val body: String,
    val unreadCount: Int,
    val msgTimeMs: Long
)

class ChatListViewModel(
    private val chatRepository: ChatRepository,
    private val callRepository: CallRepository,
    private val currentUserId: String,
    private val userEmail: String,
    private val userDisplayName: String,
    initialTheme: AppThemeMode,
    private val networkConnectedFlow: StateFlow<Boolean> = MutableStateFlow(true)
) : ViewModel() {

    @Volatile
    private var latestThemeWire = initialTheme.wireValue

    private val _actionMessage = MutableStateFlow<String?>(null)
    val actionMessage: StateFlow<String?> = _actionMessage.asStateFlow()

    private val _isBusy = MutableStateFlow(false)
    val isBusy: StateFlow<Boolean> = _isBusy.asStateFlow()

    private val _peopleSearchQuery = MutableStateFlow("")
    val peopleSearchQuery: StateFlow<String> = _peopleSearchQuery.asStateFlow()

    private val _peopleSearchResults = MutableStateFlow<List<PublicUserProfile>>(emptyList())
    val peopleSearchResults: StateFlow<List<PublicUserProfile>> = _peopleSearchResults.asStateFlow()

    private val _isSearchingPeople = MutableStateFlow(false)
    val isSearchingPeople: StateFlow<Boolean> = _isSearchingPeople.asStateFlow()

    private val _peopleSearchError = MutableStateFlow<String?>(null)
    val peopleSearchError: StateFlow<String?> = _peopleSearchError.asStateFlow()

    private val _lastGeneratedRoleCode = MutableStateFlow<GeneratedRoleCode?>(null)
    val lastGeneratedRoleCode: StateFlow<GeneratedRoleCode?> = _lastGeneratedRoleCode.asStateFlow()

    private val _registrationStatus = MutableStateFlow(RegistrationStatus.CHECKING)
    val registrationStatus: StateFlow<RegistrationStatus> = _registrationStatus.asStateFlow()

    private val _registrationError = MutableStateFlow<String?>(null)
    val registrationError: StateFlow<String?> = _registrationError.asStateFlow()

    private val _activeOpenChatId = MutableStateFlow<String?>(null)
    private val _isAppInForeground = MutableStateFlow(true)

    private val _incomingMessageAlerts = MutableSharedFlow<IncomingMessageAlert>(extraBufferCapacity = 16)
    val incomingMessageAlerts: SharedFlow<IncomingMessageAlert> = _incomingMessageAlerts.asSharedFlow()

    private val _incomingCallAlerts = MutableSharedFlow<CallSession>(extraBufferCapacity = 8)
    val incomingCallAlerts: SharedFlow<CallSession> = _incomingCallAlerts.asSharedFlow()

    private var peopleSearchJob: Job? = null
    private var presenceHeartbeatJob: Job? = null
    @Volatile
    private var isResourceSavingMode: Boolean = false
    private var hasConvBaseline = false
    private val lastConvSignatures = mutableMapOf<String, Pair<Long, Int>>()
    private val notifiedCallIds = mutableSetOf<String>()

    private val _isVerifyingProfile = MutableStateFlow(true)
    private val _isConversationsFromCache = MutableStateFlow(true)
    private val _isRefreshingOnReconnect = MutableStateFlow(false)
    @Volatile
    private var needsProfileVerificationRetry: Boolean = false
    private var profileVerificationJob: Job? = null

    private val conversationsRefreshTrigger = MutableStateFlow(0)

    @OptIn(ExperimentalCoroutinesApi::class)
    val conversationsState: StateFlow<UiState<List<Conversation>>> = conversationsRefreshTrigger
        .flatMapLatest {
            chatRepository
                .observeConversationsWithMetadata(currentUserId)
                .map<ChatRepository.ConversationsSnapshotResult, UiState<List<Conversation>>> { snap ->
                    _isConversationsFromCache.value = snap.isFromCache
                    UiState.Success(snap.conversations)
                }
                .catch { error ->
                    _isConversationsFromCache.value = false
                    val fsError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (fsError == null && error is CancellationException) throw error
                    if (!chatRepository.isCurrentUser(currentUserId)) {
                        throw CancellationException("Auth session changed")
                    }
                    val root = fsError ?: error
                    Log.w(TAG, "Error observing conversations", root)
                    emit(UiState.Error(root.message ?: "Не удалось загрузить чаты"))
                }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(0L),
            initialValue = UiState.Loading
        )

    val topStatusUiState: StateFlow<TopStatusUiState> = combine(
        networkConnectedFlow,
        _isVerifyingProfile,
        _isConversationsFromCache,
        _isRefreshingOnReconnect,
        conversationsState
    ) { isConnected, isVerifying, isFromCache, isRefreshing, convState ->
        resolveTopStatusUiState(
            isNetworkConnected = isConnected,
            isVerifyingAccount = isVerifying,
            isConversationsFromCache = isFromCache,
            isRefreshingOnReconnect = isRefreshing,
            isConversationsLoading = convState is UiState.Loading
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.Eagerly,
        initialValue = TopStatusUiState(
            phase = if (networkConnectedFlow.value) NetworkSyncPhase.UPDATING else NetworkSyncPhase.WAITING_FOR_NETWORK,
            isVerifyingAccount = true,
            isNetworkConnected = networkConnectedFlow.value
        )
    )

    fun retryLoadConversations() {
        conversationsRefreshTrigger.value += 1
    }

    val totalUnreadCount: StateFlow<Int> = conversationsState
        .map { state ->
            val list = (state as? UiState.Success)?.data ?: emptyList()
            list.sumOf { it.unreadCountFor(currentUserId) }
        }
        .distinctUntilChanged()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(0L),
            initialValue = 0
        )

    val directoryUsers: StateFlow<List<PublicUserProfile>> = chatRepository
        .observeDiscoverableUsers()
        .catch { error ->
            val fsError = generateSequence(error) { it.cause }
                .filterIsInstance<FirebaseFirestoreException>()
                .firstOrNull()
            if (fsError == null && error is CancellationException) throw error
            Log.w(TAG, "Error observing user directory", fsError ?: error)
            emit(emptyList())
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(0L),
            initialValue = emptyList()
        )

    private val directoryUserIds: StateFlow<Set<String>> = directoryUsers
        .map { list -> list.mapTo(mutableSetOf()) { it.userId } }
        .distinctUntilChanged()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(0L),
            initialValue = emptySet()
        )

    @OptIn(ExperimentalCoroutinesApi::class)
    private val livePeerProfiles: StateFlow<Map<String, PublicUserProfile>> = combine(
        conversationsState
            .map { state ->
                val list = (state as? UiState.Success)?.data.orEmpty()
                list.flatMap { it.memberUids }
                    .filter { it != currentUserId && it.isNotBlank() }
                    .distinct()
                    .sorted()
            }
            .distinctUntilChanged(),
        directoryUserIds
    ) { peerUids, knownIds ->
        peerUids.filterNot { it in knownIds }
    }
        .distinctUntilChanged()
        .flatMapLatest { missingPeerUids ->
            chatRepository.observePublicProfilesByIds(missingPeerUids)
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(0L),
            initialValue = emptyMap()
        )

    val chatPeersMap: StateFlow<Map<String, PublicUserProfile>> = combine(
        directoryUsers,
        livePeerProfiles
    ) { directory, livePeers ->
        buildMap {
            directory.forEach { put(it.userId, it) }
            livePeers.forEach { (uid, profile) -> put(uid, profile) }
        }
    }
        .distinctUntilChanged()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(0L),
            initialValue = emptyMap()
        )

    val privateProfile: StateFlow<UserPrivateProfile?> = chatRepository
        .observePrivateProfile(currentUserId)
        .catch { error ->
            val fsError = generateSequence(error) { it.cause }
                .filterIsInstance<FirebaseFirestoreException>()
                .firstOrNull()
            if (fsError == null && error is CancellationException) throw error
            Log.w(TAG, "Error observing private profile", fsError ?: error)
            emit(null)
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(0L),
            initialValue = null
        )

    val deletedAccountRecord: StateFlow<DeletedAccountRecord?> = chatRepository
        .observeDeletedAccount(currentUserId)
        .catch { error ->
            val fsError = generateSequence(error) { it.cause }
                .filterIsInstance<FirebaseFirestoreException>()
                .firstOrNull()
            if (fsError == null && error is CancellationException) throw error
            Log.w(TAG, "Error observing deleted account status", fsError ?: error)
            emit(null)
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(0L),
            initialValue = null
        )

    val customRoles: StateFlow<List<CustomRoleRecord>> = chatRepository
        .observeCustomRoles()
        .catch { error ->
            val fsError = generateSequence(error) { it.cause }
                .filterIsInstance<FirebaseFirestoreException>()
                .firstOrNull()
            if (fsError == null && error is CancellationException) throw error
            Log.w(TAG, "Error observing custom roles", fsError ?: error)
            emit(emptyList())
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(0L),
            initialValue = emptyList()
        )

    @OptIn(ExperimentalCoroutinesApi::class)
    val roleCodes: StateFlow<List<RoleCodeRecord>> = privateProfile
        .map {
            it != null && !it.isBanned() && (
                UserRole.fromWire(it.role) == UserRole.DEVELOPER ||
                    it.hasPermission(CustomRolePermission.ISSUE_TESTER_CODES)
                )
        }
        .distinctUntilChanged()
        .flatMapLatest { canViewCodes ->
            if (canViewCodes) {
                chatRepository.observeRoleCodes()
                    .catch { error ->
                        val fsError = generateSequence(error) { it.cause }
                            .filterIsInstance<FirebaseFirestoreException>()
                            .firstOrNull()
                        if (fsError == null && error is CancellationException) throw error
                        Log.w(TAG, "Error observing role codes", fsError ?: error)
                        emit(emptyList())
                    }
            } else {
                flowOf(emptyList())
            }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(0L),
            initialValue = emptyList()
        )

    @OptIn(ExperimentalCoroutinesApi::class)
    val allUsersForAdmin: StateFlow<List<UserPrivateProfile>> = privateProfile
        .map {
            it != null && !it.isBanned() && (
                UserRole.fromWire(it.role) == UserRole.DEVELOPER ||
                    it.hasPermission(CustomRolePermission.VIEW_MODERATION) ||
                    it.hasPermission(CustomRolePermission.MODERATE_MUTE) ||
                    it.hasPermission(CustomRolePermission.MODERATE_BAN)
                )
        }
        .distinctUntilChanged()
        .flatMapLatest { canViewUsers ->
            if (canViewUsers) {
                chatRepository.observeAllUsersForAdmin()
                    .catch { error ->
                        val fsError = generateSequence(error) { it.cause }
                            .filterIsInstance<FirebaseFirestoreException>()
                            .firstOrNull()
                        if (fsError == null && error is CancellationException) throw error
                        Log.w(TAG, "Error observing admin users", fsError ?: error)
                        emit(emptyList())
                    }
            } else {
                flowOf(emptyList())
            }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(0L),
            initialValue = emptyList()
        )

    val callHistory: StateFlow<List<CallSession>> = callRepository
        .observeMyCalls(currentUserId)
        .catch { error ->
            val fsError = generateSequence(error) { it.cause }
                .filterIsInstance<FirebaseFirestoreException>()
                .firstOrNull()
            if (fsError == null && error is CancellationException) throw error
            Log.w(TAG, "Error observing calls", fsError ?: error)
            emit(emptyList())
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(0L),
            initialValue = emptyList()
        )

    val activeCalls: StateFlow<List<CallSession>> = callHistory
        .map { calls -> calls.filter { it.status == "ringing" || it.status == "active" } }
        .distinctUntilChanged()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(0L),
            initialValue = emptyList()
        )

    @Volatile
    private var initialPresenceSettled = false

    private fun launchProfileVerification(forceWhenOnline: Boolean = false) {
        if (profileVerificationJob?.isActive == true && !forceWhenOnline) return
        profileVerificationJob?.cancel()
        profileVerificationJob = viewModelScope.launch {
            if (!networkConnectedFlow.value) {
                needsProfileVerificationRetry = true
                _isVerifyingProfile.value = true
                return@launch
            }
            _isVerifyingProfile.value = true
            val result = runCatching {
                chatRepository.checkRegistrationAndSyncSignedInUserProfile(
                    uid = currentUserId,
                    email = userEmail,
                    displayName = userDisplayName,
                    preferredTheme = latestThemeWire
                )
            }
            result.onSuccess { needsSetup ->
                needsProfileVerificationRetry = false
                _isVerifyingProfile.value = false
                if (needsSetup) {
                    _registrationStatus.value = RegistrationStatus.NEEDS_PROFILE_SETUP
                } else {
                    initialPresenceSettled = true
                    _registrationStatus.value = RegistrationStatus.COMPLETED
                }
            }.onFailure { error ->
                if (error is CancellationException) throw error
                if (!chatRepository.isCurrentUser(currentUserId)) return@onFailure
                Log.w(TAG, "Failed to verify/sync user profile", error)
                val isNetworkError = !networkConnectedFlow.value ||
                    generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .any {
                            it.code == FirebaseFirestoreException.Code.UNAVAILABLE ||
                                it.code == FirebaseFirestoreException.Code.DEADLINE_EXCEEDED
                        }
                if (isNetworkError) {
                    needsProfileVerificationRetry = true
                } else {
                    needsProfileVerificationRetry = false
                    _isVerifyingProfile.value = false
                    _actionMessage.value = "Ошибка синхронизации профиля: ${error.localizedMessage ?: "неизвестно"}"
                    _registrationStatus.value = RegistrationStatus.COMPLETED
                }
            }
        }
    }

    init {
        launchProfileVerification()

        viewModelScope.launch {
            var wasConnected = networkConnectedFlow.value
            var reconnectJob: Job? = null
            networkConnectedFlow.collect { isConnected ->
                if (!isConnected) {
                    wasConnected = false
                    reconnectJob?.cancel()
                    _isRefreshingOnReconnect.value = false
                } else if (!wasConnected) {
                    wasConnected = true
                    _isRefreshingOnReconnect.value = true
                    if (needsProfileVerificationRetry || _registrationStatus.value == RegistrationStatus.CHECKING) {
                        launchProfileVerification(forceWhenOnline = true)
                    }
                    reconnectJob?.cancel()
                    reconnectJob = viewModelScope.launch {
                        val synced = chatRepository.verifyConversationsFromServer(currentUserId)
                        if (synced) {
                            _isConversationsFromCache.value = false
                        }
                        if (_registrationStatus.value == RegistrationStatus.COMPLETED) {
                            chatRepository.updatePresence(currentUserId, isOnline = true)
                        }
                        _isRefreshingOnReconnect.value = false
                    }
                }
            }
        }

        // Watch incoming messages across chats for system notifications & heads-up banners
        viewModelScope.launch {
            conversationsState.collect { state ->
                val list = (state as? UiState.Success)?.data ?: return@collect
                if (!hasConvBaseline) {
                    list.forEach { conv ->
                        val timeMs = (conv.updatedAt ?: conv.createdAt)?.toDate()?.time ?: 0L
                        lastConvSignatures[conv.id] = timeMs to conv.unreadCountFor(currentUserId)
                    }
                    hasConvBaseline = true
                    return@collect
                }

                val usersById = chatPeersMap.value
                list.forEach { conv ->
                    val unread = conv.unreadCountFor(currentUserId)
                    val timeMs = (conv.updatedAt ?: conv.createdAt)?.toDate()?.time ?: 0L
                    val sig = timeMs to unread
                    val prev = lastConvSignatures[conv.id]
                    lastConvSignatures[conv.id] = sig

                    val isNewIncoming = !conv.isSavedMessages(currentUserId) &&
                        unread > 0 &&
                        conv.lastMessageSenderId.isNotBlank() &&
                        conv.lastMessageSenderId != currentUserId &&
                        (prev == null || unread > prev.second || (timeMs > prev.first && unread > 0))

                    if (isNewIncoming) {
                        val isCurrentlyViewingThisChat = _isAppInForeground.value && _activeOpenChatId.value == conv.id
                        if (!isCurrentlyViewingThisChat) {
                            val senderId = conv.lastMessageSenderId
                            val cachedSenderProfile = usersById[senderId]
                            viewModelScope.launch {
                                val senderProfile = cachedSenderProfile
                                    ?: runCatching { chatRepository.getPublicProfile(senderId) }.getOrNull()
                                val peerUid = conv.memberUids.firstOrNull { it != currentUserId }
                                val chatTitle = if (conv.isGroup) {
                                    conv.title.ifBlank { "Групповой чат" }
                                } else {
                                    usersById[peerUid]?.displayName
                                        ?: (if (peerUid == senderId) senderProfile?.displayName else null)
                                        ?: conv.memberNames[peerUid]
                                        ?: conv.title.ifBlank { "SpoX" }
                                }
                                val fallbackBody = when (conv.lastMessageType) {
                                    "voice" -> "Голосовое сообщение"
                                    "image" -> "Зашифрованное фото"
                                    "file" -> "Зашифрованный файл"
                                    "call_event" -> conv.lastMessagePreview.ifBlank { "Событие звонка" }
                                    else -> conv.lastMessagePreview.ifBlank { "Новое зашифрованное сообщение" }
                                }
                                val decryptedBody = runCatching {
                                    chatRepository.resolveLatestIncomingMessagePreview(
                                        conversation = conv,
                                        currentUserId = currentUserId,
                                        expectedSenderId = senderId
                                    )
                                }.getOrNull()?.takeIf { it.isNotBlank() } ?: fallbackBody
                                val senderDisplay = senderProfile?.displayName?.ifBlank { null }
                                    ?: conv.memberNames[senderId]?.ifBlank { null }
                                    ?: chatTitle
                                val avatarSeed = senderProfile?.avatarColorIndex?.toInt()
                                    ?: kotlin.math.abs(senderDisplay.hashCode())
                                _incomingMessageAlerts.tryEmit(
                                    IncomingMessageAlert(
                                        chatId = conv.id,
                                        title = chatTitle,
                                        senderId = senderId,
                                        senderName = senderDisplay,
                                        senderRole = senderProfile?.role.orEmpty().ifBlank { "user" },
                                        customRoleName = senderProfile?.customRoleName.orEmpty(),
                                        customRoleBadge = senderProfile?.customRoleBadge.orEmpty(),
                                        customRoleColorHex = senderProfile?.customRoleColorHex.orEmpty(),
                                        senderAvatarBase64 = senderProfile?.avatarBase64.orEmpty(),
                                        senderAvatarColorIndex = avatarSeed,
                                        isGroup = conv.isGroup,
                                        body = decryptedBody,
                                        unreadCount = unread,
                                        msgTimeMs = timeMs
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }

        // Watch incoming ringing calls for system notifications
        viewModelScope.launch {
            activeCalls.collect { calls ->
                val activeIds = calls.map { it.id }.toSet()
                notifiedCallIds.retainAll(activeIds)
                calls.forEach { call ->
                    val isIncomingRinging = call.status == "ringing" &&
                        call.callerId != currentUserId &&
                        currentUserId !in call.activeParticipantUids
                    if (isIncomingRinging && call.id !in notifiedCallIds) {
                        notifiedCallIds.add(call.id)
                        _incomingCallAlerts.tryEmit(call)
                    }
                }
            }
        }
    }

    fun setActiveOpenChatId(chatId: String?) {
        _activeOpenChatId.value = chatId
        ActiveChatTracker.activeChatId = chatId
    }

    fun setResourceSavingMode(enabled: Boolean) {
        if (isResourceSavingMode == enabled) return
        isResourceSavingMode = enabled
        if (_isAppInForeground.value && presenceHeartbeatJob?.isActive == true) {
            presenceHeartbeatJob?.cancel()
            presenceHeartbeatJob = viewModelScope.launch {
                val intervalMs = if (isResourceSavingMode) {
                    RESOURCE_SAVING_HEARTBEAT_INTERVAL_MS
                } else {
                    PRESENCE_HEARTBEAT_INTERVAL_MS
                }
                delay(intervalMs)
                while (isActive) {
                    if (_registrationStatus.value == RegistrationStatus.COMPLETED) {
                        chatRepository.updatePresence(currentUserId, isOnline = true)
                    }
                    delay(
                        if (isResourceSavingMode) RESOURCE_SAVING_HEARTBEAT_INTERVAL_MS
                        else PRESENCE_HEARTBEAT_INTERVAL_MS
                    )
                }
            }
        }
    }

    fun setAppInForeground(inForeground: Boolean) {
        _isAppInForeground.value = inForeground
        ActiveChatTracker.isAppInForeground = inForeground
        if (inForeground) {
            if (presenceHeartbeatJob?.isActive == true) return
            val skipImmediateBeat = initialPresenceSettled || _registrationStatus.value == RegistrationStatus.CHECKING
            initialPresenceSettled = false
            presenceHeartbeatJob = viewModelScope.launch {
                val initialIntervalMs = if (isResourceSavingMode) {
                    RESOURCE_SAVING_HEARTBEAT_INTERVAL_MS
                } else {
                    PRESENCE_HEARTBEAT_INTERVAL_MS
                }
                if (skipImmediateBeat) {
                    delay(initialIntervalMs)
                }
                while (isActive) {
                    if (_registrationStatus.value == RegistrationStatus.COMPLETED) {
                        chatRepository.updatePresence(currentUserId, isOnline = true)
                    }
                    delay(
                        if (isResourceSavingMode) RESOURCE_SAVING_HEARTBEAT_INTERVAL_MS
                        else PRESENCE_HEARTBEAT_INTERVAL_MS
                    )
                }
            }
        } else {
            presenceHeartbeatJob?.cancel()
            presenceHeartbeatJob = null
            if (_registrationStatus.value == RegistrationStatus.COMPLETED) {
                viewModelScope.launch {
                    withContext(NonCancellable) {
                        chatRepository.updatePresence(currentUserId, isOnline = false)
                    }
                }
            }
        }
    }

    suspend fun markOfflineNow() {
        presenceHeartbeatJob?.cancel()
        presenceHeartbeatJob = null
        withContext(NonCancellable) {
            chatRepository.updatePresence(currentUserId, isOnline = false)
        }
    }

    fun filterUsers(
        users: List<PublicUserProfile>,
        query: String,
        excludeCurrentUser: Boolean = true
    ): List<PublicUserProfile> {
        return chatRepository.filterAndRankUsers(
            users = users,
            rawQuery = query,
            excludeUid = if (excludeCurrentUser) currentUserId else null
        )
    }

    fun computeEmailHash(query: String): String? = chatRepository.computeEmailHash(query)

    fun updatePeopleSearchQuery(query: String) {
        _peopleSearchQuery.value = query
        _peopleSearchError.value = null
        val trimmed = query.trim()
        if (trimmed.isEmpty()) {
            peopleSearchJob?.cancel()
            _isSearchingPeople.value = false
            _peopleSearchResults.value = emptyList()
            return
        }

        _peopleSearchResults.value = filterUsers(directoryUsers.value, trimmed)
        peopleSearchJob?.cancel()
        peopleSearchJob = viewModelScope.launch {
            _isSearchingPeople.value = true
            delay(200)
            runCatching {
                chatRepository.searchUsers(trimmed, excludeUid = currentUserId)
            }.onSuccess { results ->
                if (_peopleSearchQuery.value.trim() == trimmed) {
                    _peopleSearchResults.value = results
                    _isSearchingPeople.value = false
                }
            }.onFailure { error ->
                if (error is CancellationException) throw error
                _isSearchingPeople.value = false
                _peopleSearchError.value = error.localizedMessage ?: "Не удалось выполнить поиск"
            }
        }
    }

    fun clearPeopleSearch() {
        peopleSearchJob?.cancel()
        _peopleSearchQuery.value = ""
        _peopleSearchResults.value = emptyList()
        _isSearchingPeople.value = false
        _peopleSearchError.value = null
    }

    private suspend fun resolveMyPublicProfile(): PublicUserProfile {
        directoryUsers.value.firstOrNull { it.userId == currentUserId && it.publicKeyBase64.isNotBlank() }?.let {
            return it
        }
        chatPeersMap.value[currentUserId]?.takeIf { it.publicKeyBase64.isNotBlank() }?.let {
            return it
        }
        return chatRepository.getOrSyncCurrentPublicProfile(
            uid = currentUserId,
            email = userEmail,
            displayName = privateProfile.value?.displayName?.ifBlank { userDisplayName } ?: userDisplayName,
            preferredTheme = latestThemeWire
        )
    }

    private fun findExistingDirectConversation(peerUid: String): Conversation? {
        val list = (conversationsState.value as? UiState.Success)?.data ?: return null
        return list.firstOrNull { conv ->
            !conv.isGroup &&
                !conv.isSavedMessages(currentUserId) &&
                conv.memberUids.size == 2 &&
                currentUserId in conv.memberUids &&
                peerUid in conv.memberUids
        }
    }

    fun openSavedMessages(onOpened: (String) -> Unit) {
        val list = (conversationsState.value as? UiState.Success)?.data.orEmpty()
        val existingSaved = list.firstOrNull { it.isSavedMessages(currentUserId) }
        if (existingSaved != null && !existingSaved.memberKeyEnvelopes[currentUserId].isNullOrBlank()) {
            onOpened(existingSaved.id)
            return
        }
        if (_isBusy.value) return
        viewModelScope.launch {
            _isBusy.value = true
            runCatching {
                val me = resolveMyPublicProfile()
                chatRepository.getOrCreateSavedMessagesChat(me)
            }.onSuccess { chatId ->
                _isBusy.value = false
                onOpened(chatId)
            }.onFailure { error ->
                _isBusy.value = false
                _actionMessage.value = error.localizedMessage ?: "Не удалось открыть Избранное"
            }
        }
    }

    fun startDirectChat(peer: PublicUserProfile, onOpened: (String) -> Unit) {
        if (peer.userId == currentUserId) {
            openSavedMessages(onOpened)
            return
        }
        val existingDm = findExistingDirectConversation(peer.userId)
        if (existingDm != null &&
            !existingDm.memberKeyEnvelopes[currentUserId].isNullOrBlank() &&
            !existingDm.memberKeyEnvelopes[peer.userId].isNullOrBlank()
        ) {
            onOpened(existingDm.id)
            return
        }
        if (_isBusy.value) return
        viewModelScope.launch {
            _isBusy.value = true
            runCatching {
                val me = resolveMyPublicProfile()
                chatRepository.getOrCreateDirectChat(me, peer)
            }.onSuccess { chatId ->
                _isBusy.value = false
                onOpened(chatId)
            }.onFailure { error ->
                _isBusy.value = false
                _actionMessage.value = error.localizedMessage ?: "Не удалось создать личный чат"
            }
        }
    }

    fun findAndStartDirectChat(query: String, onOpened: (String) -> Unit) {
        val cleaned = query.trim()
        if (cleaned.isBlank()) {
            _actionMessage.value = "Введите имя, @юзернейм или email"
            return
        }
        if (_isBusy.value) return
        viewModelScope.launch {
            _isBusy.value = true
            runCatching {
                val found = filterUsers(directoryUsers.value, cleaned).firstOrNull()
                    ?: chatRepository.searchUsers(cleaned, excludeUid = currentUserId).firstOrNull()
                    ?: throw IllegalStateException("Пользователь не найден или скрыт в поиске")
                val existingDm = findExistingDirectConversation(found.userId)
                if (existingDm != null &&
                    !existingDm.memberKeyEnvelopes[currentUserId].isNullOrBlank() &&
                    !existingDm.memberKeyEnvelopes[found.userId].isNullOrBlank()
                ) {
                    existingDm.id
                } else {
                    val me = resolveMyPublicProfile()
                    chatRepository.getOrCreateDirectChat(me, found)
                }
            }.onSuccess { chatId ->
                _isBusy.value = false
                onOpened(chatId)
            }.onFailure { error ->
                _isBusy.value = false
                _actionMessage.value = error.localizedMessage ?: "Пользователь не найден"
            }
        }
    }

    fun createGroupChat(
        title: String,
        selectedMembers: List<PublicUserProfile>,
        description: String = "",
        onCreated: (String) -> Unit
    ) {
        viewModelScope.launch {
            _isBusy.value = true
            runCatching {
                val me = resolveMyPublicProfile()
                chatRepository.createGroupChat(title, me, selectedMembers, description)
            }.onSuccess { chatId ->
                _isBusy.value = false
                onCreated(chatId)
            }.onFailure { error ->
                _isBusy.value = false
                _actionMessage.value = error.localizedMessage ?: "Не удалось создать группу"
            }
        }
    }

    fun deleteConversation(
        conversation: Conversation,
        onDeleted: () -> Unit = {}
    ) {
        if (_isBusy.value) return
        viewModelScope.launch {
            _isBusy.value = true
            runCatching {
                chatRepository.deleteConversation(conversation)
            }.onSuccess {
                _isBusy.value = false
                _actionMessage.value = if (conversation.isGroup) {
                    "Группа «${conversation.title}» удалена"
                } else if (conversation.isSavedMessages(currentUserId)) {
                    "Чат «Избранное» удалён"
                } else {
                    "Чат удалён"
                }
                onDeleted()
            }.onFailure { error ->
                _isBusy.value = false
                _actionMessage.value = error.localizedMessage ?: "Не удалось удалить чат"
            }
        }
    }

    fun leaveGroup(
        conversation: Conversation,
        onLeft: () -> Unit = {}
    ) {
        if (_isBusy.value) return
        viewModelScope.launch {
            _isBusy.value = true
            runCatching {
                chatRepository.leaveGroupChat(conversation, currentUserId)
            }.onSuccess {
                _isBusy.value = false
                _actionMessage.value = "Вы покинули группу «${conversation.title}»"
                onLeft()
            }.onFailure { error ->
                _isBusy.value = false
                _actionMessage.value = error.localizedMessage ?: "Не удалось покинуть группу"
            }
        }
    }

    fun completeRegistrationProfile(
        displayName: String,
        rawUsername: String,
        avatarBase64: String,
        preferredTheme: AppThemeMode? = null
    ) {
        if (_isBusy.value) return
        val themeWire = preferredTheme?.wireValue ?: latestThemeWire
        latestThemeWire = themeWire
        viewModelScope.launch {
            _isBusy.value = true
            _registrationError.value = null
            runCatching {
                chatRepository.syncSignedInUserProfile(
                    uid = currentUserId,
                    email = userEmail,
                    displayName = displayName,
                    preferredTheme = themeWire,
                    rawUsername = rawUsername,
                    avatarBase64 = avatarBase64
                )
            }.onSuccess {
                _isBusy.value = false
                _registrationStatus.value = RegistrationStatus.COMPLETED
            }.onFailure { error ->
                _isBusy.value = false
                _registrationError.value = error.localizedMessage ?: "Не удалось завершить регистрацию"
            }
        }
    }

    fun clearRegistrationError() {
        _registrationError.value = null
    }

    fun updateProfile(
        displayName: String,
        rawUsername: String,
        avatarBase64: String,
        onSuccess: () -> Unit = {}
    ) {
        viewModelScope.launch {
            _isBusy.value = true
            runCatching {
                chatRepository.updateUserProfile(
                    uid = currentUserId,
                    displayName = displayName,
                    rawUsername = rawUsername,
                    avatarBase64 = avatarBase64
                )
            }.onSuccess {
                _isBusy.value = false
                _actionMessage.value = "Профиль обновлён"
                onSuccess()
            }.onFailure { error ->
                _isBusy.value = false
                _actionMessage.value = error.localizedMessage ?: "Не удалось обновить профиль"
            }
        }
    }

    fun deleteUsername(
        currentDisplayName: String,
        currentAvatarBase64: String,
        onSuccess: () -> Unit = {}
    ) {
        viewModelScope.launch {
            _isBusy.value = true
            runCatching {
                chatRepository.updateUserProfile(
                    uid = currentUserId,
                    displayName = currentDisplayName,
                    rawUsername = "",
                    avatarBase64 = currentAvatarBase64
                )
            }.onSuccess {
                _isBusy.value = false
                _actionMessage.value = "Юзернейм удалён"
                onSuccess()
            }.onFailure { error ->
                _isBusy.value = false
                _actionMessage.value = error.localizedMessage ?: "Не удалось удалить юзернейм"
            }
        }
    }

    fun syncThemePreference(mode: AppThemeMode) {
        latestThemeWire = mode.wireValue
        viewModelScope.launch {
            chatRepository.updateThemePreferenceOnProfile(currentUserId, mode.wireValue)
        }
    }

    fun setDiscoverable(discoverable: Boolean) {
        viewModelScope.launch {
            runCatching {
                chatRepository.updateDiscoverability(currentUserId, discoverable)
            }.onFailure { error ->
                _actionMessage.value = error.localizedMessage ?: "Не удалось обновить приватность"
            }
        }
    }

    fun redeemRoleCode(rawCode: String, onSuccess: (UserRole) -> Unit = {}) {
        viewModelScope.launch {
            _isBusy.value = true
            runCatching {
                chatRepository.redeemRoleCode(rawCode)
            }.onSuccess { grantedRole ->
                _isBusy.value = false
                _actionMessage.value = "Статус «${grantedRole.labelRu}» успешно активирован!"
                onSuccess(grantedRole)
            }.onFailure { error ->
                _isBusy.value = false
                _actionMessage.value = error.localizedMessage ?: "Не удалось активировать код"
            }
        }
    }

    fun generateRoleCode(targetRole: UserRole) {
        viewModelScope.launch {
            _isBusy.value = true
            runCatching {
                chatRepository.generateRoleCode(targetRole)
            }.onSuccess { (plainCode, _) ->
                _isBusy.value = false
                _lastGeneratedRoleCode.value = GeneratedRoleCode(plainCode, targetRole)
                _actionMessage.value = "Создан одноразовый код (${targetRole.labelRu})"
            }.onFailure { error ->
                _isBusy.value = false
                _actionMessage.value = error.localizedMessage ?: "Только разработчик может создавать коды"
            }
        }
    }

    fun deleteRoleCode(codeHash: String) {
        viewModelScope.launch {
            runCatching {
                chatRepository.deleteRoleCode(codeHash)
            }.onSuccess {
                _actionMessage.value = "Код удалён"
            }.onFailure { error ->
                _actionMessage.value = error.localizedMessage ?: "Не удалось удалить код"
            }
        }
    }

    fun clearGeneratedRoleCode() {
        _lastGeneratedRoleCode.value = null
    }

    fun moderateUser(
        targetUid: String,
        status: ModerationStatus,
        durationMillis: Long? = null,
        reason: String = ""
    ) {
        viewModelScope.launch {
            _isBusy.value = true
            runCatching {
                chatRepository.moderateUserAccount(
                    targetUid = targetUid,
                    status = status,
                    durationMillis = durationMillis,
                    reason = reason
                )
            }.onSuccess {
                _isBusy.value = false
                _actionMessage.value = when (status) {
                    ModerationStatus.MUTED -> "Пользователь переведён в мут"
                    ModerationStatus.BANNED -> "Аккаунт заблокирован"
                    ModerationStatus.ACTIVE -> "Ограничения сняты"
                }
            }.onFailure { error ->
                _isBusy.value = false
                _actionMessage.value = error.localizedMessage ?: "Не удалось применить ограничение"
            }
        }
    }

    fun deleteUserAccount(targetUid: String, reason: String = "") {
        viewModelScope.launch {
            _isBusy.value = true
            runCatching {
                chatRepository.deleteUserAccountByAdmin(targetUid, reason)
            }.onSuccess {
                _isBusy.value = false
                _actionMessage.value = "Аккаунт пользователя удалён"
            }.onFailure { error ->
                _isBusy.value = false
                _actionMessage.value = error.localizedMessage ?: "Не удалось удалить аккаунт"
            }
        }
    }

    fun saveCustomRole(
        editingRoleId: String?,
        name: String,
        badgeText: String,
        colorHex: String,
        permissions: Set<CustomRolePermission>,
        onSuccess: () -> Unit = {}
    ) {
        viewModelScope.launch {
            _isBusy.value = true
            runCatching {
                chatRepository.saveCustomRole(
                    editingRoleId = editingRoleId,
                    rawName = name,
                    rawBadgeText = badgeText,
                    rawColorHex = colorHex,
                    permissions = permissions
                )
            }.onSuccess { saved ->
                _isBusy.value = false
                _actionMessage.value = if (editingRoleId.isNullOrBlank()) {
                    "Роль «${saved.name}» создана"
                } else {
                    "Роль «${saved.name}» обновлена"
                }
                onSuccess()
            }.onFailure { error ->
                _isBusy.value = false
                _actionMessage.value = error.localizedMessage ?: "Не удалось сохранить роль"
            }
        }
    }

    fun deleteCustomRole(roleId: String) {
        viewModelScope.launch {
            _isBusy.value = true
            runCatching {
                chatRepository.deleteCustomRole(roleId)
            }.onSuccess {
                _isBusy.value = false
                _actionMessage.value = "Кастомная роль удалена"
            }.onFailure { error ->
                _isBusy.value = false
                _actionMessage.value = error.localizedMessage ?: "Не удалось удалить роль"
            }
        }
    }

    fun assignCustomRole(targetUid: String, customRole: CustomRoleRecord?) {
        viewModelScope.launch {
            _isBusy.value = true
            runCatching {
                chatRepository.assignCustomRoleToUser(targetUid, customRole)
            }.onSuccess {
                _isBusy.value = false
                _actionMessage.value = if (customRole == null) {
                    "Кастомная роль снята"
                } else {
                    "Роль «${customRole.name}» выдана"
                }
            }.onFailure { error ->
                _isBusy.value = false
                _actionMessage.value = error.localizedMessage ?: "Не удалось выдать роль"
            }
        }
    }

    fun syncFcmToken(token: String) {
        if (token.isBlank()) return
        viewModelScope.launch {
            chatRepository.updateFcmToken(currentUserId, token)
        }
    }

    fun startCallWithConversation(
        conversation: Conversation,
        callType: String,
        onCallStarted: (String) -> Unit
    ) {
        if (privateProfile.value?.isCurrentlyMuted() == true) {
            _actionMessage.value = "Вы не можете начинать звонки в режиме чтения"
            return
        }
        val existingCallId = conversation.activeCallId
        if (existingCallId.isNotBlank()) {
            onCallStarted(existingCallId)
            return
        }
        if (_isBusy.value) return
        val callerName = privateProfile.value?.displayName?.ifBlank { userDisplayName }
            ?: userDisplayName.ifBlank { "Участник" }
        viewModelScope.launch {
            _isBusy.value = true
            runCatching {
                callRepository.startCall(
                    conversation = conversation,
                    callerName = callerName,
                    callType = callType
                )
            }.onSuccess { callId ->
                _isBusy.value = false
                onCallStarted(callId)
            }.onFailure { error ->
                _isBusy.value = false
                _actionMessage.value = error.localizedMessage ?: "Не удалось начать звонок"
            }
        }
    }

    fun startCallWithPeer(
        peer: PublicUserProfile,
        callType: String,
        onCallStarted: (String) -> Unit
    ) {
        if (peer.userId == currentUserId) {
            _actionMessage.value = "Нельзя позвонить самому себе"
            return
        }
        if (privateProfile.value?.isCurrentlyMuted() == true) {
            _actionMessage.value = "Вы не можете начинать звонки в режиме чтения"
            return
        }
        val existingDm = findExistingDirectConversation(peer.userId)
        if (existingDm != null && existingDm.activeCallId.isNotBlank()) {
            onCallStarted(existingDm.activeCallId)
            return
        }
        if (_isBusy.value) return
        val callerName = privateProfile.value?.displayName?.ifBlank { userDisplayName }
            ?: userDisplayName.ifBlank { "Участник" }
        viewModelScope.launch {
            _isBusy.value = true
            runCatching {
                val targetConv = if (existingDm != null &&
                    !existingDm.memberKeyEnvelopes[currentUserId].isNullOrBlank() &&
                    !existingDm.memberKeyEnvelopes[peer.userId].isNullOrBlank()
                ) {
                    existingDm
                } else {
                    val me = resolveMyPublicProfile()
                    val chatId = chatRepository.getOrCreateDirectChat(me, peer)
                    Conversation(
                        id = chatId,
                        isGroup = false,
                        title = peer.displayName,
                        memberUids = listOf(currentUserId, peer.userId)
                    )
                }
                callRepository.startCall(
                    conversation = targetConv,
                    callerName = callerName,
                    callType = callType
                )
            }.onSuccess { callId ->
                _isBusy.value = false
                onCallStarted(callId)
            }.onFailure { error ->
                _isBusy.value = false
                _actionMessage.value = error.localizedMessage ?: "Не удалось начать звонок"
            }
        }
    }

    fun declineIncomingCall(call: CallSession) {
        viewModelScope.launch {
            callRepository.leaveOrEndCall(call)
        }
    }

    fun showMessage(message: String) {
        _actionMessage.value = message
    }

    fun clearMessage() {
        _actionMessage.value = null
    }

    private companion object {
        const val TAG = "ChatListVM"
        const val PRESENCE_HEARTBEAT_INTERVAL_MS = 35_000L
        const val RESOURCE_SAVING_HEARTBEAT_INTERVAL_MS = 90_000L
    }
}

