package com.example.media

import android.content.Context
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.os.Build
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File
import kotlin.math.roundToInt

data class RecordedVoiceResult(
    val audioBytes: ByteArray,
    val durationMs: Long,
    val waveform: List<Int>
)

data class VoicePlaybackState(
    val activeMessageId: String? = null,
    val isPlaying: Boolean = false,
    val progress: Float = 0f,
    val currentPositionMs: Long = 0L
)

class VoiceRecorderManager(private val context: Context) {
    private var recorder: MediaRecorder? = null
    private var outputFile: File? = null
    private var startTimeMs: Long = 0L
    private var meterJob: Job? = null
    private val collectedSamples = mutableListOf<Int>()

    private val _isRecording = MutableStateFlow(false)
    val isRecording: StateFlow<Boolean> = _isRecording.asStateFlow()

    private val _elapsedMs = MutableStateFlow(0L)
    val elapsedMs: StateFlow<Long> = _elapsedMs.asStateFlow()

    private val _liveBars = MutableStateFlow<List<Int>>(emptyList())
    val liveBars: StateFlow<List<Int>> = _liveBars.asStateFlow()

    fun startRecording(scope: CoroutineScope): Boolean {
        if (_isRecording.value) return false
        val dir = File(context.cacheDir, "voice").apply { mkdirs() }
        val file = File(dir, "rec_${System.currentTimeMillis()}.m4a")
        outputFile = file
        collectedSamples.clear()
        _liveBars.value = emptyList()
        _elapsedMs.value = 0L

        return try {
            val mr = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                MediaRecorder(context)
            } else {
                @Suppress("DEPRECATION")
                MediaRecorder()
            }
            mr.apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setAudioEncodingBitRate(28_000)
                setAudioSamplingRate(16_000)
                setMaxDuration(120_000)
                setOutputFile(file.absolutePath)
                prepare()
                start()
            }
            recorder = mr
            startTimeMs = System.currentTimeMillis()
            _isRecording.value = true

            meterJob = scope.launch(Dispatchers.Main) {
                while (isActive && _isRecording.value) {
                    val amp = runCatching { recorder?.maxAmplitude ?: 0 }.getOrDefault(0)
                    val normalized = ((amp / 32767f) * 100f).roundToInt().coerceIn(8, 100)
                    collectedSamples.add(normalized)
                    _liveBars.value = collectedSamples.takeLast(28)
                    _elapsedMs.value = System.currentTimeMillis() - startTimeMs
                    delay(70L)
                }
            }
            true
        } catch (e: Exception) {
            cleanupRecorder()
            false
        }
    }

    fun stopAndBuild(): RecordedVoiceResult? {
        if (!_isRecording.value) return null
        val duration = (System.currentTimeMillis() - startTimeMs).coerceAtLeast(300L)
        _isRecording.value = false
        meterJob?.cancel()
        meterJob = null

        runCatching { recorder?.stop() }
        runCatching { recorder?.release() }
        recorder = null

        val file = outputFile
        outputFile = null
        val bytes = if (file != null && file.exists()) {
            val read = file.readBytes()
            file.delete()
            read
        } else {
            ByteArray(0)
        }

        if (bytes.isEmpty() || bytes.size > 650 * 1024) {
            return null
        }

        val bars = downsampleBars(collectedSamples, 28)
        return RecordedVoiceResult(
            audioBytes = bytes,
            durationMs = duration,
            waveform = bars
        )
    }

    fun cancelRecording() {
        _isRecording.value = false
        meterJob?.cancel()
        meterJob = null
        cleanupRecorder()
        _liveBars.value = emptyList()
        _elapsedMs.value = 0L
    }

    private fun cleanupRecorder() {
        runCatching { recorder?.stop() }
        runCatching { recorder?.release() }
        recorder = null
        runCatching { outputFile?.delete() }
        outputFile = null
    }

    private fun downsampleBars(samples: List<Int>, target: Int): List<Int> {
        if (samples.isEmpty()) return List(target) { 18 }
        if (samples.size <= target) {
            val padded = samples.toMutableList()
            while (padded.size < target) padded.add(16)
            return padded
        }
        val step = samples.size.toFloat() / target
        return List(target) { idx ->
            val start = (idx * step).toInt().coerceIn(0, samples.lastIndex)
            val end = ((idx + 1) * step).toInt().coerceIn(start + 1, samples.size)
            samples.subList(start, end).average().roundToInt().coerceIn(10, 100)
        }
    }
}

class VoicePlayerManager(private val context: Context) {
    private var mediaPlayer: MediaPlayer? = null
    private var progressJob: Job? = null
    private var currentFile: File? = null

    private val _playbackState = MutableStateFlow(VoicePlaybackState())
    val playbackState: StateFlow<VoicePlaybackState> = _playbackState.asStateFlow()

    fun togglePlay(messageId: String, audioBytes: ByteArray, scope: CoroutineScope) {
        val state = _playbackState.value
        if (state.activeMessageId == messageId && mediaPlayer != null) {
            if (state.isPlaying) {
                runCatching { mediaPlayer?.pause() }
                _playbackState.value = state.copy(isPlaying = false)
            } else {
                runCatching { mediaPlayer?.start() }
                _playbackState.value = state.copy(isPlaying = true)
            }
            return
        }

        stop()
        val dir = File(context.cacheDir, "voice").apply { mkdirs() }
        val tempFile = File(dir, "play_${messageId.take(16)}.m4a")
        tempFile.writeBytes(audioBytes)
        currentFile = tempFile

        try {
            val player = MediaPlayer().apply {
                setDataSource(tempFile.absolutePath)
                prepare()
                setOnCompletionListener {
                    stop()
                }
                start()
            }
            mediaPlayer = player
            _playbackState.value = VoicePlaybackState(
                activeMessageId = messageId,
                isPlaying = true,
                progress = 0f,
                currentPositionMs = 0L
            )
            progressJob = scope.launch(Dispatchers.Main) {
                while (isActive && mediaPlayer != null) {
                    val mp = mediaPlayer ?: break
                    val dur = runCatching { mp.duration }.getOrDefault(1).coerceAtLeast(1)
                    val pos = runCatching { mp.currentPosition }.getOrDefault(0)
                    _playbackState.value = _playbackState.value.copy(
                        isPlaying = runCatching { mp.isPlaying }.getOrDefault(false),
                        progress = (pos.toFloat() / dur.toFloat()).coerceIn(0f, 1f),
                        currentPositionMs = pos.toLong()
                    )
                    delay(60L)
                }
            }
        } catch (e: Exception) {
            stop()
        }
    }

    fun stop() {
        progressJob?.cancel()
        progressJob = null
        runCatching { mediaPlayer?.stop() }
        runCatching { mediaPlayer?.release() }
        mediaPlayer = null
        runCatching { currentFile?.delete() }
        currentFile = null
        _playbackState.value = VoicePlaybackState()
    }
}
