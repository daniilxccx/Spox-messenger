package com.example.ui.auth

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.security.AppLockManager
import com.example.security.BiometricCapability
import com.example.security.findFragmentActivity

@Composable
fun AppLockScreen(
    uid: String,
    userDisplayName: String,
    userEmail: String,
    pinEnabled: Boolean,
    biometricEnabled: Boolean,
    biometricCapability: BiometricCapability,
    appLockManager: AppLockManager,
    onUnlocked: () -> Unit,
    onSignOutAndResetLock: () -> Unit
) {
    val context = LocalContext.current
    val fragmentActivity = remember(context) { context.findFragmentActivity() }
    val canUseBiometric = biometricEnabled &&
        biometricCapability == BiometricCapability.READY &&
        fragmentActivity != null

    var enteredPin by remember { mutableStateOf("") }
    var errorText by remember { mutableStateOf<String?>(null) }

    fun launchBiometrics() {
        val activity = fragmentActivity ?: return
        errorText = null
        appLockManager.showBiometricPrompt(
            activity = activity,
            title = "Вход в SpoX",
            subtitle = "Подтвердите личность для доступа к защищённым чатам",
            hasPinFallback = pinEnabled,
            onSuccess = onUnlocked,
            onFallbackOrCancel = {
                if (!pinEnabled) {
                    errorText = "Проверка отменена. Нажмите кнопку ниже, чтобы повторить."
                }
            },
            onError = { msg -> errorText = msg }
        )
    }

    LaunchedEffect(canUseBiometric) {
        if (canUseBiometric) {
            launchBiometrics()
        }
    }

    fun appendDigit(digit: String) {
        if (enteredPin.length >= AppLockManager.PIN_LENGTH) return
        errorText = null
        val updated = enteredPin + digit
        enteredPin = updated
        if (updated.length == AppLockManager.PIN_LENGTH) {
            if (appLockManager.verifyPin(uid, updated)) {
                enteredPin = ""
                onUnlocked()
            } else {
                enteredPin = ""
                errorText = "Неверный PIN-код. Попробуйте ещё раз."
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        MaterialTheme.colorScheme.background,
                        MaterialTheme.colorScheme.surfaceContainerLow,
                        MaterialTheme.colorScheme.background
                    )
                )
            )
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 24.dp, vertical = 20.dp)
            .testTag("app_lock_screen")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 420.dp)
                .align(Alignment.Center),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Spacer(modifier = Modifier.height(12.dp))

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Surface(
                    shape = CircleShape,
                    color = MaterialTheme.colorScheme.primaryContainer,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.45f)),
                    modifier = Modifier.size(68.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = if (pinEnabled) Icons.Filled.Lock else Icons.Filled.Shield,
                            contentDescription = "Блокировка SpoX",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(32.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "SpoX заблокирован",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onBackground
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = listOf(userDisplayName, userEmail)
                        .filter { it.isNotBlank() }
                        .joinToString(" • "),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = if (pinEnabled) {
                        "Введите 4-значный PIN-код${if (canUseBiometric) " или используйте биометрию" else ""}"
                    } else {
                        "Подтвердите вход с помощью биометрии устройства"
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )

                if (pinEnabled) {
                    Spacer(modifier = Modifier.height(24.dp))
                    PinDotsRow(
                        filledCount = enteredPin.length,
                        isError = errorText != null
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = errorText.orEmpty(),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error,
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .height(22.dp)
                        .testTag("app_lock_error_text")
                )
            }

            if (pinEnabled) {
                PinNumericKeypad(
                    showBiometricButton = canUseBiometric,
                    onDigit = ::appendDigit,
                    onBackspace = {
                        if (enteredPin.isNotEmpty()) {
                            enteredPin = enteredPin.dropLast(1)
                            errorText = null
                        }
                    },
                    onBiometricClick = ::launchBiometrics
                )
            } else {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Button(
                        onClick = ::launchBiometrics,
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp)
                            .testTag("biometric_unlock_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Fingerprint,
                            contentDescription = null,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text("Разблокировать по биометрии")
                    }
                }
            }

            TextButton(
                onClick = onSignOutAndResetLock,
                modifier = Modifier
                    .height(48.dp)
                    .testTag("lock_screen_sign_out_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.Logout,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text("Выйти и сменить аккаунт")
            }
        }
    }
}

@Composable
fun PinSetupDialog(
    isChangingExisting: Boolean,
    onDismiss: () -> Unit,
    onPinConfirmed: (String) -> Unit
) {
    var firstPin by remember { mutableStateOf<String?>(null) }
    var currentInput by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val isConfirmStep = firstPin != null

    fun handleDigit(digit: String) {
        if (currentInput.length >= AppLockManager.PIN_LENGTH) return
        errorMessage = null
        val updated = currentInput + digit
        currentInput = updated
        if (updated.length == AppLockManager.PIN_LENGTH) {
            val existingFirst = firstPin
            if (existingFirst == null) {
                firstPin = updated
                currentInput = ""
            } else if (existingFirst == updated) {
                onPinConfirmed(updated)
            } else {
                firstPin = null
                currentInput = ""
                errorMessage = "PIN-коды не совпадают. Введите заново."
            }
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = when {
                    isConfirmStep -> "Повторите PIN-код"
                    isChangingExisting -> "Новый PIN-код (4 цифры)"
                    else -> "Создайте PIN-код (4 цифры)"
                }
            )
        },
        text = {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = if (isConfirmStep) {
                        "Введите тот же 4-значный код для подтверждения."
                    } else {
                        "Этот код будет запрашиваться при открытии SpoX на этом устройстве."
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(16.dp))
                PinDotsRow(
                    filledCount = currentInput.length,
                    isError = errorMessage != null
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = errorMessage.orEmpty(),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.height(20.dp)
                )
                Spacer(modifier = Modifier.height(8.dp))
                PinNumericKeypad(
                    showBiometricButton = false,
                    buttonSizeDp = 56,
                    onDigit = ::handleDigit,
                    onBackspace = {
                        if (currentInput.isNotEmpty()) {
                            currentInput = currentInput.dropLast(1)
                            errorMessage = null
                        }
                    },
                    onBiometricClick = {}
                )
            }
        },
        confirmButton = {},
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("pin_setup_cancel_button")
            ) {
                Text("Отмена")
            }
        }
    )
}

@Composable
private fun PinDotsRow(
    filledCount: Int,
    isError: Boolean
) {
    Row(
        horizontalArrangement = Arrangement.spacedBy(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        repeat(AppLockManager.PIN_LENGTH) { index ->
            val isFilled = index < filledCount
            val dotColor by animateColorAsState(
                targetValue = when {
                    isError -> MaterialTheme.colorScheme.error
                    isFilled -> MaterialTheme.colorScheme.primary
                    else -> MaterialTheme.colorScheme.outlineVariant
                },
                animationSpec = tween(160),
                label = "pin_dot_$index"
            )
            Box(
                modifier = Modifier
                    .size(16.dp)
                    .clip(CircleShape)
                    .background(dotColor)
            )
        }
    }
}

@Composable
private fun PinNumericKeypad(
    showBiometricButton: Boolean,
    buttonSizeDp: Int = 72,
    onDigit: (String) -> Unit,
    onBackspace: () -> Unit,
    onBiometricClick: () -> Unit
) {
    val rows = listOf(
        listOf("1", "2", "3"),
        listOf("4", "5", "6"),
        listOf("7", "8", "9")
    )

    Column(
        verticalArrangement = Arrangement.spacedBy(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        rows.forEach { rowDigits ->
            Row(horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                rowDigits.forEach { digit ->
                    KeypadCircleButton(
                        sizeDp = buttonSizeDp,
                        onClick = { onDigit(digit) },
                        testTag = "pin_key_$digit"
                    ) {
                        Text(
                            text = digit,
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(18.dp)) {
            if (showBiometricButton) {
                KeypadCircleButton(
                    sizeDp = buttonSizeDp,
                    onClick = onBiometricClick,
                    testTag = "pin_key_biometric"
                ) {
                    Icon(
                        imageVector = Icons.Filled.Fingerprint,
                        contentDescription = "Разблокировать по биометрии",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(28.dp)
                    )
                }
            } else {
                Spacer(modifier = Modifier.size(buttonSizeDp.dp))
            }

            KeypadCircleButton(
                sizeDp = buttonSizeDp,
                onClick = { onDigit("0") },
                testTag = "pin_key_0"
            ) {
                Text(
                    text = "0",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            KeypadCircleButton(
                sizeDp = buttonSizeDp,
                onClick = onBackspace,
                testTag = "pin_key_backspace"
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.Backspace,
                    contentDescription = "Удалить цифру",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(24.dp)
                )
            }
        }
    }
}

@Composable
private fun KeypadCircleButton(
    sizeDp: Int,
    onClick: () -> Unit,
    testTag: String,
    content: @Composable () -> Unit
) {
    Surface(
        shape = CircleShape,
        color = MaterialTheme.colorScheme.surfaceContainer,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        modifier = Modifier
            .size(sizeDp.dp)
            .clip(CircleShape)
            .clickable(onClick = onClick)
            .testTag(testTag)
    ) {
        Box(contentAlignment = Alignment.Center) {
            content()
        }
    }
}
