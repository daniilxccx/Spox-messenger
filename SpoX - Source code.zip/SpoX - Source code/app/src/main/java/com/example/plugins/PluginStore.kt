package com.example.plugins

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class PluginStore(context: Context) {

    private val appContext = context.applicationContext
    private val storageFile = File(appContext.filesDir, "spox_plugins.json")
    private val lock = Any()

    private val _plugins = MutableStateFlow<List<SpoXPlugin>>(emptyList())
    val plugins: StateFlow<List<SpoXPlugin>> = _plugins.asStateFlow()

    private val _logs = MutableStateFlow<List<String>>(emptyList())
    val logs: StateFlow<List<String>> = _logs.asStateFlow()

    init {
        synchronized(lock) {
            _plugins.value = loadOrSeedLocked()
        }
    }

    private fun loadOrSeedLocked(): List<SpoXPlugin> {
        val builtIns = BuiltInPlugins.defaultPlugins()
        if (!storageFile.exists()) {
            persistLocked(builtIns)
            return builtIns
        }

        val parsed = runCatching {
            val raw = storageFile.readText(Charsets.UTF_8)
            val arr = JSONArray(raw)
            buildList {
                for (i in 0 until arr.length()) {
                    val obj = arr.optJSONObject(i) ?: continue
                    val id = obj.optString("id").trim()
                    val source = obj.optString("sourceCode")
                    if (id.isBlank() || source.isBlank()) continue
                    val cmdsArr = obj.optJSONArray("commands")
                    val cmds = buildList {
                        if (cmdsArr != null) {
                            for (j in 0 until cmdsArr.length()) {
                                val cmd = cmdsArr.optString(j).trim()
                                if (cmd.isNotEmpty()) add(cmd)
                            }
                        }
                    }
                    add(
                        SpoXPlugin(
                            id = id,
                            name = obj.optString("name", id),
                            version = obj.optString("version", "1.0"),
                            author = obj.optString("author", "Пользователь"),
                            description = obj.optString("description", ""),
                            commands = cmds,
                            sourceCode = source,
                            enabled = obj.optBoolean("enabled", true),
                            isBuiltIn = obj.optBoolean("isBuiltIn", false),
                            isModifiedBuiltIn = obj.optBoolean("isModifiedBuiltIn", false),
                            updatedAtMs = obj.optLong("updatedAtMs", System.currentTimeMillis()),
                            lastError = obj.optString("lastError").ifBlank { null }
                        )
                    )
                }
            }
        }.getOrElse { emptyList() }

        if (parsed.isEmpty()) {
            persistLocked(builtIns)
            return builtIns
        }

        val existingIds = parsed.map { it.id }.toSet()
        val missingBuiltIns = builtIns.filter { it.id !in existingIds }
        return if (missingBuiltIns.isEmpty()) {
            parsed
        } else {
            val merged = parsed + missingBuiltIns
            persistLocked(merged)
            merged
        }
    }

    private fun persistLocked(list: List<SpoXPlugin>) {
        val arr = JSONArray()
        list.forEach { plugin ->
            val obj = JSONObject().apply {
                put("id", plugin.id)
                put("name", plugin.name)
                put("version", plugin.version)
                put("author", plugin.author)
                put("description", plugin.description)
                put("commands", JSONArray(plugin.commands))
                put("sourceCode", plugin.sourceCode)
                put("enabled", plugin.enabled)
                put("isBuiltIn", plugin.isBuiltIn)
                put("isModifiedBuiltIn", plugin.isModifiedBuiltIn)
                put("updatedAtMs", plugin.updatedAtMs)
                put("lastError", plugin.lastError.orEmpty())
            }
            arr.put(obj)
        }
        val tmp = File(storageFile.parentFile, "${storageFile.name}.tmp")
        tmp.writeText(arr.toString(), Charsets.UTF_8)
        if (!tmp.renameTo(storageFile)) {
            storageFile.writeText(arr.toString(), Charsets.UTF_8)
            tmp.delete()
        }
    }

    fun setPluginEnabled(pluginId: String, enabled: Boolean) {
        synchronized(lock) {
            val next = _plugins.value.map { plugin ->
                if (plugin.id == pluginId) {
                    plugin.copy(enabled = enabled, lastError = if (enabled) null else plugin.lastError)
                } else {
                    plugin
                }
            }
            _plugins.value = next
            persistLocked(next)
        }
    }

    fun installOrUpdateFromSource(
        sourceCode: String,
        overrideId: String? = null,
        enableAfterSave: Boolean = true
    ): Result<SpoXPlugin> {
        val trimmed = sourceCode.trim()
        if (trimmed.isEmpty()) {
            return Result.failure(IllegalArgumentException("Код плагина не может быть пустым"))
        }
        val metaResult = SpoxLuaEngine.extractMetadata(trimmed, fallbackId = overrideId)
        if (metaResult.isFailure) {
            return Result.failure(
                metaResult.exceptionOrNull() ?: IllegalArgumentException("Ошибка синтаксиса Lua")
            )
        }
        val meta = metaResult.getOrThrow()
        val finalId = overrideId?.trim()?.ifBlank { null } ?: meta.id

        val savedPlugin = synchronized(lock) {
            val current = _plugins.value.toMutableList()
            val existingIdx = current.indexOfFirst { it.id == finalId }
            val existing = current.getOrNull(existingIdx)
            val builtInOriginal = BuiltInPlugins.defaultPlugins().firstOrNull { it.id == finalId }
            val updated = SpoXPlugin(
                id = finalId,
                name = meta.name,
                version = meta.version,
                author = meta.author,
                description = meta.description,
                commands = meta.commands,
                sourceCode = sourceCode,
                enabled = enableAfterSave,
                isBuiltIn = existing?.isBuiltIn ?: (builtInOriginal != null),
                isModifiedBuiltIn = builtInOriginal != null && builtInOriginal.sourceCode.trim() != trimmed,
                updatedAtMs = System.currentTimeMillis(),
                lastError = null
            )
            if (existingIdx >= 0) {
                current[existingIdx] = updated
            } else {
                current.add(0, updated)
            }
            _plugins.value = current
            persistLocked(current)
            updated
        }
        appendLog("[${savedPlugin.name}] Плагин сохранён и готов к работе")
        return Result.success(savedPlugin)
    }

    fun deleteCustomPlugin(pluginId: String): Boolean {
        return synchronized(lock) {
            val target = _plugins.value.firstOrNull { it.id == pluginId } ?: return@synchronized false
            if (target.isBuiltIn) return@synchronized false
            val next = _plugins.value.filterNot { it.id == pluginId }
            _plugins.value = next
            persistLocked(next)
            true
        }
    }

    fun resetBuiltInPlugin(pluginId: String): Boolean {
        val builtIn = BuiltInPlugins.defaultPlugins().firstOrNull { it.id == pluginId } ?: return false
        return synchronized(lock) {
            val existingEnabled = _plugins.value.firstOrNull { it.id == pluginId }?.enabled ?: builtIn.enabled
            val restored = builtIn.copy(enabled = existingEnabled, updatedAtMs = System.currentTimeMillis())
            val next = _plugins.value.map { if (it.id == pluginId) restored else it }
            _plugins.value = next
            persistLocked(next)
            true
        }
    }

    fun collectAvailableCommands(): List<PluginCommandHint> {
        val active = _plugins.value.filter { it.enabled }
        val hints = ArrayList<PluginCommandHint>()
        val seen = HashSet<String>()
        active.forEach { plugin ->
            plugin.commands.forEach { rawCmd ->
                val cmd = if (rawCmd.startsWith("/")) rawCmd.lowercase() else "/${rawCmd.lowercase()}"
                if (seen.add(cmd)) {
                    hints.add(
                        PluginCommandHint(
                            command = cmd,
                            pluginName = plugin.name,
                            description = plugin.description
                        )
                    )
                }
            }
        }
        return hints
    }

    fun dispatchCommand(rawText: String, ctx: PluginHookContext): PluginCommandOutcome {
        val trimmed = rawText.trim()
        if (!trimmed.startsWith("/")) return PluginCommandOutcome.NotHandled
        val parts = trimmed.split(Regex("\\s+"), limit = 2)
        val cmd = parts[0].lowercase()
        val argsText = parts.getOrElse(1) { "" }

        val active = _plugins.value.filter { it.enabled }
        for (plugin in active) {
            val result = SpoxLuaEngine.executeCommand(
                sourceCode = plugin.sourceCode,
                command = cmd,
                argsText = argsText,
                rawText = trimmed,
                ctx = ctx
            )
            if (result.isFailure) {
                val msg = result.exceptionOrNull()?.message ?: "Ошибка плагина"
                recordPluginError(plugin.id, msg)
                appendLog("[${plugin.name}] Ошибка: $msg")
                continue
            }
            val (outcome, logs) = result.getOrThrow()
            logs.forEach { appendLog("[${plugin.name}] $it") }
            if (outcome !is PluginCommandOutcome.NotHandled) {
                return outcome
            }
        }
        return PluginCommandOutcome.NotHandled
    }

    fun transformOutgoingMessage(rawText: String, ctx: PluginHookContext): OutgoingTransformResult {
        var currentText = rawText
        val notices = ArrayList<String>()
        val active = _plugins.value.filter { it.enabled }

        for (plugin in active) {
            val result = SpoxLuaEngine.executeOnSendMessage(
                sourceCode = plugin.sourceCode,
                text = currentText,
                ctx = ctx
            )
            if (result.isFailure) {
                val msg = result.exceptionOrNull()?.message ?: "Ошибка плагина"
                recordPluginError(plugin.id, msg)
                appendLog("[${plugin.name}] Ошибка on_send_message: $msg")
                continue
            }
            when (val outcome = result.getOrThrow()) {
                is OutgoingTransformResult.Cancelled -> return outcome
                is OutgoingTransformResult.Proceed -> {
                    currentText = outcome.text
                    notices.addAll(outcome.notices)
                }
            }
        }
        return OutgoingTransformResult.Proceed(currentText, notices)
    }

    fun formatMessageForDisplay(rawText: String, ctx: PluginHookContext): String {
        var currentText = rawText
        val active = _plugins.value.filter { it.enabled }
        for (plugin in active) {
            val result = SpoxLuaEngine.executeOnRenderMessage(
                sourceCode = plugin.sourceCode,
                text = currentText,
                ctx = ctx
            )
            if (result.isSuccess) {
                currentText = result.getOrThrow()
            }
        }
        return currentText
    }

    fun clearLogs() {
        _logs.value = emptyList()
    }

    private fun appendLog(entry: String) {
        val current = _logs.value.toMutableList()
        current.add(0, entry)
        if (current.size > 40) {
            _logs.value = current.take(40)
        } else {
            _logs.value = current
        }
    }

    private fun recordPluginError(pluginId: String, errorMsg: String) {
        synchronized(lock) {
            val next = _plugins.value.map { p ->
                if (p.id == pluginId) p.copy(lastError = errorMsg) else p
            }
            _plugins.value = next
            persistLocked(next)
        }
    }

    fun readLuaFromUri(uri: Uri): Result<String> = runCatching {
        appContext.contentResolver.openInputStream(uri)?.use { stream ->
            stream.bufferedReader(Charsets.UTF_8).readText()
        } ?: throw IllegalStateException("Не удалось открыть выбранный .lua файл")
    }

    fun writeLuaToUri(uri: Uri, content: String): Result<Unit> = runCatching {
        appContext.contentResolver.openOutputStream(uri)?.use { stream ->
            stream.write(content.toByteArray(Charsets.UTF_8))
            stream.flush()
        } ?: throw IllegalStateException("Не удалось записать файл шаблона")
    }

    companion object {
        @Volatile
        private var instance: PluginStore? = null

        fun getInstance(context: Context): PluginStore {
            return instance ?: synchronized(this) {
                instance ?: PluginStore(context.applicationContext).also { instance = it }
            }
        }
    }
}
