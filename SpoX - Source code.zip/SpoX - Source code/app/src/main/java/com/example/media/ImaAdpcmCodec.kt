package com.example.media

import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Pure Kotlin IMA-ADPCM (4 bits/sample, 4:1 compression) speech codec.
 * At 16 kHz mono 16-bit PCM, 240 ms (3840 samples = 7680 bytes) compresses to 1924 bytes
 * with a self-contained header per packet so packet loss never corrupts subsequent frames.
 */
object ImaAdpcmCodec {

    private val INDEX_TABLE = intArrayOf(
        -1, -1, -1, -1, 2, 4, 6, 8,
        -1, -1, -1, -1, 2, 4, 6, 8
    )

    private val STEP_TABLE = intArrayOf(
        7, 8, 9, 10, 11, 12, 13, 14, 16, 17,
        19, 21, 23, 25, 28, 31, 34, 37, 41, 45,
        50, 55, 60, 66, 73, 80, 88, 97, 107, 118,
        130, 143, 157, 173, 190, 209, 230, 253, 279, 307,
        337, 371, 408, 449, 494, 544, 598, 658, 724, 796,
        876, 963, 1060, 1166, 1282, 1411, 1552, 1707, 1878, 2066,
        2272, 2499, 2749, 3024, 3327, 3660, 4026, 4428, 4871, 5358,
        5894, 6484, 7132, 7845, 8630, 9493, 10442, 11487, 12635, 13899,
        15289, 16818, 18500, 20350, 22385, 24623, 27086, 29794, 32767
    )

    fun encode(samples: ShortArray, count: Int = samples.size): ByteArray {
        if (count <= 0) return ByteArray(0)
        val nibbleBytes = (count + 1) / 2
        val out = ByteArray(4 + nibbleBytes)

        var predictor = samples[0].toInt()
        var index = 0

        val header = ByteBuffer.wrap(out, 0, 4).order(ByteOrder.LITTLE_ENDIAN)
        header.putShort(predictor.toShort())
        out[2] = index.toByte()
        out[3] = (count and 0x01).toByte() // bit 0 indicates odd sample count

        var step = STEP_TABLE[index]
        for (i in 0 until count) {
            val sample = samples[i].toInt()
            var diff = sample - predictor
            var nibble = 0
            if (diff < 0) {
                nibble = 8
                diff = -diff
            }

            var delta = 0
            var vpdiff = step shr 3
            if (diff >= step) {
                nibble = nibble or 4
                diff -= step
                vpdiff += step
            }
            step = step shr 1
            if (diff >= step) {
                nibble = nibble or 2
                diff -= step
                vpdiff += step
            }
            step = step shr 1
            if (diff >= step) {
                nibble = nibble or 1
                vpdiff += step
            }

            if ((nibble and 8) != 0) {
                predictor -= vpdiff
            } else {
                predictor += vpdiff
            }
            predictor = predictor.coerceIn(-32768, 32767)

            index = (index + INDEX_TABLE[nibble]).coerceIn(0, STEP_TABLE.lastIndex)
            step = STEP_TABLE[index]

            val byteIdx = 4 + (i shr 1)
            if ((i and 1) == 0) {
                out[byteIdx] = (nibble and 0x0F).toByte()
            } else {
                out[byteIdx] = (out[byteIdx].toInt() or ((nibble and 0x0F) shl 4)).toByte()
            }
            @Suppress("UNUSED_VALUE")
            delta = 0
        }
        return out
    }

    fun decode(encoded: ByteArray): ShortArray {
        if (encoded.size < 4) return ShortArray(0)
        val bb = ByteBuffer.wrap(encoded, 0, 4).order(ByteOrder.LITTLE_ENDIAN)
        var predictor = bb.short.toInt()
        var index = (encoded[2].toInt() and 0xFF).coerceIn(0, STEP_TABLE.lastIndex)
        val hasOddSample = (encoded[3].toInt() and 0x01) == 1

        val payloadBytes = encoded.size - 4
        if (payloadBytes <= 0) return ShortArray(0)
        val sampleCount = if (hasOddSample) (payloadBytes * 2 - 1) else (payloadBytes * 2)
        val out = ShortArray(sampleCount)

        var step = STEP_TABLE[index]
        for (i in 0 until sampleCount) {
            val byteVal = encoded[4 + (i shr 1)].toInt() and 0xFF
            val nibble = if ((i and 1) == 0) (byteVal and 0x0F) else ((byteVal ushr 4) and 0x0F)

            var vpdiff = step shr 3
            if ((nibble and 4) != 0) vpdiff += step
            if ((nibble and 2) != 0) vpdiff += step shr 1
            if ((nibble and 1) != 0) vpdiff += step shr 2

            if ((nibble and 8) != 0) {
                predictor -= vpdiff
            } else {
                predictor += vpdiff
            }
            predictor = predictor.coerceIn(-32768, 32767)
            out[i] = predictor.toShort()

            index = (index + INDEX_TABLE[nibble]).coerceIn(0, STEP_TABLE.lastIndex)
            step = STEP_TABLE[index]
        }
        return out
    }
}
