package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.NewReleases
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SystemUpdate
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.theme.ApplyLiquidGlassWindowBlur
import com.example.ui.theme.isLiquidGlassActive
import com.example.ui.theme.liquidGlassSheetContainerColor
import com.example.ui.theme.liquidGlassSheetScrimColor
import com.example.ui.theme.liquidGlassSurface
import com.example.updates.AppUpdateState
import com.example.updates.AppUpdateStore
import com.example.updates.GitHubReleaseInfo
import com.example.updates.GitHubUpdateService
import com.example.updates.UpdateCheckStatus
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun UpdateAvailableBanner(
    release: GitHubReleaseInfo,
    currentVersion: String,
    onOpenUpdates: () -> Unit,
    onDismissVersion: () -> Unit,
    modifier: Modifier = Modifier
) {
    val glassActive = isLiquidGlassActive()
    val bannerShape = RoundedCornerShape(18.dp)

    Surface(
        shape = bannerShape,
        color = if (glassActive) Color.Transparent else MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.72f),
        border = if (glassActive) null else BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.45f)),
        modifier = modifier
            .fillMaxWidth()
            .then(
                if (glassActive) {
                    Modifier.liquidGlassSurface(
                        shape = bannerShape,
                        tintColor = MaterialTheme.colorScheme.primaryContainer,
                        isHighlighted = true
                    )
                } else Modifier
            )
            .clickable(onClick = onOpenUpdates)
            .testTag("update_available_banner")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 12.dp, top = 8.dp, bottom = 8.dp, end = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Surface(
                shape = CircleShape,
                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.18f),
                modifier = Modifier.size(36.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Filled.SystemUpdate,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Доступна версия ${release.versionName}",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "Текущая v$currentVersion • GitHub Releases",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            TextButton(
                onClick = onOpenUpdates,
                modifier = Modifier
                    .heightIn(min = 48.dp)
                    .testTag("update_banner_open_button")
            ) {
                Text("Обновить")
            }
            IconButton(
                onClick = onDismissVersion,
                modifier = Modifier.testTag("update_banner_dismiss_button")
            ) {
                Icon(
                    imageVector = Icons.Filled.Close,
                    contentDescription = "Скрыть уведомление об обновлении",
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppUpdateSheet(
    updateStore: AppUpdateStore,
    onShowMessage: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val scope = rememberCoroutineScope()
    val state by updateStore.state.collectAsStateWithLifecycle()
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val scrollState = rememberScrollState()

    fun openExternal(url: String) {
        val opened = updateStore.openTrustedReleaseUrl(context, url)
        if (!opened) {
            onShowMessage("Не удалось открыть ссылку на GitHub")
        }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = liquidGlassSheetContainerColor(),
        scrimColor = liquidGlassSheetScrimColor()
    ) {
        ApplyLiquidGlassWindowBlur()
        AppUpdateContent(
            state = state,
            onCheckNow = {
                scope.launch {
                    updateStore.checkForUpdates(force = true)
                }
            },
            onDownloadApk = { release ->
                val targetUrl = release.apkAsset?.downloadUrl ?: release.htmlUrl
                openExternal(targetUrl)
            },
            onOpenReleasePage = { url ->
                openExternal(url)
            },
            onOpenAllReleases = {
                openExternal(GitHubUpdateService.RELEASES_WEB_URL)
            },
            onCopyUrl = { url ->
                clipboard.setText(AnnotatedString(url))
                onShowMessage("Ссылка скопирована в буфер обмена")
            },
            onToggleAutoCheck = { enabled ->
                updateStore.setAutoCheckEnabled(enabled)
            },
            onSkipVersion = { tag ->
                updateStore.skipVersion(tag)
                onShowMessage("Уведомление для $tag скрыто")
            },
            onClearSkippedVersion = {
                updateStore.clearSkippedVersion()
            },
            onDismiss = onDismiss,
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(scrollState)
                .navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 8.dp)
                .testTag("app_update_sheet")
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AppUpdateContent(
    state: AppUpdateState,
    onCheckNow: () -> Unit,
    onDownloadApk: (GitHubReleaseInfo) -> Unit,
    onOpenReleasePage: (String) -> Unit,
    onOpenAllReleases: () -> Unit,
    onCopyUrl: (String) -> Unit,
    onToggleAutoCheck: (Boolean) -> Unit,
    onSkipVersion: (String) -> Unit,
    onClearSkippedVersion: () -> Unit,
    onDismiss: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val glassActive = isLiquidGlassActive()
    val cardShape = RoundedCornerShape(20.dp)
    val isChecking = state.status == UpdateCheckStatus.CHECKING

    Column(
        modifier = modifier,
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Header
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            Surface(
                shape = CircleShape,
                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.14f),
                modifier = Modifier.size(46.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Filled.SystemUpdate,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Обновления SpoX",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "GitHub Releases • ${GitHubUpdateService.GITHUB_OWNER}/${GitHubUpdateService.GITHUB_REPO}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }

        // Status Card
        Surface(
            shape = cardShape,
            color = if (glassActive) Color.Transparent else when (state.status) {
                UpdateCheckStatus.UPDATE_AVAILABLE -> MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.34f)
                UpdateCheckStatus.ERROR -> MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.36f)
                else -> MaterialTheme.colorScheme.surfaceContainer
            },
            border = if (glassActive) null else BorderStroke(
                1.dp,
                when (state.status) {
                    UpdateCheckStatus.UPDATE_AVAILABLE -> MaterialTheme.colorScheme.primary.copy(alpha = 0.5f)
                    UpdateCheckStatus.ERROR -> MaterialTheme.colorScheme.error.copy(alpha = 0.45f)
                    else -> MaterialTheme.colorScheme.outlineVariant
                }
            ),
            modifier = Modifier
                .fillMaxWidth()
                .then(
                    if (glassActive) {
                        Modifier.liquidGlassSurface(
                            shape = cardShape,
                            tintColor = if (state.status == UpdateCheckStatus.UPDATE_AVAILABLE) {
                                MaterialTheme.colorScheme.primaryContainer
                            } else {
                                MaterialTheme.colorScheme.surfaceContainer
                            },
                            isHighlighted = state.status == UpdateCheckStatus.UPDATE_AVAILABLE
                        )
                    } else Modifier
                )
                .testTag("update_status_card")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    when (state.status) {
                        UpdateCheckStatus.CHECKING -> CircularProgressIndicator(
                            modifier = Modifier.size(22.dp),
                            strokeWidth = 2.4.dp
                        )
                        UpdateCheckStatus.UPDATE_AVAILABLE -> Icon(
                            imageVector = Icons.Filled.NewReleases,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(22.dp)
                        )
                        UpdateCheckStatus.UP_TO_DATE -> Icon(
                            imageVector = Icons.Filled.CheckCircle,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(22.dp)
                        )
                        UpdateCheckStatus.ERROR -> Icon(
                            imageVector = Icons.Filled.ErrorOutline,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(22.dp)
                        )
                        UpdateCheckStatus.IDLE, UpdateCheckStatus.NO_RELEASES -> Icon(
                            imageVector = Icons.Filled.SystemUpdate,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = when (state.status) {
                                UpdateCheckStatus.IDLE -> "Готово к проверке обновлений"
                                UpdateCheckStatus.CHECKING -> "Проверяем релизы на GitHub..."
                                UpdateCheckStatus.UPDATE_AVAILABLE ->
                                    "Доступно обновление: v${state.latestRelease?.versionName}"
                                UpdateCheckStatus.UP_TO_DATE -> "Установлена актуальная версия"
                                UpdateCheckStatus.NO_RELEASES -> "На GitHub пока нет опубликованных релизов"
                                UpdateCheckStatus.ERROR -> "Не удалось проверить обновления"
                            },
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.testTag("update_status_title")
                        )
                        val checkedLabel = state.lastCheckedAtMs?.let { ts ->
                            val time = SimpleDateFormat("dd.MM HH:mm", Locale.getDefault()).format(Date(ts))
                            " • Проверено: $time"
                        }.orEmpty()
                        Text(
                            text = "Текущая: v${state.currentVersion} (сборка ${state.currentVersionCode})$checkedLabel",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                if (!state.errorMessage.isNullOrBlank()) {
                    Text(
                        text = state.errorMessage,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error,
                        modifier = Modifier.testTag("update_error_message")
                    )
                }

                Button(
                    onClick = onCheckNow,
                    enabled = !isChecking,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("check_updates_now_button")
                ) {
                    Icon(Icons.Filled.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(if (isChecking) "Проверка..." else "Проверить обновления сейчас")
                }
            }
        }

        // Latest release details
        state.latestRelease?.let { release ->
            Surface(
                shape = cardShape,
                color = if (glassActive) Color.Transparent else MaterialTheme.colorScheme.surfaceContainer,
                border = if (glassActive) null else BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                modifier = Modifier
                    .fillMaxWidth()
                    .then(if (glassActive) Modifier.liquidGlassSurface(shape = cardShape) else Modifier)
                    .testTag("latest_release_card")
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = release.title,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            val formattedDate = GitHubUpdateService.formatReleaseDate(release.publishedAtIso)
                            if (formattedDate.isNotBlank()) {
                                Text(
                                    text = "Опубликовано: $formattedDate",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        Surface(
                            shape = RoundedCornerShape(50),
                            color = if (state.isUpdateAvailable) {
                                MaterialTheme.colorScheme.primaryContainer
                            } else {
                                MaterialTheme.colorScheme.secondaryContainer
                            }
                        ) {
                            Text(
                                text = release.tagName,
                                style = MaterialTheme.typography.labelMedium,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.SemiBold,
                                color = if (state.isUpdateAvailable) {
                                    MaterialTheme.colorScheme.onPrimaryContainer
                                } else {
                                    MaterialTheme.colorScheme.onSecondaryContainer
                                },
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                    }

                    if (release.changelog.isNotBlank()) {
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = MaterialTheme.colorScheme.surfaceContainerLow,
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = release.changelog,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.padding(12.dp)
                            )
                        }
                    }

                    release.apkAsset?.let { apk ->
                        Text(
                            text = "Файл: ${apk.name} • ${GitHubUpdateService.formatBytes(apk.sizeBytes)} • Скачиваний: ${apk.downloadCount}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Button(
                        onClick = { onDownloadApk(release) },
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("download_update_apk_button")
                    ) {
                        Icon(Icons.Filled.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (release.apkAsset != null) {
                                "Скачать APK (${GitHubUpdateService.formatBytes(release.apkAsset.sizeBytes)})"
                            } else {
                                "Открыть релиз на GitHub"
                            }
                        )
                    }

                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = { onOpenReleasePage(release.htmlUrl) },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .heightIn(min = 48.dp)
                                .testTag("open_release_page_button")
                        ) {
                            Icon(
                                Icons.AutoMirrored.Filled.OpenInNew,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Страница релиза")
                        }

                        OutlinedButton(
                            onClick = { onCopyUrl(release.apkAsset?.downloadUrl ?: release.htmlUrl) },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .heightIn(min = 48.dp)
                                .testTag("copy_release_link_button")
                        ) {
                            Icon(Icons.Filled.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Копировать ссылку")
                        }

                        if (state.isUpdateAvailable) {
                            if (state.skippedTag == release.tagName) {
                                TextButton(
                                    onClick = onClearSkippedVersion,
                                    modifier = Modifier.heightIn(min = 48.dp)
                                ) {
                                    Text("Показывать баннер")
                                }
                            } else {
                                TextButton(
                                    onClick = { onSkipVersion(release.tagName) },
                                    modifier = Modifier
                                        .heightIn(min = 48.dp)
                                        .testTag("skip_update_version_button")
                                ) {
                                    Text("Пропустить ${release.tagName}")
                                }
                            }
                        }
                    }
                }
            }
        }

        // Settings & History Card
        Surface(
            shape = cardShape,
            color = if (glassActive) Color.Transparent else MaterialTheme.colorScheme.surfaceContainer,
            border = if (glassActive) null else BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
            modifier = Modifier
                .fillMaxWidth()
                .then(if (glassActive) Modifier.liquidGlassSurface(shape = cardShape) else Modifier)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Автопроверка при запуске",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "Фоновая проверка новых релизов на GitHub",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(
                        checked = state.autoCheckEnabled,
                        onCheckedChange = onToggleAutoCheck,
                        modifier = Modifier.testTag("auto_check_updates_switch")
                    )
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

                OutlinedButton(
                    onClick = onOpenAllReleases,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("open_all_github_releases_button")
                ) {
                    Icon(Icons.AutoMirrored.Filled.OpenInNew, contentDescription = null, modifier = Modifier.size(17.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Все релизы на GitHub")
                }

                if (state.recentReleases.size > 1) {
                    Text(
                        text = "История релизов (${state.recentReleases.size})",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                    state.recentReleases.take(5).forEach { rel ->
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surfaceContainerLow,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onOpenReleasePage(rel.htmlUrl) }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = rel.title,
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.SemiBold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    val dateStr = GitHubUpdateService.formatReleaseDate(rel.publishedAtIso)
                                    Text(
                                        text = buildString {
                                            append(rel.tagName)
                                            if (rel.isPrerelease) append(" • Pre-release")
                                            if (dateStr.isNotBlank()) append(" • $dateStr")
                                        },
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.OpenInNew,
                                    contentDescription = "Открыть релиз",
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        if (onDismiss != null) {
            Button(
                onClick = onDismiss,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("updates_done_button")
            ) {
                Text("Готово")
            }
        }

        Spacer(modifier = Modifier.height(6.dp))
    }
}
