package com.example.updates

import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.net.HttpURLConnection
import java.net.URI
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone

object GitHubUpdateService {

    const val GITHUB_OWNER = "daniilxccx"
    const val GITHUB_REPO = "Spox-messenger"
    const val RELEASES_WEB_URL = "https://github.com/$GITHUB_OWNER/$GITHUB_REPO/releases"
    const val RELEASES_LIST_API_URL =
        "https://api.github.com/repos/$GITHUB_OWNER/$GITHUB_REPO/releases?per_page=10"

    private val TRUSTED_GITHUB_HOSTS = setOf(
        "github.com",
        "www.github.com",
        "api.github.com",
        "objects.githubusercontent.com",
        "release-assets.githubusercontent.com",
        "github-releases.githubusercontent.com",
        "codeload.github.com"
    )

    data class FetchOutcome(
        val releases: List<GitHubReleaseInfo>
    )

    suspend fun fetchReleases(): Result<FetchOutcome> = withContext(Dispatchers.IO) {
        runCatching {
            val connection = (URL(RELEASES_LIST_API_URL).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 10_000
                readTimeout = 12_000
                useCaches = false
                setRequestProperty("Accept", "application/vnd.github+json")
                setRequestProperty("X-GitHub-Api-Version", "2022-11-28")
                setRequestProperty("User-Agent", "SpoX-Android/${BuildConfig.VERSION_NAME}")
            }

            try {
                val code = connection.responseCode
                val body = (if (code in 200..299) connection.inputStream else connection.errorStream)
                    ?.bufferedReader(Charsets.UTF_8)
                    ?.use(BufferedReader::readText)
                    .orEmpty()

                when (code) {
                    in 200..299 -> {
                        val releases = parseReleasesListJson(body)
                        FetchOutcome(releases = releases)
                    }
                    404 -> {
                        throw IllegalStateException(
                            "Репозиторий или раздел релизов не найден на GitHub (HTTP 404)"
                        )
                    }
                    403, 429 -> {
                        throw IllegalStateException(
                            "Превышен лимит запросов GitHub API. Попробуйте чуть позже"
                        )
                    }
                    else -> {
                        val apiMessage = runCatching { JSONObject(body).optString("message") }
                            .getOrNull()
                            ?.ifBlank { null }
                        throw IllegalStateException(
                            apiMessage ?: "Ошибка GitHub API (HTTP $code)"
                        )
                    }
                }
            } finally {
                connection.disconnect()
            }
        }
    }

    fun selectBestCandidateRelease(releases: List<GitHubReleaseInfo>): GitHubReleaseInfo? {
        val published = releases.filterNot { it.isDraft }
        if (published.isEmpty()) return null
        val stable = published.filterNot { it.isPrerelease }
        val pool = stable.ifEmpty { published }
        return pool.maxWithOrNull { a, b -> compareVersions(a.versionName, b.versionName) }
    }

    fun parseReleasesListJson(rawJson: String): List<GitHubReleaseInfo> {
        val trimmed = rawJson.trim()
        if (trimmed.isEmpty()) return emptyList()
        val arr = JSONArray(trimmed)
        return buildList {
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                val parsed = parseReleaseJson(obj)
                if (!parsed.isDraft) {
                    add(parsed)
                }
            }
        }
    }

    fun parseReleaseJson(obj: JSONObject): GitHubReleaseInfo {
        val rawTag = obj.optString("tag_name").trim()
        val versionName = normalizeVersion(rawTag.ifEmpty { obj.optString("name").trim() })
        val title = obj.optString("name").trim().ifEmpty { rawTag.ifEmpty { "Релиз $versionName" } }
        val changelog = obj.optString("body").trim()
        val rawHtmlUrl = obj.optString("html_url").trim()
        val safeHtmlUrl = if (isTrustedGitHubUrl(rawHtmlUrl)) rawHtmlUrl else RELEASES_WEB_URL
        val publishedAt = obj.optString("published_at").trim()
            .ifEmpty { obj.optString("created_at").trim() }
        val isPrerelease = obj.optBoolean("prerelease", false)
        val isDraft = obj.optBoolean("draft", false)

        val assetsArr = obj.optJSONArray("assets") ?: JSONArray()
        val parsedAssets = buildList {
            for (i in 0 until assetsArr.length()) {
                val aObj = assetsArr.optJSONObject(i) ?: continue
                val assetName = aObj.optString("name").trim()
                val downloadUrl = aObj.optString("browser_download_url").trim()
                if (assetName.isEmpty() || !isTrustedGitHubUrl(downloadUrl)) continue
                add(
                    GitHubReleaseAsset(
                        name = assetName,
                        downloadUrl = downloadUrl,
                        sizeBytes = aObj.optLong("size", 0L).coerceAtLeast(0L),
                        downloadCount = aObj.optInt("download_count", 0).coerceAtLeast(0),
                        contentType = aObj.optString("content_type").trim()
                    )
                )
            }
        }

        val apkAsset = parsedAssets.firstOrNull {
            it.name.equals("SpoX.apk", ignoreCase = true)
        } ?: parsedAssets.firstOrNull {
            it.name.endsWith(".apk", ignoreCase = true)
        }

        return GitHubReleaseInfo(
            tagName = rawTag.ifEmpty { versionName },
            versionName = versionName,
            title = title,
            changelog = changelog,
            htmlUrl = safeHtmlUrl,
            publishedAtIso = publishedAt,
            isPrerelease = isPrerelease,
            isDraft = isDraft,
            apkAsset = apkAsset,
            allAssets = parsedAssets
        )
    }

    fun normalizeVersion(raw: String): String {
        val cleaned = raw.trim()
            .removePrefix("v")
            .removePrefix("V")
            .trim()
        return cleaned.ifEmpty { "0.0" }
    }

    /**
     * Compares two SemVer-like strings (e.g. "v1.2.0" vs "1.1", "1.2.0-beta" vs "1.2.0").
     * Returns > 0 if [candidate] is newer than [current], 0 if equal, < 0 if older.
     */
    fun compareVersions(candidate: String, current: String): Int {
        val a = parseVersionParts(candidate)
        val b = parseVersionParts(current)

        val maxLen = maxOf(a.numbers.size, b.numbers.size)
        for (i in 0 until maxLen) {
            val av = a.numbers.getOrElse(i) { 0 }
            val bv = b.numbers.getOrElse(i) { 0 }
            if (av != bv) return av.compareTo(bv)
        }

        return when {
            a.preRelease == null && b.preRelease == null -> 0
            a.preRelease == null && b.preRelease != null -> 1
            a.preRelease != null && b.preRelease == null -> -1
            else -> a.preRelease!!.compareTo(b.preRelease!!, ignoreCase = true)
        }
    }

    private data class ParsedVersion(
        val numbers: List<Int>,
        val preRelease: String?
    )

    private fun parseVersionParts(raw: String): ParsedVersion {
        val normalized = normalizeVersion(raw).substringBefore('+')
        val mainPart = normalized.substringBefore('-')
        val preRelease = normalized.substringAfter('-', "").trim().ifEmpty { null }
        val nums = mainPart.split('.')
            .map { seg ->
                val digits = seg.takeWhile { it.isDigit() }
                digits.toIntOrNull() ?: 0
            }
            .ifEmpty { listOf(0) }
        return ParsedVersion(numbers = nums, preRelease = preRelease)
    }

    fun isTrustedGitHubUrl(url: String): Boolean {
        if (url.isBlank()) return false
        return runCatching {
            val uri = URI(url.trim())
            val scheme = uri.scheme?.lowercase(Locale.US) ?: return@runCatching false
            val host = uri.host?.lowercase(Locale.US) ?: return@runCatching false
            scheme == "https" && (host in TRUSTED_GITHUB_HOSTS || host.endsWith(".githubusercontent.com"))
        }.getOrDefault(false)
    }

    fun formatBytes(bytes: Long): String {
        if (bytes <= 0L) return "—"
        val kb = bytes / 1024.0
        if (kb < 1024.0) return String.format(Locale.US, "%.0f КБ", kb)
        val mb = kb / 1024.0
        return String.format(Locale.US, "%.1f МБ", mb)
    }

    fun formatReleaseDate(iso: String): String {
        if (iso.isBlank()) return ""
        val inputFormats = listOf(
            "yyyy-MM-dd'T'HH:mm:ss'Z'",
            "yyyy-MM-dd'T'HH:mm:ssXXX"
        )
        for (pattern in inputFormats) {
            val parsed = runCatching {
                SimpleDateFormat(pattern, Locale.US).apply {
                    timeZone = TimeZone.getTimeZone("UTC")
                }.parse(iso)
            }.getOrNull()
            if (parsed != null) {
                return SimpleDateFormat("d MMM yyyy, HH:mm", Locale.forLanguageTag("ru")).format(parsed)
            }
        }
        return iso.substringBefore('T')
    }
}
