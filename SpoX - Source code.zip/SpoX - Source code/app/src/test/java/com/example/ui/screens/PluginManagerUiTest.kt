package com.example.ui.screens

import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.assertIsOff
import androidx.compose.ui.test.assertIsOn
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import com.example.data.model.AppThemeMode
import com.example.data.model.ChatAppearanceConfig
import com.example.plugins.BuiltInPlugins
import com.example.plugins.SpoxLuaEngine
import com.example.ui.theme.CipherChatTheme
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class PluginManagerUiTest {

    @get:Rule
    val composeRule = createComposeRule()

    @Test
    fun pluginManager_displaysBuiltInsDownloadsTemplateAndCreatesPluginInLuaSandbox() {
        var downloadTemplateCalls = 0
        var exportedPair: Pair<String, String>? = null

        composeRule.setContent {
            var plugins by remember { mutableStateOf(BuiltInPlugins.defaultPlugins()) }
            CipherChatTheme(themeMode = AppThemeMode.DARK, appearanceConfig = ChatAppearanceConfig()) {
                PluginManagerContent(
                    plugins = plugins,
                    onTogglePlugin = { id, enabled ->
                        plugins = plugins.map { if (it.id == id) it.copy(enabled = enabled) else it }
                    },
                    onSavePluginSource = { source, overrideId ->
                        SpoxLuaEngine.extractMetadata(source, fallbackId = overrideId).map { meta ->
                            val saved = com.example.plugins.SpoXPlugin(
                                id = overrideId ?: meta.id,
                                name = meta.name,
                                version = meta.version,
                                author = meta.author,
                                description = meta.description,
                                commands = meta.commands,
                                sourceCode = source,
                                enabled = true,
                                isBuiltIn = false
                            )
                            plugins = listOf(saved) + plugins.filterNot { it.id == saved.id }
                            saved
                        }
                    },
                    onDeleteCustomPlugin = { id ->
                        plugins = plugins.filterNot { it.id == id }
                    },
                    onResetBuiltInPlugin = {},
                    onDownloadTemplate = { downloadTemplateCalls++ },
                    onExportPluginLua = { fileName, src -> exportedPair = fileName to src },
                    onRequestImportLua = {},
                    modifier = Modifier.verticalScroll(rememberScrollState())
                )
            }
        }

        composeRule.waitForIdle()

        // Header and language label
        composeRule.onNodeWithText("Плагины SpoX").assertIsDisplayed()
        composeRule.onNodeWithText("Язык: SpoX Lua (.lua)", substring = true).assertIsDisplayed()

        // Template download card & action
        composeRule.onNodeWithTag("download_plugin_template_button").assertIsDisplayed().performClick()
        assertEquals(1, downloadTemplateCalls)

        // All 4 built-in plugins exist
        composeRule.onNodeWithTag("plugin_card_builtin_quick_macros").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("plugin_card_builtin_smart_calc").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("plugin_card_builtin_typography").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("plugin_card_builtin_message_inspector").performScrollTo().assertIsDisplayed()

        // Toggle typography switch on
        composeRule.onNodeWithTag("plugin_switch_builtin_typography").performScrollTo().assertIsOff().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("plugin_switch_builtin_typography").assertIsOn()

        // Export a built-in plugin as .lua
        composeRule.onNodeWithTag("plugin_card_builtin_quick_macros").performScrollTo()
        composeRule.onNodeWithTag("plugin_export_builtin_quick_macros").performScrollTo().performClick()
        composeRule.waitForIdle()
        assertEquals("builtin_quick_macros.lua", exportedPair?.first)
        assertTrue(exportedPair?.second?.contains("on_command") == true)

        // Create new plugin from starter template in Lua editor & run sandbox test
        composeRule.onNodeWithTag("create_from_template_button").performScrollTo().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("plugin_editor_dialog").assertIsDisplayed()
        composeRule.onNodeWithTag("plugin_run_sandbox_button").performScrollTo().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("plugin_sandbox_result").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithText("Привет, SpoX!", substring = true).performScrollTo().assertIsDisplayed()

        // Save new plugin from template -> card appears in list
        composeRule.onNodeWithTag("plugin_save_code_button").performScrollTo().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("plugin_card_my_custom_plugin").performScrollTo().assertIsDisplayed()

        // Open API help dialog
        composeRule.onNodeWithTag("plugins_api_help_button").performScrollTo().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("plugin_api_help_dialog").assertIsDisplayed()
    }
}
