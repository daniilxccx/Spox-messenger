package com.example.data.repository

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.AppThemeMode
import com.example.data.model.AppVisualTheme
import com.example.data.model.ChatWallpaperPreset
import com.example.data.model.OutgoingBubbleStyle
import java.io.File
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ThemePreferenceStoreTest {

    private lateinit var context: Context
    private lateinit var store: ThemePreferenceStore

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        store = ThemePreferenceStore(context)
    }

    @Test
    fun appearanceCustomizationPersistsAndResets() = runBlocking {
        val initial = store.appearanceConfig.first()
        assertEquals(true, initial.showStories)
        assertEquals(true, initial.showFolders)

        store.setThemeMode(AppThemeMode.LIGHT)
        store.setVisualTheme(AppVisualTheme.AMETHYST)
        store.setWallpaperPreset(ChatWallpaperPreset.AURORA_GLOW)
        store.setOutgoingBubbleStyle(OutgoingBubbleStyle.CRIMSON_ROSE)
        store.setShowStories(false)
        store.setShowFolders(false)

        val updated = store.appearanceConfig.first()
        assertEquals(AppThemeMode.LIGHT, updated.themeMode)
        assertEquals(AppVisualTheme.AMETHYST, updated.visualTheme)
        assertEquals(ChatWallpaperPreset.AURORA_GLOW, updated.wallpaperPreset)
        assertEquals(OutgoingBubbleStyle.CRIMSON_ROSE, updated.outgoingBubbleStyle)
        assertEquals(false, updated.showStories)
        assertEquals(false, updated.showFolders)

        store.resetCustomization()

        val afterReset = store.appearanceConfig.first()
        assertEquals(AppVisualTheme.SPOX_CYBER, afterReset.visualTheme)
        assertEquals(ChatWallpaperPreset.THEME_DEFAULT, afterReset.wallpaperPreset)
        assertEquals(OutgoingBubbleStyle.THEME_AUTO, afterReset.outgoingBubbleStyle)
        assertEquals(true, afterReset.showStories)
        assertEquals(true, afterReset.showFolders)
    }

    @Test
    fun customizationEnumsFallbackGracefullyOnUnknownWireValue() {
        assertEquals(AppVisualTheme.SPOX_CYBER, AppVisualTheme.fromWire("unknown_skin"))
        assertEquals(AppVisualTheme.OCEAN_NIGHT, AppVisualTheme.fromWire("ocean_night"))
        assertEquals(ChatWallpaperPreset.THEME_DEFAULT, ChatWallpaperPreset.fromWire(null))
        assertEquals(ChatWallpaperPreset.CYBER_GRID, ChatWallpaperPreset.fromWire("cyber_grid"))
        assertEquals(OutgoingBubbleStyle.THEME_AUTO, OutgoingBubbleStyle.fromWire(""))
        assertEquals(OutgoingBubbleStyle.EMERALD_MINT, OutgoingBubbleStyle.fromWire("emerald_mint"))
    }

    @Test
    fun corruptedDataStoreFileRecoversToDefaults() = runBlocking {
        val dsDir = File(context.filesDir, "datastore")
        dsDir.mkdirs()
        val prefsFile = File(dsDir, "cipherchat_prefs.preferences_pb")
        prefsFile.writeBytes(byteArrayOf(0x7F, 0x00, 0x13, 0x55, 0x22, 0x11))

        val recovered = store.appearanceConfig.first()
        assertEquals(AppVisualTheme.SPOX_CYBER, recovered.visualTheme)
        assertEquals(ChatWallpaperPreset.THEME_DEFAULT, recovered.wallpaperPreset)
        assertEquals(OutgoingBubbleStyle.THEME_AUTO, recovered.outgoingBubbleStyle)
    }
}
