package com.example.ui.call

import android.app.KeyguardManager
import android.app.PictureInPictureParams
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.os.Build
import android.os.Bundle
import android.util.Rational
import android.view.WindowManager
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.R
import com.example.crypto.CryptoManager
import com.example.data.model.ChatAppearanceConfig
import com.example.data.repository.CallRepository
import com.example.data.repository.ChatRepository
import com.example.data.repository.ThemePreferenceStore
import com.example.media.OngoingCallService
import com.example.notifications.SpoXNotificationHelper
import com.example.ui.screens.CallScreen
import com.example.ui.theme.CipherChatTheme
import com.example.ui.viewmodel.CallViewModel
import com.google.firebase.Firebase
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.flow.MutableStateFlow

class IncomingCallActivity : FragmentActivity() {

    private data class LaunchArgs(
        val callId: String,
        val autoAnswer: Boolean
    )

    private val launchArgsFlow = MutableStateFlow<LaunchArgs?>(null)
    private val isInPipFlow = MutableStateFlow(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        configureLockScreenPresentation()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        if (!extractArgs(intent)) {
            finishAndRemoveTask()
            return
        }

        val activeSession = com.example.data.repository.FirebaseSessionManager.ensureInitialized(applicationContext)
        val activeAuth = activeSession?.auth ?: runCatching { Firebase.auth }.getOrNull()
        val currentUser = runCatching { activeAuth?.currentUser }.getOrNull()
        if (currentUser == null || activeAuth == null) {
            finishAndRemoveTask()
            return
        }

        val uid = currentUser.uid
        val displayName = currentUser.displayName
            ?.takeIf { it.isNotBlank() }
            ?: currentUser.email?.substringBefore("@").orEmpty().ifBlank { "Участник" }

        setContent {
            val context = LocalContext.current
            val args by launchArgsFlow.collectAsStateWithLifecycle()
            val isInPip by isInPipFlow.collectAsStateWithLifecycle()
            val activeArgs = args ?: return@setContent

            val themeStore = remember(context) { ThemePreferenceStore(context.applicationContext) }
            val appearanceConfig by themeStore.appearanceConfig.collectAsStateWithLifecycle(
                initialValue = ChatAppearanceConfig()
            )
            val cryptoManager = remember(context, uid) {
                CryptoManager(context.applicationContext, accountScope = uid)
            }

            val callViewModel: CallViewModel = viewModel(
                key = "lockscreen_call_${uid}_${activeArgs.callId}",
                factory = viewModelFactory {
                    initializer {
                        val app = checkNotNull(this[APPLICATION_KEY])
                        val db = com.example.data.repository.FirebaseSessionManager.getFirestore(
                            app,
                            activeSession?.app ?: FirebaseApp.getInstance()
                        ) ?: FirebaseFirestore.getInstance(app.getString(R.string.firestore_database_id))
                        CallViewModel(
                            callRepository = CallRepository(db, activeAuth),
                            chatRepository = ChatRepository(db, cryptoManager, activeAuth),
                            callId = activeArgs.callId,
                            currentUserId = uid,
                            currentUserName = displayName,
                            autoAnswer = activeArgs.autoAnswer
                        )
                    }
                }
            )

            LaunchedEffect(activeArgs.callId, activeArgs.autoAnswer) {
                if (activeArgs.autoAnswer) {
                    SpoXNotificationHelper.cancelCallNotification(
                        context.applicationContext,
                        activeArgs.callId
                    )
                    callViewModel.acceptIncomingCall()
                }
            }

            CipherChatTheme(
                themeMode = appearanceConfig.themeMode,
                appearanceConfig = appearanceConfig
            ) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    CallScreen(
                        viewModel = callViewModel,
                        currentUserId = uid,
                        isInPictureInPicture = isInPip,
                        onMinimizeCall = { minimizeToBackgroundOrPip() },
                        onCallClosed = {
                            SpoXNotificationHelper.cancelCallNotification(
                                applicationContext,
                                activeArgs.callId
                            )
                            finishAndRemoveTask()
                        }
                    )
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        extractArgs(intent)
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (OngoingCallService.isCallRunning.value) {
            tryEnterCallPip()
        }
    }

    override fun onPictureInPictureModeChanged(
        isInPictureInPictureMode: Boolean,
        newConfig: Configuration
    ) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        isInPipFlow.value = isInPictureInPictureMode
    }

    private fun minimizeToBackgroundOrPip() {
        val kg = getSystemService(KeyguardManager::class.java)
        if (kg?.isKeyguardLocked == true) {
            moveTaskToBack(true)
            return
        }
        if (!tryEnterCallPip()) {
            moveTaskToBack(true)
        }
    }

    private fun tryEnterCallPip(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return false
        if (!packageManager.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)) return false
        if (isInPictureInPictureMode) return false
        return runCatching {
            val params = PictureInPictureParams.Builder()
                .setAspectRatio(Rational(3, 4))
                .build()
            enterPictureInPictureMode(params)
        }.getOrDefault(false)
    }

    private fun extractArgs(intent: Intent?): Boolean {
        val callId = intent?.getStringExtra(SpoXNotificationHelper.EXTRA_OPEN_CALL_ID).orEmpty()
        if (callId.isBlank()) return false
        val autoAnswer = intent?.getBooleanExtra(SpoXNotificationHelper.EXTRA_AUTO_ANSWER, false) ?: false
        launchArgsFlow.value = LaunchArgs(callId = callId, autoAnswer = autoAnswer)
        if (autoAnswer) {
            SpoXNotificationHelper.cancelCallNotification(applicationContext, callId)
        }
        return true
    }

    private fun configureLockScreenPresentation() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }
}
