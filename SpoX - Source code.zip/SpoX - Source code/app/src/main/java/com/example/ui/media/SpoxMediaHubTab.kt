package com.example.ui.media

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PlaylistPlay
import androidx.compose.material.icons.filled.VideoFile
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.media.FileAttachmentHelper
import com.example.media.LocalSpoxAudioPlayer
import com.example.media.MediaKind
import com.example.media.SpoxAudioTrack
import com.example.media.SpoxMediaHistoryItem
import com.example.media.SpoxVideoRequest
import com.example.ui.theme.isLiquidGlassActive
import com.example.ui.theme.liquidGlassSurface

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SpoxMediaHubTab(
    onOpenVideo: (SpoxVideoRequest) -> Unit,
    onShowMessage: (String) -> Unit,
    extraTopPaddingDp: Int = 8,
    extraBottomPaddingDp: Int = 84
) {
    val isGlass = isLiquidGlassActive()
    val context = LocalContext.current
    val audioPlayer = LocalSpoxAudioPlayer.current
    val audioState = audioPlayer?.uiState?.collectAsStateWithLifecycle()?.value

    val recentMedia = remember { mutableStateListOf<SpoxMediaHistoryItem>() }

    fun registerAndPlayUris(uris: List<android.net.Uri>, forceKind: MediaKind? = null) {
        if (uris.isEmpty()) return
        val newAudioTracks = mutableListOf<SpoxAudioTrack>()
        var videoToLaunch: SpoxVideoRequest? = null

        uris.forEach { uri ->
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }
            val meta = FileAttachmentHelper.resolveUriMetadata(context, uri)
            if (FileAttachmentHelper.isUnsafeExecutableFile(meta.fileName, meta.mimeType)) {
                onShowMessage("Файл ${meta.fileName} не является поддерживаемым медиаформатом")
                return@forEach
            }
            val resolvedKind = when {
                meta.mediaKind == MediaKind.VIDEO || meta.mediaKind == MediaKind.AUDIO -> meta.mediaKind
                forceKind != null -> forceKind
                else -> MediaKind.VIDEO
            }
            val badge = FileAttachmentHelper.formatBadge(meta.fileName, meta.mimeType)
            val id = "local_${uri.toString().hashCode()}"
            val item = SpoxMediaHistoryItem(
                id = id,
                uri = uri,
                title = meta.fileName,
                mediaKind = resolvedKind,
                formatBadge = badge,
                sizeBytes = meta.sizeBytes,
                mimeType = meta.mimeType
            )
            recentMedia.removeAll { it.id == id }
            recentMedia.add(0, item)

            if (resolvedKind == MediaKind.AUDIO) {
                newAudioTracks.add(
                    SpoxAudioTrack(
                        id = id,
                        uri = uri,
                        title = meta.fileName.substringBeforeLast('.').ifBlank { meta.fileName },
                        subtitle = if (meta.sizeBytes > 0L) FileAttachmentHelper.formatSize(meta.sizeBytes) else "Локальный файл",
                        formatBadge = badge,
                        mimeType = meta.mimeType,
                        sizeBytes = meta.sizeBytes
                    )
                )
            } else if (videoToLaunch == null) {
                videoToLaunch = SpoxVideoRequest(
                    id = id,
                    uri = uri,
                    title = meta.fileName,
                    formatBadge = badge,
                    mimeType = meta.mimeType,
                    sizeBytes = meta.sizeBytes
                )
            }
        }

        if (videoToLaunch != null) {
            onOpenVideo(videoToLaunch!!)
        } else if (newAudioTracks.isNotEmpty() && audioPlayer != null) {
            val allAudioQueue = (newAudioTracks + recentMedia
                .filter { it.mediaKind == MediaKind.AUDIO }
                .map { hist ->
                    SpoxAudioTrack(
                        id = hist.id,
                        uri = hist.uri,
                        title = hist.title.substringBeforeLast('.').ifBlank { hist.title },
                        subtitle = if (hist.sizeBytes > 0L) FileAttachmentHelper.formatSize(hist.sizeBytes) else "Локальный файл",
                        formatBadge = hist.formatBadge,
                        mimeType = hist.mimeType,
                        sizeBytes = hist.sizeBytes
                    )
                }).distinctBy { it.id }
            audioPlayer.playQueue(allAudioQueue, 0)
        }
    }

    val galleryVideoLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) registerAndPlayUris(listOf(uri), forceKind = MediaKind.VIDEO)
    }

    val anyVideoFileLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) registerAndPlayUris(listOf(uri), forceKind = MediaKind.VIDEO)
    }

    val multiAudioFileLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        if (uris.isNotEmpty()) registerAndPlayUris(uris, forceKind = MediaKind.AUDIO)
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("media_hub_tab"),
        contentPadding = PaddingValues(
            start = 16.dp,
            end = 16.dp,
            top = extraTopPaddingDp.dp,
            bottom = extraBottomPaddingDp.dp
        ),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            val heroShape = RoundedCornerShape(22.dp)
            Surface(
                shape = heroShape,
                color = if (isGlass) Color.Transparent else MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.42f),
                border = if (isGlass) null else BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.25f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .then(
                        if (isGlass) {
                            Modifier.liquidGlassSurface(
                                shape = heroShape,
                                tintColor = MaterialTheme.colorScheme.primaryContainer,
                                isHighlighted = true
                            )
                        } else Modifier
                    )
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Filled.Movie,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(26.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "Встроенный медиаплеер SpoX",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Прямое воспроизведение видео и музыки без сторонних приложений",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Text(
                        text = "Поддержка форматов видео и аудио:",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary
                    )

                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        FileAttachmentHelper.SUPPORTED_VIDEO_BADGES.forEach { badge ->
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = MaterialTheme.colorScheme.surface
                            ) {
                                Text(
                                    text = badge,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.SemiBold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                        FileAttachmentHelper.SUPPORTED_AUDIO_BADGES.forEach { badge ->
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = MaterialTheme.colorScheme.secondaryContainer
                            ) {
                                Text(
                                    text = badge,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.onSecondaryContainer,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        item {
            val videoShape = RoundedCornerShape(20.dp)
            Surface(
                shape = videoShape,
                color = if (isGlass) Color.Transparent else MaterialTheme.colorScheme.surfaceContainerLow,
                border = if (isGlass) null else BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                modifier = Modifier
                    .fillMaxWidth()
                    .then(
                        if (isGlass) Modifier.liquidGlassSurface(shape = videoShape) else Modifier
                    )
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.VideoFile, contentDescription = null, tint = MaterialTheme.colorScheme.tertiary)
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text("Видеоплеер", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                            Text(
                                "MKV, AVI, WebM, MOV, FLV, TS, MP4 — с дорожками и субтитрами",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                anyVideoFileLauncher.launch(
                                    arrayOf("video/*", "application/x-matroska", "application/ogg", "*/*")
                                )
                            },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("pick_local_video_file_button")
                        ) {
                            Icon(Icons.Filled.FolderOpen, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Файл (MKV, AVI...)")
                        }
                        OutlinedButton(
                            onClick = {
                                galleryVideoLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                                )
                            },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("pick_gallery_video_button")
                        ) {
                            Icon(Icons.Filled.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Из галереи")
                        }
                    }
                }
            }
        }

        item {
            val audioShape = RoundedCornerShape(20.dp)
            Surface(
                shape = audioShape,
                color = if (isGlass) Color.Transparent else MaterialTheme.colorScheme.surfaceContainerLow,
                border = if (isGlass) null else BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                modifier = Modifier
                    .fillMaxWidth()
                    .then(
                        if (isGlass) Modifier.liquidGlassSurface(shape = audioShape) else Modifier
                    )
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.LibraryMusic, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text("Аудиоплеер", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                            Text(
                                "MP3, FLAC, OPUS, OGG, WAV, M4A, AAC с фоновым мини-плеером",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    FilledTonalButton(
                        onClick = {
                            multiAudioFileLauncher.launch(
                                arrayOf("audio/*", "application/ogg", "*/*")
                            )
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("pick_local_audio_files_button")
                    ) {
                        Icon(Icons.Filled.MusicNote, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Открыть музыку или плейлист")
                    }
                }
            }
        }

        val audioRecent = recentMedia.filter { it.mediaKind == MediaKind.AUDIO }
        if (recentMedia.isNotEmpty()) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Недавние медиа (${recentMedia.size})",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold
                    )
                    if (audioRecent.size > 1 && audioPlayer != null) {
                        OutlinedButton(
                            onClick = {
                                val queue = audioRecent.map { hist ->
                                    SpoxAudioTrack(
                                        id = hist.id,
                                        uri = hist.uri,
                                        title = hist.title.substringBeforeLast('.').ifBlank { hist.title },
                                        subtitle = if (hist.sizeBytes > 0L) FileAttachmentHelper.formatSize(hist.sizeBytes) else "Локальный файл",
                                        formatBadge = hist.formatBadge,
                                        mimeType = hist.mimeType,
                                        sizeBytes = hist.sizeBytes
                                    )
                                }
                                audioPlayer.playQueue(queue, 0)
                            }
                        ) {
                            Icon(Icons.Filled.PlaylistPlay, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Играть аудио")
                        }
                    }
                }
            }

            items(recentMedia, key = { it.id }) { item ->
                val isPlayingThisAudio = item.mediaKind == MediaKind.AUDIO &&
                    audioState?.activeTrack?.id == item.id &&
                    audioState.isPlaying

                val itemShape = RoundedCornerShape(16.dp)
                Surface(
                    shape = itemShape,
                    color = if (isGlass) Color.Transparent else MaterialTheme.colorScheme.surfaceContainerLow,
                    border = if (isGlass) null else BorderStroke(
                        1.dp,
                        if (isPlayingThisAudio) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .then(
                            if (isGlass) {
                                Modifier.liquidGlassSurface(
                                    shape = itemShape,
                                    isHighlighted = isPlayingThisAudio
                                )
                            } else Modifier
                        )
                        .clickable {
                            if (item.mediaKind == MediaKind.AUDIO && audioPlayer != null) {
                                val queue = audioRecent.map { hist ->
                                    SpoxAudioTrack(
                                        id = hist.id,
                                        uri = hist.uri,
                                        title = hist.title.substringBeforeLast('.').ifBlank { hist.title },
                                        subtitle = if (hist.sizeBytes > 0L) FileAttachmentHelper.formatSize(hist.sizeBytes) else "Локальный файл",
                                        formatBadge = hist.formatBadge,
                                        mimeType = hist.mimeType,
                                        sizeBytes = hist.sizeBytes
                                    )
                                }
                                val idx = queue.indexOfFirst { it.id == item.id }.coerceAtLeast(0)
                                audioPlayer.playQueue(queue, idx)
                            } else {
                                onOpenVideo(
                                    SpoxVideoRequest(
                                        id = item.id,
                                        uri = item.uri,
                                        title = item.title,
                                        formatBadge = item.formatBadge,
                                        mimeType = item.mimeType,
                                        sizeBytes = item.sizeBytes
                                    )
                                )
                            }
                        }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.primaryContainer,
                            modifier = Modifier.size(44.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = when {
                                        isPlayingThisAudio -> Icons.Filled.GraphicEq
                                        item.mediaKind == MediaKind.AUDIO -> Icons.Filled.MusicNote
                                        else -> Icons.Filled.VideoFile
                                    },
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = item.title,
                                style = MaterialTheme.typography.titleSmall,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            val sizeLabel = if (item.sizeBytes > 0L) " • ${FileAttachmentHelper.formatSize(item.sizeBytes)}" else ""
                            Text(
                                text = "${item.formatBadge}$sizeLabel",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        IconButton(
                            onClick = { recentMedia.removeAll { it.id == item.id } },
                            modifier = Modifier.size(48.dp)
                        ) {
                            Icon(Icons.Filled.Close, contentDescription = "Убрать из списка")
                        }
                    }
                }
            }
        }
    }
}
