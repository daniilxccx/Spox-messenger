package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import kotlinx.coroutines.launch
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.ModerationStatus
import com.example.data.model.UserPrivateProfile
import com.example.data.model.UserRole
import com.example.ui.components.ModerationStatusChip
import com.example.ui.components.RoleBadge
import com.example.ui.components.UserAvatar
import kotlin.math.abs

private enum class AdminUserFilter(val label: String) {
    ALL("Все"),
    ACTIVE("Активные"),
    MUTED("В муте"),
    BANNED("Блок")
}

private data class MutePreset(val label: String, val durationMillis: Long?)

private val MUTE_PRESETS = listOf(
    MutePreset("15 мин", 15L * 60_000L),
    MutePreset("1 час", 60L * 60_000L),
    MutePreset("24 часа", 24L * 60L * 60_000L),
    MutePreset("7 дней", 7L * 24L * 60L * 60_000L),
    MutePreset("Бессрочно", null)
)

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun AdminModerationSheet(
    users: List<UserPrivateProfile>,
    currentUserId: String,
    isBusy: Boolean,
    onDismiss: () -> Unit,
    onModerateUser: (targetUid: String, status: ModerationStatus, durationMillis: Long?, reason: String) -> Unit,
    onDeleteUserAccount: (targetUid: String, reason: String) -> Unit
) {
    val scope = rememberCoroutineScope()
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var searchQuery by remember { mutableStateOf("") }
    val filterPagerState = rememberPagerState(
        initialPage = AdminUserFilter.ALL.ordinal,
        pageCount = { AdminUserFilter.entries.size }
    )

    var muteTarget by remember { mutableStateOf<UserPrivateProfile?>(null) }
    var banTarget by remember { mutableStateOf<UserPrivateProfile?>(null) }
    var deleteTarget by remember { mutableStateOf<UserPrivateProfile?>(null) }

    val mutedCount = remember(users) { users.count { it.isCurrentlyMuted() } }
    val bannedCount = remember(users) { users.count { it.isBanned() } }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 6.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.primaryContainer,
                        modifier = Modifier.size(40.dp)
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Filled.AdminPanelSettings,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "Управление аккаунтами",
                            style = MaterialTheme.typography.titleLarge
                        )
                        Text(
                            text = "Всего: ${users.size} • Мут: $mutedCount • Блок: $bannedCount",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Filled.Close, contentDescription = "Закрыть")
                }
            }

            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Поиск (имя, @юзернейм, email, UID)...") },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Filled.Close, contentDescription = "Очистить")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("admin_user_search_input")
            )

            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                AdminUserFilter.entries.forEachIndexed { index, filter ->
                    FilterChip(
                        selected = filterPagerState.targetPage == index,
                        onClick = { scope.launch { filterPagerState.animateScrollToPage(index) } },
                        label = { Text(filter.label) },
                        modifier = Modifier.testTag("admin_filter_${filter.name.lowercase()}")
                    )
                }
            }

            HorizontalDivider()

            HorizontalPager(
                state = filterPagerState,
                beyondViewportPageCount = 1,
                key = { AdminUserFilter.entries[it].name },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("admin_tabs_pager")
            ) { pageIndex ->
                val pageFilter = AdminUserFilter.entries[pageIndex]
                val listState = rememberLazyListState()
                val filteredUsers = remember(users, searchQuery, pageFilter) {
                    val q = searchQuery.trim().lowercase()
                    users.filter { user ->
                        val matchesFilter = when (pageFilter) {
                            AdminUserFilter.ALL -> true
                            AdminUserFilter.ACTIVE -> !user.isBanned() && !user.isCurrentlyMuted()
                            AdminUserFilter.MUTED -> user.isCurrentlyMuted()
                            AdminUserFilter.BANNED -> user.isBanned()
                        }
                        val matchesQuery = q.isEmpty() ||
                            user.displayName.lowercase().contains(q) ||
                            user.handle.lowercase().contains(q) ||
                            user.email.lowercase().contains(q) ||
                            user.userId.lowercase().contains(q)
                        matchesFilter && matchesQuery
                    }
                }

                if (filteredUsers.isEmpty()) {
                    Text(
                        text = "Подходящие пользователи не найдены.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(vertical = 24.dp)
                    )
                } else {
                    LazyColumn(
                        state = listState,
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 200.dp, max = 460.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(filteredUsers, key = { it.userId }) { user ->
                        val isSelf = user.userId == currentUserId
                        val isMuted = user.isCurrentlyMuted()
                        val isBanned = user.isBanned()
                        val role = UserRole.fromWire(user.role)
                        val effectiveStatus = when {
                            isBanned -> ModerationStatus.BANNED
                            isMuted -> ModerationStatus.MUTED
                            else -> ModerationStatus.ACTIVE
                        }

                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = MaterialTheme.colorScheme.surfaceContainer,
                            border = BorderStroke(
                                1.dp,
                                if (isBanned) MaterialTheme.colorScheme.error.copy(alpha = 0.45f)
                                else MaterialTheme.colorScheme.outlineVariant
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("admin_user_card_${user.userId}")
                        ) {
                            Column(
                                modifier = Modifier.padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    UserAvatar(
                                        name = user.displayName.ifBlank { user.email },
                                        avatarBase64 = user.avatarBase64,
                                        colorIndex = abs(user.userId.hashCode()),
                                        size = 44.dp
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            Text(
                                                text = if (isSelf) "${user.displayName} (Вы)" else user.displayName,
                                                style = MaterialTheme.typography.titleMedium,
                                                fontWeight = FontWeight.SemiBold,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis,
                                                modifier = Modifier.weight(1f, fill = false)
                                            )
                                            RoleBadge(role = role, compact = true)
                                            ModerationStatusChip(
                                                status = effectiveStatus,
                                                mutedUntilEpochMs = user.mutedUntilEpochMs,
                                                compact = false
                                            )
                                        }
                                        val secondary = buildString {
                                            if (user.handle.isNotBlank()) {
                                                append(user.handle)
                                                append(" • ")
                                            }
                                            append(user.email)
                                        }
                                        Text(
                                            text = secondary,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }

                                if (effectiveStatus != ModerationStatus.ACTIVE && user.moderationReason.isNotBlank()) {
                                    Text(
                                        text = "Причина: ${user.moderationReason}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (isBanned) MaterialTheme.colorScheme.error
                                        else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }

                                if (!isSelf) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        OutlinedButton(
                                            onClick = {
                                                if (isMuted) {
                                                    onModerateUser(user.userId, ModerationStatus.ACTIVE, null, "")
                                                } else {
                                                    muteTarget = user
                                                }
                                            },
                                            enabled = !isBusy,
                                            shape = RoundedCornerShape(12.dp),
                                            modifier = Modifier
                                                .weight(1f)
                                                .height(48.dp)
                                                .testTag("admin_mute_button_${user.userId}")
                                        ) {
                                            Icon(
                                                imageVector = if (isMuted) Icons.Filled.VolumeUp else Icons.Filled.VolumeOff,
                                                contentDescription = null,
                                                modifier = Modifier.size(16.dp)
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(if (isMuted) "Размут" else "Мут", maxLines = 1)
                                        }

                                        OutlinedButton(
                                            onClick = {
                                                if (isBanned) {
                                                    onModerateUser(user.userId, ModerationStatus.ACTIVE, null, "")
                                                } else {
                                                    banTarget = user
                                                }
                                            },
                                            enabled = !isBusy,
                                            shape = RoundedCornerShape(12.dp),
                                            modifier = Modifier
                                                .weight(1f)
                                                .height(48.dp)
                                                .testTag("admin_ban_button_${user.userId}")
                                        ) {
                                            Icon(
                                                imageVector = if (isBanned) Icons.Filled.CheckCircle else Icons.Filled.Block,
                                                contentDescription = null,
                                                tint = if (isBanned) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                                                modifier = Modifier.size(16.dp)
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(
                                                text = if (isBanned) "Разблок" else "Блок",
                                                color = if (isBanned) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                                                maxLines = 1
                                            )
                                        }

                                        OutlinedButton(
                                            onClick = { deleteTarget = user },
                                            enabled = !isBusy,
                                            shape = RoundedCornerShape(12.dp),
                                            modifier = Modifier
                                                .height(48.dp)
                                                .testTag("admin_delete_button_${user.userId}")
                                        ) {
                                            Icon(
                                                imageVector = Icons.Filled.DeleteForever,
                                                contentDescription = "Удалить аккаунт",
                                                tint = MaterialTheme.colorScheme.error,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            }

            Spacer(modifier = Modifier.height(6.dp))
        }
    }

    muteTarget?.let { target ->
        var selectedPreset by remember(target.userId) { mutableStateOf(MUTE_PRESETS[1]) }
        var reasonDraft by remember(target.userId) { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { muteTarget = null },
            title = { Text("Мут для ${target.displayName}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "В режиме мута пользователь сможет читать чаты, но не сможет отправлять сообщения и начинать звонки.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        MUTE_PRESETS.forEach { preset ->
                            FilterChip(
                                selected = selectedPreset == preset,
                                onClick = { selectedPreset = preset },
                                label = { Text(preset.label) }
                            )
                        }
                    }
                    OutlinedTextField(
                        value = reasonDraft,
                        onValueChange = { if (it.length <= 240) reasonDraft = it },
                        label = { Text("Причина (необязательно)") },
                        placeholder = { Text("Например: спам или нарушение правил") },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onModerateUser(
                            target.userId,
                            ModerationStatus.MUTED,
                            selectedPreset.durationMillis,
                            reasonDraft
                        )
                        muteTarget = null
                    }
                ) {
                    Text("Выдать мут")
                }
            },
            dismissButton = {
                TextButton(onClick = { muteTarget = null }) {
                    Text("Отмена")
                }
            }
        )
    }

    banTarget?.let { target ->
        var reasonDraft by remember(target.userId) { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { banTarget = null },
            title = { Text("Заблокировать ${target.displayName}?") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Аккаунт будет полностью заблокирован: пользователь увидит экран блокировки и не сможет отправлять сообщения или создавать чаты.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    OutlinedTextField(
                        value = reasonDraft,
                        onValueChange = { if (it.length <= 240) reasonDraft = it },
                        label = { Text("Причина блокировки") },
                        placeholder = { Text("Укажите причину...") },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onModerateUser(target.userId, ModerationStatus.BANNED, null, reasonDraft)
                        banTarget = null
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.error,
                        contentColor = MaterialTheme.colorScheme.onError
                    )
                ) {
                    Text("Заблокировать")
                }
            },
            dismissButton = {
                TextButton(onClick = { banTarget = null }) {
                    Text("Отмена")
                }
            }
        )
    }

    deleteTarget?.let { target ->
        var reasonDraft by remember(target.userId) { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            title = { Text("Удалить аккаунт ${target.displayName}?") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Профили пользователя будут удалены из SpoX, а сам аккаунт будет навсегда закрыт для входа и переписки.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error
                    )
                    OutlinedTextField(
                        value = reasonDraft,
                        onValueChange = { if (it.length <= 240) reasonDraft = it },
                        label = { Text("Причина удаления") },
                        placeholder = { Text("Например: удаление по решению админа") },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onDeleteUserAccount(target.userId, reasonDraft)
                        deleteTarget = null
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.error,
                        contentColor = MaterialTheme.colorScheme.onError
                    )
                ) {
                    Text("Удалить навсегда")
                }
            },
            dismissButton = {
                TextButton(onClick = { deleteTarget = null }) {
                    Text("Отмена")
                }
            }
        )
    }
}
