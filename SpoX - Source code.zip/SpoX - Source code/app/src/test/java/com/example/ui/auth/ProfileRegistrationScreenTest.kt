package com.example.ui.auth

import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.assertIsEnabled
import androidx.compose.ui.test.assertIsNotEnabled
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.test.performTextClearance
import androidx.compose.ui.test.performTextInput
import com.example.data.model.AppThemeMode
import com.example.data.repository.SavedAccount
import com.example.ui.theme.CipherChatTheme
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.LightBackground
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ProfileRegistrationScreenTest {

    @get:Rule
    val composeRule = createComposeRule()

    @Test
    fun profileRegistrationScreen_validatesNameAndSubmitsEditedProfile() {
        var submittedName = ""
        var submittedHandle = ""
        var submittedAvatar = "unset"

        composeRule.setContent {
            CipherChatTheme(themeMode = AppThemeMode.DARK) {
                ProfileRegistrationScreen(
                    uid = "new_user_1",
                    userEmail = "alex.novikov@gmail.com",
                    initialDisplayName = "Alex",
                    keyFingerprint = "ABCD 1234 EF56",
                    isBusy = false,
                    errorMessage = null,
                    onClearError = {},
                    onSubmitProfile = { name, handle, avatar ->
                        submittedName = name
                        submittedHandle = handle
                        submittedAvatar = avatar
                    },
                    onSignOut = {}
                )
            }
        }

        // Photo picker trigger and submit button exist and submit is enabled with initial name
        composeRule.onNodeWithTag("registration_pick_photo_button").performScrollTo().assertIsEnabled()
        composeRule.onNodeWithTag("registration_submit_button").performScrollTo().assertIsEnabled()

        // Clearing name disables submit button
        composeRule.onNodeWithTag("registration_name_input").performScrollTo().performTextClearance()
        composeRule.onNodeWithTag("registration_submit_button").performScrollTo().assertIsNotEnabled()

        // Entering custom name and username enables submit and invokes callback
        composeRule.onNodeWithTag("registration_name_input").performScrollTo().performTextInput("Алексей Новиков")
        composeRule.onNodeWithTag("registration_username_input").performScrollTo().performTextClearance()
        composeRule.onNodeWithTag("registration_username_input").performScrollTo().performTextInput("alex_spox")
        composeRule.onNodeWithTag("registration_submit_button").performScrollTo().assertIsEnabled().performClick()
        composeRule.waitForIdle()

        assertEquals("Алексей Новиков", submittedName)
        assertEquals("alex_spox", submittedHandle)
        assertEquals("", submittedAvatar)
    }

    @Test
    fun profileRegistrationScreen_themeToggleSwitchesColorScheme() {
        var observedBackground: Color = Color.Unspecified

        composeRule.setContent {
            var mode by remember { mutableStateOf(AppThemeMode.DARK) }
            CipherChatTheme(themeMode = mode) {
                observedBackground = MaterialTheme.colorScheme.background
                ProfileRegistrationScreen(
                    uid = "new_user_2",
                    userEmail = "tema@example.com",
                    initialDisplayName = "Tema",
                    keyFingerprint = "1122 3344",
                    isBusy = false,
                    errorMessage = null,
                    themeMode = mode,
                    onToggleTheme = {
                        mode = if (mode == AppThemeMode.LIGHT) AppThemeMode.DARK else AppThemeMode.LIGHT
                    },
                    onClearError = {},
                    onSubmitProfile = { _, _, _ -> },
                    onSignOut = {}
                )
            }
        }

        assertEquals(DarkBackground, observedBackground)

        composeRule.onNodeWithTag("registration_theme_toggle_button")
            .assertIsDisplayed()
            .performClick()
        composeRule.waitForIdle()

        assertEquals(LightBackground, observedBackground)

        composeRule.onNodeWithTag("registration_theme_toggle_button").performClick()
        composeRule.waitForIdle()

        assertEquals(DarkBackground, observedBackground)
    }

    @Test
    fun authScreen_themeToggleIsClickableAboveScrollableContentAndUpdatesTheme() {
        var observedBackground: Color = Color.Unspecified

        composeRule.setContent {
            var mode by remember { mutableStateOf(AppThemeMode.DARK) }
            CipherChatTheme(themeMode = mode) {
                observedBackground = MaterialTheme.colorScheme.background
                AuthScreen(
                    themeMode = mode,
                    onToggleTheme = {
                        mode = if (mode == AppThemeMode.LIGHT) AppThemeMode.DARK else AppThemeMode.LIGHT
                    },
                    savedAccounts = listOf(
                        SavedAccount(
                            uid = "saved_1",
                            email = "user@example.com",
                            displayName = "Saved User",
                            handle = "saved_user"
                        )
                    ),
                    skipAutoSignIn = true,
                    canAutoSignIn = false,
                    onAuthSuccess = {}
                )
            }
        }

        assertEquals(DarkBackground, observedBackground)

        composeRule.onNodeWithTag("auth_theme_toggle_button")
            .assertIsDisplayed()
            .performClick()
        composeRule.waitForIdle()

        assertEquals(LightBackground, observedBackground)
    }
}
