package com.example.crypto

import android.content.Context
import android.util.Base64
import com.example.data.model.ForwardOriginInfo
import com.example.data.model.ReplyQuoteInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.security.KeyFactory
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.MessageDigest
import java.security.PrivateKey
import java.security.PublicKey
import java.security.SecureRandom
import java.security.spec.ECGenParameterSpec
import java.security.spec.PKCS8EncodedKeySpec
import java.security.spec.X509EncodedKeySpec
import javax.crypto.Cipher
import javax.crypto.KeyAgreement
import javax.crypto.Mac
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

data class EncryptedBlob(
    val ivBase64: String,
    val ciphertextBase64: String
)

data class DecryptedTextPayload(
    val text: String,
    val replyTo: ReplyQuoteInfo? = null,
    val forwardedFrom: ForwardOriginInfo? = null
)

data class DecryptedFilePayload(
    val fileName: String,
    val mimeType: String,
    val sizeBytes: Long,
    val bytes: ByteArray,
    val isChunked: Boolean = false,
    val chunkCount: Int = 0,
    val replyTo: ReplyQuoteInfo? = null,
    val forwardedFrom: ForwardOriginInfo? = null
)

data class DecryptedVoicePayload(
    val durationMs: Long,
    val waveform: List<Int>,
    val audioBytes: ByteArray,
    val replyTo: ReplyQuoteInfo? = null,
    val forwardedFrom: ForwardOriginInfo? = null
)

/**
 * Real End-to-End Encryption engine using:
 * - ECDH P-256 (secp256r1) identity & ephemeral key exchange
 * - HKDF-SHA256 key derivation
 * - AES-256-GCM authenticated encryption for messages, voice notes, and files
 */
class CryptoManager(
    context: Context? = null,
    private val accountScope: String? = null
) {

    private val prefs = context?.applicationContext?.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    private val secureRandom = SecureRandom()

    @Volatile
    private var cachedKeyPair: KeyPair? = null

    @Volatile
    private var cachedFingerprint: String? = null

    private fun privKeyName(): String =
        if (accountScope.isNullOrBlank()) KEY_PRIVATE_B64 else "${KEY_PRIVATE_B64}_$accountScope"

    private fun pubKeyName(): String =
        if (accountScope.isNullOrBlank()) KEY_PUBLIC_B64 else "${KEY_PUBLIC_B64}_$accountScope"

    fun getOrCreateIdentityKeyPair(): KeyPair {
        cachedKeyPair?.let { return it }
        synchronized(this) {
            cachedKeyPair?.let { return it }
            val scopedPriv = prefs?.getString(privKeyName(), null)
            val scopedPub = prefs?.getString(pubKeyName(), null)
            var migratedFromLegacy = false
            val existingPriv: String?
            val existingPub: String?
            if (!scopedPriv.isNullOrBlank() && !scopedPub.isNullOrBlank()) {
                existingPriv = scopedPriv
                existingPub = scopedPub
            } else {
                val canMigrateLegacy = !accountScope.isNullOrBlank() &&
                    prefs != null &&
                    prefs.getString(KEY_LEGACY_MIGRATED_UID, null) == null &&
                    prefs.all.keys.none { it.startsWith("${KEY_PRIVATE_B64}_") }
                migratedFromLegacy = canMigrateLegacy
                existingPriv = if (canMigrateLegacy) prefs?.getString(KEY_PRIVATE_B64, null) else null
                existingPub = if (canMigrateLegacy) prefs?.getString(KEY_PUBLIC_B64, null) else null
            }

            if (!existingPriv.isNullOrBlank() && !existingPub.isNullOrBlank()) {
                runCatching {
                    val kf = KeyFactory.getInstance("EC")
                    val priv = kf.generatePrivate(PKCS8EncodedKeySpec(decodeB64(existingPriv)))
                    val pub = kf.generatePublic(X509EncodedKeySpec(decodeB64(existingPub)))
                    if (migratedFromLegacy || scopedPriv.isNullOrBlank() || scopedPub.isNullOrBlank()) {
                        prefs?.edit()?.apply {
                            putString(privKeyName(), existingPriv)
                            putString(pubKeyName(), existingPub)
                            if (migratedFromLegacy && !accountScope.isNullOrBlank()) {
                                putString(KEY_LEGACY_MIGRATED_UID, accountScope)
                            }
                        }?.apply()
                    }
                    return KeyPair(pub, priv).also { cachedKeyPair = it }
                }
            }

            val kpg = KeyPairGenerator.getInstance("EC")
            try {
                kpg.initialize(ECGenParameterSpec("secp256r1"), secureRandom)
            } catch (_: Exception) {
                kpg.initialize(ECGenParameterSpec("prime256v1"), secureRandom)
            }
            val generated = kpg.generateKeyPair()
            prefs?.edit()
                ?.putString(privKeyName(), encodeB64(generated.private.encoded))
                ?.putString(pubKeyName(), encodeB64(generated.public.encoded))
                ?.apply()
            cachedKeyPair = generated
            return generated
        }
    }

    fun getPublicKeyBase64(): String = encodeB64(getOrCreateIdentityKeyPair().public.encoded)

    fun getCachedKeyFingerprint(): String? = cachedFingerprint

    suspend fun getKeyFingerprintAsync(): String = withContext(Dispatchers.Default) {
        getKeyFingerprint()
    }

    fun getKeyFingerprint(publicKeyBase64: String = getPublicKeyBase64()): String {
        if (cachedKeyPair != null && cachedFingerprint != null && publicKeyBase64 == encodeB64(cachedKeyPair!!.public.encoded)) {
            return cachedFingerprint!!
        }
        val digest = MessageDigest.getInstance("SHA-256").digest(decodeB64(publicKeyBase64))
        val formatted = digest.take(12).joinToString("") { "%02X".format(it) }
            .chunked(4)
            .joinToString(" ")
        if (cachedKeyPair != null && publicKeyBase64 == encodeB64(cachedKeyPair!!.public.encoded)) {
            cachedFingerprint = formatted
        }
        return formatted
    }

    fun sha256Hex(input: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(input.toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }

    fun generateRoomKey(): ByteArray {
        val key = ByteArray(32)
        secureRandom.nextBytes(key)
        return key
    }

    /**
     * Wraps a 256-bit AES room key for a recipient using an ephemeral ECDH P-256 keypair,
     * HKDF-SHA256, and AES-256-GCM. Format: ephemPubB64:ivB64:cipherB64
     */
    fun wrapRoomKeyForMember(roomKey: ByteArray, recipientPublicKeyBase64: String): String {
        val kf = KeyFactory.getInstance("EC")
        val recipientPub: PublicKey = kf.generatePublic(X509EncodedKeySpec(decodeB64(recipientPublicKeyBase64)))

        val kpg = KeyPairGenerator.getInstance("EC")
        kpg.initialize(ECGenParameterSpec("secp256r1"), secureRandom)
        val ephemeral = kpg.generateKeyPair()

        val sharedSecret = deriveEcdhSharedSecret(ephemeral.private, recipientPub)
        val wrappingKey = hkdfSha256(sharedSecret, "CipherChat-RoomKey-Wrap-v1".toByteArray())
        val wrapped = encryptAesGcm(wrappingKey, roomKey)

        return listOf(
            encodeB64(ephemeral.public.encoded),
            wrapped.ivBase64,
            wrapped.ciphertextBase64
        ).joinToString(":")
    }

    fun unwrapRoomKey(envelope: String): ByteArray? = runCatching {
        val parts = envelope.split(":")
        if (parts.size != 3) return null
        val ephemPubBytes = decodeB64(parts[0])
        val kf = KeyFactory.getInstance("EC")
        val ephemPub = kf.generatePublic(X509EncodedKeySpec(ephemPubBytes))
        val myPrivate = getOrCreateIdentityKeyPair().private
        val sharedSecret = deriveEcdhSharedSecret(myPrivate, ephemPub)
        val wrappingKey = hkdfSha256(sharedSecret, "CipherChat-RoomKey-Wrap-v1".toByteArray())
        decryptAesGcm(wrappingKey, parts[1], parts[2])
    }.getOrNull()

    fun encryptText(roomKey: ByteArray, plaintext: String): EncryptedBlob {
        return encryptAesGcm(roomKey, plaintext.toByteArray(Charsets.UTF_8))
    }

    fun decryptText(roomKey: ByteArray, ivBase64: String, ciphertextBase64: String): String? {
        return decryptAesGcm(roomKey, ivBase64, ciphertextBase64)?.toString(Charsets.UTF_8)
    }

    fun encryptRichText(
        roomKey: ByteArray,
        plaintext: String,
        replyTo: ReplyQuoteInfo? = null,
        forwardedFrom: ForwardOriginInfo? = null
    ): EncryptedBlob {
        if (replyTo == null && forwardedFrom == null) {
            return encryptText(roomKey, plaintext)
        }
        val json = JSONObject().apply {
            put("text", plaintext)
            attachEnvelopeMetadata(this, replyTo, forwardedFrom)
        }
        return encryptText(roomKey, RICH_TEXT_PREFIX + json.toString())
    }

    fun decryptRichText(
        roomKey: ByteArray,
        ivBase64: String,
        ciphertextBase64: String
    ): DecryptedTextPayload? {
        val raw = decryptText(roomKey, ivBase64, ciphertextBase64) ?: return null
        if (!raw.startsWith(RICH_TEXT_PREFIX)) {
            return DecryptedTextPayload(text = raw)
        }
        val parsed = runCatching {
            val json = JSONObject(raw.removePrefix(RICH_TEXT_PREFIX))
            DecryptedTextPayload(
                text = json.getString("text"),
                replyTo = parseReplyQuote(json.optJSONObject("replyTo")),
                forwardedFrom = parseForwardOrigin(json.optJSONObject("forwardedFrom"))
            )
        }.getOrNull()
        return parsed ?: DecryptedTextPayload(text = raw)
    }

    fun encryptFilePayload(
        roomKey: ByteArray,
        fileName: String,
        mimeType: String,
        bytes: ByteArray,
        replyTo: ReplyQuoteInfo? = null,
        forwardedFrom: ForwardOriginInfo? = null
    ): EncryptedBlob {
        val json = JSONObject().apply {
            put("fileName", fileName)
            put("mimeType", mimeType)
            put("sizeBytes", bytes.size.toLong())
            put("isChunked", false)
            put("chunkCount", 0)
            put("dataBase64", encodeB64(bytes))
            attachEnvelopeMetadata(this, replyTo, forwardedFrom)
        }.toString()
        return encryptText(roomKey, json)
    }

    fun encryptChunkedFileManifest(
        roomKey: ByteArray,
        fileName: String,
        mimeType: String,
        sizeBytes: Long,
        chunkCount: Int,
        replyTo: ReplyQuoteInfo? = null,
        forwardedFrom: ForwardOriginInfo? = null
    ): EncryptedBlob {
        val json = JSONObject().apply {
            put("fileName", fileName)
            put("mimeType", mimeType)
            put("sizeBytes", sizeBytes)
            put("isChunked", true)
            put("chunkCount", chunkCount)
            attachEnvelopeMetadata(this, replyTo, forwardedFrom)
        }.toString()
        return encryptText(roomKey, json)
    }

    fun encryptMediaChunk(roomKey: ByteArray, chunkBytes: ByteArray): EncryptedBlob {
        return encryptAesGcm(roomKey, chunkBytes)
    }

    fun decryptMediaChunk(roomKey: ByteArray, ivBase64: String, ciphertextBase64: String): ByteArray? {
        return decryptAesGcm(roomKey, ivBase64, ciphertextBase64)
    }

    fun decryptFilePayload(
        roomKey: ByteArray,
        ivBase64: String,
        ciphertextBase64: String
    ): DecryptedFilePayload? = runCatching {
        val raw = decryptText(roomKey, ivBase64, ciphertextBase64) ?: return null
        val json = JSONObject(raw)
        val isChunked = json.optBoolean("isChunked", false)
        val chunkCount = json.optInt("chunkCount", 0)
        val dataB64 = json.optString("dataBase64", "")
        val decodedBytes = if (isChunked) {
            ByteArray(0)
        } else {
            decodeB64(dataB64)
        }
        DecryptedFilePayload(
            fileName = json.optString("fileName", "file.bin"),
            mimeType = json.optString("mimeType", "application/octet-stream"),
            sizeBytes = json.optLong("sizeBytes", decodedBytes.size.toLong()),
            bytes = decodedBytes,
            isChunked = isChunked,
            chunkCount = chunkCount,
            replyTo = parseReplyQuote(json.optJSONObject("replyTo")),
            forwardedFrom = parseForwardOrigin(json.optJSONObject("forwardedFrom"))
        )
    }.getOrNull()

    fun encryptVoicePayload(
        roomKey: ByteArray,
        durationMs: Long,
        waveform: List<Int>,
        audioBytes: ByteArray,
        replyTo: ReplyQuoteInfo? = null,
        forwardedFrom: ForwardOriginInfo? = null
    ): EncryptedBlob {
        val json = JSONObject().apply {
            put("durationMs", durationMs)
            put("waveform", JSONArray(waveform))
            put("audioBase64", encodeB64(audioBytes))
            attachEnvelopeMetadata(this, replyTo, forwardedFrom)
        }.toString()
        return encryptText(roomKey, json)
    }

    fun decryptVoicePayload(
        roomKey: ByteArray,
        ivBase64: String,
        ciphertextBase64: String
    ): DecryptedVoicePayload? = runCatching {
        val raw = decryptText(roomKey, ivBase64, ciphertextBase64) ?: return null
        val json = JSONObject(raw)
        val arr = json.optJSONArray("waveform") ?: JSONArray()
        val bars = List(arr.length()) { idx -> arr.optInt(idx, 20) }
        DecryptedVoicePayload(
            durationMs = json.optLong("durationMs", 0L),
            waveform = bars,
            audioBytes = decodeB64(json.getString("audioBase64")),
            replyTo = parseReplyQuote(json.optJSONObject("replyTo")),
            forwardedFrom = parseForwardOrigin(json.optJSONObject("forwardedFrom"))
        )
    }.getOrNull()

    private fun attachEnvelopeMetadata(
        target: JSONObject,
        replyTo: ReplyQuoteInfo?,
        forwardedFrom: ForwardOriginInfo?
    ) {
        if (replyTo != null) {
            target.put(
                "replyTo",
                JSONObject().apply {
                    put("messageId", replyTo.messageId)
                    put("senderName", replyTo.senderName)
                    put("previewText", replyTo.previewText.take(160))
                    put("messageType", replyTo.messageType)
                }
            )
        }
        if (forwardedFrom != null) {
            target.put(
                "forwardedFrom",
                JSONObject().apply {
                    put("originalSenderId", forwardedFrom.originalSenderId)
                    put("originalSenderName", forwardedFrom.originalSenderName)
                }
            )
        }
    }

    private fun parseReplyQuote(obj: JSONObject?): ReplyQuoteInfo? {
        obj ?: return null
        val messageId = obj.optString("messageId", "")
        val senderName = obj.optString("senderName", "")
        val previewText = obj.optString("previewText", "")
        val messageType = obj.optString("messageType", "text")
        if (messageId.isBlank() && previewText.isBlank()) return null
        return ReplyQuoteInfo(
            messageId = messageId,
            senderName = senderName.ifBlank { "Участник" },
            previewText = previewText,
            messageType = messageType
        )
    }

    private fun parseForwardOrigin(obj: JSONObject?): ForwardOriginInfo? {
        obj ?: return null
        val origName = obj.optString("originalSenderName", "")
        val origId = obj.optString("originalSenderId", "")
        if (origName.isBlank() && origId.isBlank()) return null
        return ForwardOriginInfo(
            originalSenderId = origId,
            originalSenderName = origName.ifBlank { "Участник" }
        )
    }

    fun computeConversationSafetyNumber(fingerprints: List<String>): String {
        val canonical = fingerprints.sorted().joinToString("|")
        val digest = MessageDigest.getInstance("SHA-256").digest(canonical.toByteArray(Charsets.UTF_8))
        val digits = digest.take(15).joinToString("") { byte ->
            val v = (byte.toInt() and 0xFF) % 100
            "%02d".format(v)
        }
        return digits.chunked(5).joinToString(" ")
    }

    private fun deriveEcdhSharedSecret(privateKey: PrivateKey, publicKey: PublicKey): ByteArray {
        val agreement = KeyAgreement.getInstance("ECDH")
        agreement.init(privateKey)
        agreement.doPhase(publicKey, true)
        return agreement.generateSecret()
    }

    private fun hkdfSha256(ikm: ByteArray, info: ByteArray): ByteArray {
        val macExtract = Mac.getInstance("HmacSHA256")
        val salt = ByteArray(32)
        macExtract.init(SecretKeySpec(salt, "HmacSHA256"))
        val prk = macExtract.doFinal(ikm)

        val macExpand = Mac.getInstance("HmacSHA256")
        macExpand.init(SecretKeySpec(prk, "HmacSHA256"))
        macExpand.update(info)
        macExpand.update(0x01.toByte())
        return macExpand.doFinal().copyOf(32)
    }

    private fun encryptAesGcm(key: ByteArray, plaintext: ByteArray): EncryptedBlob {
        val iv = ByteArray(12)
        secureRandom.nextBytes(iv)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, iv))
        val ciphertext = cipher.doFinal(plaintext)
        return EncryptedBlob(encodeB64(iv), encodeB64(ciphertext))
    }

    private fun decryptAesGcm(key: ByteArray, ivBase64: String, ciphertextBase64: String): ByteArray? {
        return runCatching {
            val iv = decodeB64(ivBase64)
            val ct = decodeB64(ciphertextBase64)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, iv))
            cipher.doFinal(ct)
        }.getOrNull()
    }

    private fun encodeB64(bytes: ByteArray): String = Base64.encodeToString(bytes, Base64.NO_WRAP)

    private fun decodeB64(value: String): ByteArray = Base64.decode(value, Base64.NO_WRAP)

    private companion object {
        const val PREFS_NAME = "cipherchat_e2ee_identity"
        const val KEY_PRIVATE_B64 = "ecdh_priv_b64"
        const val KEY_PUBLIC_B64 = "ecdh_pub_b64"
        const val KEY_LEGACY_MIGRATED_UID = "ecdh_legacy_migrated_uid"
        const val RICH_TEXT_PREFIX = "__SPOX_E2EE_META_V1__:"
    }
}
