package com.example.ui.viewmodel

import android.content.Context
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.crypto.CryptoManager
import com.example.media.FileAttachmentHelper
import com.example.data.model.Conversation
import com.example.data.model.DecryptedContent
import com.example.data.model.DecryptedMessageItem
import com.example.data.model.EncryptedMessage
import com.example.data.model.ForwardOriginInfo
import com.example.data.model.PublicUserProfile
import com.example.data.model.ReplyQuoteInfo
import com.example.data.model.UserPrivateProfile
import com.example.data.repository.CallRepository
import com.example.data.repository.ChatRepository
import com.example.media.MediaKind
import com.example.media.PreparedAttachment
import com.example.media.RecordedVoiceResult
import com.example.plugins.OutgoingTransformResult
import com.example.plugins.PluginCommandOutcome
import com.example.plugins.PluginHookContext
import com.example.plugins.PluginStore
import com.example.ui.components.MediaTransferUiState
import com.example.ui.components.formatDurationMillis
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean

data class ChatRoomUiData(
    val conversation: Conversation?,
    val messages: List<DecryptedMessageItem>,
    val hasRoomKey: Boolean,
    val safetyNumber: String,
    val memberProfiles: List<PublicUserProfile>,
    val isCurrentUserMuted: Boolean = false,
    val mutedUntilEpochMs: Long = 0L,
    val moderationReason: String = ""
)

class ChatRoomViewModel(
    private val chatRepository: ChatRepository,
    private val callRepository: CallRepository,
    private val crypto: CryptoManager,
    private val chatId: String,
    private val currentUserId: String,
    private val currentUserName: String,
    private val pluginStore: PluginStore? = null
) : ViewModel() {

    private val _statusBanner = MutableStateFlow<String?>(null)
    val statusBanner: StateFlow<String?> = _statusBanner.asStateFlow()

    private val _isSending = MutableStateFlow(false)
    val isSending: StateFlow<Boolean> = _isSending.asStateFlow()

    private val _activeUpload = MutableStateFlow<MediaTransferUiState?>(null)
    val activeUpload: StateFlow<MediaTransferUiState?> = _activeUpload.asStateFlow()

    private val _downloadProgress = MutableStateFlow<Map<String, Float>>(emptyMap())
    val downloadProgress: StateFlow<Map<String, Float>> = _downloadProgress.asStateFlow()

    private val _completedDownloads = MutableStateFlow<Set<String>>(emptySet())
    val completedDownloads: StateFlow<Set<String>> = _completedDownloads.asStateFlow()

    private val _replyingTo = MutableStateFlow<ReplyQuoteInfo?>(null)
    val replyingTo: StateFlow<ReplyQuoteInfo?> = _replyingTo.asStateFlow()

    private val _isForwarding = MutableStateFlow(false)
    val isForwarding: StateFlow<Boolean> = _isForwarding.asStateFlow()

    private val _isGroupActionBusy = MutableStateFlow(false)
    val isGroupActionBusy: StateFlow<Boolean> = _isGroupActionBusy.asStateFlow()

    private val _isChatClosedOrRemoved = MutableStateFlow(false)
    val isChatClosedOrRemoved: StateFlow<Boolean> = _isChatClosedOrRemoved.asStateFlow()

    private val _isMessagesFromCache = MutableStateFlow(false)
    val isMessagesFromCache: StateFlow<Boolean> = _isMessagesFromCache.asStateFlow()

    private val _memberSearchResults = MutableStateFlow<List<PublicUserProfile>>(emptyList())
    val memberSearchResults: StateFlow<List<PublicUserProfile>> = _memberSearchResults.asStateFlow()

    private val _isSearchingMembers = MutableStateFlow(false)
    val isSearchingMembers: StateFlow<Boolean> = _isSearchingMembers.asStateFlow()

    private var memberSearchJob: kotlinx.coroutines.Job? = null
    private var hasSeenConversation = false
    private val _fallbackMemberProfiles = MutableStateFlow<Map<String, PublicUserProfile>>(emptyMap())
    private val _roomKeyVersion = MutableStateFlow(0)
    private val attemptedKeyRepair = AtomicBoolean(false)

    private data class CachedDecryptedEntry(
        val keyVersion: Int,
        val hadRoomKey: Boolean,
        val raw: EncryptedMessage,
        val item: DecryptedMessageItem
    )

    private val decryptedMessageCache = ConcurrentHashMap<String, CachedDecryptedEntry>()

    @Volatile
    private var cachedRoomKey: ByteArray? = null

    @Volatile
    private var cachedRoomEnvelope: String? = null

    val userConversations: StateFlow<List<Conversation>> = chatRepository
        .observeConversations(currentUserId)
        .catch { error ->
            val fsError = generateSequence(error) { it.cause }
                .filterIsInstance<FirebaseFirestoreException>()
                .firstOrNull()
            if (fsError == null && error is CancellationException) throw error
            emit(emptyList())
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(0L),
            initialValue = emptyList()
        )

    val directoryUsers: StateFlow<List<PublicUserProfile>> = chatRepository
        .observeDiscoverableUsers()
        .catch { error ->
            val fsError = generateSequence(error) { it.cause }
                .filterIsInstance<FirebaseFirestoreException>()
                .firstOrNull()
            if (fsError == null && error is CancellationException) throw error
            emit(emptyList())
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(0L),
            initialValue = emptyList()
        )

    val privateProfile: StateFlow<UserPrivateProfile?> = chatRepository
        .observePrivateProfile(currentUserId)
        .catch { error ->
            val fsError = generateSequence(error) { it.cause }
                .filterIsInstance<FirebaseFirestoreException>()
                .firstOrNull()
            if (fsError == null && error is CancellationException) throw error
            emit(null)
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(0L),
            initialValue = null
        )

    private val conversationFlow = chatRepository
        .observeConversation(chatId, currentUserId)
        .map { conv ->
            if (conv != null) {
                hasSeenConversation = true
            } else if (hasSeenConversation) {
                _isChatClosedOrRemoved.value = true
            }
            conv
        }
        .catch { error ->
            val fsError = generateSequence(error) { it.cause }
                .filterIsInstance<FirebaseFirestoreException>()
                .firstOrNull()
            if (fsError == null && error is CancellationException) throw error
            if (fsError?.code == FirebaseFirestoreException.Code.PERMISSION_DENIED && hasSeenConversation) {
                _isChatClosedOrRemoved.value = true
                emit(null)
            } else {
                throw error
            }
        }

    private val messagesFlow = chatRepository
        .observeMessagesWithMetadata(chatId, currentUserId)
        .map { snap ->
            _isMessagesFromCache.value = snap.isFromCache
            snap.messages
        }
        .catch { error ->
            _isMessagesFromCache.value = false
            val fsError = generateSequence(error) { it.cause }
                .filterIsInstance<FirebaseFirestoreException>()
                .firstOrNull()
            if (fsError == null && error is CancellationException) throw error
            if (fsError?.code == FirebaseFirestoreException.Code.PERMISSION_DENIED && hasSeenConversation) {
                _isChatClosedOrRemoved.value = true
                emit(emptyList())
            } else {
                throw error
            }
        }

    @OptIn(ExperimentalCoroutinesApi::class)
    private val liveMemberProfilesFlow = conversationFlow
        .map { conv -> conv?.memberUids.orEmpty().filter { it.isNotBlank() }.distinct().sorted() }
        .distinctUntilChanged()
        .flatMapLatest { memberIds -> chatRepository.observePublicProfilesByIds(memberIds) }

    @Suppress("UNCHECKED_CAST")
    val roomState: StateFlow<UiState<ChatRoomUiData>> = combine(
        conversationFlow,
        messagesFlow,
        directoryUsers,
        privateProfile,
        _fallbackMemberProfiles,
        liveMemberProfilesFlow,
        _roomKeyVersion
    ) { values ->
        val conversation = values[0] as Conversation?
        val rawMessages = values[1] as List<EncryptedMessage>
        val users = values[2] as List<PublicUserProfile>
        val myPriv = values[3] as UserPrivateProfile?
        val fallbackMap = values[4] as Map<String, PublicUserProfile>
        val liveMemberMap = values[5] as Map<String, PublicUserProfile>

        val envelope = conversation?.memberKeyEnvelopes?.get(currentUserId)
        val roomKey = if (!envelope.isNullOrBlank()) {
            val currentCached = cachedRoomKey
            if (currentCached != null && cachedRoomEnvelope == envelope) {
                currentCached
            } else {
                val unwrapped = crypto.unwrapRoomKey(envelope)
                if (unwrapped != null) {
                    cachedRoomKey = unwrapped
                    cachedRoomEnvelope = envelope
                    unwrapped
                } else {
                    cachedRoomKey
                }
            }
        } else {
            cachedRoomKey
        }

        val directoryById = users.associateBy { it.userId }
        val memberProfiles = if (conversation != null) {
            conversation.memberUids.mapNotNull { uid ->
                liveMemberMap[uid] ?: directoryById[uid] ?: fallbackMap[uid]
            }
        } else {
            emptyList()
        }

        val fingerprints = memberProfiles.map { it.keyFingerprint }.ifEmpty {
            listOf(crypto.getKeyFingerprint())
        }
        val safetyNumber = crypto.computeConversationSafetyNumber(fingerprints)

        val keyVersion = (values[6] as Int)
        val hasRoomKeyNow = roomKey != null
        val decrypted = rawMessages.map { msg ->
            val cached = decryptedMessageCache[msg.id]
            val canReuseCached = cached != null &&
                cached.raw.isDeleted == msg.isDeleted &&
                cached.raw.messageType == msg.messageType &&
                cached.raw.senderName == msg.senderName &&
                cached.raw.ivBase64 == msg.ivBase64 &&
                cached.raw.encryptedPayload == msg.encryptedPayload &&
                (cached.item.isEncryptedVerified || msg.isDeleted ||
                    (cached.keyVersion == keyVersion && cached.hadRoomKey == hasRoomKeyNow))
            if (canReuseCached) {
                if (cached.item.createdAt == msg.createdAt) cached.item
                else cached.item.copy(createdAt = msg.createdAt)
            } else {
                var replyMeta: ReplyQuoteInfo? = null
                var forwardMeta: ForwardOriginInfo? = null
                val content: DecryptedContent = when {
                    msg.isDeleted -> DecryptedContent.Deleted
                    roomKey == null -> DecryptedContent.KeyUnavailable
                    msg.messageType == "text" -> {
                        val txtPayload = crypto.decryptRichText(roomKey, msg.ivBase64, msg.encryptedPayload)
                        if (txtPayload != null) {
                            replyMeta = txtPayload.replyTo
                            forwardMeta = txtPayload.forwardedFrom
                            DecryptedContent.Text(txtPayload.text)
                        } else {
                            DecryptedContent.KeyUnavailable
                        }
                    }
                    msg.messageType == "voice" -> {
                        val voice = crypto.decryptVoicePayload(roomKey, msg.ivBase64, msg.encryptedPayload)
                        if (voice != null) {
                            replyMeta = voice.replyTo
                            forwardMeta = voice.forwardedFrom
                            DecryptedContent.Voice(voice.durationMs, voice.waveform, voice.audioBytes)
                        } else {
                            DecryptedContent.KeyUnavailable
                        }
                    }
                    msg.messageType == "file" || msg.messageType == "image" -> {
                        val file = crypto.decryptFilePayload(roomKey, msg.ivBase64, msg.encryptedPayload)
                        if (file != null) {
                            replyMeta = file.replyTo
                            forwardMeta = file.forwardedFrom
                            DecryptedContent.FileAttachment(
                                fileName = file.fileName,
                                mimeType = file.mimeType,
                                sizeBytes = file.sizeBytes,
                                bytes = file.bytes,
                                isImage = msg.messageType == "image" || file.mimeType.startsWith("image/"),
                                isChunked = file.isChunked,
                                chunkCount = file.chunkCount
                            )
                        } else {
                            DecryptedContent.KeyUnavailable
                        }
                    }
                    msg.messageType == "call_event" -> {
                        val txt = crypto.decryptText(roomKey, msg.ivBase64, msg.encryptedPayload)
                        if (txt != null) DecryptedContent.CallEvent(txt) else DecryptedContent.KeyUnavailable
                    }
                    else -> DecryptedContent.KeyUnavailable
                }

                val built = DecryptedMessageItem(
                    id = msg.id,
                    conversationId = msg.conversationId,
                    senderId = msg.senderId,
                    senderName = msg.senderName,
                    messageType = msg.messageType,
                    content = content,
                    createdAt = msg.createdAt,
                    isEncryptedVerified = roomKey != null && content !is DecryptedContent.KeyUnavailable,
                    replyTo = replyMeta,
                    forwardedFrom = forwardMeta
                )
                if (hasRoomKeyNow || msg.isDeleted) {
                    decryptedMessageCache[msg.id] = CachedDecryptedEntry(
                        keyVersion = keyVersion,
                        hadRoomKey = hasRoomKeyNow,
                        raw = msg,
                        item = built
                    )
                }
                built
            }
        }

        val isMuted = myPriv?.isCurrentlyMuted() == true
        UiState.Success(
            ChatRoomUiData(
                conversation = conversation,
                messages = decrypted,
                hasRoomKey = roomKey != null,
                safetyNumber = safetyNumber,
                memberProfiles = memberProfiles,
                isCurrentUserMuted = isMuted,
                mutedUntilEpochMs = if (isMuted) myPriv?.mutedUntilEpochMs ?: 0L else 0L,
                moderationReason = if (isMuted) myPriv?.moderationReason.orEmpty() else ""
            )
        ) as UiState<ChatRoomUiData>
    }.flowOn(Dispatchers.Default).catch { error ->
        val fsError = generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (fsError == null && error is CancellationException) throw error
        val root = fsError ?: error
        Log.w(TAG, "Error observing chat room", root)
        emit(UiState.Error(root.message ?: "Ошибка загрузки чата"))
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(0L),
        initialValue = UiState.Loading
    )

    init {
        viewModelScope.launch {
            roomState.collect { state ->
                val data = (state as? UiState.Success)?.data ?: return@collect
                val conv = data.conversation ?: return@collect

                // Fetch fallback profiles for members who disabled directory discoverability
                val knownIds = (directoryUsers.value.map { it.userId } + _fallbackMemberProfiles.value.keys).toSet()
                val missingIds = conv.memberUids.filter { it !in knownIds }
                if (missingIds.isNotEmpty()) {
                    launch {
                        runCatching {
                            chatRepository.getPublicProfiles(missingIds)
                        }.onSuccess { loaded ->
                            if (loaded.isNotEmpty()) {
                                _fallbackMemberProfiles.value = _fallbackMemberProfiles.value + loaded.associateBy { it.userId }
                            }
                        }
                    }
                }

                // Auto-repair E2EE key if missing or generated on a new device install
                if (!data.hasRoomKey && attemptedKeyRepair.compareAndSet(false, true)) {
                    launch {
                        runCatching {
                            chatRepository.repairRoomKey(conv, currentUserId)
                        }.onSuccess { newKey ->
                            cachedRoomKey = newKey
                            cachedRoomEnvelope = null
                            _roomKeyVersion.value++
                        }.onFailure { err ->
                            Log.w(TAG, "Auto room key repair failed", err)
                        }
                    }
                }

                // Mark conversation read whenever viewing it with unread incoming messages
                val unread = conv.unreadCountFor(currentUserId)
                val myReadCursor = conv.lastReadAtMillis[currentUserId] ?: 0L
                val latestIncomingMs = data.messages
                    .filter { it.senderId != currentUserId }
                    .mapNotNull { it.createdAt?.toDate()?.time }
                    .maxOrNull() ?: 0L
                val convUpdatedMs = conv.updatedAt?.toDate()?.time ?: 0L
                val needsReadReceipt = unread > 0 ||
                    (conv.lastMessageSenderId.isNotBlank() &&
                        conv.lastMessageSenderId != currentUserId &&
                        maxOf(latestIncomingMs, convUpdatedMs) > myReadCursor)

                if (needsReadReceipt) {
                    launch {
                        val readAt = maxOf(System.currentTimeMillis(), latestIncomingMs, convUpdatedMs)
                        chatRepository.markConversationAsRead(conv, currentUserId, readAt)
                    }
                }
            }
        }
    }

    fun retryRepairRoomKey() {
        val conv = (roomState.value as? UiState.Success)?.data?.conversation ?: return
        viewModelScope.launch {
            runCatching {
                chatRepository.repairRoomKey(conv, currentUserId)
            }.onSuccess { newKey ->
                cachedRoomKey = newKey
                cachedRoomEnvelope = null
                _roomKeyVersion.value++
                _statusBanner.value = "Ключ шифрования восстановлен"
            }.onFailure { err ->
                _statusBanner.value = err.localizedMessage ?: "Не удалось восстановить ключ"
            }
        }
    }

    private suspend fun ensureWritableKey(conversation: Conversation): ByteArray {
        cachedRoomKey?.let { return it }
        val repaired = chatRepository.repairRoomKey(conversation, currentUserId)
        cachedRoomKey = repaired
        cachedRoomEnvelope = null
        _roomKeyVersion.value++
        return repaired
    }

    private fun checkMuteBlock(): Boolean {
        val priv = privateProfile.value ?: return false
        if (priv.isBanned()) {
            _statusBanner.value = "Аккаунт заблокирован администратором"
            return true
        }
        if (priv.isCurrentlyMuted()) {
            _statusBanner.value = "Отправка отключена: вам выдан мут"
            return true
        }
        return false
    }

    fun startReply(item: DecryptedMessageItem) {
        val preview = when (val c = item.content) {
            is DecryptedContent.Text -> c.text.replace('\n', ' ').trim().take(120)
            is DecryptedContent.Voice -> "Голосовое сообщение (${formatDurationMillis(c.durationMs)})"
            is DecryptedContent.FileAttachment -> when {
                c.isImage -> "Фото: ${c.fileName}"
                FileAttachmentHelper.classifyMediaKind(c.mimeType, c.fileName) == MediaKind.VIDEO -> "Видео: ${c.fileName}"
                FileAttachmentHelper.classifyMediaKind(c.mimeType, c.fileName) == MediaKind.AUDIO -> "Аудио: ${c.fileName}"
                else -> "Файл: ${c.fileName}"
            }
            is DecryptedContent.CallEvent -> c.text
            else -> return
        }
        val authorLabel = if (item.senderId == currentUserId) {
            currentUserName.ifBlank { "Вы" }
        } else {
            item.senderName.ifBlank { "Участник" }
        }
        _replyingTo.value = ReplyQuoteInfo(
            messageId = item.id,
            senderName = authorLabel,
            previewText = preview.ifBlank { "Сообщение" },
            messageType = item.messageType
        )
    }

    fun cancelReply() {
        _replyingTo.value = null
    }

    fun sendTextMessage(text: String) {
        val cleaned = text.trim()
        if (cleaned.isEmpty()) return
        if (checkMuteBlock()) return
        val data = (roomState.value as? UiState.Success)?.data ?: return
        val conversation = data.conversation ?: return
        val pendingReply = _replyingTo.value

        viewModelScope.launch {
            _isSending.value = true
            runCatching {
                var finalTextToSend = cleaned
                if (pluginStore != null) {
                    val hookCtx = PluginHookContext(
                        chatId = chatId,
                        chatTitle = conversation.title,
                        isGroup = conversation.isGroup,
                        senderName = currentUserName,
                        memberCount = conversation.memberUids.size,
                        replyToText = pendingReply?.previewText.orEmpty()
                    )
                    val handledAsCommand = if (cleaned.startsWith("/")) {
                        when (val cmdOutcome = withContext(Dispatchers.Default) {
                            pluginStore.dispatchCommand(cleaned, hookCtx)
                        }) {
                            is PluginCommandOutcome.HandledSend -> {
                                finalTextToSend = cmdOutcome.text
                                cmdOutcome.notice?.let { _statusBanner.value = it }
                                true
                            }
                            is PluginCommandOutcome.HandledLocal -> {
                                _statusBanner.value = cmdOutcome.message
                                _isSending.value = false
                                return@launch
                            }
                            PluginCommandOutcome.NotHandled -> false
                        }
                    } else {
                        false
                    }

                    if (!handledAsCommand) {
                        when (val transform = withContext(Dispatchers.Default) {
                            pluginStore.transformOutgoingMessage(cleaned, hookCtx)
                        }) {
                            is OutgoingTransformResult.Cancelled -> {
                                _statusBanner.value = transform.reason
                                _isSending.value = false
                                return@launch
                            }
                            is OutgoingTransformResult.Proceed -> {
                                finalTextToSend = transform.text.trim().ifEmpty { cleaned }
                                transform.notices.firstOrNull()?.let { _statusBanner.value = it }
                            }
                        }
                    }
                }

                val key = ensureWritableKey(conversation)
                val blob = crypto.encryptRichText(key, finalTextToSend, replyTo = pendingReply)
                chatRepository.sendEncryptedMessage(
                    conversation = conversation,
                    senderName = currentUserName,
                    messageType = "text",
                    ivBase64 = blob.ivBase64,
                    encryptedPayload = blob.ciphertextBase64,
                    encryptedPreviewLabel = "Зашифрованное сообщение"
                )
                if (_replyingTo.value?.messageId == pendingReply?.messageId) {
                    _replyingTo.value = null
                }
            }.onFailure { error ->
                _statusBanner.value = error.localizedMessage ?: "Ошибка отправки сообщения"
            }
            _isSending.value = false
        }
    }

    fun sendVoiceMessage(recorded: RecordedVoiceResult) {
        if (checkMuteBlock()) return
        val data = (roomState.value as? UiState.Success)?.data ?: return
        val conversation = data.conversation ?: return
        val pendingReply = _replyingTo.value

        viewModelScope.launch {
            _isSending.value = true
            _activeUpload.value = MediaTransferUiState(
                id = "voice_up",
                fileName = "Голосовое сообщение",
                mediaKind = MediaKind.VOICE,
                progress = 0.22f,
                phaseLabel = "Шифрование аудиопотока..."
            )
            runCatching {
                val key = ensureWritableKey(conversation)
                val blob = crypto.encryptVoicePayload(
                    roomKey = key,
                    durationMs = recorded.durationMs,
                    waveform = recorded.waveform,
                    audioBytes = recorded.audioBytes,
                    replyTo = pendingReply
                )
                _activeUpload.value = _activeUpload.value?.copy(
                    progress = 0.72f,
                    phaseLabel = "Отправка зашифрованного аудио..."
                )
                chatRepository.sendEncryptedMessage(
                    conversation = conversation,
                    senderName = currentUserName,
                    messageType = "voice",
                    ivBase64 = blob.ivBase64,
                    encryptedPayload = blob.ciphertextBase64,
                    encryptedPreviewLabel = "Голосовое сообщение"
                )
                if (_replyingTo.value?.messageId == pendingReply?.messageId) {
                    _replyingTo.value = null
                }
                _activeUpload.value = _activeUpload.value?.copy(
                    progress = 1f,
                    phaseLabel = "Отправлено"
                )
                delay(280L)
            }.onFailure { error ->
                _statusBanner.value = error.localizedMessage ?: "Ошибка отправки голосового сообщения"
            }
            _activeUpload.value = null
            _isSending.value = false
        }
    }

    fun sendAttachment(attachment: PreparedAttachment) {
        if (checkMuteBlock()) {
            attachment.stagedFile?.let { runCatching { it.delete() } }
            return
        }
        val data = (roomState.value as? UiState.Success)?.data ?: run {
            attachment.stagedFile?.let { runCatching { it.delete() } }
            return
        }
        val conversation = data.conversation ?: run {
            attachment.stagedFile?.let { runCatching { it.delete() } }
            return
        }
        val pendingReply = _replyingTo.value

        viewModelScope.launch {
            _isSending.value = true
            _activeUpload.value = MediaTransferUiState(
                id = "media_up",
                fileName = attachment.fileName,
                mediaKind = attachment.mediaKind,
                progress = 0.08f,
                phaseLabel = "Подготовка ${attachment.mediaKind.label.lowercase()} (${FileAttachmentHelper.formatSize(attachment.sizeBytes)})..."
            )
            try {
                runCatching {
                    val key = ensureWritableKey(conversation)
                    val preview = when (attachment.mediaKind) {
                        MediaKind.PHOTO -> "Зашифрованное фото"
                        MediaKind.VIDEO -> "Зашифрованное видео (${FileAttachmentHelper.formatSize(attachment.sizeBytes)})"
                        MediaKind.AUDIO -> "Зашифрованное аудио (${FileAttachmentHelper.formatSize(attachment.sizeBytes)})"
                        else -> "Зашифрованный файл (${FileAttachmentHelper.formatSize(attachment.sizeBytes)})"
                    }

                    val staged = attachment.stagedFile
                    if (attachment.isChunked && staged != null) {
                        chatRepository.sendChunkedMediaMessage(
                            conversation = conversation,
                            senderName = currentUserName,
                            roomKey = key,
                            sourceFile = staged,
                            fileName = attachment.fileName,
                            mimeType = attachment.mimeType,
                            sizeBytes = attachment.sizeBytes,
                            encryptedPreviewLabel = preview,
                            replyTo = pendingReply
                        ) { uploadedChunks, totalChunks ->
                            val frac = (uploadedChunks.toFloat() / totalChunks.coerceAtLeast(1).toFloat())
                                .coerceIn(0.08f, 0.96f)
                            _activeUpload.value = _activeUpload.value?.copy(
                                progress = frac,
                                phaseLabel = "Шифрование и отправка: $uploadedChunks/$totalChunks"
                            )
                        }
                    } else {
                        delay(120L)
                        _activeUpload.value = _activeUpload.value?.copy(
                            progress = 0.56f,
                            phaseLabel = "Шифрование AES-256-GCM..."
                        )
                        val blob = crypto.encryptFilePayload(
                            roomKey = key,
                            fileName = attachment.fileName,
                            mimeType = attachment.mimeType,
                            bytes = attachment.bytes,
                            replyTo = pendingReply
                        )
                        _activeUpload.value = _activeUpload.value?.copy(
                            progress = 0.86f,
                            phaseLabel = "Загрузка в защищённый чат..."
                        )
                        val msgType = if (attachment.isImage) "image" else "file"
                        chatRepository.sendEncryptedMessage(
                            conversation = conversation,
                            senderName = currentUserName,
                            messageType = msgType,
                            ivBase64 = blob.ivBase64,
                            encryptedPayload = blob.ciphertextBase64,
                            encryptedPreviewLabel = preview
                        )
                    }

                    if (_replyingTo.value?.messageId == pendingReply?.messageId) {
                        _replyingTo.value = null
                    }
                    _activeUpload.value = _activeUpload.value?.copy(
                        progress = 1f,
                        phaseLabel = "Готово"
                    )
                    delay(280L)
                }.onFailure { error ->
                    _statusBanner.value = error.localizedMessage ?: "Ошибка отправки файла"
                }
            } finally {
                attachment.stagedFile?.let { runCatching { it.delete() } }
                _activeUpload.value = null
                _isSending.value = false
            }
        }
    }

    private suspend fun resolveMyPublicProfile(): PublicUserProfile {
        val fromRoom = (roomState.value as? UiState.Success)?.data?.memberProfiles
            ?.firstOrNull { it.userId == currentUserId && it.publicKeyBase64.isNotBlank() }
        if (fromRoom != null) return fromRoom
        directoryUsers.value.firstOrNull { it.userId == currentUserId && it.publicKeyBase64.isNotBlank() }?.let {
            return it
        }
        return chatRepository.getPublicProfile(currentUserId)?.takeIf { it.publicKeyBase64.isNotBlank() }
            ?: PublicUserProfile(
                userId = currentUserId,
                displayName = currentUserName,
                publicKeyBase64 = crypto.getPublicKeyBase64(),
                keyFingerprint = crypto.getKeyFingerprint()
            )
    }

    private suspend fun forwardToConversation(
        item: DecryptedMessageItem,
        targetConv: Conversation
    ) {
        val envelope = targetConv.memberKeyEnvelopes[currentUserId].orEmpty()
        val targetKey = (if (envelope.isNotBlank()) crypto.unwrapRoomKey(envelope) else null)
            ?: chatRepository.repairRoomKey(targetConv, currentUserId)

        val origin = item.forwardedFrom ?: ForwardOriginInfo(
            originalSenderId = item.senderId,
            originalSenderName = item.senderName.ifBlank {
                if (item.senderId == currentUserId) currentUserName else "Участник"
            }
        )

        val content = item.content
        if (content is DecryptedContent.FileAttachment && content.isChunked) {
            val sourceConv = (roomState.value as? UiState.Success)?.data?.conversation
            val sourceKey = cachedRoomKey
                ?: sourceConv?.let { ensureWritableKey(it) }
                ?: throw IllegalStateException("Ключ шифрования исходного чата недоступен")
            val tempFile = withContext(Dispatchers.IO) {
                File.createTempFile("fwd_media_", ".bin")
            }
            try {
                chatRepository.downloadAndDecryptChunkedMedia(
                    chatId = item.conversationId.ifBlank { chatId },
                    messageId = item.id,
                    roomKey = sourceKey,
                    targetFile = tempFile,
                    expectedChunkCount = content.chunkCount
                )
                val kind = FileAttachmentHelper.classifyMediaKind(content.mimeType, content.fileName)
                val preview = when (kind) {
                    MediaKind.VIDEO -> "Пересланное видео (${FileAttachmentHelper.formatSize(content.sizeBytes)})"
                    MediaKind.AUDIO -> "Пересланное аудио (${FileAttachmentHelper.formatSize(content.sizeBytes)})"
                    else -> "Пересланный файл (${FileAttachmentHelper.formatSize(content.sizeBytes)})"
                }
                chatRepository.sendChunkedMediaMessage(
                    conversation = targetConv,
                    senderName = currentUserName,
                    roomKey = targetKey,
                    sourceFile = tempFile,
                    fileName = content.fileName,
                    mimeType = content.mimeType,
                    sizeBytes = content.sizeBytes,
                    encryptedPreviewLabel = preview,
                    forwardedFrom = origin
                )
            } finally {
                runCatching { tempFile.delete() }
            }
            return
        }

        val (msgType, blob, preview) = when (content) {
            is DecryptedContent.Text -> Triple(
                "text",
                crypto.encryptRichText(targetKey, content.text, forwardedFrom = origin),
                "Пересланное сообщение"
            )
            is DecryptedContent.Voice -> Triple(
                "voice",
                crypto.encryptVoicePayload(
                    roomKey = targetKey,
                    durationMs = content.durationMs,
                    waveform = content.waveform,
                    audioBytes = content.audioBytes,
                    forwardedFrom = origin
                ),
                "Пересланное голосовое"
            )
            is DecryptedContent.FileAttachment -> Triple(
                if (content.isImage) "image" else "file",
                crypto.encryptFilePayload(
                    roomKey = targetKey,
                    fileName = content.fileName,
                    mimeType = content.mimeType,
                    bytes = content.bytes,
                    forwardedFrom = origin
                ),
                if (content.isImage) "Пересланное фото" else "Пересланный файл"
            )
            else -> throw IllegalStateException("Этот тип сообщения нельзя переслать")
        }

        chatRepository.sendEncryptedMessage(
            conversation = targetConv,
            senderName = currentUserName,
            messageType = msgType,
            ivBase64 = blob.ivBase64,
            encryptedPayload = blob.ciphertextBase64,
            encryptedPreviewLabel = preview
        )
    }

    fun forwardMessageToSaved(
        item: DecryptedMessageItem,
        onDone: () -> Unit = {}
    ) {
        if (checkMuteBlock()) return
        if (_isForwarding.value) return
        viewModelScope.launch {
            _isForwarding.value = true
            runCatching {
                val me = resolveMyPublicProfile()
                val savedId = chatRepository.getOrCreateSavedMessagesChat(me)
                val targetConv = userConversations.value.firstOrNull { it.id == savedId }
                    ?: chatRepository.getConversationById(savedId)
                    ?: throw IllegalStateException("Не удалось открыть чат «Избранное»")
                forwardToConversation(item, targetConv)
            }.onSuccess {
                _isForwarding.value = false
                _statusBanner.value = "Переслано в «Избранное»"
                onDone()
            }.onFailure { error ->
                _isForwarding.value = false
                _statusBanner.value = error.localizedMessage ?: "Не удалось переслать в «Избранное»"
            }
        }
    }

    fun forwardMessageToConversation(
        item: DecryptedMessageItem,
        targetConversation: Conversation,
        targetTitle: String,
        onDone: () -> Unit = {}
    ) {
        if (checkMuteBlock()) return
        if (_isForwarding.value) return
        viewModelScope.launch {
            _isForwarding.value = true
            runCatching {
                val freshConv = chatRepository.getConversationById(targetConversation.id) ?: targetConversation
                forwardToConversation(item, freshConv)
            }.onSuccess {
                _isForwarding.value = false
                val label = if (targetConversation.isSavedMessages(currentUserId)) {
                    "Переслано в «Избранное»"
                } else {
                    "Переслано в «$targetTitle»"
                }
                _statusBanner.value = label
                onDone()
            }.onFailure { error ->
                _isForwarding.value = false
                _statusBanner.value = error.localizedMessage ?: "Не удалось переслать сообщение"
            }
        }
    }

    fun forwardMessageToUser(
        item: DecryptedMessageItem,
        peer: PublicUserProfile,
        onDone: () -> Unit = {}
    ) {
        if (checkMuteBlock()) return
        if (_isForwarding.value) return
        viewModelScope.launch {
            _isForwarding.value = true
            runCatching {
                val me = resolveMyPublicProfile()
                val chatId = chatRepository.getOrCreateDirectChat(me, peer)
                val targetConv = userConversations.value.firstOrNull { it.id == chatId }
                    ?: chatRepository.getConversationById(chatId)
                    ?: throw IllegalStateException("Не удалось открыть чат с ${peer.displayName}")
                forwardToConversation(item, targetConv)
            }.onSuccess {
                _isForwarding.value = false
                _statusBanner.value = "Переслано: ${peer.displayName}"
                onDone()
            }.onFailure { error ->
                _isForwarding.value = false
                _statusBanner.value = error.localizedMessage ?: "Не удалось переслать сообщение"
            }
        }
    }

    fun prepareMediaFileForPlayback(
        context: Context,
        item: DecryptedMessageItem,
        file: DecryptedContent.FileAttachment,
        onReady: (File) -> Unit
    ) {
        if (_downloadProgress.value.containsKey(item.id)) return
        val appContext = context.applicationContext
        if (!file.isChunked) {
            viewModelScope.launch {
                val cached = withContext(Dispatchers.IO) {
                    FileAttachmentHelper.writeDecryptedMediaToCache(
                        context = appContext,
                        cacheKey = item.id,
                        fileName = file.fileName,
                        bytes = file.bytes
                    )
                }
                if (cached != null) {
                    _completedDownloads.value = _completedDownloads.value + item.id
                    onReady(cached)
                } else {
                    _statusBanner.value = "Не удалось подготовить файл к открытию"
                }
            }
            return
        }

        val readyCached = FileAttachmentHelper.getCachedMediaFileIfReady(
            context = appContext,
            cacheKey = item.id,
            fileName = file.fileName,
            expectedSizeBytes = file.sizeBytes
        )
        if (readyCached != null) {
            _completedDownloads.value = _completedDownloads.value + item.id
            onReady(readyCached)
            return
        }

        val conv = (roomState.value as? UiState.Success)?.data?.conversation
        viewModelScope.launch {
            _downloadProgress.value = _downloadProgress.value + (item.id to 0.05f)
            runCatching {
                val key = cachedRoomKey
                    ?: conv?.let { ensureWritableKey(it) }
                    ?: throw IllegalStateException("Ключ комнаты недоступен для расшифровки файла")
                val targetFile = FileAttachmentHelper.mediaPlaybackCacheFile(
                    context = appContext,
                    cacheKey = item.id,
                    fileName = file.fileName
                )
                chatRepository.downloadAndDecryptChunkedMedia(
                    chatId = item.conversationId.ifBlank { chatId },
                    messageId = item.id,
                    roomKey = key,
                    targetFile = targetFile,
                    expectedChunkCount = file.chunkCount
                ) { done, total ->
                    val frac = (done.toFloat() / total.coerceAtLeast(1).toFloat()).coerceIn(0.05f, 1.0f)
                    _downloadProgress.value = _downloadProgress.value + (item.id to frac)
                }
            }.onSuccess { downloadedFile ->
                _downloadProgress.value = _downloadProgress.value - item.id
                _completedDownloads.value = _completedDownloads.value + item.id
                onReady(downloadedFile)
            }.onFailure { error ->
                _downloadProgress.value = _downloadProgress.value - item.id
                _statusBanner.value = error.localizedMessage ?: "Не удалось скачать и расшифровать медиафайл"
            }
        }
    }

    fun startAnimatedMediaDownload(messageId: String, onReadyToOpen: () -> Unit) {
        if (_downloadProgress.value.containsKey(messageId)) return
        viewModelScope.launch {
            _downloadProgress.value = _downloadProgress.value + (messageId to 0.18f)
            delay(160L)
            _downloadProgress.value = _downloadProgress.value + (messageId to 0.54f)
            delay(180L)
            _downloadProgress.value = _downloadProgress.value + (messageId to 0.88f)
            delay(160L)
            _downloadProgress.value = _downloadProgress.value + (messageId to 1.0f)
            delay(140L)
            _downloadProgress.value = _downloadProgress.value - messageId
            _completedDownloads.value = _completedDownloads.value + messageId
            onReadyToOpen()
        }
    }

    fun deleteOwnMessage(messageId: String) {
        val key = cachedRoomKey ?: return
        viewModelScope.launch {
            runCatching {
                chatRepository.softDeleteMessage(chatId, messageId, key)
            }.onFailure { error ->
                _statusBanner.value = error.localizedMessage ?: "Не удалось удалить сообщение"
            }
        }
    }

    fun filterAddableMembers(
        users: List<PublicUserProfile>,
        existingMemberUids: List<String>,
        query: String
    ): List<PublicUserProfile> {
        val candidates = users.filter { it.userId !in existingMemberUids && !it.isBanned() }
        return chatRepository.filterAndRankUsers(candidates, query)
    }

    fun searchAddableUsers(query: String, existingMemberUids: List<String>) {
        val cleaned = query.trim()
        memberSearchJob?.cancel()
        if (cleaned.isEmpty()) {
            _isSearchingMembers.value = false
            _memberSearchResults.value = emptyList()
            return
        }
        val localMatches = filterAddableMembers(directoryUsers.value, existingMemberUids, cleaned)
        _memberSearchResults.value = localMatches
        memberSearchJob = viewModelScope.launch {
            _isSearchingMembers.value = true
            delay(220L)
            runCatching {
                chatRepository.searchUsers(cleaned, excludeUid = currentUserId)
                    .filter { it.userId !in existingMemberUids && !it.isBanned() }
            }.onSuccess { serverResults ->
                val merged = (localMatches + serverResults).distinctBy { it.userId }
                _memberSearchResults.value = merged
                _isSearchingMembers.value = false
            }.onFailure { err ->
                if (err is CancellationException) throw err
                _isSearchingMembers.value = false
            }
        }
    }

    fun clearMemberSearch() {
        memberSearchJob?.cancel()
        _isSearchingMembers.value = false
        _memberSearchResults.value = emptyList()
    }

    fun updateGroupSettings(
        newTitle: String,
        newDescription: String,
        onSuccess: () -> Unit = {}
    ) {
        if (checkMuteBlock() || _isGroupActionBusy.value) return
        val data = (roomState.value as? UiState.Success)?.data ?: return
        val conversation = data.conversation ?: return
        val cleanedTitle = newTitle.trim()
        if (cleanedTitle.isEmpty()) {
            _statusBanner.value = "Введите название группы"
            return
        }
        viewModelScope.launch {
            _isGroupActionBusy.value = true
            runCatching {
                chatRepository.updateGroupSettings(conversation, cleanedTitle, newDescription)
                if (cleanedTitle != conversation.title) {
                    cachedRoomKey?.let { key ->
                        val blob = crypto.encryptText(key, "Название группы изменено на «$cleanedTitle»")
                        chatRepository.sendEncryptedMessage(
                            conversation = conversation,
                            senderName = currentUserName,
                            messageType = "call_event",
                            ivBase64 = blob.ivBase64,
                            encryptedPayload = blob.ciphertextBase64,
                            encryptedPreviewLabel = "Настройки группы обновлены"
                        )
                    }
                }
            }.onSuccess {
                _isGroupActionBusy.value = false
                _statusBanner.value = "Настройки группы сохранены"
                onSuccess()
            }.onFailure { error ->
                _isGroupActionBusy.value = false
                _statusBanner.value = error.localizedMessage ?: "Не удалось обновить настройки группы"
            }
        }
    }

    fun addMembersToGroup(
        members: List<PublicUserProfile>,
        onSuccess: () -> Unit = {}
    ) {
        if (checkMuteBlock() || _isGroupActionBusy.value) return
        val data = (roomState.value as? UiState.Success)?.data ?: return
        val conversation = data.conversation ?: return
        if (members.isEmpty()) return
        viewModelScope.launch {
            _isGroupActionBusy.value = true
            runCatching {
                val key = ensureWritableKey(conversation)
                val added = chatRepository.addMembersToGroup(conversation, members, key)
                if (added.isNotEmpty()) {
                    val namesLabel = added.joinToString(", ") { it.displayName }
                    val msgText = if (added.size == 1) {
                        "$namesLabel добавлен(а) в группу (ключ E2EE выдан)"
                    } else {
                        "В группу добавлены: $namesLabel (ключ E2EE выдан)"
                    }
                    val blob = crypto.encryptText(key, msgText)
                    chatRepository.sendEncryptedMessage(
                        conversation = conversation.copy(
                            memberUids = (conversation.memberUids + added.map { it.userId }).distinct()
                        ),
                        senderName = currentUserName,
                        messageType = "call_event",
                        ivBase64 = blob.ivBase64,
                        encryptedPayload = blob.ciphertextBase64,
                        encryptedPreviewLabel = "Добавлены участники"
                    )
                }
                added
            }.onSuccess { added ->
                _isGroupActionBusy.value = false
                _statusBanner.value = if (added.size == 1) {
                    "${added.first().displayName} добавлен(а) в группу"
                } else {
                    "Добавлено участников: ${added.size}"
                }
                clearMemberSearch()
                onSuccess()
            }.onFailure { error ->
                _isGroupActionBusy.value = false
                _statusBanner.value = error.localizedMessage ?: "Не удалось добавить участников"
            }
        }
    }

    fun addMemberToGroup(member: PublicUserProfile) {
        addMembersToGroup(listOf(member))
    }

    fun removeMemberFromGroup(
        targetUid: String,
        targetName: String,
        onSuccess: () -> Unit = {}
    ) {
        if (_isGroupActionBusy.value) return
        val data = (roomState.value as? UiState.Success)?.data ?: return
        val conversation = data.conversation ?: return
        viewModelScope.launch {
            _isGroupActionBusy.value = true
            runCatching {
                val newKey = chatRepository.removeMemberFromGroup(conversation, targetUid)
                cachedRoomKey = newKey
                cachedRoomEnvelope = null
                _roomKeyVersion.value++
                val remaining = conversation.memberUids.filter { it != targetUid }
                val blob = crypto.encryptText(newKey, "$targetName удалён(а) из группы • ключ E2EE обновлён")
                chatRepository.sendEncryptedMessage(
                    conversation = conversation.copy(memberUids = remaining),
                    senderName = currentUserName,
                    messageType = "call_event",
                    ivBase64 = blob.ivBase64,
                    encryptedPayload = blob.ciphertextBase64,
                    encryptedPreviewLabel = "Участник удалён"
                )
            }.onSuccess {
                _isGroupActionBusy.value = false
                _statusBanner.value = "$targetName удалён(а) из группы"
                onSuccess()
            }.onFailure { error ->
                _isGroupActionBusy.value = false
                _statusBanner.value = error.localizedMessage ?: "Не удалось удалить участника"
            }
        }
    }

    fun leaveGroup(onLeft: () -> Unit) {
        if (_isGroupActionBusy.value) return
        val data = (roomState.value as? UiState.Success)?.data ?: return
        val conversation = data.conversation ?: return
        viewModelScope.launch {
            _isGroupActionBusy.value = true
            runCatching {
                chatRepository.leaveGroupChat(conversation, currentUserId)
            }.onSuccess {
                _isGroupActionBusy.value = false
                onLeft()
            }.onFailure { error ->
                _isGroupActionBusy.value = false
                _statusBanner.value = error.localizedMessage ?: "Не удалось покинуть группу"
            }
        }
    }

    fun deleteCurrentChat(onDeleted: () -> Unit) {
        if (_isGroupActionBusy.value) return
        val data = (roomState.value as? UiState.Success)?.data ?: return
        val conversation = data.conversation ?: return
        viewModelScope.launch {
            _isGroupActionBusy.value = true
            runCatching {
                chatRepository.deleteConversation(conversation)
            }.onSuccess {
                _isGroupActionBusy.value = false
                onDeleted()
            }.onFailure { error ->
                _isGroupActionBusy.value = false
                _statusBanner.value = error.localizedMessage ?: "Не удалось удалить чат"
            }
        }
    }

    fun createGroupFromDirectChat(
        additionalMembers: List<PublicUserProfile>,
        title: String,
        onCreated: (String) -> Unit
    ) {
        if (checkMuteBlock() || _isGroupActionBusy.value) return
        val data = (roomState.value as? UiState.Success)?.data ?: return
        val conversation = data.conversation ?: return
        val peerUid = conversation.memberUids.firstOrNull { it != currentUserId }
        val peerProfile = peerUid?.let { uid ->
            data.memberProfiles.firstOrNull { it.userId == uid }
                ?: directoryUsers.value.firstOrNull { it.userId == uid }
        }
        viewModelScope.launch {
            _isGroupActionBusy.value = true
            runCatching {
                val me = resolveMyPublicProfile()
                val resolvedPeer = peerProfile ?: peerUid?.let { chatRepository.getPublicProfile(it) }
                chatRepository.createGroupFromDirectChat(
                    creator = me,
                    peer = resolvedPeer,
                    additionalMembers = additionalMembers,
                    title = title
                )
            }.onSuccess { newGroupId ->
                _isGroupActionBusy.value = false
                clearMemberSearch()
                onCreated(newGroupId)
            }.onFailure { error ->
                _isGroupActionBusy.value = false
                _statusBanner.value = error.localizedMessage ?: "Не удалось создать группу"
            }
        }
    }

    fun startOrJoinCall(callType: String, onCallReady: (String) -> Unit) {
        val data = (roomState.value as? UiState.Success)?.data ?: return
        val conversation = data.conversation ?: return
        val existingCallId = conversation.activeCallId
        if (existingCallId.isNotBlank()) {
            onCallReady(existingCallId)
            return
        }
        if (checkMuteBlock()) return
        viewModelScope.launch {
            runCatching {
                val callId = callRepository.startCall(
                    conversation = conversation,
                    callerName = currentUserName,
                    callType = callType
                )
                cachedRoomKey?.let { key ->
                    val label = if (callType == "video") "Начат видеозвонок" else "Начат аудиозвонок"
                    val blob = crypto.encryptText(key, label)
                    chatRepository.sendEncryptedMessage(
                        conversation = conversation,
                        senderName = currentUserName,
                        messageType = "call_event",
                        ivBase64 = blob.ivBase64,
                        encryptedPayload = blob.ciphertextBase64,
                        encryptedPreviewLabel = label
                    )
                }
                callId
            }.onSuccess { callId ->
                onCallReady(callId)
            }.onFailure { error ->
                _statusBanner.value = error.localizedMessage ?: "Не удалось начать звонок"
            }
        }
    }

    fun showError(message: String) {
        _statusBanner.value = message
    }

    fun clearBanner() {
        _statusBanner.value = null
    }

    private companion object {
        const val TAG = "ChatRoomVM"
    }
}

