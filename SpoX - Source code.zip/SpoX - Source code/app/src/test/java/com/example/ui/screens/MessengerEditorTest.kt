package com.example.ui.screens

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.assertIsOff
import androidx.compose.ui.test.assertIsOn
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.unit.dp
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.AppThemeMode
import com.example.data.model.ChatAppearanceConfig
import com.example.security.AppLockManager
import com.example.security.BiometricCapability
import com.example.ui.components.BitmapMemoryCache
import com.example.ui.theme.CipherChatTheme
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class MessengerEditorTest {

    @get:Rule
    val composeRule = createComposeRule()

    @Test
    fun messengerEditor_togglesStoriesAndFoldersAndUpdatesPreview() {
        composeRule.setContent {
            var config by remember { mutableStateOf(ChatAppearanceConfig()) }
            CipherChatTheme(themeMode = AppThemeMode.DARK, appearanceConfig = config) {
                MessengerEditorContent(
                    appearance = config,
                    onSetShowStories = { config = config.copy(showStories = it) },
                    onSetShowFolders = { config = config.copy(showFolders = it) },
                    modifier = Modifier.verticalScroll(rememberScrollState())
                )
            }
        }

        composeRule.waitForIdle()
        composeRule.onNodeWithTag("preview_stories_strip").assertIsDisplayed()
        composeRule.onNodeWithTag("preview_folders_bar").assertIsDisplayed()
        composeRule.onNodeWithTag("editor_show_stories_switch").assertIsOn()
        composeRule.onNodeWithTag("editor_show_folders_switch").assertIsOn()

        // Hide Stories
        composeRule.onNodeWithTag("editor_show_stories_switch").performScrollTo().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("editor_show_stories_switch").assertIsOff()
        composeRule.onNodeWithTag("preview_stories_strip").assertDoesNotExist()
        composeRule.onNodeWithTag("preview_folders_bar").assertIsDisplayed()

        // Hide Folders
        composeRule.onNodeWithTag("editor_show_folders_switch").performScrollTo().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("editor_show_folders_switch").assertIsOff()
        composeRule.onNodeWithTag("preview_folders_bar").assertDoesNotExist()

        // Re-enable both
        composeRule.onNodeWithTag("editor_show_stories_switch").performScrollTo().performClick()
        composeRule.onNodeWithTag("editor_show_folders_switch").performScrollTo().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("editor_show_stories_switch").assertIsOn()
        composeRule.onNodeWithTag("editor_show_folders_switch").assertIsOn()
        composeRule.onNodeWithTag("preview_stories_strip").assertIsDisplayed()
        composeRule.onNodeWithTag("preview_folders_bar").assertIsDisplayed()
    }

    @Test
    fun customizationSettingsTab_togglesStoriesAndFolders() {
        var storiesState = true
        var foldersState = true
        var liquidGlassState = false

        composeRule.setContent {
            var config by remember { mutableStateOf(ChatAppearanceConfig()) }
            CipherChatTheme(themeMode = AppThemeMode.DARK, appearanceConfig = config) {
                androidx.compose.foundation.layout.Column(
                    modifier = Modifier.verticalScroll(rememberScrollState())
                ) {
                    CustomizationSettingsTab(
                        appearance = config,
                        onSelectThemeMode = {},
                        onSelectVisualTheme = {},
                        onSelectWallpaperPreset = {},
                        onPickCustomWallpaperUri = {},
                        onSelectOutgoingBubbleStyle = {},
                        onSetShowStories = {
                            storiesState = it
                            config = config.copy(showStories = it)
                        },
                        onSetShowFolders = {
                            foldersState = it
                            config = config.copy(showFolders = it)
                        },
                        onSetLiquidGlassEnabled = {
                            liquidGlassState = it
                            config = config.copy(liquidGlassEnabled = it)
                        },
                        onResetCustomization = {}
                    )
                }
            }
        }

        composeRule.onNodeWithTag("liquid_glass_switch").assertIsOff()
        composeRule.onNodeWithTag("liquid_glass_switch").performScrollTo().performClick()
        composeRule.onNodeWithTag("custom_tab_show_stories_switch").performScrollTo().performClick()
        composeRule.onNodeWithTag("custom_tab_show_folders_switch").performScrollTo().performClick()
        composeRule.waitForIdle()

        composeRule.onNodeWithTag("liquid_glass_switch").assertIsOn()
        assertEquals(true, liquidGlassState)
        assertEquals(false, storiesState)
        assertEquals(false, foldersState)
    }

    @Test
    fun messengerEditor_togglesLiquidGlass() {
        var glassEnabled = false
        composeRule.setContent {
            var config by remember { mutableStateOf(ChatAppearanceConfig()) }
            CipherChatTheme(themeMode = AppThemeMode.DARK, appearanceConfig = config) {
                MessengerEditorContent(
                    appearance = config,
                    onSetShowStories = { config = config.copy(showStories = it) },
                    onSetShowFolders = { config = config.copy(showFolders = it) },
                    onSetLiquidGlassEnabled = {
                        glassEnabled = it
                        config = config.copy(liquidGlassEnabled = it)
                    },
                    modifier = Modifier.verticalScroll(rememberScrollState())
                )
            }
        }

        composeRule.onNodeWithTag("editor_liquid_glass_switch").assertIsOff()
        composeRule.onNodeWithTag("editor_liquid_glass_switch").performScrollTo().performClick()
        composeRule.waitForIdle()

        composeRule.onNodeWithTag("editor_liquid_glass_switch").assertIsOn()
        assertEquals(true, glassEnabled)
    }

    @Test
    fun appSettingsSheet_togglesResourceSavingModeAndClearsRamCache() {
        val context = ApplicationProvider.getApplicationContext<android.content.Context>()
        val appLockManager = AppLockManager(context)
        var resourceSaving = false
        var lastMessage = ""

        composeRule.setContent {
            var enabled by remember { mutableStateOf(false) }
            CipherChatTheme(
                themeMode = AppThemeMode.DARK,
                appearanceConfig = ChatAppearanceConfig(resourceSavingMode = enabled)
            ) {
                AppSettingsSheet(
                    privateProfile = null,
                    publicProfile = null,
                    isPinEnabled = false,
                    isBiometricEnabled = false,
                    biometricCapability = BiometricCapability.HARDWARE_UNAVAILABLE,
                    appLockManager = appLockManager,
                    isResourceSavingEnabled = enabled,
                    onDismiss = {},
                    onOpenCustomization = {},
                    onSetDiscoverable = {},
                    onSetResourceSavingEnabled = { next ->
                        enabled = next
                        resourceSaving = next
                        BitmapMemoryCache.setResourceSavingMode(next)
                    },
                    onSetPin = {},
                    onDisablePin = {},
                    onSetBiometricEnabled = {},
                    onLockAppNow = {},
                    onShowMessage = { lastMessage = it },
                    onBiometricError = {}
                )
            }
        }

        composeRule.waitForIdle()
        composeRule.onNodeWithTag("resource_saving_switch").performScrollTo().assertIsOff()
        composeRule.onNodeWithTag("resource_saving_switch").performClick()
        composeRule.waitForIdle()

        composeRule.onNodeWithTag("resource_saving_switch").assertIsOn()
        assertEquals(true, resourceSaving)

        composeRule.onNodeWithTag("clear_ram_cache_button").performScrollTo().performClick()
        composeRule.waitForIdle()
        assertEquals("Кэш изображений в RAM очищен", lastMessage)
        BitmapMemoryCache.setResourceSavingMode(false)
    }

    @Test
    fun liquidGlassActive_togglesAndUpdatesPreviews() {
        var resolvedGlass = false

        composeRule.setContent {
            var config by remember { mutableStateOf(ChatAppearanceConfig()) }
            CipherChatTheme(themeMode = AppThemeMode.DARK, appearanceConfig = config) {
                resolvedGlass = com.example.ui.theme.isLiquidGlassActive()
                MessengerEditorContent(
                    appearance = config,
                    onSetShowStories = {},
                    onSetShowFolders = {},
                    onSetLiquidGlassEnabled = { config = config.copy(liquidGlassEnabled = it) },
                    modifier = Modifier.verticalScroll(rememberScrollState())
                )
            }
        }

        assertEquals(false, resolvedGlass)
        composeRule.onNodeWithTag("editor_liquid_glass_switch").performScrollTo().performClick()
        composeRule.waitForIdle()
        assertEquals(true, resolvedGlass)
    }

    @Test
    fun liquidGlassActive_disabledWhenResourceSavingModeOn() {
        var resolvedGlass = true

        composeRule.setContent {
            CipherChatTheme(
                themeMode = AppThemeMode.DARK,
                appearanceConfig = ChatAppearanceConfig(
                    liquidGlassEnabled = true,
                    resourceSavingMode = true
                )
            ) {
                resolvedGlass = com.example.ui.theme.isLiquidGlassActive()
            }
        }

        composeRule.waitForIdle()
        assertEquals(false, resolvedGlass)
    }

    @Test
    fun liquidGlass_preservesThemeSurfaceRgbWithoutBrightening() {
        var normalBg = Color.Unspecified
        var glassBg = Color.Unspecified
        var normalContainerHigh = Color.Unspecified
        var glassContainerHigh = Color.Unspecified

        composeRule.setContent {
            CipherChatTheme(
                themeMode = AppThemeMode.DARK,
                appearanceConfig = ChatAppearanceConfig(
                    themeMode = AppThemeMode.DARK,
                    liquidGlassEnabled = false
                )
            ) {
                normalBg = MaterialTheme.colorScheme.background
                normalContainerHigh = MaterialTheme.colorScheme.surfaceContainerHigh
            }
            CipherChatTheme(
                themeMode = AppThemeMode.DARK,
                appearanceConfig = ChatAppearanceConfig(
                    themeMode = AppThemeMode.DARK,
                    liquidGlassEnabled = true
                )
            ) {
                glassBg = MaterialTheme.colorScheme.background
                glassContainerHigh = MaterialTheme.colorScheme.surfaceContainerHigh
            }
        }

        composeRule.waitForIdle()
        assertEquals(normalBg, glassBg)
        assertEquals(normalContainerHigh.red, glassContainerHigh.red, 0.001f)
        assertEquals(normalContainerHigh.green, glassContainerHigh.green, 0.001f)
        assertEquals(normalContainerHigh.blue, glassContainerHigh.blue, 0.001f)
    }

    @Test
    fun liquidGlass_floatingHeaderMeasuringIncludesTopInsetSoFoldersNeverOverlapContent() {
        composeRule.setContent {
            val density = LocalDensity.current
            var headerHeightPx by remember { mutableIntStateOf(0) }
            val topInsetDp = 36.dp
            val headerHeightDp = with(density) { headerHeightPx.toDp() }
            val scrollTopPadding = if (headerHeightPx > 0) headerHeightDp + 10.dp else topInsetDp + 140.dp

            Box(modifier = Modifier.fillMaxSize()) {
                LazyColumn(
                    contentPadding = PaddingValues(top = scrollTopPadding),
                    modifier = Modifier.fillMaxSize()
                ) {
                    item {
                        Text(
                            text = "Истории",
                            modifier = Modifier.testTag("test_stories_item")
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .onSizeChanged { headerHeightPx = it.height }
                        .padding(top = topInsetDp)
                        .testTag("test_floating_header")
                ) {
                    Column {
                        Text("SpoX")
                        Text(
                            "Папки",
                            modifier = Modifier.testTag("test_folders_bar")
                        )
                    }
                }
            }
        }

        composeRule.waitForIdle()
        val headerBounds = composeRule.onNodeWithTag("test_floating_header").fetchSemanticsNode().boundsInRoot
        val storiesBounds = composeRule.onNodeWithTag("test_stories_item").fetchSemanticsNode().boundsInRoot
        assertTrue(
            "Expected stories top (${storiesBounds.top}) >= header bottom (${headerBounds.bottom})",
            storiesBounds.top >= headerBounds.bottom
        )
    }

    @Test
    fun smoothAppearance_opensDialogAndTogglesAllFourOptions() {
        var storiesSmooth = true
        var chatsSmooth = true
        var panelSmooth = true
        var messagesSmooth = true

        composeRule.setContent {
            var config by remember { mutableStateOf(ChatAppearanceConfig()) }
            CipherChatTheme(themeMode = AppThemeMode.DARK, appearanceConfig = config) {
                MessengerEditorContent(
                    appearance = config,
                    onSetShowStories = { config = config.copy(showStories = it) },
                    onSetShowFolders = { config = config.copy(showFolders = it) },
                    onSetLiquidGlassEnabled = { config = config.copy(liquidGlassEnabled = it) },
                    onSetSmoothStoriesAppearance = {
                        storiesSmooth = it
                        config = config.copy(smoothStoriesAppearance = it)
                    },
                    onSetSmoothChatsAppearance = {
                        chatsSmooth = it
                        config = config.copy(smoothChatsAppearance = it)
                    },
                    onSetSmoothChatsPanelAppearance = {
                        panelSmooth = it
                        config = config.copy(smoothChatsPanelAppearance = it)
                    },
                    onSetSmoothChatMessagesAppearance = {
                        messagesSmooth = it
                        config = config.copy(smoothChatMessagesAppearance = it)
                    },
                    modifier = Modifier.verticalScroll(rememberScrollState())
                )
            }
        }

        composeRule.waitForIdle()
        composeRule.onNodeWithTag("smooth_appearance_dialog").assertDoesNotExist()
        composeRule.onNodeWithTag("editor_smooth_appearance_row").performScrollTo().performClick()
        composeRule.waitForIdle()

        composeRule.onNodeWithTag("smooth_appearance_dialog").assertIsDisplayed()
        composeRule.onNodeWithTag("smooth_stories_switch").assertIsOn()
        composeRule.onNodeWithTag("smooth_chats_switch").assertIsOn()
        composeRule.onNodeWithTag("smooth_chats_panel_switch").assertIsOn()
        composeRule.onNodeWithTag("smooth_chat_messages_switch").assertIsOn()

        composeRule.onNodeWithTag("smooth_stories_switch").performScrollTo().performClick()
        composeRule.onNodeWithTag("smooth_chats_switch").performScrollTo().performClick()
        composeRule.onNodeWithTag("smooth_chats_panel_switch").performScrollTo().performClick()
        composeRule.onNodeWithTag("smooth_chat_messages_switch").performScrollTo().performClick()
        composeRule.waitForIdle()

        composeRule.onNodeWithTag("smooth_stories_switch").assertIsOff()
        composeRule.onNodeWithTag("smooth_chats_switch").assertIsOff()
        composeRule.onNodeWithTag("smooth_chats_panel_switch").assertIsOff()
        composeRule.onNodeWithTag("smooth_chat_messages_switch").assertIsOff()
        assertEquals(false, storiesSmooth)
        assertEquals(false, chatsSmooth)
        assertEquals(false, panelSmooth)
        assertEquals(false, messagesSmooth)

        composeRule.onNodeWithTag("smooth_toggle_all_button").performScrollTo().performClick()
        composeRule.waitForIdle()
        assertEquals(true, storiesSmooth)
        assertEquals(true, chatsSmooth)
        assertEquals(true, panelSmooth)
        assertEquals(true, messagesSmooth)

        composeRule.onNodeWithTag("smooth_appearance_done_button").performScrollTo().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("smooth_appearance_dialog").assertDoesNotExist()
    }
}
