package com.example.ui.viewmodel

import android.content.Context
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.CallParticipant
import com.example.data.model.CallSession
import com.example.data.repository.CallRepository
import com.example.data.repository.ChatRepository
import com.example.media.OngoingCallService
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class CallRoomUiState(
    val call: CallSession?,
    val participants: List<CallParticipant>,
    val participantAvatars: Map<String, String> = emptyMap(),
    val participantNames: Map<String, String> = emptyMap(),
    val isIncomingAwaitingAnswer: Boolean = false
)

class CallViewModel(
    private val callRepository: CallRepository,
    private val chatRepository: ChatRepository,
    private val callId: String,
    private val currentUserId: String,
    private val currentUserName: String,
    private val autoAnswer: Boolean = true
) : ViewModel() {

    val isMuted: StateFlow<Boolean> = OngoingCallService.isMuted
    val isSpeakerOn: StateFlow<Boolean> = OngoingCallService.isSpeakerOn
    val elapsedSeconds: StateFlow<Long> = OngoingCallService.elapsedSeconds
    val localAudioLevel: StateFlow<Int> = OngoingCallService.localAudioLevel
    val isBackgroundServiceActive: StateFlow<Boolean> = OngoingCallService.isCallRunning

    private val _isCameraOn = MutableStateFlow(false)
    val isCameraOn: StateFlow<Boolean> = _isCameraOn.asStateFlow()

    private val _hasAcceptedCall = MutableStateFlow(autoAnswer)
    val hasAcceptedCall: StateFlow<Boolean> = _hasAcceptedCall.asStateFlow()

    private var hasJoined = false

    private val directoryUsers = chatRepository
        .observeDiscoverableUsers()
        .catch { error ->
            val fsError = generateSequence(error) { it.cause }
                .filterIsInstance<FirebaseFirestoreException>()
                .firstOrNull()
            if (fsError == null && error is CancellationException) throw error
            emit(emptyList())
        }

    val callUiState: StateFlow<UiState<CallRoomUiState>> = combine(
        callRepository.observeCall(callId, currentUserId),
        callRepository.observeParticipants(callId, currentUserId),
        directoryUsers,
        _hasAcceptedCall
    ) { call, participants, users, accepted ->
        val isIncomingRingingForMe = call != null &&
            call.status == "ringing" &&
            call.callerId != currentUserId &&
            currentUserId !in call.activeParticipantUids
        val awaitingAnswer = isIncomingRingingForMe && !accepted

        if (call != null && !hasJoined && call.status != "ended" && !awaitingAnswer) {
            if (currentUserId !in call.activeParticipantUids) {
                hasJoined = true
                val videoDefault = call.callType == "video"
                _isCameraOn.value = videoDefault
                viewModelScope.launch {
                    runCatching { callRepository.joinCall(call, currentUserName, videoDefault) }
                }
            } else {
                hasJoined = true
                _isCameraOn.value = call.callType == "video"
            }
        }
        val avatars = users.associate { it.userId to it.avatarBase64 }
        val names = users.associate { it.userId to it.displayName }
        UiState.Success(
            CallRoomUiState(
                call = call,
                participants = participants,
                participantAvatars = avatars,
                participantNames = names,
                isIncomingAwaitingAnswer = awaitingAnswer
            )
        ) as UiState<CallRoomUiState>
    }.catch { error ->
        val fsError = generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (fsError == null && error is CancellationException) throw error
        Log.w(TAG, "Error observing call room", fsError ?: error)
        emit(UiState.Error((fsError ?: error).message ?: "Ошибка звонка"))
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(0L),
        initialValue = UiState.Loading
    )

    fun attachOngoingCallService(context: Context) {
        val data = (callUiState.value as? UiState.Success)?.data ?: return
        val call = data.call ?: return
        if (call.status == "ended" || data.isIncomingAwaitingAnswer) return
        val title = call.conversationTitle.ifBlank { call.callerName.ifBlank { "Звонок SpoX" } }
        OngoingCallService.startOrAttach(
            context = context,
            callId = call.id,
            title = title,
            userId = currentUserId,
            cameraOn = _isCameraOn.value
        )
    }

    fun toggleMute(context: Context) {
        OngoingCallService.toggleMute(context)
    }

    fun toggleCamera(context: Context, granted: Boolean) {
        if (!granted) return
        val next = !_isCameraOn.value
        _isCameraOn.value = next
        OngoingCallService.updateCameraState(context, next)
        viewModelScope.launch {
            if (next) {
                callRepository.switchCallType(callId, "video")
            }
            callRepository.updateMyMediaState(
                callId = callId,
                isMuted = isMuted.value,
                isCameraOn = next,
                isSpeaking = false,
                audioLevel = localAudioLevel.value
            )
        }
    }

    fun setCameraEnabled(context: Context, enabled: Boolean) {
        _isCameraOn.value = enabled
        OngoingCallService.updateCameraState(context, enabled)
        viewModelScope.launch {
            callRepository.updateMyMediaState(
                callId = callId,
                isMuted = isMuted.value,
                isCameraOn = enabled,
                isSpeaking = false,
                audioLevel = localAudioLevel.value
            )
        }
    }

    fun toggleSpeaker(context: Context): Boolean {
        return OngoingCallService.toggleSpeaker(context)
    }

    fun acceptIncomingCall() {
        if (_hasAcceptedCall.value) return
        _hasAcceptedCall.value = true
        val call = (callUiState.value as? UiState.Success)?.data?.call ?: return
        if (!hasJoined && call.status != "ended") {
            hasJoined = true
            val videoDefault = call.callType == "video"
            _isCameraOn.value = videoDefault
            viewModelScope.launch {
                runCatching { callRepository.joinCall(call, currentUserName, videoDefault) }
            }
        }
    }

    fun endOrLeaveCall(context: Context, onFinished: () -> Unit) {
        val call = (callUiState.value as? UiState.Success)?.data?.call
        OngoingCallService.stopLocalOnly(context)
        viewModelScope.launch {
            if (call != null) {
                callRepository.leaveOrEndCall(call)
            } else {
                callRepository.declineCallById(callId)
            }
            onFinished()
        }
    }

    private companion object {
        const val TAG = "CallVM"
    }
}
