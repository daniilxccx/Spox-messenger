package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.filled.Message
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.AutoAwesomeMotion
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.ViewAgenda
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.ChatAppearanceConfig
import com.example.ui.components.smoothAppear
import com.example.ui.theme.ApplyLiquidGlassWindowBlur
import com.example.ui.theme.LiquidGlassBackdrop
import com.example.ui.theme.isLiquidGlassActive
import com.example.ui.theme.liquidGlassDialogContainerColor
import com.example.ui.theme.liquidGlassSheetContainerColor
import com.example.ui.theme.liquidGlassSheetScrimColor
import com.example.ui.theme.liquidGlassSurface

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MessengerEditorSheet(
    appearance: ChatAppearanceConfig,
    onSetShowStories: (Boolean) -> Unit,
    onSetShowFolders: (Boolean) -> Unit,
    onSetLiquidGlassEnabled: (Boolean) -> Unit = {},
    onSetSmoothStoriesAppearance: (Boolean) -> Unit = {},
    onSetSmoothChatsAppearance: (Boolean) -> Unit = {},
    onSetSmoothChatsPanelAppearance: (Boolean) -> Unit = {},
    onSetSmoothChatMessagesAppearance: (Boolean) -> Unit = {},
    onOpenFullCustomization: () -> Unit,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val scrollState = rememberScrollState()

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = liquidGlassSheetContainerColor(),
        scrimColor = liquidGlassSheetScrimColor()
    ) {
        ApplyLiquidGlassWindowBlur()
        MessengerEditorContent(
            appearance = appearance,
            onSetShowStories = onSetShowStories,
            onSetShowFolders = onSetShowFolders,
            onSetLiquidGlassEnabled = onSetLiquidGlassEnabled,
            onSetSmoothStoriesAppearance = onSetSmoothStoriesAppearance,
            onSetSmoothChatsAppearance = onSetSmoothChatsAppearance,
            onSetSmoothChatsPanelAppearance = onSetSmoothChatsPanelAppearance,
            onSetSmoothChatMessagesAppearance = onSetSmoothChatMessagesAppearance,
            onOpenFullCustomization = {
                onDismiss()
                onOpenFullCustomization()
            },
            onDismiss = onDismiss,
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(scrollState)
                .navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 8.dp)
                .testTag("messenger_editor_sheet")
        )
    }
}

@Composable
fun MessengerEditorContent(
    appearance: ChatAppearanceConfig,
    onSetShowStories: (Boolean) -> Unit,
    onSetShowFolders: (Boolean) -> Unit,
    onSetLiquidGlassEnabled: (Boolean) -> Unit = {},
    onSetSmoothStoriesAppearance: (Boolean) -> Unit = {},
    onSetSmoothChatsAppearance: (Boolean) -> Unit = {},
    onSetSmoothChatsPanelAppearance: (Boolean) -> Unit = {},
    onSetSmoothChatMessagesAppearance: (Boolean) -> Unit = {},
    onOpenFullCustomization: (() -> Unit)? = null,
    onDismiss: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    var showSmoothAppearanceDialog by remember { mutableStateOf(false) }

    Column(
        modifier = modifier,
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            Surface(
                shape = CircleShape,
                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.14f),
                modifier = Modifier.size(46.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Filled.Tune,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Редактирование мессенджера",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Скрывайте и возвращайте элементы главного экрана",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // Live miniature wireframe preview of the messenger home screen
        val isGlassPreview = appearance.liquidGlassEnabled && !appearance.resourceSavingMode
        val previewShape = RoundedCornerShape(20.dp)
        Surface(
            shape = previewShape,
            color = if (isGlassPreview) Color.Transparent else MaterialTheme.colorScheme.surfaceContainerLow,
            border = BorderStroke(
                1.dp,
                if (isGlassPreview) MaterialTheme.colorScheme.outline.copy(alpha = 0.7f)
                else MaterialTheme.colorScheme.outlineVariant
            ),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("messenger_editor_preview")
        ) {
            Box(modifier = Modifier.fillMaxWidth()) {
                if (isGlassPreview) {
                    LiquidGlassBackdrop(modifier = Modifier.matchParentSize())
                }
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (isGlassPreview) "Макет • Liquid Glass" else "Макет списка чатов",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = buildString {
                                append(if (appearance.showStories) "Истории вкл" else "Истории скрыты")
                                append(" • ")
                                append(if (appearance.showFolders) "Папки вкл" else "Папки скрыты")
                            },
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    // Mock Search Pill
                    val searchPillShape = RoundedCornerShape(50)
                    Surface(
                        shape = searchPillShape,
                        color = if (isGlassPreview) Color.Transparent else MaterialTheme.colorScheme.surfaceContainerHigh,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(24.dp)
                            .then(
                                if (isGlassPreview) Modifier.liquidGlassSurface(shape = searchPillShape)
                                else Modifier
                            )
                    ) {
                        Box(
                            contentAlignment = Alignment.CenterStart,
                            modifier = Modifier.padding(horizontal = 10.dp)
                        ) {
                            Text(
                                text = "Поиск...",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                            )
                        }
                    }

                    // Animated Folders Bar Preview
                    val previewSmoothFolders = appearance.smoothChatsPanelAppearance && !appearance.resourceSavingMode
                    AnimatedVisibility(
                        visible = appearance.showFolders,
                        enter = if (previewSmoothFolders) expandVertically(tween(220)) + fadeIn(tween(200)) else androidx.compose.animation.EnterTransition.None,
                        exit = if (previewSmoothFolders) shrinkVertically(tween(200)) + fadeOut(tween(160)) else androidx.compose.animation.ExitTransition.None
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .smoothAppear(
                                    enabled = appearance.smoothChatsPanelAppearance,
                                    key = "preview_panel_${appearance.showFolders}_${appearance.smoothChatsPanelAppearance}",
                                    initialTranslationYDp = -6f
                                )
                                .testTag("preview_folders_bar")
                        ) {
                            listOf("Все", "Личные", "Группы", "Люди").forEachIndexed { index, label ->
                                val tabShape = RoundedCornerShape(50)
                                Surface(
                                    shape = tabShape,
                                    color = when {
                                        isGlassPreview -> Color.Transparent
                                        index == 0 -> MaterialTheme.colorScheme.primaryContainer
                                        else -> MaterialTheme.colorScheme.surfaceContainer
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .then(
                                            if (isGlassPreview) {
                                                Modifier.liquidGlassSurface(
                                                    shape = tabShape,
                                                    isHighlighted = index == 0
                                                )
                                            } else {
                                                Modifier
                                            }
                                        )
                                ) {
                                    Box(
                                        contentAlignment = Alignment.Center,
                                        modifier = Modifier.padding(vertical = 5.dp)
                                    ) {
                                        Text(
                                            text = label,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = if (index == 0) MaterialTheme.colorScheme.onPrimaryContainer
                                            else MaterialTheme.colorScheme.onSurfaceVariant,
                                            maxLines = 1
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Animated Stories Strip Preview
                    val previewSmoothStories = appearance.smoothStoriesAppearance && !appearance.resourceSavingMode
                    AnimatedVisibility(
                        visible = appearance.showStories,
                        enter = if (previewSmoothStories) expandVertically(tween(220)) + fadeIn(tween(200)) else androidx.compose.animation.EnterTransition.None,
                        exit = if (previewSmoothStories) shrinkVertically(tween(200)) + fadeOut(tween(160)) else androidx.compose.animation.ExitTransition.None
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .smoothAppear(
                                    enabled = appearance.smoothStoriesAppearance,
                                    key = "preview_stories_${appearance.showStories}_${appearance.smoothStoriesAppearance}",
                                    initialTranslationXDp = 10f,
                                    initialTranslationYDp = 0f
                                )
                                .testTag("preview_stories_strip")
                        ) {
                            repeat(5) { idx ->
                                Box(
                                    modifier = Modifier
                                        .size(30.dp)
                                        .clip(CircleShape)
                                        .background(
                                            if (idx == 0) {
                                                Brush.linearGradient(
                                                    listOf(
                                                        MaterialTheme.colorScheme.primary,
                                                        MaterialTheme.colorScheme.secondary
                                                    )
                                                )
                                            } else {
                                                Brush.linearGradient(
                                                    listOf(
                                                        MaterialTheme.colorScheme.secondary.copy(alpha = 0.7f),
                                                        MaterialTheme.colorScheme.tertiary.copy(alpha = 0.7f)
                                                    )
                                                )
                                            }
                                        )
                                        .padding(2.dp)
                                        .clip(CircleShape)
                                        .background(MaterialTheme.colorScheme.surfaceContainerHigh)
                                )
                            }
                        }
                    }

                    // Mock Chat Rows
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        repeat(2) { rowIdx ->
                            val mockRowShape = RoundedCornerShape(12.dp)
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .smoothAppear(
                                        enabled = appearance.smoothChatsAppearance,
                                        key = "preview_chat_${rowIdx}_${appearance.smoothChatsAppearance}",
                                        delayMillis = rowIdx * 45,
                                        initialTranslationYDp = 8f
                                    )
                                    .then(
                                        if (isGlassPreview) {
                                            Modifier
                                                .liquidGlassSurface(shape = mockRowShape, tintAlpha = 0.28f)
                                                .padding(horizontal = 8.dp, vertical = 6.dp)
                                        } else {
                                            Modifier
                                        }
                                    )
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(28.dp)
                                        .clip(CircleShape)
                                        .background(MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = if (isGlassPreview) 0.7f else 1f))
                                )
                                Column(
                                    verticalArrangement = Arrangement.spacedBy(4.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth(0.45f)
                                            .height(8.dp)
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = if (isGlassPreview) 0.7f else 1f))
                                    )
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth(0.75f)
                                            .height(6.dp)
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(MaterialTheme.colorScheme.surfaceContainerHighest.copy(alpha = 0.65f))
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        MessengerToggleOptionCard(
            icon = Icons.Filled.AutoAwesomeMotion,
            title = "Истории",
            description = if (appearance.showStories) {
                "Лента историй и быстрых контактов показана над списком чатов"
            } else {
                "Лента историй скрыта — сверху сразу открываются ваши чаты"
            },
            checked = appearance.showStories,
            onCheckedChange = onSetShowStories,
            rowTag = "editor_stories_row",
            switchTag = "editor_show_stories_switch"
        )

        MessengerToggleOptionCard(
            icon = Icons.Filled.Folder,
            title = "Папки",
            description = if (appearance.showFolders) {
                "Панель папок («Все», «Личные», «Группы», «Люди», «Плеер») показана"
            } else {
                "Папки скрыты — открыт единый список всех чатов"
            },
            checked = appearance.showFolders,
            onCheckedChange = onSetShowFolders,
            rowTag = "editor_folders_row",
            switchTag = "editor_show_folders_switch"
        )

        MessengerToggleOptionCard(
            icon = Icons.Filled.WaterDrop,
            title = "Liquid Glass",
            description = if (appearance.liquidGlassEnabled) {
                "Полупрозрачный стеклянный интерфейс активен по всему приложению"
            } else {
                "Включите полупрозрачный эффект стекла для всего мессенджера"
            },
            checked = appearance.liquidGlassEnabled,
            onCheckedChange = onSetLiquidGlassEnabled,
            rowTag = "editor_liquid_glass_row",
            switchTag = "editor_liquid_glass_switch"
        )

        val smoothEnabledCount = listOf(
            appearance.smoothStoriesAppearance,
            appearance.smoothChatsAppearance,
            appearance.smoothChatsPanelAppearance,
            appearance.smoothChatMessagesAppearance
        ).count { it }
        MessengerNavigationOptionCard(
            icon = Icons.Filled.AutoAwesome,
            title = "Плавное появление",
            description = when {
                appearance.resourceSavingMode ->
                    "Вкл. $smoothEnabledCount из 4 (приостановлено режимом экономии ресурсов)"
                smoothEnabledCount == 4 ->
                    "Включено для всех разделов: истории, чаты, панель и сообщения"
                smoothEnabledCount == 0 ->
                    "Отключено — элементы интерфейса появляются мгновенно"
                else ->
                    "Активно $smoothEnabledCount из 4: выберите детали анимации"
            },
            badgeText = "$smoothEnabledCount/4",
            isHighlighted = smoothEnabledCount > 0,
            onClick = { showSmoothAppearanceDialog = true },
            rowTag = "editor_smooth_appearance_row"
        )

        if (onOpenFullCustomization != null) {
            OutlinedButton(
                onClick = onOpenFullCustomization,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("editor_open_customization_button")
            ) {
                Icon(Icons.Filled.Palette, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Темы, обои и цвета сообщений")
            }
        }

        if (onDismiss != null) {
            Button(
                onClick = onDismiss,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("editor_done_button")
            ) {
                Text("Готово")
            }
        }

        Spacer(modifier = Modifier.height(6.dp))
    }

    if (showSmoothAppearanceDialog) {
        SmoothAppearanceSettingsDialog(
            appearance = appearance,
            onSetSmoothStoriesAppearance = onSetSmoothStoriesAppearance,
            onSetSmoothChatsAppearance = onSetSmoothChatsAppearance,
            onSetSmoothChatsPanelAppearance = onSetSmoothChatsPanelAppearance,
            onSetSmoothChatMessagesAppearance = onSetSmoothChatMessagesAppearance,
            onDismiss = { showSmoothAppearanceDialog = false }
        )
    }
}

@Composable
internal fun MessengerNavigationOptionCard(
    icon: ImageVector,
    title: String,
    description: String,
    badgeText: String,
    isHighlighted: Boolean,
    onClick: () -> Unit,
    rowTag: String
) {
    val glassActive = isLiquidGlassActive()
    val cardShape = RoundedCornerShape(18.dp)
    Surface(
        shape = cardShape,
        color = if (glassActive) Color.Transparent else MaterialTheme.colorScheme.surfaceContainer,
        border = if (glassActive) null else BorderStroke(
            width = 1.dp,
            color = if (isHighlighted) MaterialTheme.colorScheme.primary.copy(alpha = 0.42f)
            else MaterialTheme.colorScheme.outlineVariant
        ),
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 48.dp)
            .then(
                if (glassActive) {
                    Modifier.liquidGlassSurface(
                        shape = cardShape,
                        isHighlighted = isHighlighted
                    )
                } else {
                    Modifier.clip(cardShape)
                }
            )
            .clickable(onClick = onClick)
            .testTag(rowTag)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Surface(
                shape = CircleShape,
                color = if (isHighlighted) MaterialTheme.colorScheme.primary.copy(alpha = 0.16f)
                else MaterialTheme.colorScheme.surfaceContainerHigh,
                modifier = Modifier.size(40.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = if (isHighlighted) MaterialTheme.colorScheme.primary
                        else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Surface(
                shape = RoundedCornerShape(50),
                color = if (isHighlighted) MaterialTheme.colorScheme.primaryContainer
                else MaterialTheme.colorScheme.surfaceContainerHigh
            ) {
                Text(
                    text = badgeText,
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = if (isHighlighted) MaterialTheme.colorScheme.onPrimaryContainer
                    else MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }

            Icon(
                imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                contentDescription = "Открыть настройки плавного появления",
                tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun SmoothAppearanceSettingsDialog(
    appearance: ChatAppearanceConfig,
    onSetSmoothStoriesAppearance: (Boolean) -> Unit,
    onSetSmoothChatsAppearance: (Boolean) -> Unit,
    onSetSmoothChatsPanelAppearance: (Boolean) -> Unit,
    onSetSmoothChatMessagesAppearance: (Boolean) -> Unit,
    onDismiss: () -> Unit
) {
    val glassActive = isLiquidGlassActive()
    val dialogShape = RoundedCornerShape(26.dp)
    val enabledCount = listOf(
        appearance.smoothStoriesAppearance,
        appearance.smoothChatsAppearance,
        appearance.smoothChatsPanelAppearance,
        appearance.smoothChatMessagesAppearance
    ).count { it }
    val allEnabled = enabledCount == 4

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            shape = dialogShape,
            color = if (glassActive) Color.Transparent else liquidGlassDialogContainerColor(),
            border = if (glassActive) null else BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
            tonalElevation = if (glassActive) 0.dp else 6.dp,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 18.dp, vertical = 24.dp)
                .widthIn(max = 520.dp)
                .then(
                    if (glassActive) {
                        Modifier.liquidGlassSurface(
                            shape = dialogShape,
                            tintColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                            tintAlpha = 0.78f
                        )
                    } else {
                        Modifier
                    }
                )
                .testTag("smooth_appearance_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 18.dp, vertical = 18.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Surface(
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.16f),
                        modifier = Modifier.size(44.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Filled.AutoAwesome,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Плавное появление",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Настройка анимации появления разделов",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    Surface(
                        shape = RoundedCornerShape(50),
                        color = MaterialTheme.colorScheme.primaryContainer
                    ) {
                        Text(
                            text = "$enabledCount из 4",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }

                if (appearance.resourceSavingMode) {
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.7f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "Сейчас включён «Режим экономии ресурсов» — анимации появятся снова после его выключения.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onTertiaryContainer,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                        )
                    }
                }

                MessengerToggleOptionCard(
                    icon = Icons.Filled.AutoAwesomeMotion,
                    title = "Плавное появление историй",
                    description = "Плавное раскрытие ленты историй и кружков контактов",
                    checked = appearance.smoothStoriesAppearance,
                    onCheckedChange = onSetSmoothStoriesAppearance,
                    rowTag = "editor_smooth_stories_row",
                    switchTag = "smooth_stories_switch"
                )

                MessengerToggleOptionCard(
                    icon = Icons.AutoMirrored.Filled.Chat,
                    title = "Плавное появление чатов",
                    description = "Мягкое появление карточек диалогов, контактов и списка чатов",
                    checked = appearance.smoothChatsAppearance,
                    onCheckedChange = onSetSmoothChatsAppearance,
                    rowTag = "editor_smooth_chats_row",
                    switchTag = "smooth_chats_switch"
                )

                MessengerToggleOptionCard(
                    icon = Icons.Filled.ViewAgenda,
                    title = "Плавное появление панели чатов",
                    description = "Плавная анимация панели поиска, папок и переключения вкладок",
                    checked = appearance.smoothChatsPanelAppearance,
                    onCheckedChange = onSetSmoothChatsPanelAppearance,
                    rowTag = "editor_smooth_chats_panel_row",
                    switchTag = "smooth_chats_panel_switch"
                )

                MessengerToggleOptionCard(
                    icon = Icons.AutoMirrored.Filled.Message,
                    title = "Плавное появление сообщений в чате",
                    description = "Мягкое появление входящих и отправленных сообщений в переписке",
                    checked = appearance.smoothChatMessagesAppearance,
                    onCheckedChange = onSetSmoothChatMessagesAppearance,
                    rowTag = "editor_smooth_chat_messages_row",
                    switchTag = "smooth_chat_messages_switch"
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(
                        onClick = {
                            val target = !allEnabled
                            onSetSmoothStoriesAppearance(target)
                            onSetSmoothChatsAppearance(target)
                            onSetSmoothChatsPanelAppearance(target)
                            onSetSmoothChatMessagesAppearance(target)
                        },
                        modifier = Modifier
                            .heightIn(min = 48.dp)
                            .testTag("smooth_toggle_all_button")
                    ) {
                        Text(if (allEnabled) "Выключить все" else "Включить все")
                    }
                    Spacer(modifier = Modifier.weight(1f))
                    Button(
                        onClick = onDismiss,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .heightIn(min = 48.dp)
                            .testTag("smooth_appearance_done_button")
                    ) {
                        Text("Готово")
                    }
                }
            }
        }
    }
}

@Composable
internal fun MessengerToggleOptionCard(
    icon: ImageVector,
    title: String,
    description: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    rowTag: String,
    switchTag: String
) {
    val glassActive = isLiquidGlassActive()
    val cardShape = RoundedCornerShape(18.dp)
    Surface(
        shape = cardShape,
        color = if (glassActive) Color.Transparent else MaterialTheme.colorScheme.surfaceContainer,
        border = if (glassActive) null else BorderStroke(
            width = 1.dp,
            color = if (checked) MaterialTheme.colorScheme.primary.copy(alpha = 0.42f)
            else MaterialTheme.colorScheme.outlineVariant
        ),
        modifier = Modifier
            .fillMaxWidth()
            .then(
                if (glassActive) {
                    Modifier.liquidGlassSurface(
                        shape = cardShape,
                        isHighlighted = checked
                    )
                } else {
                    Modifier.clip(cardShape)
                }
            )
            .clickable { onCheckedChange(!checked) }
            .testTag(rowTag)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Surface(
                shape = CircleShape,
                color = if (checked) MaterialTheme.colorScheme.primary.copy(alpha = 0.16f)
                else MaterialTheme.colorScheme.surfaceContainerHigh,
                modifier = Modifier.size(40.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = if (checked) MaterialTheme.colorScheme.primary
                        else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Switch(
                checked = checked,
                onCheckedChange = onCheckedChange,
                modifier = Modifier.testTag(switchTag)
            )
        }
    }
}
