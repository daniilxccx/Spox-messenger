package com.example.updates

enum class UpdateCheckStatus {
    IDLE,
    CHECKING,
    UPDATE_AVAILABLE,
    UP_TO_DATE,
    NO_RELEASES,
    ERROR
}

data class GitHubReleaseAsset(
    val name: String,
    val downloadUrl: String,
    val sizeBytes: Long,
    val downloadCount: Int,
    val contentType: String
)

data class GitHubReleaseInfo(
    val tagName: String,
    val versionName: String,
    val title: String,
    val changelog: String,
    val htmlUrl: String,
    val publishedAtIso: String,
    val isPrerelease: Boolean,
    val isDraft: Boolean,
    val apkAsset: GitHubReleaseAsset?,
    val allAssets: List<GitHubReleaseAsset>
)

data class AppUpdateState(
    val currentVersion: String,
    val currentVersionCode: Int,
    val status: UpdateCheckStatus = UpdateCheckStatus.IDLE,
    val latestRelease: GitHubReleaseInfo? = null,
    val recentReleases: List<GitHubReleaseInfo> = emptyList(),
    val lastCheckedAtMs: Long? = null,
    val errorMessage: String? = null,
    val autoCheckEnabled: Boolean = true,
    val skippedTag: String? = null
) {
    val isUpdateAvailable: Boolean
        get() = status == UpdateCheckStatus.UPDATE_AVAILABLE && latestRelease != null

    val shouldShowBanner: Boolean
        get() = isUpdateAvailable && latestRelease?.tagName != skippedTag
}
