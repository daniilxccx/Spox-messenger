package com.example.ui.auth

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.AlternateEmail
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.media.FileAttachmentHelper
import com.example.ui.components.UserAvatar
import com.example.ui.screens.AvatarViewerDialog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.abs

@Composable
fun ProfileRegistrationScreen(
    uid: String,
    userEmail: String,
    initialDisplayName: String,
    keyFingerprint: String,
    isBusy: Boolean,
    errorMessage: String?,
    onClearError: () -> Unit,
    onSubmitProfile: (displayName: String, rawUsername: String, avatarBase64: String) -> Unit,
    onSignOut: () -> Unit
) {
    val context = LocalContext.current
    val focusManager = LocalFocusManager.current
    val scrollState = rememberScrollState()

    val suggestedHandle = remember(uid, userEmail) {
        userEmail.substringBefore("@")
            .lowercase()
            .replace(Regex("[^a-z0-9_.]"), "_")
            .take(32)
            .let { if (it.length < 2) "user_${uid.take(6)}" else it }
    }
    val avatarColorIndex = remember(uid) { abs(uid.hashCode() % 8) }

    var nameInput by rememberSaveable(uid) {
        mutableStateOf(initialDisplayName.trim().take(60))
    }
    var usernameInput by rememberSaveable(uid) {
        mutableStateOf(suggestedHandle)
    }
    var avatarBase64 by rememberSaveable(uid) {
        mutableStateOf("")
    }
    var localAvatarError by remember { mutableStateOf<String?>(null) }
    var showAvatarPreview by remember { mutableStateOf(false) }

    val trimmedName = nameInput.trim()
    val trimmedHandle = usernameInput.trim().removePrefix("@")
    val isNameValid = trimmedName.isNotEmpty() && trimmedName.length <= 60
    val isHandleValid = trimmedHandle.isEmpty() || Regex("^[a-zA-Z0-9_.]{2,32}$").matches(trimmedHandle)
    val canSubmit = !isBusy && isNameValid && isHandleValid

    val coroutineScope = rememberCoroutineScope()
    val avatarPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            localAvatarError = null
            onClearError()
            coroutineScope.launch {
                val result = withContext(Dispatchers.IO) {
                    FileAttachmentHelper.prepareAvatarBase64(context, uri)
                }
                result
                    .onSuccess { encoded -> avatarBase64 = encoded }
                    .onFailure { err ->
                        localAvatarError = err.localizedMessage ?: "Не удалось загрузить фото"
                    }
            }
        }
    }

    val primaryGlow = MaterialTheme.colorScheme.primary.copy(alpha = 0.16f)
    val secondaryGlow = MaterialTheme.colorScheme.secondary.copy(alpha = 0.12f)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .drawBehind {
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(primaryGlow, Color.Transparent),
                        center = Offset(size.width * 0.8f, size.height * 0.12f),
                        radius = (size.minDimension * 0.8f).coerceAtLeast(1f)
                    )
                )
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(secondaryGlow, Color.Transparent),
                        center = Offset(size.width * 0.15f, size.height * 0.85f),
                        radius = (size.minDimension * 0.7f).coerceAtLeast(1f)
                    )
                )
            }
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(horizontal = 22.dp, vertical = 20.dp)
                .widthIn(max = 520.dp)
                .align(Alignment.Center)
                .testTag("profile_registration_screen"),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Surface(
                shape = RoundedCornerShape(50),
                color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.7f),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.35f))
            ) {
                Text(
                    text = userEmail,
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = "Настройка профиля",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "Выберите фото профиля и введите имя, чтобы завершить регистрацию в SpoX.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(22.dp))

            Surface(
                shape = RoundedCornerShape(24.dp),
                color = MaterialTheme.colorScheme.surfaceContainerLow,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .clip(CircleShape)
                            .clickable(enabled = !isBusy) {
                                if (avatarBase64.isNotBlank()) {
                                    showAvatarPreview = true
                                } else {
                                    avatarPickerLauncher.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                    )
                                }
                            }
                            .padding(4.dp)
                            .testTag("registration_avatar_trigger")
                    ) {
                        UserAvatar(
                            name = trimmedName.ifBlank { userEmail },
                            avatarBase64 = avatarBase64,
                            colorIndex = avatarColorIndex,
                            size = 116.dp
                        )
                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.primary,
                            shadowElevation = 4.dp,
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .size(38.dp)
                                .clip(CircleShape)
                                .clickable(enabled = !isBusy) {
                                    avatarPickerLauncher.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                    )
                                }
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Filled.CameraAlt,
                                    contentDescription = "Выбрать фото профиля",
                                    tint = MaterialTheme.colorScheme.onPrimary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                avatarPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            },
                            enabled = !isBusy,
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("registration_pick_photo_button")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.PhotoLibrary,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (avatarBase64.isBlank()) "Выбрать фото" else "Изменить фото",
                                maxLines = 1
                            )
                        }
                        if (avatarBase64.isNotBlank()) {
                            OutlinedButton(
                                onClick = {
                                    avatarBase64 = ""
                                    localAvatarError = null
                                },
                                enabled = !isBusy,
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier
                                    .height(48.dp)
                                    .testTag("registration_remove_photo_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.DeleteOutline,
                                    contentDescription = "Удалить фото",
                                    tint = MaterialTheme.colorScheme.error,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Убрать", color = MaterialTheme.colorScheme.error)
                            }
                        }
                    }

                    var nameTouched by remember { mutableStateOf(false) }
                    OutlinedTextField(
                        value = nameInput,
                        onValueChange = { input ->
                            nameTouched = true
                            if (input.length <= 60) {
                                nameInput = input
                                onClearError()
                            }
                        },
                        enabled = !isBusy,
                        label = { Text("Ваше имя") },
                        placeholder = { Text("Например: Алексей") },
                        leadingIcon = { Icon(Icons.Filled.Badge, contentDescription = null) },
                        trailingIcon = {
                            if (nameInput.isNotEmpty() && !isBusy) {
                                IconButton(
                                    onClick = {
                                        nameTouched = true
                                        nameInput = ""
                                    },
                                    modifier = Modifier.size(48.dp)
                                ) {
                                    Icon(Icons.Filled.Close, contentDescription = "Очистить имя")
                                }
                            }
                        },
                        isError = nameTouched && !isNameValid,
                        supportingText = {
                            Text(
                                text = if (trimmedName.isEmpty()) {
                                    "Введите имя (от 1 до 60 символов)"
                                } else {
                                    "Имя отображается в ваших чатах (${trimmedName.length}/60)"
                                }
                            )
                        },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(
                            capitalization = KeyboardCapitalization.Words,
                            imeAction = ImeAction.Next
                        ),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("registration_name_input")
                    )

                    OutlinedTextField(
                        value = usernameInput,
                        onValueChange = { input ->
                            val filtered = input.removePrefix("@")
                            if (filtered.length <= 32) {
                                usernameInput = filtered
                                onClearError()
                            }
                        },
                        enabled = !isBusy,
                        label = { Text("Юзернейм (необязательно)") },
                        placeholder = { Text("ivan_cipher") },
                        prefix = { Text("@") },
                        leadingIcon = { Icon(Icons.Filled.AlternateEmail, contentDescription = null) },
                        isError = !isHandleValid,
                        supportingText = {
                            Text(
                                text = if (!isHandleValid) {
                                    "Допустимы латинские буквы, цифры, _ и . (2–32 символа)"
                                } else {
                                    "По юзернейму вас смогут найти другие пользователи"
                                }
                            )
                        },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                        keyboardActions = KeyboardActions(
                            onDone = {
                                focusManager.clearFocus()
                                if (canSubmit) {
                                    onSubmitProfile(trimmedName, trimmedHandle, avatarBase64)
                                }
                            }
                        ),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("registration_username_input")
                    )

                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = MaterialTheme.colorScheme.surfaceContainer,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.7f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Key,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Ключ шифрования ECDH P-256 создан",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = keyFingerprint,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontFamily = FontFamily.Monospace,
                                    color = MaterialTheme.colorScheme.primary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }

                    val displayError = localAvatarError ?: errorMessage
                    if (!displayError.isNullOrBlank()) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.errorContainer,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = displayError,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onErrorContainer,
                                textAlign = TextAlign.Center,
                                modifier = Modifier
                                    .padding(horizontal = 12.dp, vertical = 8.dp)
                                    .testTag("registration_error_text")
                            )
                        }
                    }

                    Button(
                        onClick = {
                            focusManager.clearFocus()
                            onSubmitProfile(trimmedName, trimmedHandle, avatarBase64)
                        },
                        enabled = canSubmit,
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp)
                            .testTag("registration_submit_button")
                    ) {
                        if (isBusy) {
                            CircularProgressIndicator(
                                strokeWidth = 2.5.dp,
                                color = MaterialTheme.colorScheme.onPrimary,
                                modifier = Modifier.size(22.dp)
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Filled.Check,
                                contentDescription = null,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Завершить регистрацию",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            TextButton(
                onClick = onSignOut,
                enabled = !isBusy,
                modifier = Modifier
                    .height(48.dp)
                    .testTag("registration_sign_out_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.Logout,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text("Выйти и выбрать другой аккаунт")
            }
        }
    }

    if (showAvatarPreview) {
        AvatarViewerDialog(
            displayName = trimmedName.ifBlank { userEmail },
            handle = if (trimmedHandle.isNotBlank()) "@$trimmedHandle" else "",
            avatarBase64 = avatarBase64,
            avatarColorIndex = avatarColorIndex,
            onEditAvatar = {
                showAvatarPreview = false
                avatarPickerLauncher.launch(
                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                )
            },
            onDismiss = { showAvatarPreview = false }
        )
    }
}
