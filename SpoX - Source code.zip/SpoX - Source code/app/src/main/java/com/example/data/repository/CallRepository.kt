package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.data.model.CallAudioFrame
import com.example.data.model.CallParticipant
import com.example.data.model.CallSession
import com.example.data.model.Conversation
import com.google.firebase.Firebase
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentChange
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import java.util.UUID

class CallRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = FirebaseSessionManager.activeAuthOrDefault()
) {

    constructor(context: Context) : this(
        FirebaseSessionManager.getActiveFirestore(context)
            ?: FirebaseFirestore.getInstance(
                context.applicationContext.getString(R.string.firestore_database_id)
            ),
        FirebaseSessionManager.getActiveAuth(context) ?: Firebase.auth
    )

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("Пользователь должен быть авторизован.")
    }

    fun observeMyCalls(userId: String): Flow<List<CallSession>> = flow {
        val path = "calls"
        emitAll(
            db.collection(path)
                .whereArrayContains("memberUids", userId)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(CallSession::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                }
                .catch { error ->
                    logStreamError(error, OperationType.LIST, path, userId)
                    throw error
                }
        )
    }

    fun observeCall(callId: String, userId: String): Flow<CallSession?> = flow {
        val docRef = db.collection("calls").document(callId)
        emitAll(
            docRef.snapshots()
                .map { it.toObject(CallSession::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
                .catch { error ->
                    logStreamError(error, OperationType.GET, docRef.path, userId)
                    throw error
                }
        )
    }

    fun observeParticipants(callId: String, userId: String): Flow<List<CallParticipant>> = flow {
        val path = "calls/$callId/participants"
        emitAll(
            db.collection("calls").document(callId).collection("participants")
                .whereArrayContains("memberUids", userId)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(CallParticipant::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedBy { it.joinedAt ?: Timestamp(0, 0) }
                }
                .catch { error ->
                    logStreamError(error, OperationType.LIST, path, userId)
                    throw error
                }
        )
    }

    suspend fun startCall(
        conversation: Conversation,
        callerName: String,
        callType: String
    ): String {
        val uid = requireUserId()
        val callId = "call_${UUID.randomUUID().toString().replace("-", "").take(20)}"
        val callRef = db.collection("calls").document(callId)
        val chatRef = db.collection("conversations").document(conversation.id)
        val participantRef = callRef.collection("participants").document(uid)

        val safeCallerName = callerName.ifBlank { "Участник" }.take(60)
        val safeTitle = conversation.title.ifBlank { safeCallerName }.take(80)

        val callPayload = mapOf(
            "conversationId" to conversation.id,
            "conversationTitle" to safeTitle,
            "callerId" to uid,
            "callerName" to safeCallerName,
            "isGroupCall" to conversation.isGroup,
            "callType" to callType,
            "status" to "ringing",
            "memberUids" to conversation.memberUids,
            "activeParticipantUids" to listOf(uid),
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )

        val participantPayload = mapOf(
            "callId" to callId,
            "userId" to uid,
            "displayName" to safeCallerName,
            "memberUids" to conversation.memberUids,
            "isMuted" to false,
            "isCameraOn" to (callType == "video"),
            "isSpeaking" to false,
            "audioLevel" to 0L,
            "joinedAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )

        try {
            callRef.set(callPayload).await()
            participantRef.set(participantPayload).await()
            chatRef.update(
                mapOf(
                    "activeCallId" to callId,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            return callId
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, callRef.path)
            throw e
        }
    }

    suspend fun joinCall(
        call: CallSession,
        displayName: String,
        enableVideo: Boolean
    ) {
        val uid = requireUserId()
        if (call.status == "ended") return
        val callRef = db.collection("calls").document(call.id)
        val participantRef = callRef.collection("participants").document(uid)
        val updatedActive = (call.activeParticipantUids + uid).distinct().take(50)

        try {
            callRef.update(
                mapOf(
                    "status" to "active",
                    "activeParticipantUids" to updatedActive,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()

            participantRef.set(
                mapOf(
                    "callId" to call.id,
                    "userId" to uid,
                    "displayName" to displayName.ifBlank { "Участник" }.take(60),
                    "memberUids" to call.memberUids,
                    "isMuted" to false,
                    "isCameraOn" to enableVideo,
                    "isSpeaking" to false,
                    "audioLevel" to 0L,
                    "joinedAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, callRef.path)
            throw e
        }
    }

    suspend fun updateMyMediaState(
        callId: String,
        isMuted: Boolean,
        isCameraOn: Boolean,
        isSpeaking: Boolean,
        audioLevel: Int
    ) {
        val uid = requireUserId()
        val participantRef = db.collection("calls").document(callId)
            .collection("participants").document(uid)
        try {
            val snap = participantRef.get().await()
            if (snap.exists()) {
                participantRef.update(
                    mapOf(
                        "isMuted" to isMuted,
                        "isCameraOn" to isCameraOn,
                        "isSpeaking" to isSpeaking,
                        "audioLevel" to audioLevel.coerceIn(0, 100).toLong(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, participantRef.path)
        }
    }

    suspend fun switchCallType(callId: String, newCallType: String) {
        requireUserId()
        val callRef = db.collection("calls").document(callId)
        try {
            callRef.update(
                mapOf(
                    "callType" to newCallType,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, callRef.path)
        }
    }

    suspend fun leaveOrEndCall(call: CallSession) {
        val uid = requireUserId()
        val callRef = db.collection("calls").document(call.id)
        val participantRef = callRef.collection("participants").document(uid)
        val chatRef = db.collection("conversations").document(call.conversationId)

        try {
            if (call.status != "ended") {
                val remaining = call.activeParticipantUids.filter { it != uid }
                val shouldEndCall = !call.isGroupCall || remaining.isEmpty()
                if (shouldEndCall) {
                    callRef.update(
                        mapOf(
                            "status" to "ended",
                            "activeParticipantUids" to emptyList<String>(),
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    ).await()
                    runCatching {
                        chatRef.update(
                            mapOf(
                                "activeCallId" to "",
                                "updatedAt" to FieldValue.serverTimestamp()
                            )
                        ).await()
                    }
                } else {
                    callRef.update(
                        mapOf(
                            "activeParticipantUids" to remaining,
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    ).await()
                }
            }
            runCatching { participantRef.delete().await() }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, callRef.path)
        }
    }

    suspend fun declineCallById(callId: String) {
        if (callId.isBlank()) return
        if (auth.currentUser == null) return
        val callRef = db.collection("calls").document(callId)
        try {
            val snapshot = callRef.get().await()
            val call = snapshot.toObject(
                CallSession::class.java,
                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
            ) ?: return
            leaveOrEndCall(call)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, callRef.path)
        }
    }

    suspend fun sendAudioFrame(
        callId: String,
        memberUids: List<String>,
        seq: Long,
        payloadBase64: String,
        sampleRate: Int = 16000
    ) {
        val uid = auth.currentUser?.uid ?: return
        if (callId.isBlank() || payloadBase64.isBlank() || memberUids.isEmpty()) return

        val framesCol = db.collection("calls").document(callId).collection("audio_frames")
        val frameId = "${uid}_$seq"
        val payload = mapOf(
            "callId" to callId,
            "senderId" to uid,
            "seq" to seq,
            "sampleRate" to sampleRate.toLong(),
            "codec" to "ima_adpcm",
            "payloadBase64" to payloadBase64,
            "memberUids" to memberUids,
            "createdAt" to FieldValue.serverTimestamp()
        )
        try {
            framesCol.document(frameId).set(payload).await()
            if (seq >= 24L) {
                val staleId = "${uid}_${seq - 24L}"
                framesCol.document(staleId).delete()
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            logStreamError(e, OperationType.CREATE, "calls/$callId/audio_frames/$frameId", uid)
        }
    }

    fun observeIncomingAudioFrames(
        callId: String,
        currentUserId: String
    ): Flow<CallAudioFrame> = callbackFlow {
        val framesQuery = db.collection("calls")
            .document(callId)
            .collection("audio_frames")
            .whereArrayContains("memberUids", currentUserId)

        var isFirstSnapshot = true
        val seenIds = LinkedHashSet<String>()

        val registration = framesQuery.addSnapshotListener { snapshot, error ->
            if (error != null) {
                logStreamError(error, OperationType.LIST, "calls/$callId/audio_frames", currentUserId)
                return@addSnapshotListener
            }
            if (snapshot == null) return@addSnapshotListener

            if (isFirstSnapshot) {
                isFirstSnapshot = false
                // Record existing backlog as seen so reconnecting never replays stale audio
                val latestPerSender = HashMap<String, CallAudioFrame>()
                for (doc in snapshot.documents) {
                    seenIds.add(doc.id)
                    val frame = doc.toObject(
                        CallAudioFrame::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ) ?: continue
                    if (frame.senderId != currentUserId && frame.payloadBase64.isNotBlank()) {
                        val prev = latestPerSender[frame.senderId]
                        if (prev == null || frame.seq > prev.seq) {
                            latestPerSender[frame.senderId] = frame
                        }
                    }
                }
                // Only emit the very latest frame per peer on initial attach (at most 240ms)
                latestPerSender.values
                    .sortedBy { it.seq }
                    .forEach { trySend(it) }
                return@addSnapshotListener
            }

            val freshFrames = mutableListOf<CallAudioFrame>()
            for (change in snapshot.documentChanges) {
                if (change.type != DocumentChange.Type.ADDED) continue
                val doc = change.document
                if (!seenIds.add(doc.id)) continue
                if (seenIds.size > 400) {
                    val iter = seenIds.iterator()
                    repeat(100) {
                        if (iter.hasNext()) {
                            iter.next()
                            iter.remove()
                        }
                    }
                }
                val frame = doc.toObject(
                    CallAudioFrame::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                )
                if (frame.senderId != currentUserId && frame.payloadBase64.isNotBlank()) {
                    freshFrames.add(frame)
                }
            }
            freshFrames.sortBy { it.seq }
            for (frame in freshFrames) {
                trySend(frame)
            }
        }

        awaitClose { registration.remove() }
    }

    private fun logStreamError(
        error: Throwable,
        operationType: OperationType,
        path: String,
        uid: String
    ) {
        val firestoreError = generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreError == null && error is CancellationException) return
        val exceptionToLog = firestoreError ?: (error as? Exception)
        if (exceptionToLog != null && auth.currentUser?.uid == uid) {
            handleFirestoreError(exceptionToLog, operationType, path)
        }
    }
}
