package com.example.data.repository

import com.example.base.FirestoreEmulatorTestBase
import com.example.crypto.CryptoManager
import com.example.data.model.ModerationStatus
import com.example.data.model.UserPresenceStatus
import com.example.data.model.UserRole
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.util.UUID

class CipherChatRepositoryRuleTest : FirestoreEmulatorTestBase() {

    @Test
    fun syncProfile_andCreateEncryptedGroupChat_succeedsForMembersAndBlocksOutsiders() = runBlocking {
        val aliceCrypto = CryptoManager()
        val bobCrypto = CryptoManager()
        val charlieCrypto = CryptoManager()

        val aliceUid = signInTestUser("alice_${UUID.randomUUID().toString().take(6)}@test.com")
        val aliceRepo = ChatRepository(firestore, aliceCrypto)
        withTimeout(TIMEOUT_MS) {
            aliceRepo.syncSignedInUserProfile(aliceUid, "alice@test.com", "Alice")
        }

        val bobUid = signInTestUser("bob_${UUID.randomUUID().toString().take(6)}@test.com")
        val bobRepo = ChatRepository(firestore, bobCrypto)
        withTimeout(TIMEOUT_MS) {
            bobRepo.syncSignedInUserProfile(bobUid, "bob@test.com", "Bob")
        }

        val charlieUid = signInTestUser("charlie_${UUID.randomUUID().toString().take(6)}@test.com")
        val charlieRepo = ChatRepository(firestore, charlieCrypto)
        withTimeout(TIMEOUT_MS) {
            charlieRepo.syncSignedInUserProfile(charlieUid, "charlie@test.com", "Charlie")
        }

        val discoverable = withTimeout(FLOW_TIMEOUT_MS) {
            charlieRepo.observeDiscoverableUsers().first { list ->
                list.any { it.userId == aliceUid } && list.any { it.userId == bobUid }
            }
        }
        val alicePublic = discoverable.first { it.userId == aliceUid }
        val bobPublic = discoverable.first { it.userId == bobUid }

        // Sign back in as Alice and create an encrypted group chat with Bob
        signInTestUser("alice_group_${aliceUid.take(5)}@test.com")
        val aliceUid2 = auth.currentUser!!.uid
        withTimeout(TIMEOUT_MS) {
            aliceRepo.syncSignedInUserProfile(aliceUid2, "alice2@test.com", "Alice Two")
        }
        val alicePublic2 = withTimeout(FLOW_TIMEOUT_MS) {
            aliceRepo.observeDiscoverableUsers().first { list -> list.any { it.userId == aliceUid2 } }
                .first { it.userId == aliceUid2 }
        }

        val groupId = withTimeout(TIMEOUT_MS) {
            aliceRepo.createGroupChat("Secret Lab", alicePublic2, listOf(bobPublic))
        }
        assertTrue(groupId.isNotBlank())

        val conv = withTimeout(FLOW_TIMEOUT_MS) {
            aliceRepo.observeConversations(aliceUid2).first { list -> list.any { it.id == groupId } }
                .first { it.id == groupId }
        }

        val aliceEnvelope = conv.memberKeyEnvelopes[aliceUid2]
        assertNotNull(aliceEnvelope)
        val roomKey = aliceCrypto.unwrapRoomKey(aliceEnvelope!!)
        assertNotNull(roomKey)

        val blob = aliceCrypto.encryptText(roomKey!!, "Привет, мир E2EE!")
        withTimeout(TIMEOUT_MS) {
            aliceRepo.sendEncryptedMessage(
                conversation = conv,
                senderName = "Alice Two",
                messageType = "text",
                ivBase64 = blob.ivBase64,
                encryptedPayload = blob.ciphertextBase64,
                encryptedPreviewLabel = "Зашифрованное сообщение"
            )
        }

        val msgs = withTimeout(FLOW_TIMEOUT_MS) {
            aliceRepo.observeMessages(groupId, aliceUid2).first { it.isNotEmpty() }
        }
        val decrypted = aliceCrypto.decryptText(roomKey, msgs.first().ivBase64, msgs.first().encryptedPayload)
        assertEquals("Привет, мир E2EE!", decrypted)

        // Outsider Charlie querying with his own UID sees zero messages, and trying to read the
        // conversation doc or query with Alice's UID fails with PERMISSION_DENIED
        signInTestUser("outsider_${UUID.randomUUID().toString().take(6)}@test.com")
        val outsiderUid = auth.currentUser!!.uid
        val outsiderMsgs = withTimeout(FLOW_TIMEOUT_MS) {
            charlieRepo.observeMessages(groupId, outsiderUid).first()
        }
        assertTrue(outsiderMsgs.isEmpty())

        try {
            withTimeout(FLOW_TIMEOUT_MS) {
                charlieRepo.observeConversation(groupId, outsiderUid).first()
            }
            fail("Expected PERMISSION_DENIED for non-member reading group conversation")
        } catch (e: Exception) {
            val fsEx = e.unwrapFirestoreException()
            assertNotNull("Expected nested FirebaseFirestoreException, got $e", fsEx)
            assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, fsEx!!.code)
        }
    }

    @Test
    fun observeConversations_unauthenticated_failsWithPermissionDenied() = runBlocking {
        auth.signOut()
        val repo = ChatRepository(firestore, CryptoManager())
        try {
            withTimeout(FLOW_TIMEOUT_MS) {
                repo.observeConversations("any_user").first()
            }
            fail("Expected PERMISSION_DENIED for unauthenticated user")
        } catch (e: Exception) {
            val fsEx = e.unwrapFirestoreException()
            assertNotNull("Expected nested FirebaseFirestoreException, got $e", fsEx)
            assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, fsEx!!.code)
        }
    }

    @Test
    fun calls_startJoinAndEnd_enforcesMemberIsolationAndTerminalState() = runBlocking {
        val aliceEmail = "caller_${UUID.randomUUID().toString().take(6)}@test.com"
        val aliceUid = signInTestUser(aliceEmail)
        val aliceCrypto = CryptoManager()
        val aliceRepo = ChatRepository(firestore, aliceCrypto)
        val callRepo = CallRepository(firestore)

        withTimeout(TIMEOUT_MS) {
            aliceRepo.syncSignedInUserProfile(aliceUid, aliceEmail, "Caller")
        }
        val alicePublic = withTimeout(FLOW_TIMEOUT_MS) {
            aliceRepo.observeDiscoverableUsers().first { l -> l.any { it.userId == aliceUid } }
                .first { it.userId == aliceUid }
        }
        val chatId = withTimeout(TIMEOUT_MS) {
            aliceRepo.createGroupChat("Voice Room", alicePublic, emptyList())
        }
        val conv = withTimeout(FLOW_TIMEOUT_MS) {
            aliceRepo.observeConversations(aliceUid).first { l -> l.any { it.id == chatId } }
                .first { it.id == chatId }
        }

        val callId = withTimeout(TIMEOUT_MS) {
            callRepo.startCall(conv, "Caller", "audio")
        }
        val call = withTimeout(FLOW_TIMEOUT_MS) {
            callRepo.observeCall(callId, aliceUid).first { it != null }!!
        }
        assertEquals("ringing", call.status)

        withTimeout(TIMEOUT_MS) {
            callRepo.leaveOrEndCall(call)
        }
        val endedCall = withTimeout(FLOW_TIMEOUT_MS) {
            callRepo.observeCall(callId, aliceUid).first { it?.status == "ended" }!!
        }
        assertEquals("ended", endedCall.status)
    }

    @Test
    fun profileEditing_updatesNicknameUsernameAvatarAndPreservesOnResync() = runBlocking {
        val email = "editor_${UUID.randomUUID().toString().take(6)}@test.com"
        val uid = signInTestUser(email)
        val repo = ChatRepository(firestore, CryptoManager())

        withTimeout(TIMEOUT_MS) {
            repo.syncSignedInUserProfile(uid, email, "Initial Name")
        }

        val fakeAvatar = "ZmFrZUF2YXRhckpwZWdCeXRlcw=="
        withTimeout(TIMEOUT_MS) {
            repo.updateUserProfile(
                uid = uid,
                displayName = "Cipher Master",
                rawUsername = "cipher_master_7",
                avatarBase64 = fakeAvatar
            )
        }

        val updatedPriv = withTimeout(FLOW_TIMEOUT_MS) {
            repo.observePrivateProfile(uid).first { it?.displayName == "Cipher Master" }!!
        }
        assertEquals("@cipher_master_7", updatedPriv.handle)
        assertEquals(fakeAvatar, updatedPriv.avatarBase64)

        val updatedPub = withTimeout(FLOW_TIMEOUT_MS) {
            repo.observeDiscoverableUsers().first { list ->
                list.any { it.userId == uid && it.displayName == "Cipher Master" }
            }.first { it.userId == uid }
        }
        assertEquals("@cipher_master_7", updatedPub.handle)
        assertEquals(fakeAvatar, updatedPub.avatarBase64)

        // Delete username (empty string)
        withTimeout(TIMEOUT_MS) {
            repo.updateUserProfile(
                uid = uid,
                displayName = "Cipher Master",
                rawUsername = "",
                avatarBase64 = fakeAvatar
            )
        }

        val withoutHandle = withTimeout(FLOW_TIMEOUT_MS) {
            repo.observePrivateProfile(uid).first { it?.handle == "" }!!
        }
        assertEquals("", withoutHandle.handle)

        // Re-syncing on next login must NOT clobber custom displayName, handle, or avatarBase64
        withTimeout(TIMEOUT_MS) {
            repo.syncSignedInUserProfile(uid, email, "Google Default Name")
        }
        val afterResync = withTimeout(FLOW_TIMEOUT_MS) {
            repo.observePrivateProfile(uid).first { it != null }!!
        }
        assertEquals("Cipher Master", afterResync.displayName)
        assertEquals("", afterResync.handle)
        assertEquals(fakeAvatar, afterResync.avatarBase64)
    }

    @Test
    fun searchUsers_findsByEmailUsernameAndDisplayName() = runBlocking {
        val bobEmail = "bob_lookup_${UUID.randomUUID().toString().take(6)}@test.com"
        val bobUid = signInTestUser(bobEmail)
        val bobRepo = ChatRepository(firestore, CryptoManager())
        withTimeout(TIMEOUT_MS) {
            bobRepo.syncSignedInUserProfile(bobUid, bobEmail, "Bob Initial")
            bobRepo.updateUserProfile(
                uid = bobUid,
                displayName = "Борис Разработчик",
                rawUsername = "bobby_cipher",
                avatarBase64 = ""
            )
        }

        val aliceEmail = "alice_search_${UUID.randomUUID().toString().take(6)}@test.com"
        val aliceUid = signInTestUser(aliceEmail)
        val aliceRepo = ChatRepository(firestore, CryptoManager())
        withTimeout(TIMEOUT_MS) {
            aliceRepo.syncSignedInUserProfile(aliceUid, aliceEmail, "Алиса")
            aliceRepo.updateUserProfile(
                uid = aliceUid,
                displayName = "Алиса Админ",
                rawUsername = "alice_root",
                avatarBase64 = ""
            )
        }

        // Wait until Bob is visible in discoverable directory
        withTimeout(FLOW_TIMEOUT_MS) {
            aliceRepo.observeDiscoverableUsers().first { list ->
                list.any { it.userId == bobUid && it.handle == "@bobby_cipher" }
            }
        }

        // 1. Search by exact email
        val byEmail = withTimeout(TIMEOUT_MS) { aliceRepo.searchUsers(bobEmail, excludeUid = aliceUid) }
        assertTrue(byEmail.any { it.userId == bobUid })

        // 2. Search by @username (with and without @)
        val byAtHandle = withTimeout(TIMEOUT_MS) { aliceRepo.searchUsers("@bobby_cipher", excludeUid = aliceUid) }
        assertEquals(bobUid, byAtHandle.firstOrNull()?.userId)

        val byPartialHandle = withTimeout(TIMEOUT_MS) { aliceRepo.searchUsers("bobby", excludeUid = aliceUid) }
        assertEquals(bobUid, byPartialHandle.firstOrNull()?.userId)

        // 3. Search by display name (case-insensitive)
        val byName = withTimeout(TIMEOUT_MS) { aliceRepo.searchUsers("борис", excludeUid = aliceUid) }
        assertEquals(bobUid, byName.firstOrNull()?.userId)

        // 4. Caller is excluded from search results
        val selfSearch = withTimeout(TIMEOUT_MS) { aliceRepo.searchUsers("@alice_root", excludeUid = aliceUid) }
        assertTrue(selfSearch.none { it.userId == aliceUid })
    }

    @Test
    fun roleCodes_bootstrapDeveloperGeneratesTesterCodeAndNonDeveloperBlocked() = runBlocking {
        // 1. Alice signs in as a regular user; cannot generate codes
        val aliceEmail = "dev_alice_${UUID.randomUUID().toString().take(6)}@test.com"
        val aliceUid = signInTestUser(aliceEmail)
        val aliceRepo = ChatRepository(firestore, CryptoManager())
        withTimeout(TIMEOUT_MS) {
            aliceRepo.syncSignedInUserProfile(aliceUid, aliceEmail, "Алиса")
        }

        try {
            withTimeout(TIMEOUT_MS) {
                aliceRepo.generateRoleCode(com.example.data.model.UserRole.TESTER)
            }
            fail("Expected regular user to be blocked from generating role codes")
        } catch (e: Exception) {
            val fsEx = e.unwrapFirestoreException()
            assertNotNull("Expected nested FirebaseFirestoreException, got $e", fsEx)
            assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, fsEx!!.code)
        }

        // 2. Wait until Alice's profile exists, then redeem single-use bootstrap developer code
        withTimeout(FLOW_TIMEOUT_MS) {
            aliceRepo.observePrivateProfile(aliceUid).first { it != null }
        }
        val grantedDevRole = withTimeout(TIMEOUT_MS) {
            aliceRepo.redeemRoleCode("SPOX-DEV-8K4M-9X2Q")
        }
        assertEquals(com.example.data.model.UserRole.DEVELOPER, grantedDevRole)

        val devPriv = withTimeout(FLOW_TIMEOUT_MS) {
            aliceRepo.observePrivateProfile(aliceUid).first { it?.role == "developer" }!!
        }
        assertEquals("developer", devPriv.role)

        // Re-syncing must preserve developer status
        withTimeout(TIMEOUT_MS) {
            aliceRepo.syncSignedInUserProfile(aliceUid, aliceEmail, "Алиса")
        }
        val devAfterSync = withTimeout(FLOW_TIMEOUT_MS) {
            aliceRepo.observePrivateProfile(aliceUid).first { it != null }!!
        }
        assertEquals("developer", devAfterSync.role)

        // 3. Developer Alice generates a single-use Tester code
        val (testerPlainCode, testerRecord) = withTimeout(TIMEOUT_MS) {
            aliceRepo.generateRoleCode(com.example.data.model.UserRole.TESTER)
        }
        assertTrue(testerPlainCode.startsWith("SPOX-TST-"))
        assertEquals("tester", testerRecord.targetRole)

        // Also generate a second code and delete it as developer
        val (_, extraRecord) = withTimeout(TIMEOUT_MS) {
            aliceRepo.generateRoleCode(com.example.data.model.UserRole.DEVELOPER)
        }
        withTimeout(TIMEOUT_MS) {
            aliceRepo.deleteRoleCode(extraRecord.codeHash)
        }

        // 4. Bob signs in as a regular user and redeems Alice's tester code
        val bobEmail = "tester_bob_${UUID.randomUUID().toString().take(6)}@test.com"
        val bobUid = signInTestUser(bobEmail)
        val bobRepo = ChatRepository(firestore, CryptoManager())
        withTimeout(TIMEOUT_MS) {
            bobRepo.syncSignedInUserProfile(bobUid, bobEmail, "Боб")
        }
        withTimeout(FLOW_TIMEOUT_MS) {
            bobRepo.observePrivateProfile(bobUid).first { it != null }
        }

        val grantedTesterRole = withTimeout(TIMEOUT_MS) {
            bobRepo.redeemRoleCode(testerPlainCode)
        }
        assertEquals(com.example.data.model.UserRole.TESTER, grantedTesterRole)

        val bobPub = withTimeout(FLOW_TIMEOUT_MS) {
            bobRepo.observeDiscoverableUsers().first { list ->
                list.any { it.userId == bobUid && it.role == "tester" }
            }.first { it.userId == bobUid }
        }
        assertEquals("tester", bobPub.role)

        // 5. Re-using either the bootstrap code or already-used tester code is rejected
        val charlieEmail = "charlie_late_${UUID.randomUUID().toString().take(6)}@test.com"
        val charlieUid = signInTestUser(charlieEmail)
        val charlieRepo = ChatRepository(firestore, CryptoManager())
        withTimeout(TIMEOUT_MS) {
            charlieRepo.syncSignedInUserProfile(charlieUid, charlieEmail, "Чарли")
        }
        withTimeout(FLOW_TIMEOUT_MS) {
            charlieRepo.observePrivateProfile(charlieUid).first { it != null }
        }

        try {
            withTimeout(TIMEOUT_MS) {
                charlieRepo.redeemRoleCode("SPOX-DEV-8K4M-9X2Q")
            }
            fail("Expected already-claimed bootstrap code to fail")
        } catch (_: Exception) {
            // Expected rejection
        }

        try {
            withTimeout(TIMEOUT_MS) {
                charlieRepo.redeemRoleCode(testerPlainCode)
            }
            fail("Expected already-used tester code to fail")
        } catch (_: Exception) {
            // Expected rejection
        }
    }

    @Test
    fun directChat_unreadCountsReadReceiptsAndRoomKeyRepair() = runBlocking {
        val aliceCrypto = CryptoManager()
        val aliceEmail = "rcpt_alice_${UUID.randomUUID().toString().take(6)}@test.com"
        val aliceUid = signInTestUser(aliceEmail)
        val aliceRepo = ChatRepository(firestore, aliceCrypto)
        withTimeout(TIMEOUT_MS) {
            aliceRepo.syncSignedInUserProfile(aliceUid, aliceEmail, "Алиса")
        }

        val bobCrypto = CryptoManager()
        val bobEmail = "rcpt_bob_${UUID.randomUUID().toString().take(6)}@test.com"
        val bobUid = signInTestUser(bobEmail)
        val bobRepo = ChatRepository(firestore, bobCrypto)
        withTimeout(TIMEOUT_MS) {
            bobRepo.syncSignedInUserProfile(bobUid, bobEmail, "Боб")
        }

        val bobPub = bobRepo.getPublicProfile(bobUid)!!
        signInTestUser(aliceEmail)
        val alicePub = aliceRepo.getPublicProfile(aliceUid)!!

        val chatId = withTimeout(TIMEOUT_MS) {
            aliceRepo.getOrCreateDirectChat(alicePub, bobPub)
        }
        val conv1 = withTimeout(FLOW_TIMEOUT_MS) {
            aliceRepo.observeConversation(chatId, aliceUid).first { it != null }!!
        }
        val aliceRoomKey = aliceCrypto.unwrapRoomKey(conv1.memberKeyEnvelopes[aliceUid]!!)!!
        val enc = aliceCrypto.encryptText(aliceRoomKey, "Привет, Боб!")
        withTimeout(TIMEOUT_MS) {
            aliceRepo.sendEncryptedMessage(
                conversation = conv1,
                senderName = "Алиса",
                messageType = "text",
                ivBase64 = enc.ivBase64,
                encryptedPayload = enc.ciphertextBase64,
                encryptedPreviewLabel = "Зашифрованное сообщение"
            )
        }

        val afterSend = withTimeout(FLOW_TIMEOUT_MS) {
            aliceRepo.observeConversation(chatId, aliceUid).first {
                it != null && it.unreadCountFor(bobUid) == 1
            }!!
        }
        assertEquals(0, afterSend.unreadCountFor(aliceUid))
        assertEquals(1, afterSend.unreadCountFor(bobUid))
        assertFalse(afterSend.isLastMessageReadByOther(aliceUid))

        // Bob opens chat and marks it read; also repairs room key as if on a fresh device install
        signInTestUser(bobEmail)
        val bobNewCrypto = CryptoManager()
        val bobReinstallRepo = ChatRepository(firestore, bobNewCrypto)
        withTimeout(TIMEOUT_MS) {
            bobReinstallRepo.syncSignedInUserProfile(bobUid, bobEmail, "Боб")
        }
        val bobConv = withTimeout(FLOW_TIMEOUT_MS) {
            bobReinstallRepo.observeConversation(chatId, bobUid).first { it != null }!!
        }
        withTimeout(TIMEOUT_MS) {
            bobReinstallRepo.markConversationAsRead(bobConv, bobUid)
        }
        val repairedKey = withTimeout(TIMEOUT_MS) {
            bobReinstallRepo.repairRoomKey(bobConv, bobUid)
        }
        val replyBlob = bobNewCrypto.encryptText(repairedKey, "Прочитано, отвечаю!")
        val latestConvAfterRead = withTimeout(FLOW_TIMEOUT_MS) {
            bobReinstallRepo.observeConversation(chatId, bobUid).first {
                it != null && it.unreadCountFor(bobUid) == 0
            }!!
        }
        assertTrue(latestConvAfterRead.isLastMessageReadByOther(aliceUid))

        withTimeout(TIMEOUT_MS) {
            bobReinstallRepo.sendEncryptedMessage(
                conversation = latestConvAfterRead,
                senderName = "Боб",
                messageType = "text",
                ivBase64 = replyBlob.ivBase64,
                encryptedPayload = replyBlob.ciphertextBase64,
                encryptedPreviewLabel = "Зашифрованное сообщение"
            )
        }

        val msgs = withTimeout(FLOW_TIMEOUT_MS) {
            bobReinstallRepo.observeMessages(chatId, bobUid).first { it.size >= 2 }
        }
        assertTrue(msgs.size >= 2)
    }

    @Test
    fun adminModeration_muteBanUnbanAndDeleteUserAccount() = runBlocking {
        val adminEmail = "mod_admin_${UUID.randomUUID().toString().take(6)}@test.com"
        val adminUid = signInTestUser(adminEmail)
        val adminCrypto = CryptoManager()
        val adminRepo = ChatRepository(firestore, adminCrypto)
        withTimeout(TIMEOUT_MS) {
            adminRepo.syncSignedInUserProfile(adminUid, adminEmail, "Админ")
        }
        withTimeout(FLOW_TIMEOUT_MS) {
            adminRepo.observePrivateProfile(adminUid).first { it != null }
        }
        withTimeout(TIMEOUT_MS) {
            adminRepo.redeemRoleCode("SPOX-DEV-8K4M-9X2Q")
        }

        val targetEmail = "mod_user_${UUID.randomUUID().toString().take(6)}@test.com"
        val targetUid = signInTestUser(targetEmail)
        val targetCrypto = CryptoManager()
        val targetRepo = ChatRepository(firestore, targetCrypto)
        withTimeout(TIMEOUT_MS) {
            targetRepo.syncSignedInUserProfile(targetUid, targetEmail, "Нарушитель")
        }
        val targetPub = targetRepo.getPublicProfile(targetUid)!!

        // Non-admin cannot moderate anyone
        try {
            withTimeout(TIMEOUT_MS) {
                targetRepo.moderateUserAccount(adminUid, ModerationStatus.BANNED, null, "попытка")
            }
            fail("Expected non-admin moderation call to fail with PERMISSION_DENIED")
        } catch (e: Exception) {
            val fsEx = e.unwrapFirestoreException()
            assertNotNull(fsEx)
            assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, fsEx!!.code)
        }

        // Create a shared chat so we can verify muted/banned send blocks
        signInTestUser(adminEmail)
        val adminPub = adminRepo.getPublicProfile(adminUid)!!
        val chatId = withTimeout(TIMEOUT_MS) {
            adminRepo.getOrCreateDirectChat(adminPub, targetPub)
        }

        // Admin mutes target for 1 hour
        withTimeout(TIMEOUT_MS) {
            adminRepo.moderateUserAccount(targetUid, ModerationStatus.MUTED, 3_600_000L, "Флуд в чате")
        }

        signInTestUser(targetEmail)
        val mutedPriv = withTimeout(FLOW_TIMEOUT_MS) {
            targetRepo.observePrivateProfile(targetUid).first { it?.moderationStatus == "muted" }!!
        }
        assertTrue(mutedPriv.isCurrentlyMuted())
        val sharedConv = withTimeout(FLOW_TIMEOUT_MS) {
            targetRepo.observeConversation(chatId, targetUid).first { it != null }!!
        }
        val targetKey = targetCrypto.unwrapRoomKey(sharedConv.memberKeyEnvelopes[targetUid]!!)!!
        val blockedMsg = targetCrypto.encryptText(targetKey, "Не должно пройти")
        try {
            withTimeout(TIMEOUT_MS) {
                targetRepo.sendEncryptedMessage(
                    conversation = sharedConv,
                    senderName = "Нарушитель",
                    messageType = "text",
                    ivBase64 = blockedMsg.ivBase64,
                    encryptedPayload = blockedMsg.ciphertextBase64,
                    encryptedPreviewLabel = "Зашифрованное сообщение"
                )
            }
            fail("Expected muted user message send to be denied")
        } catch (e: Exception) {
            val fsEx = e.unwrapFirestoreException()
            assertNotNull(fsEx)
            assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, fsEx!!.code)
        }

        // Admin unmutes, then bans, then deletes target account
        signInTestUser(adminEmail)
        withTimeout(TIMEOUT_MS) {
            adminRepo.moderateUserAccount(targetUid, ModerationStatus.ACTIVE, null, "")
            adminRepo.moderateUserAccount(targetUid, ModerationStatus.BANNED, null, "Нарушение правил")
        }

        signInTestUser(targetEmail)
        val bannedPriv = withTimeout(FLOW_TIMEOUT_MS) {
            targetRepo.observePrivateProfile(targetUid).first { it?.isBanned() == true }!!
        }
        assertTrue(bannedPriv.isBanned())

        signInTestUser(adminEmail)
        withTimeout(TIMEOUT_MS) {
            adminRepo.deleteUserAccountByAdmin(targetUid, "Удалён администратором")
        }

        signInTestUser(targetEmail)
        val deletedRecord = withTimeout(FLOW_TIMEOUT_MS) {
            targetRepo.observeDeletedAccount(targetUid).first { it != null }!!
        }
        assertEquals("Удалён администратором", deletedRecord.reason)
    }

    @Test
    fun presence_updatePresenceAndObservePeerStatuses() = runBlocking {
        val aliceEmail = "pres_alice_${UUID.randomUUID().toString().take(6)}@test.com"
        val aliceUid = signInTestUser(aliceEmail)
        val aliceRepo = ChatRepository(firestore, CryptoManager())
        withTimeout(TIMEOUT_MS) {
            aliceRepo.syncSignedInUserProfile(aliceUid, aliceEmail, "Алиса")
        }

        val bobEmail = "pres_bob_${UUID.randomUUID().toString().take(6)}@test.com"
        val bobUid = signInTestUser(bobEmail)
        val bobRepo = ChatRepository(firestore, CryptoManager())
        withTimeout(TIMEOUT_MS) {
            bobRepo.syncSignedInUserProfile(bobUid, bobEmail, "Боб")
            // Even if Bob disables discoverability, chat peers observe his presence by UID
            bobRepo.updateDiscoverability(bobUid, false)
            bobRepo.updatePresence(bobUid, isOnline = true)
        }

        signInTestUser(aliceEmail)
        val onlineMap = withTimeout(FLOW_TIMEOUT_MS) {
            aliceRepo.observePublicProfilesByIds(listOf(bobUid)).first { map ->
                map[bobUid]?.isOnline == true
            }
        }
        val bobOnlineProfile = onlineMap[bobUid]!!
        assertEquals(UserPresenceStatus.ONLINE, bobOnlineProfile.presenceStatus())

        // Simulate time advancing past heartbeat timeout (3 min -> recently online) and > 15 min -> offline
        val onlineTsMs = (bobOnlineProfile.lastSeenAt ?: bobOnlineProfile.updatedAt)!!.toDate().time
        assertEquals(UserPresenceStatus.RECENTLY, bobOnlineProfile.presenceStatus(onlineTsMs + 4 * 60_000L))
        assertEquals(UserPresenceStatus.OFFLINE, bobOnlineProfile.presenceStatus(onlineTsMs + 20 * 60_000L))

        // Bob goes offline -> peer observer receives isOnline = false -> "был в сети недавно"
        signInTestUser(bobEmail)
        withTimeout(TIMEOUT_MS) {
            bobRepo.updatePresence(bobUid, isOnline = false)
        }

        signInTestUser(aliceEmail)
        val offlineMap = withTimeout(FLOW_TIMEOUT_MS) {
            aliceRepo.observePublicProfilesByIds(listOf(bobUid)).first { map ->
                map[bobUid]?.isOnline == false
            }
        }
        val bobOfflineProfile = offlineMap[bobUid]!!
        assertEquals(UserPresenceStatus.RECENTLY, bobOfflineProfile.presenceStatus())
        val offlineTsMs = (bobOfflineProfile.lastSeenAt ?: bobOfflineProfile.updatedAt)!!.toDate().time
        assertEquals(UserPresenceStatus.OFFLINE, bobOfflineProfile.presenceStatus(offlineTsMs + 20 * 60_000L))
    }

    @Test
    fun directChat_findPersonAndOpenSameDmIdFromBothPeersWithInstantMessaging() = runBlocking {
        val aliceCrypto = CryptoManager()
        val aliceEmail = "dm_alice_${UUID.randomUUID().toString().take(6)}@test.com"
        val aliceUid = signInTestUser(aliceEmail)
        val aliceRepo = ChatRepository(firestore, aliceCrypto)
        withTimeout(TIMEOUT_MS) {
            aliceRepo.syncSignedInUserProfile(aliceUid, aliceEmail, "Алиса Вайс")
            aliceRepo.updateUserProfile(aliceUid, "Алиса Вайс", "alice_dm", "")
        }

        val bobCrypto = CryptoManager()
        val bobEmail = "dm_bob_${UUID.randomUUID().toString().take(6)}@test.com"
        val bobUid = signInTestUser(bobEmail)
        val bobRepo = ChatRepository(firestore, bobCrypto)
        withTimeout(TIMEOUT_MS) {
            bobRepo.syncSignedInUserProfile(bobUid, bobEmail, "Боб Смит")
            bobRepo.updateUserProfile(bobUid, "Боб Смит", "bob_dm", "")
        }

        // Alice finds Bob by @handle and opens DM with 1 call
        signInTestUser(aliceEmail)
        val alicePub = aliceRepo.getPublicProfile(aliceUid)!!
        val foundBob = withTimeout(TIMEOUT_MS) {
            aliceRepo.searchUsers("@bob_dm", excludeUid = aliceUid).first()
        }
        assertEquals(bobUid, foundBob.userId)
        val dmIdFromAlice = withTimeout(TIMEOUT_MS) {
            aliceRepo.getOrCreateDirectChat(alicePub, foundBob)
        }

        val aliceConv = withTimeout(FLOW_TIMEOUT_MS) {
            aliceRepo.observeConversation(dmIdFromAlice, aliceUid).first { it != null }!!
        }
        assertFalse(aliceConv.isGroup)
        assertEquals(setOf(aliceUid, bobUid), aliceConv.memberUids.toSet())

        // Alice immediately writes a message in the DM
        val aliceRoomKey = aliceCrypto.unwrapRoomKey(aliceConv.memberKeyEnvelopes[aliceUid]!!)!!
        val enc1 = aliceCrypto.encryptText(aliceRoomKey, "Привет в ЛС!")
        withTimeout(TIMEOUT_MS) {
            aliceRepo.sendEncryptedMessage(
                conversation = aliceConv,
                senderName = "Алиса Вайс",
                messageType = "text",
                ivBase64 = enc1.ivBase64,
                encryptedPayload = enc1.ciphertextBase64,
                encryptedPreviewLabel = "Зашифрованное сообщение"
            )
        }

        // Bob searches Alice by display name and opens the exact same DM
        signInTestUser(bobEmail)
        val bobPub = bobRepo.getPublicProfile(bobUid)!!
        val foundAlice = withTimeout(TIMEOUT_MS) {
            bobRepo.searchUsers("Алиса Вайс", excludeUid = bobUid).first()
        }
        val dmIdFromBob = withTimeout(TIMEOUT_MS) {
            bobRepo.getOrCreateDirectChat(bobPub, foundAlice)
        }
        assertEquals(dmIdFromAlice, dmIdFromBob)

        val bobConv = withTimeout(FLOW_TIMEOUT_MS) {
            bobRepo.observeConversation(dmIdFromBob, bobUid).first { it != null }!!
        }
        val bobMsgs = withTimeout(FLOW_TIMEOUT_MS) {
            bobRepo.observeMessages(dmIdFromBob, bobUid).first { it.isNotEmpty() }
        }
        val bobRoomKey = bobCrypto.unwrapRoomKey(bobConv.memberKeyEnvelopes[bobUid]!!)!!
        assertEquals(
            "Привет в ЛС!",
            bobCrypto.decryptText(bobRoomKey, bobMsgs.first().ivBase64, bobMsgs.first().encryptedPayload)
        )

        // Bob replies directly in the same DM
        val enc2 = bobCrypto.encryptText(bobRoomKey, "Удобно, без групп!")
        withTimeout(TIMEOUT_MS) {
            bobRepo.sendEncryptedMessage(
                conversation = bobConv,
                senderName = "Боб Смит",
                messageType = "text",
                ivBase64 = enc2.ivBase64,
                encryptedPayload = enc2.ciphertextBase64,
                encryptedPreviewLabel = "Зашифрованное сообщение"
            )
        }

        signInTestUser(aliceEmail)
        val aliceMsgs = withTimeout(FLOW_TIMEOUT_MS) {
            aliceRepo.observeMessages(dmIdFromAlice, aliceUid).first { it.size >= 2 }
        }
        assertEquals(
            "Удобно, без групп!",
            aliceCrypto.decryptText(aliceRoomKey, aliceMsgs[1].ivBase64, aliceMsgs[1].encryptedPayload)
        )
    }

    @Test
    fun calls_twoWayAudioFramesStream_betweenCallerAndCallee() = runBlocking {
        val aliceEmail = "voice_alice_${UUID.randomUUID().toString().take(6)}@test.com"
        val bobEmail = "voice_bob_${UUID.randomUUID().toString().take(6)}@test.com"

        val aliceUid = signInTestUser(aliceEmail)
        val aliceCrypto = CryptoManager()
        val aliceRepo = ChatRepository(firestore, aliceCrypto)
        withTimeout(TIMEOUT_MS) {
            aliceRepo.syncSignedInUserProfile(aliceUid, aliceEmail, "Алиса")
        }

        val bobUid = signInTestUser(bobEmail)
        val bobCrypto = CryptoManager()
        val bobRepo = ChatRepository(firestore, bobCrypto)
        withTimeout(TIMEOUT_MS) {
            bobRepo.syncSignedInUserProfile(bobUid, bobEmail, "Боб")
        }

        val callRepo = CallRepository(firestore)
        val alicePub = withTimeout(TIMEOUT_MS) { aliceRepo.getPublicProfile(aliceUid)!! }
        val bobPub = withTimeout(TIMEOUT_MS) { bobRepo.getPublicProfile(bobUid)!! }

        signInTestUser(aliceEmail)
        val dmId = withTimeout(TIMEOUT_MS) { aliceRepo.getOrCreateDirectChat(alicePub, bobPub) }
        val conv = withTimeout(FLOW_TIMEOUT_MS) {
            aliceRepo.observeConversation(dmId, aliceUid).first { it != null }!!
        }

        val callId = withTimeout(TIMEOUT_MS) { callRepo.startCall(conv, "Алиса", "audio") }
        val call = withTimeout(FLOW_TIMEOUT_MS) { callRepo.observeCall(callId, aliceUid).first { it != null }!! }

        // Bob answers and joins call
        signInTestUser(bobEmail)
        withTimeout(TIMEOUT_MS) { callRepo.joinCall(call, "Боб", enableVideo = false) }

        // Bob sends an audio frame to Alice
        withTimeout(TIMEOUT_MS) {
            callRepo.sendAudioFrame(
                callId = callId,
                memberUids = conv.memberUids,
                seq = 0L,
                payloadBase64 = "AAAAYm9iX2F1ZGlvX2ZyYW1l"
            )
        }

        // Alice receives Bob's audio frame
        signInTestUser(aliceEmail)
        val aliceReceived = withTimeout(FLOW_TIMEOUT_MS) {
            callRepo.observeIncomingAudioFrames(callId, aliceUid).first()
        }
        assertEquals(bobUid, aliceReceived.senderId)
        assertEquals(0L, aliceReceived.seq)
        assertEquals("AAAAYm9iX2F1ZGlvX2ZyYW1l", aliceReceived.payloadBase64)

        // Alice sends an audio frame back to Bob
        withTimeout(TIMEOUT_MS) {
            callRepo.sendAudioFrame(
                callId = callId,
                memberUids = conv.memberUids,
                seq = 0L,
                payloadBase64 = "AAAAYWxpY2VfYXVkaW9fZnJhbWU="
            )
        }

        signInTestUser(bobEmail)
        val bobReceived = withTimeout(FLOW_TIMEOUT_MS) {
            callRepo.observeIncomingAudioFrames(callId, bobUid).first()
        }
        assertEquals(aliceUid, bobReceived.senderId)
        assertEquals("AAAAYWxpY2VfYXVkaW9fZnJhbWU=", bobReceived.payloadBase64)

        // Cleanup: end call
        withTimeout(TIMEOUT_MS) { callRepo.leaveOrEndCall(call) }
    }

    @Test
    fun groupManagement_settingsAddRemoveRotateKeyLeaveAndDelete() = runBlocking {
        val aliceEmail = "gm_alice_${UUID.randomUUID().toString().take(6)}@test.com"
        val bobEmail = "gm_bob_${UUID.randomUUID().toString().take(6)}@test.com"
        val charlieEmail = "gm_charlie_${UUID.randomUUID().toString().take(6)}@test.com"

        val aliceUid = signInTestUser(aliceEmail)
        val aliceCrypto = CryptoManager()
        val aliceRepo = ChatRepository(firestore, aliceCrypto)
        withTimeout(TIMEOUT_MS) { aliceRepo.syncSignedInUserProfile(aliceUid, aliceEmail, "Алиса") }

        val bobUid = signInTestUser(bobEmail)
        val bobCrypto = CryptoManager()
        val bobRepo = ChatRepository(firestore, bobCrypto)
        withTimeout(TIMEOUT_MS) { bobRepo.syncSignedInUserProfile(bobUid, bobEmail, "Боб") }

        val charlieUid = signInTestUser(charlieEmail)
        val charlieCrypto = CryptoManager()
        val charlieRepo = ChatRepository(firestore, charlieCrypto)
        withTimeout(TIMEOUT_MS) { charlieRepo.syncSignedInUserProfile(charlieUid, charlieEmail, "Чарли") }

        val alicePub = aliceRepo.getPublicProfile(aliceUid)!!
        val bobPub = bobRepo.getPublicProfile(bobUid)!!
        val charliePub = charlieRepo.getPublicProfile(charlieUid)!!

        // Alice creates a group with Bob
        signInTestUser(aliceEmail)
        val groupId = withTimeout(TIMEOUT_MS) {
            aliceRepo.createGroupChat(
                title = "Проект Альфа",
                description = "Секретная команда",
                creator = alicePub,
                selectedMembers = listOf(bobPub)
            )
        }
        val initialConv = withTimeout(FLOW_TIMEOUT_MS) {
            aliceRepo.observeConversation(groupId, aliceUid).first { it != null }!!
        }
        assertEquals("Секретная команда", initialConv.description)

        // Update settings (title & description)
        withTimeout(TIMEOUT_MS) {
            aliceRepo.updateGroupSettings(initialConv, "Проект Бета", "Новое описание")
        }
        val updatedConv = withTimeout(FLOW_TIMEOUT_MS) {
            aliceRepo.observeConversation(groupId, aliceUid).first { it?.title == "Проект Бета" }!!
        }
        assertEquals("Новое описание", updatedConv.description)

        // Add Charlie to the group using existing room key
        val initialKey = aliceCrypto.unwrapRoomKey(updatedConv.memberKeyEnvelopes[aliceUid]!!)!!
        withTimeout(TIMEOUT_MS) {
            aliceRepo.addMembersToGroup(updatedConv, listOf(charliePub), initialKey)
        }
        val withCharlie = withTimeout(FLOW_TIMEOUT_MS) {
            aliceRepo.observeConversation(groupId, aliceUid).first {
                it != null && charlieUid in it.memberUids
            }!!
        }
        val oldAliceEnvelope = withCharlie.memberKeyEnvelopes[aliceUid]!!

        // Alice removes Bob -> room key rotates!
        withTimeout(TIMEOUT_MS) {
            aliceRepo.removeMemberFromGroup(withCharlie, bobUid)
        }
        val afterKick = withTimeout(FLOW_TIMEOUT_MS) {
            aliceRepo.observeConversation(groupId, aliceUid).first {
                it != null && bobUid !in it.memberUids
            }!!
        }
        assertFalse(afterKick.memberKeyEnvelopes.containsKey(bobUid))
        val rotatedAliceEnvelope = afterKick.memberKeyEnvelopes[aliceUid]!!
        assertFalse(oldAliceEnvelope == rotatedAliceEnvelope)

        // Charlie still can unwrap rotated key & send message; then Charlie leaves cleanly
        signInTestUser(charlieEmail)
        val charlieConv = withTimeout(FLOW_TIMEOUT_MS) {
            charlieRepo.observeConversation(groupId, charlieUid).first { it != null }!!
        }
        val rotatedKeyForCharlie = charlieCrypto.unwrapRoomKey(charlieConv.memberKeyEnvelopes[charlieUid]!!)!!
        val blob = charlieCrypto.encryptText(rotatedKeyForCharlie, "После кика")
        withTimeout(TIMEOUT_MS) {
            charlieRepo.sendEncryptedMessage(
                conversation = charlieConv,
                senderName = "Чарли",
                messageType = "text",
                ivBase64 = blob.ivBase64,
                encryptedPayload = blob.ciphertextBase64,
                encryptedPreviewLabel = "Зашифрованное сообщение"
            )
        }

        withTimeout(TIMEOUT_MS) {
            charlieRepo.leaveGroupChat(charlieConv, charlieUid)
        }

        // Alice verifies Charlie left and deletes the entire group chat (messages + doc)
        signInTestUser(aliceEmail)
        val beforeDelete = withTimeout(FLOW_TIMEOUT_MS) {
            aliceRepo.observeConversation(groupId, aliceUid).first {
                it != null && charlieUid !in it.memberUids
            }!!
        }
        withTimeout(TIMEOUT_MS) {
            aliceRepo.deleteConversation(beforeDelete)
        }
        val remainingList = withTimeout(FLOW_TIMEOUT_MS) {
            aliceRepo.observeConversations(aliceUid).first { list -> list.none { it.id == groupId } }
        }
        assertTrue(remainingList.none { it.id == groupId })

        // DM creation & deletion by participant
        val dmId = withTimeout(TIMEOUT_MS) {
            aliceRepo.getOrCreateDirectChat(alicePub, bobPub)
        }
        val dmConv = withTimeout(FLOW_TIMEOUT_MS) {
            aliceRepo.observeConversation(dmId, aliceUid).first { it != null }!!
        }
        signInTestUser(bobEmail)
        withTimeout(TIMEOUT_MS) {
            bobRepo.deleteConversation(dmConv)
        }
        val bobRemaining = withTimeout(FLOW_TIMEOUT_MS) {
            bobRepo.observeConversations(bobUid).first { list -> list.none { it.id == dmId } }
        }
        assertTrue(bobRemaining.none { it.id == dmId })
    }

    @Test
    fun chunkedMedia_sendDownloadDecryptAndCleanupOnDelete() = runBlocking {
        val aliceEmail = "media_alice_${UUID.randomUUID().toString().take(6)}@test.com"
        val bobEmail = "media_bob_${UUID.randomUUID().toString().take(6)}@test.com"

        val aliceUid = signInTestUser(aliceEmail)
        val aliceCrypto = CryptoManager()
        val aliceRepo = ChatRepository(firestore, aliceCrypto)
        withTimeout(TIMEOUT_MS) { aliceRepo.syncSignedInUserProfile(aliceUid, aliceEmail, "Алиса") }

        val bobUid = signInTestUser(bobEmail)
        val bobCrypto = CryptoManager()
        val bobRepo = ChatRepository(firestore, bobCrypto)
        withTimeout(TIMEOUT_MS) { bobRepo.syncSignedInUserProfile(bobUid, bobEmail, "Боб") }

        val bobPub = bobRepo.getPublicProfile(bobUid)!!
        signInTestUser(aliceEmail)
        val alicePub = aliceRepo.getPublicProfile(aliceUid)!!
        val dmId = withTimeout(TIMEOUT_MS) { aliceRepo.getOrCreateDirectChat(alicePub, bobPub) }
        val aliceConv = withTimeout(FLOW_TIMEOUT_MS) {
            aliceRepo.observeConversation(dmId, aliceUid).first { it != null }!!
        }
        val aliceKey = aliceCrypto.unwrapRoomKey(aliceConv.memberKeyEnvelopes[aliceUid]!!)!!

        // Create a ~1.1 MB payload spanning 3 encrypted chunks (480 KB each)
        val payloadSize = 1_100_000
        val sourceBytes = ByteArray(payloadSize) { idx -> ((idx * 31 + 7) % 256).toByte() }
        val stagedFile = java.io.File.createTempFile("spox_test_video_", ".mkv")
        val downloadedFile = java.io.File.createTempFile("spox_test_out_", ".mkv")
        try {
            stagedFile.writeBytes(sourceBytes)
            val progressSteps = mutableListOf<Pair<Int, Int>>()
            withTimeout(15_000L) {
                aliceRepo.sendChunkedMediaMessage(
                    conversation = aliceConv,
                    senderName = "Алиса",
                    roomKey = aliceKey,
                    sourceFile = stagedFile,
                    fileName = "trailer.mkv",
                    mimeType = "video/x-matroska",
                    sizeBytes = payloadSize.toLong(),
                    encryptedPreviewLabel = "Видео: trailer.mkv",
                    onChunkProgress = { done, total -> progressSteps.add(done to total) }
                )
            }
            assertEquals(3, progressSteps.size)
            assertEquals(3 to 3, progressSteps.last())

            // Bob observes manifest message, decrypts manifest, and downloads all encrypted chunks
            signInTestUser(bobEmail)
            val bobConv = withTimeout(FLOW_TIMEOUT_MS) {
                bobRepo.observeConversation(dmId, bobUid).first { it != null }!!
            }
            val bobKey = bobCrypto.unwrapRoomKey(bobConv.memberKeyEnvelopes[bobUid]!!)!!
            val bobMsgs = withTimeout(FLOW_TIMEOUT_MS) {
                bobRepo.observeMessages(dmId, bobUid).first { it.isNotEmpty() }
            }
            val mediaMsg = bobMsgs.first()
            val manifest = bobCrypto.decryptFilePayload(bobKey, mediaMsg.ivBase64, mediaMsg.encryptedPayload)!!
            assertTrue(manifest.isChunked)
            assertEquals(3, manifest.chunkCount)
            assertEquals("trailer.mkv", manifest.fileName)
            assertEquals(payloadSize.toLong(), manifest.sizeBytes)

            val assembled = withTimeout(15_000L) {
                bobRepo.downloadAndDecryptChunkedMedia(
                    chatId = dmId,
                    messageId = mediaMsg.id,
                    roomKey = bobKey,
                    targetFile = downloadedFile,
                    expectedChunkCount = manifest.chunkCount
                )
            }
            val decryptedBytes = assembled.readBytes()
            assertEquals(payloadSize, decryptedBytes.size)
            assertTrue(sourceBytes.contentEquals(decryptedBytes))

            // Deleting the conversation deletes chunks, messages, and conversation doc
            withTimeout(10_000L) {
                bobRepo.deleteConversation(bobConv)
            }
            val remaining = withTimeout(FLOW_TIMEOUT_MS) {
                bobRepo.observeConversations(bobUid).first { list -> list.none { it.id == dmId } }
            }
            assertTrue(remaining.none { it.id == dmId })
        } finally {
            stagedFile.delete()
            downloadedFile.delete()
        }
    }

    private companion object {
        const val TIMEOUT_MS = 5000L
        const val FLOW_TIMEOUT_MS = 4000L
    }
}
