package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesomeMotion
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ColorLens
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Wallpaper
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.AppThemeMode
import com.example.data.model.AppVisualTheme
import com.example.data.model.ChatAppearanceConfig
import com.example.data.model.ChatWallpaperPreset
import com.example.data.model.OutgoingBubbleStyle
import com.example.ui.components.ChatWallpaperBackground
import com.example.ui.components.resolveOutgoingBubblePalette
import com.example.ui.theme.isLiquidGlassActive
import com.example.ui.theme.liquidGlassSurface

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CustomizationSettingsTab(
    appearance: ChatAppearanceConfig,
    onSelectThemeMode: (AppThemeMode) -> Unit,
    onSelectVisualTheme: (AppVisualTheme) -> Unit,
    onSelectWallpaperPreset: (ChatWallpaperPreset) -> Unit,
    onPickCustomWallpaperUri: (android.net.Uri) -> Unit,
    onSelectOutgoingBubbleStyle: (OutgoingBubbleStyle) -> Unit,
    onSetShowStories: (Boolean) -> Unit = {},
    onSetShowFolders: (Boolean) -> Unit = {},
    onSetLiquidGlassEnabled: (Boolean) -> Unit = {},
    onResetCustomization: () -> Unit
) {
    val wallpaperPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            onPickCustomWallpaperUri(uri)
        }
    }

    val isDark = when (appearance.themeMode) {
        AppThemeMode.DARK -> true
        AppThemeMode.LIGHT -> false
        AppThemeMode.SYSTEM -> isSystemInDarkTheme()
    }
    val bubblePalette = resolveOutgoingBubblePalette(appearance.outgoingBubbleStyle)
    val glassActive = isLiquidGlassActive()
    val previewGlass = appearance.liquidGlassEnabled && !appearance.resourceSavingMode

    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Live Chat Preview Card
        Surface(
            shape = RoundedCornerShape(20.dp),
            border = BorderStroke(
                1.dp,
                if (previewGlass) MaterialTheme.colorScheme.outline.copy(alpha = 0.7f)
                else MaterialTheme.colorScheme.outlineVariant
            ),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("customization_live_preview")
        ) {
            ChatWallpaperBackground(
                appearance = appearance,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(156.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    val headerShape = RoundedCornerShape(50)
                    Surface(
                        shape = headerShape,
                        color = if (previewGlass) androidx.compose.ui.graphics.Color.Transparent
                        else MaterialTheme.colorScheme.surface.copy(alpha = 0.85f),
                        border = if (previewGlass) null
                        else BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                        modifier = Modifier
                            .align(Alignment.CenterHorizontally)
                            .then(
                                if (previewGlass) {
                                    Modifier.liquidGlassSurface(
                                        shape = headerShape,
                                        isHighlighted = true
                                    )
                                } else {
                                    Modifier
                                }
                            )
                    ) {
                        Text(
                            text = if (previewGlass) {
                                "Предпросмотр • ${appearance.visualTheme.labelRu} • Liquid Glass"
                            } else {
                                "Предпросмотр чата • ${appearance.visualTheme.labelRu}"
                            },
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }

                    Column(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        val incomingShape = RoundedCornerShape(
                            topStart = 14.dp,
                            topEnd = 14.dp,
                            bottomStart = 4.dp,
                            bottomEnd = 14.dp
                        )
                        Surface(
                            shape = incomingShape,
                            color = if (previewGlass) androidx.compose.ui.graphics.Color.Transparent
                            else MaterialTheme.colorScheme.surfaceContainerHigh,
                            border = if (previewGlass) null
                            else BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                            modifier = Modifier
                                .align(Alignment.Start)
                                .then(
                                    if (previewGlass) {
                                        Modifier.liquidGlassSurface(
                                            shape = incomingShape,
                                            tintColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                                            tintAlpha = 0.38f
                                        )
                                    } else {
                                        Modifier
                                    }
                                )
                        ) {
                            Text(
                                text = "Как выглядят новые обои и тема?",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp)
                            )
                        }

                        val outgoingShape = RoundedCornerShape(
                            topStart = 14.dp,
                            topEnd = 14.dp,
                            bottomStart = 14.dp,
                            bottomEnd = 4.dp
                        )
                        Surface(
                            shape = outgoingShape,
                            border = if (previewGlass) null else BorderStroke(1.dp, bubblePalette.borderColor),
                            color = if (previewGlass) androidx.compose.ui.graphics.Color.Transparent else bubblePalette.startColor,
                            modifier = Modifier
                                .align(Alignment.End)
                                .then(
                                    if (previewGlass) {
                                        Modifier.liquidGlassSurface(
                                            shape = outgoingShape,
                                            tintColor = bubblePalette.startColor,
                                            accentGlow = bubblePalette.endColor,
                                            isHighlighted = true,
                                            tintAlpha = 0.36f
                                        )
                                    } else {
                                        Modifier
                                    }
                                )
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .then(
                                        if (previewGlass) {
                                            Modifier
                                        } else {
                                            Modifier.background(
                                                Brush.linearGradient(
                                                    listOf(bubblePalette.startColor, bubblePalette.endColor)
                                                )
                                            )
                                        }
                                    )
                                    .padding(horizontal = 12.dp, vertical = 7.dp)
                            ) {
                                Text(
                                    text = "Отлично, стиль обновлён!",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = bubblePalette.contentColor
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Icon(
                                    imageVector = Icons.Filled.DoneAll,
                                    contentDescription = null,
                                    tint = bubblePalette.contentColor.copy(alpha = 0.85f),
                                    modifier = Modifier.size(13.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Liquid Glass Effect (Полупрозрачный интерфейс всего приложения)
        val liquidGlassCardShape = RoundedCornerShape(18.dp)
        Surface(
            shape = liquidGlassCardShape,
            color = when {
                glassActive -> androidx.compose.ui.graphics.Color.Transparent
                appearance.liquidGlassEnabled -> MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.42f)
                else -> MaterialTheme.colorScheme.surfaceContainer
            },
            border = if (glassActive) null else BorderStroke(
                width = if (appearance.liquidGlassEnabled) 1.5.dp else 1.dp,
                color = if (appearance.liquidGlassEnabled) {
                    MaterialTheme.colorScheme.primary.copy(alpha = 0.65f)
                } else {
                    MaterialTheme.colorScheme.outlineVariant
                }
            ),
            modifier = Modifier
                .fillMaxWidth()
                .then(
                    if (glassActive) {
                        Modifier.liquidGlassSurface(
                            shape = liquidGlassCardShape,
                            tintColor = MaterialTheme.colorScheme.primaryContainer,
                            isHighlighted = appearance.liquidGlassEnabled
                        )
                    } else {
                        Modifier.clip(liquidGlassCardShape)
                    }
                )
                .clickable { onSetLiquidGlassEnabled(!appearance.liquidGlassEnabled) }
                .testTag("liquid_glass_card")
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Surface(
                    shape = CircleShape,
                    color = if (appearance.liquidGlassEnabled) {
                        MaterialTheme.colorScheme.primary.copy(alpha = 0.22f)
                    } else {
                        MaterialTheme.colorScheme.surfaceContainerHigh
                    },
                    border = BorderStroke(
                        1.dp,
                        if (appearance.liquidGlassEnabled) MaterialTheme.colorScheme.primary.copy(alpha = 0.55f)
                        else MaterialTheme.colorScheme.outlineVariant
                    ),
                    modifier = Modifier.size(44.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Filled.WaterDrop,
                            contentDescription = null,
                            tint = if (appearance.liquidGlassEnabled) {
                                MaterialTheme.colorScheme.primary
                            } else {
                                MaterialTheme.colorScheme.onSurfaceVariant
                            },
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "Liquid Glass",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        if (appearance.liquidGlassEnabled) {
                            Surface(
                                shape = RoundedCornerShape(50),
                                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.18f)
                            ) {
                                Text(
                                    text = "ВКЛ",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "Полупрозрачный стеклянный интерфейс по всему приложению",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Switch(
                    checked = appearance.liquidGlassEnabled,
                    onCheckedChange = onSetLiquidGlassEnabled,
                    modifier = Modifier.testTag("liquid_glass_switch")
                )
            }
        }

        // 1. Wallpapers (Обои)
        val sectionShape = RoundedCornerShape(18.dp)
        Surface(
            shape = sectionShape,
            color = if (glassActive) androidx.compose.ui.graphics.Color.Transparent else MaterialTheme.colorScheme.surfaceContainer,
            border = if (glassActive) null else BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
            modifier = if (glassActive) Modifier.liquidGlassSurface(shape = sectionShape) else Modifier
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Filled.Wallpaper,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "1. Обои чатов",
                        style = MaterialTheme.typography.titleSmall
                    )
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    ChatWallpaperPreset.entries.forEach { preset ->
                        if (preset == ChatWallpaperPreset.CUSTOM_IMAGE && appearance.customWallpaperPath.isBlank()) {
                            return@forEach
                        }
                        val isSelected = appearance.wallpaperPreset == preset
                        val swatchColors = if (preset == ChatWallpaperPreset.THEME_DEFAULT) {
                            listOf(
                                MaterialTheme.colorScheme.background,
                                MaterialTheme.colorScheme.surfaceContainerHigh
                            )
                        } else if (isDark) {
                            preset.darkColors
                        } else {
                            preset.lightColors
                        }
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier
                                .width(74.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .clickable { onSelectWallpaperPreset(preset) }
                                .padding(4.dp)
                                .testTag("wallpaper_preset_${preset.wireValue}")
                        ) {
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                border = BorderStroke(
                                    width = if (isSelected) 2.5.dp else 1.dp,
                                    color = if (isSelected) MaterialTheme.colorScheme.primary
                                    else MaterialTheme.colorScheme.outlineVariant
                                ),
                                modifier = Modifier
                                    .size(width = 64.dp, height = 76.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .background(
                                            if (swatchColors.size >= 2) Brush.verticalGradient(swatchColors)
                                            else Brush.verticalGradient(
                                                listOf(
                                                    MaterialTheme.colorScheme.background,
                                                    MaterialTheme.colorScheme.surface
                                                )
                                            )
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (isSelected) {
                                        Surface(
                                            shape = CircleShape,
                                            color = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(24.dp)
                                        ) {
                                            Box(contentAlignment = Alignment.Center) {
                                                Icon(
                                                    imageVector = Icons.Filled.Check,
                                                    contentDescription = "Выбрано",
                                                    tint = MaterialTheme.colorScheme.onPrimary,
                                                    modifier = Modifier.size(15.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = preset.labelRu,
                                style = MaterialTheme.typography.labelSmall,
                                color = if (isSelected) MaterialTheme.colorScheme.primary
                                else MaterialTheme.colorScheme.onSurfaceVariant,
                                fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }

                OutlinedButton(
                    onClick = {
                        wallpaperPickerLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    },
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("pick_custom_wallpaper_button")
                ) {
                    Icon(Icons.Filled.PhotoLibrary, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (appearance.customWallpaperPath.isNotBlank()) {
                            "Заменить фото обоев из галереи"
                        } else {
                            "Выбрать фото обоев из галереи"
                        }
                    )
                }
            }
        }

        // 2. Message Bubble Color (Цвет своих сообщений)
        Surface(
            shape = sectionShape,
            color = if (glassActive) androidx.compose.ui.graphics.Color.Transparent else MaterialTheme.colorScheme.surfaceContainer,
            border = if (glassActive) null else BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
            modifier = if (glassActive) Modifier.liquidGlassSurface(shape = sectionShape) else Modifier
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Filled.ColorLens,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "2. Цвет ваших сообщений",
                        style = MaterialTheme.typography.titleSmall
                    )
                }

                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutgoingBubbleStyle.entries.forEach { style ->
                        val isSelected = appearance.outgoingBubbleStyle == style
                        val start = style.startColor ?: MaterialTheme.colorScheme.primaryContainer
                        val end = style.endColor ?: MaterialTheme.colorScheme.secondaryContainer
                        val fg = style.contentColor ?: MaterialTheme.colorScheme.onPrimaryContainer

                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = if (isSelected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f)
                            else MaterialTheme.colorScheme.surfaceContainerLow,
                            border = BorderStroke(
                                width = if (isSelected) 1.5.dp else 1.dp,
                                color = if (isSelected) MaterialTheme.colorScheme.primary
                                else MaterialTheme.colorScheme.outlineVariant
                            ),
                            modifier = Modifier
                                .height(48.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .clickable { onSelectOutgoingBubbleStyle(style) }
                                .testTag("bubble_color_${style.wireValue}")
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(22.dp)
                                        .clip(CircleShape)
                                        .background(Brush.linearGradient(listOf(start, end))),
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (isSelected) {
                                        Icon(
                                            imageVector = Icons.Filled.Check,
                                            contentDescription = "Выбрано",
                                            tint = fg,
                                            modifier = Modifier.size(13.dp)
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = style.labelRu,
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }
            }
        }

        // 3. Full Messenger Themes (Темы, меняющие весь мессенджер)
        Surface(
            shape = sectionShape,
            color = if (glassActive) androidx.compose.ui.graphics.Color.Transparent else MaterialTheme.colorScheme.surfaceContainer,
            border = if (glassActive) null else BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
            modifier = if (glassActive) Modifier.liquidGlassSurface(shape = sectionShape) else Modifier
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Filled.Palette,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "3. Темы мессенджера",
                            style = MaterialTheme.typography.titleSmall
                        )
                        Text(
                            text = "Полностью меняют цвета, кнопки, фоны и интерфейс",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                    val options = listOf(
                        AppThemeMode.DARK to "Тёмная",
                        AppThemeMode.LIGHT to "Светлая",
                        AppThemeMode.SYSTEM to "Система"
                    )
                    options.forEachIndexed { index, (mode, label) ->
                        SegmentedButton(
                            selected = appearance.themeMode == mode,
                            onClick = { onSelectThemeMode(mode) },
                            shape = SegmentedButtonDefaults.itemShape(index = index, count = options.size),
                            modifier = Modifier.testTag("custom_tab_theme_mode_${mode.wireValue}")
                        ) {
                            Text(label, maxLines = 1)
                        }
                    }
                }

                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    AppVisualTheme.entries.chunked(2).forEach { rowThemes ->
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            rowThemes.forEach { theme ->
                                val isSelected = appearance.visualTheme == theme
                                val previewBg = if (isDark) theme.darkBackground else theme.lightBackground
                                val previewPri = if (isDark) theme.darkPrimary else theme.lightPrimary
                                val previewSec = if (isDark) theme.darkSecondary else theme.lightSecondary

                                Surface(
                                    shape = RoundedCornerShape(14.dp),
                                    color = if (isSelected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)
                                    else MaterialTheme.colorScheme.surfaceContainerLow,
                                    border = BorderStroke(
                                        width = if (isSelected) 1.5.dp else 1.dp,
                                        color = if (isSelected) MaterialTheme.colorScheme.primary
                                        else MaterialTheme.colorScheme.outlineVariant
                                    ),
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(14.dp))
                                        .clickable { onSelectVisualTheme(theme) }
                                        .testTag("visual_theme_${theme.wireValue}")
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 12.dp, vertical = 12.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(12.dp)
                                                        .clip(CircleShape)
                                                        .background(previewBg)
                                                )
                                                Box(
                                                    modifier = Modifier
                                                        .size(12.dp)
                                                        .clip(CircleShape)
                                                        .background(previewPri)
                                                )
                                                Box(
                                                    modifier = Modifier
                                                        .size(12.dp)
                                                        .clip(CircleShape)
                                                        .background(previewSec)
                                                )
                                            }
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Column {
                                                Text(
                                                    text = theme.labelRu,
                                                    style = MaterialTheme.typography.labelLarge,
                                                    fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Medium,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                                Text(
                                                    text = theme.subtitleRu,
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                            }
                                        }
                                        if (isSelected) {
                                            Icon(
                                                imageVector = Icons.Filled.Check,
                                                contentDescription = "Активна",
                                                tint = MaterialTheme.colorScheme.primary,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // 4. Messenger Layout Editor (Редактирование мессенджера: истории и папки)
        Surface(
            shape = sectionShape,
            color = if (glassActive) androidx.compose.ui.graphics.Color.Transparent else MaterialTheme.colorScheme.surfaceContainer,
            border = if (glassActive) null else BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
            modifier = Modifier
                .then(if (glassActive) Modifier.liquidGlassSurface(shape = sectionShape) else Modifier)
                .testTag("customization_messenger_editor_card")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Filled.Tune,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "4. Редактирование мессенджера",
                            style = MaterialTheme.typography.titleSmall
                        )
                        Text(
                            text = "Скрыть или показать разделы главного экрана",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .clickable { onSetShowStories(!appearance.showStories) }
                        .padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.AutoAwesomeMotion,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text("Истории", style = MaterialTheme.typography.bodyMedium)
                            Text(
                                text = "Лента историй и быстрых контактов",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    Switch(
                        checked = appearance.showStories,
                        onCheckedChange = onSetShowStories,
                        modifier = Modifier.testTag("custom_tab_show_stories_switch")
                    )
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .clickable { onSetShowFolders(!appearance.showFolders) }
                        .padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Folder,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text("Папки", style = MaterialTheme.typography.bodyMedium)
                            Text(
                                text = "Вкладки «Все», «Личные», «Группы», «Люди», «Плеер»",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    Switch(
                        checked = appearance.showFolders,
                        onCheckedChange = onSetShowFolders,
                        modifier = Modifier.testTag("custom_tab_show_folders_switch")
                    )
                }
            }
        }

        OutlinedButton(
            onClick = onResetCustomization,
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("reset_customization_button")
        ) {
            Icon(Icons.Filled.RestartAlt, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text("Сбросить кастомизацию")
        }

        Spacer(modifier = Modifier.height(6.dp))
    }
}
