package com.example.plugins

object BuiltInPlugins {

    const val TEMPLATE_FILE_NAME = "spox_plugin_template.lua"

    val SPOX_PLUGIN_TEMPLATE_LUA: String = """
-- @id my_custom_plugin
-- @name Мой первый плагин
-- @version 1.0
-- @author SpoX Разработчик
-- @description Пример плагина на SpoX Lua с командой /hello и автоподстановкой
-- @commands /hello

-- Обязательная таблица метаданных плагина
plugin = {
    id = "my_custom_plugin",
    name = "Мой первый плагин",
    version = "1.0",
    author = "SpoX Разработчик",
    description = "Пример плагина на SpoX Lua: добавляет команду /hello и подпись времени.",
    commands = { "/hello" }
}

--[[
Доступные хуки:
  1. on_command(ctx) -> вызывается при отправке команды вида /cmd ...
     Поля ctx:
       ctx.command       -- строка команды в нижнем регистре, например "/hello"
       ctx.args          -- аргументы после команды
       ctx.text          -- полный введённый текст
       ctx.chat_id       -- ID текущего чата
       ctx.chat_title    -- название чата
       ctx.is_group      -- true для группового чата
       ctx.sender_name   -- имя отправителя
       ctx.member_count  -- число участников
     Возврат:
       { action = "send", text = "..." }   -> отправить сообщение в чат
       { action = "local", text = "..." }  -> показать только вам (локально)

  2. on_send_message(ctx) -> вызывается перед шифрованием и отправкой обычного текста
     Возврат:
       строка (новый текст)
       или { text = "..." }
       или { cancel = true, reason = "Причина" }

  3. on_render_message(ctx) -> вызывается при отображении текстового сообщения в чате
     Возврат:
       строка (отформатированный текст для экрана)

Доступное API SpoX Lua:
  spox.log(msg), spox.notify(msg), spox.send(text)
  spox.upper(s), spox.lower(s), spox.trim(s), spox.replace(s, old, new)
  spox.split(s, sep), spox.contains(s, sub), spox.starts_with(s, prefix)
  spox.sha256_short(s), spox.app_version(), spox.now_ms(), spox.format_time(ms)
  Стандартные библиотеки: string, math, table, os (time, date), pairs, ipairs
--]]

function on_command(ctx)
    if ctx.command == "/hello" then
        local target = spox.trim(ctx.args or "")
        if target == "" then
            target = ctx.chat_title ~= "" and ctx.chat_title or "чат"
        end
        local now = spox.format_time(spox.now_ms())
        spox.log("Выполнена команда /hello для: " .. target)
        return {
            action = "send",
            text = "👋 Привет, " .. target .. "! (SpoX v" .. spox.app_version() .. " • " .. now .. ")",
            notice = "Команда /hello выполнена"
        }
    end
    return nil
end

function on_send_message(ctx)
    local text = ctx.text or ""
    -- Пример: заменяем :wave: на эмодзи перед отправкой
    text = spox.replace(text, ":wave:", "👋")
    return text
end

function on_render_message(ctx)
    return ctx.text
end
""".trimIndent() + "\n"

    private val QUICK_MACROS_LUA = """
-- @id builtin_quick_macros
-- @name Текстовые макросы и команды
-- @version 1.1
-- @author SpoX Core
-- @description Быстрые команды (/shrug, /roll, /coin, /reverse) и замена :макросов:
-- @commands /shrug, /lenny, /tableflip, /coin, /roll, /reverse

plugin = {
    id = "builtin_quick_macros",
    name = "Текстовые макросы и команды",
    version = "1.1",
    author = "SpoX Core",
    description = "Команды /shrug, /lenny, /tableflip, /coin, /roll N, /reverse и замена :shrug:, :shield:, ->",
    commands = { "/shrug", "/lenny", "/tableflip", "/coin", "/roll", "/reverse" }
}

function on_command(ctx)
    local cmd = ctx.command
    local args = spox.trim(ctx.args or "")

    if cmd == "/shrug" then
        local out = args ~= "" and (args .. " ¯\\_(ツ)_/¯") or "¯\\_(ツ)_/¯"
        return { action = "send", text = out }
    elseif cmd == "/lenny" then
        local out = args ~= "" and (args .. " ( ͡° ͜ʖ ͡°)") or "( ͡° ͜ʖ ͡°)"
        return { action = "send", text = out }
    elseif cmd == "/tableflip" then
        return { action = "send", text = "(╯°□°)╯︵ ┻━┻" }
    elseif cmd == "/coin" then
        local side = math.random(1, 2) == 1 and "Орёл 🪙" or "Решка 🪙"
        return { action = "send", text = "🎲 Подброшена монетка: " .. side }
    elseif cmd == "/roll" then
        local maxVal = tonumber(args) or 100
        if maxVal < 2 then maxVal = 2 end
        if maxVal > 1000000 then maxVal = 1000000 end
        local rolled = math.random(1, math.floor(maxVal))
        return { action = "send", text = "🎲 Случайное число (1–" .. math.floor(maxVal) .. "): " .. rolled }
    elseif cmd == "/reverse" then
        if args == "" then
            return { action = "local", text = "Использование: /reverse <текст>" }
        end
        return { action = "send", text = string.reverse(args) }
    end
    return nil
end

function on_send_message(ctx)
    local t = ctx.text or ""
    t = spox.replace(t, ":shrug:", "¯\\_(ツ)_/¯")
    t = spox.replace(t, ":lenny:", "( ͡° ͜ʖ ͡°)")
    t = spox.replace(t, ":tableflip:", "(╯°□°)╯︵ ┻━┻")
    t = spox.replace(t, ":shield:", "🛡️")
    t = spox.replace(t, ":check:", "✅")
    t = spox.replace(t, "->", "→")
    return t
end
""".trimIndent() + "\n"

    private val SMART_CALC_LUA = """
-- @id builtin_smart_calc
-- @name Калькулятор (/calc)
-- @version 1.0
-- @author SpoX Core
-- @description Вычисляет математические выражения прямо в чате по команде /calc
-- @commands /calc

plugin = {
    id = "builtin_smart_calc",
    name = "Калькулятор (/calc)",
    version = "1.0",
    author = "SpoX Core",
    description = "Решает математические выражения: + - * / ^ () и sqrt() прямо при отправке /calc 2+2*5",
    commands = { "/calc" }
}

local function make_parser(input)
    local src = spox.replace(input, " ", "")
    local pos = 1
    local len = string.len(src)

    local function peek()
        if pos > len then return "" end
        return string.sub(src, pos, pos)
    end

    local parse_expr

    local function parse_number()
        local start = pos
        local has_dot = false
        while pos <= len do
            local ch = string.sub(src, pos, pos)
            if ch >= "0" and ch <= "9" then
                pos = pos + 1
            elseif ch == "." and not has_dot then
                has_dot = true
                pos = pos + 1
            else
                break
            end
        end
        if pos == start then
            error("Ожидалось число на позиции " .. pos)
        end
        return tonumber(string.sub(src, start, pos - 1))
    end

    local function parse_factor()
        local ch = peek()
        if ch == "-" then
            pos = pos + 1
            return -parse_factor()
        elseif ch == "+" then
            pos = pos + 1
            return parse_factor()
        elseif ch == "(" then
            pos = pos + 1
            local v = parse_expr()
            if peek() ~= ")" then error("Ожидалась закрывающая скобка ')'") end
            pos = pos + 1
            return v
        elseif string.sub(src, pos, pos + 3) == "sqrt" then
            pos = pos + 4
            if peek() ~= "(" then error("После sqrt ожидалась '('") end
            pos = pos + 1
            local v = parse_expr()
            if peek() ~= ")" then error("Ожидалась ')' после sqrt") end
            pos = pos + 1
            return math.sqrt(v)
        else
            return parse_number()
        end
    end

    local function parse_power()
        local left = parse_factor()
        if peek() == "^" then
            pos = pos + 1
            return left ^ parse_power()
        end
        return left
    end

    local function parse_term()
        local left = parse_power()
        while true do
            local ch = peek()
            if ch == "*" then
                pos = pos + 1
                left = left * parse_power()
            elseif ch == "/" then
                pos = pos + 1
                local d = parse_power()
                if d == 0 then error("Деление на ноль") end
                left = left / d
            elseif ch == "%" then
                pos = pos + 1
                left = left % parse_power()
            else
                break
            end
        end
        return left
    end

    parse_expr = function()
        local left = parse_term()
        while true do
            local ch = peek()
            if ch == "+" then
                pos = pos + 1
                left = left + parse_term()
            elseif ch == "-" then
                pos = pos + 1
                left = left - parse_term()
            else
                break
            end
        end
        return left
    end

    local result = parse_expr()
    if pos <= len then
        error("Лишний символ: '" .. peek() .. "'")
    end
    return result
end

function on_command(ctx)
    if ctx.command ~= "/calc" then return nil end
    local expr = spox.trim(ctx.args or "")
    if expr == "" then
        return { action = "local", text = "Использование: /calc (2 + 3) * 4" }
    end
    expr = spox.replace(expr, ",", ".")
    local ok, res = pcall(make_parser, expr)
    if not ok then
        return { action = "local", text = "Ошибка калькулятора: " .. tostring(res) }
    end
    spox.log("Вычислено: " .. expr .. " = " .. tostring(res))
    return {
        action = "send",
        text = "🧮 " .. expr .. " = " .. tostring(res)
    }
end
""".trimIndent() + "\n"

    private val TYPOGRAPHY_LUA = """
-- @id builtin_typography
-- @name Умная типографика
-- @version 1.0
-- @author SpoX Core
-- @description Автоматически ставит тире (—), многоточие (…) и кавычки-ёлочки («»)

plugin = {
    id = "builtin_typography",
    name = "Умная типографика",
    version = "1.0",
    author = "SpoX Core",
    description = "Заменяет -- на длинное тире —, ... на … и парные кавычки на «ёлочки» перед отправкой.",
    commands = {}
}

function on_send_message(ctx)
    local t = ctx.text or ""
    if t == "" then return t end

    t = spox.replace(t, "...", "…")
    t = spox.replace(t, " -- ", " — ")
    t = spox.replace(t, "--", "—")

    local out = ""
    local open_quote = true
    local n = string.len(t)
    for i = 1, n do
        local ch = string.sub(t, i, i)
        if ch == "\"" then
            if open_quote then
                out = out .. "«"
            else
                out = out .. "»"
            end
            open_quote = not open_quote
        else
            out = out .. ch
        end
    end
    return out
end
""".trimIndent() + "\n"

    private val MESSAGE_INSPECTOR_LUA = """
-- @id builtin_message_inspector
-- @name Хеш и статистика текста
-- @version 1.0
-- @author SpoX Core
-- @description Команды /hash, /upper, /stats и подсчёт слов в длинных сообщениях
-- @commands /hash, /upper, /stats

plugin = {
    id = "builtin_message_inspector",
    name = "Хеш и статистика текста",
    version = "1.0",
    author = "SpoX Core",
    description = "Команды /hash <текст> (SHA-256), /upper <текст>, /stats <текст> и счётчик слов при отображении.",
    commands = { "/hash", "/upper", "/stats" }
}

local function count_words(text)
    local parts = spox.split(spox.trim(text), " ")
    local count = 0
    for i = 1, #parts do
        if spox.trim(parts[i]) ~= "" then
            count = count + 1
        end
    end
    return count
end

function on_command(ctx)
    local cmd = ctx.command
    local args = spox.trim(ctx.args or "")

    if cmd == "/hash" then
        if args == "" then
            return { action = "local", text = "Использование: /hash <строка>" }
        end
        local digest = spox.sha256_short(args)
        return { action = "send", text = "🔐 SHA-256 [" .. digest .. "]: " .. args }
    elseif cmd == "/upper" then
        if args == "" then
            return { action = "local", text = "Использование: /upper <текст>" }
        end
        return { action = "send", text = spox.upper(args) }
    elseif cmd == "/stats" then
        if args == "" then
            return { action = "local", text = "Использование: /stats <текст>" }
        end
        local words = count_words(args)
        local chars = string.len(args)
        return {
            action = "local",
            text = "📊 Символов: " .. chars .. " • Слов: " .. words
        }
    end
    return nil
end

function on_render_message(ctx)
    local t = ctx.text or ""
    if string.len(t) >= 80 then
        local words = count_words(t)
        return t .. "\n〔" .. words .. " сл. • " .. string.len(t) .. " симв.〕"
    end
    return t
end
""".trimIndent() + "\n"

    fun defaultPlugins(): List<SpoXPlugin> {
        val sources = listOf(
            Triple(QUICK_MACROS_LUA, true, "builtin_quick_macros"),
            Triple(SMART_CALC_LUA, true, "builtin_smart_calc"),
            Triple(TYPOGRAPHY_LUA, false, "builtin_typography"),
            Triple(MESSAGE_INSPECTOR_LUA, false, "builtin_message_inspector")
        )
        return sources.map { (src, defaultEnabled, id) ->
            val meta = SpoxLuaEngine.extractMetadata(src, fallbackId = id).getOrThrow()
            SpoXPlugin(
                id = id,
                name = meta.name,
                version = meta.version,
                author = meta.author,
                description = meta.description,
                commands = meta.commands,
                sourceCode = src,
                enabled = defaultEnabled,
                isBuiltIn = true,
                isModifiedBuiltIn = false
            )
        }
    }
}
