package com.example.ui.auth

import androidx.compose.ui.test.assertIsEnabled
import androidx.compose.ui.test.assertIsNotEnabled
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.test.performTextClearance
import androidx.compose.ui.test.performTextInput
import com.example.data.model.AppThemeMode
import com.example.ui.theme.CipherChatTheme
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ProfileRegistrationScreenTest {

    @get:Rule
    val composeRule = createComposeRule()

    @Test
    fun profileRegistrationScreen_validatesNameAndSubmitsEditedProfile() {
        var submittedName = ""
        var submittedHandle = ""
        var submittedAvatar = "unset"

        composeRule.setContent {
            CipherChatTheme(themeMode = AppThemeMode.DARK) {
                ProfileRegistrationScreen(
                    uid = "new_user_1",
                    userEmail = "alex.novikov@gmail.com",
                    initialDisplayName = "Alex",
                    keyFingerprint = "ABCD 1234 EF56",
                    isBusy = false,
                    errorMessage = null,
                    onClearError = {},
                    onSubmitProfile = { name, handle, avatar ->
                        submittedName = name
                        submittedHandle = handle
                        submittedAvatar = avatar
                    },
                    onSignOut = {}
                )
            }
        }

        // Photo picker trigger and submit button exist and submit is enabled with initial name
        composeRule.onNodeWithTag("registration_pick_photo_button").performScrollTo().assertIsEnabled()
        composeRule.onNodeWithTag("registration_submit_button").performScrollTo().assertIsEnabled()

        // Clearing name disables submit button
        composeRule.onNodeWithTag("registration_name_input").performScrollTo().performTextClearance()
        composeRule.onNodeWithTag("registration_submit_button").performScrollTo().assertIsNotEnabled()

        // Entering custom name and username enables submit and invokes callback
        composeRule.onNodeWithTag("registration_name_input").performScrollTo().performTextInput("Алексей Новиков")
        composeRule.onNodeWithTag("registration_username_input").performScrollTo().performTextClearance()
        composeRule.onNodeWithTag("registration_username_input").performScrollTo().performTextInput("alex_spox")
        composeRule.onNodeWithTag("registration_submit_button").performScrollTo().assertIsEnabled().performClick()
        composeRule.waitForIdle()

        assertEquals("Алексей Новиков", submittedName)
        assertEquals("alex_spox", submittedHandle)
        assertEquals("", submittedAvatar)
    }
}
