package com.example.notifications

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.data.repository.CallRepository
import com.example.media.OngoingCallService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class CallActionReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: return
        val callId = intent.getStringExtra(SpoXNotificationHelper.EXTRA_OPEN_CALL_ID).orEmpty()
        val appContext = context.applicationContext

        when (action) {
            SpoXNotificationHelper.ACTION_DECLINE_CALL -> {
                if (callId.isBlank()) return
                SpoXNotificationHelper.cancelCallNotification(appContext, callId)
                val pendingResult = goAsync()
                CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
                    try {
                        CallRepository(appContext).declineCallById(callId)
                    } finally {
                        pendingResult.finish()
                    }
                }
            }

            SpoXNotificationHelper.ACTION_TOGGLE_MUTE_CALL -> {
                OngoingCallService.toggleMute(appContext)
            }

            SpoXNotificationHelper.ACTION_END_CALL -> {
                if (callId.isNotBlank()) {
                    SpoXNotificationHelper.cancelCallNotification(appContext, callId)
                }
                OngoingCallService.stopAndEndCall(appContext)
            }
        }
    }
}
