package com.example.media

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin

class ImaAdpcmCodecTest {

    @Test
    fun encodeDecode_preservesSpeechWaveformWithFourToOneCompression() {
        val sampleRate = 16_000
        val count = 3_840 // 240 ms
        val input = ShortArray(count) { i ->
            val t = i.toDouble() / sampleRate
            ((sin(2.0 * PI * 440.0 * t) * 12000.0) + (sin(2.0 * PI * 880.0 * t) * 5000.0))
                .toInt()
                .coerceIn(-32768, 32767)
                .toShort()
        }

        val encoded = ImaAdpcmCodec.encode(input)
        // 4 bytes header + 1920 bytes nibble payload = 1924 bytes
        assertEquals(1924, encoded.size)

        val decoded = ImaAdpcmCodec.decode(encoded)
        assertEquals(count, decoded.size)

        var totalSignalSq = 0.0
        var totalErrorSq = 0.0
        for (i in 0 until count) {
            val orig = input[i].toDouble()
            val err = orig - decoded[i].toDouble()
            totalSignalSq += orig * orig
            totalErrorSq += err * err
        }
        val snrDb = 10.0 * kotlin.math.log10(totalSignalSq / totalErrorSq.coerceAtLeast(1.0))
        assertTrue("Expected SNR > 18 dB for speech ADPCM, got $snrDb dB", snrDb > 18.0)
    }

    @Test
    fun encodeDecode_handlesOddCountAndEmptySafely() {
        assertEquals(0, ImaAdpcmCodec.encode(ShortArray(0)).size)
        assertEquals(0, ImaAdpcmCodec.decode(ByteArray(0)).size)
        assertEquals(0, ImaAdpcmCodec.decode(ByteArray(3)).size)

        val oddInput = shortArrayOf(0, 1200, -1800, 4200, -900)
        val encoded = ImaAdpcmCodec.encode(oddInput, oddInput.size)
        val decoded = ImaAdpcmCodec.decode(encoded)
        assertEquals(oddInput.size, decoded.size)
        assertTrue(abs(oddInput.last() - decoded.last()) < 1500)
    }
}
