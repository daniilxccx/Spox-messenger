package com.example.data.model

import androidx.compose.ui.graphics.Color

enum class AppVisualTheme(
    val wireValue: String,
    val labelRu: String,
    val subtitleRu: String,
    val darkPrimary: Color,
    val darkSecondary: Color,
    val darkTertiary: Color,
    val darkBackground: Color,
    val darkSurface: Color,
    val lightPrimary: Color,
    val lightSecondary: Color,
    val lightBackground: Color
) {
    SPOX_CYBER(
        wireValue = "spox_cyber",
        labelRu = "SpoX Кибер",
        subtitleRu = "Графит и бирюза",
        darkPrimary = Color(0xFF2DD4BF),
        darkSecondary = Color(0xFF38BDF8),
        darkTertiary = Color(0xFFA78BFA),
        darkBackground = Color(0xFF090D16),
        darkSurface = Color(0xFF101724),
        lightPrimary = Color(0xFF0D9488),
        lightSecondary = Color(0xFF0284C7),
        lightBackground = Color(0xFFF3F6FA)
    ),
    OCEAN_NIGHT(
        wireValue = "ocean_night",
        labelRu = "Океан",
        subtitleRu = "Глубокий сапфир",
        darkPrimary = Color(0xFF60A5FA),
        darkSecondary = Color(0xFF38BDF8),
        darkTertiary = Color(0xFF818CF8),
        darkBackground = Color(0xFF060B18),
        darkSurface = Color(0xFF0D162B),
        lightPrimary = Color(0xFF2563EB),
        lightSecondary = Color(0xFF0284C7),
        lightBackground = Color(0xFFF0F5FF)
    ),
    AMETHYST(
        wireValue = "amethyst",
        labelRu = "Аметист",
        subtitleRu = "Неон и фиолет",
        darkPrimary = Color(0xFFC084FC),
        darkSecondary = Color(0xFFF472B6),
        darkTertiary = Color(0xFF818CF8),
        darkBackground = Color(0xFF0E0916),
        darkSurface = Color(0xFF171024),
        lightPrimary = Color(0xFF7C3AED),
        lightSecondary = Color(0xFFDB2777),
        lightBackground = Color(0xFFF7F3FF)
    ),
    EMERALD(
        wireValue = "emerald",
        labelRu = "Изумруд",
        subtitleRu = "Лесной неон",
        darkPrimary = Color(0xFF34D399),
        darkSecondary = Color(0xFFA3E635),
        darkTertiary = Color(0xFF2DD4BF),
        darkBackground = Color(0xFF07110D),
        darkSurface = Color(0xFF0E1D17),
        lightPrimary = Color(0xFF059669),
        lightSecondary = Color(0xFF16A34A),
        lightBackground = Color(0xFFF0FAF5)
    ),
    CRIMSON_GOLD(
        wireValue = "crimson_gold",
        labelRu = "Закат",
        subtitleRu = "Янтарь и коралл",
        darkPrimary = Color(0xFFFB923C),
        darkSecondary = Color(0xFFFBBF24),
        darkTertiary = Color(0xFFFB7185),
        darkBackground = Color(0xFF140B09),
        darkSurface = Color(0xFF1F1210),
        lightPrimary = Color(0xFFEA580C),
        lightSecondary = Color(0xFFD97706),
        lightBackground = Color(0xFFFFF6F0)
    ),
    MONO_SLATE(
        wireValue = "mono_slate",
        labelRu = "Монохром",
        subtitleRu = "Строгий минимал",
        darkPrimary = Color(0xFFE2E8F0),
        darkSecondary = Color(0xFF94A3B8),
        darkTertiary = Color(0xFFCBD5E1),
        darkBackground = Color(0xFF0A0A0C),
        darkSurface = Color(0xFF141418),
        lightPrimary = Color(0xFF1E293B),
        lightSecondary = Color(0xFF475569),
        lightBackground = Color(0xFFF8FAFC)
    );

    companion object {
        fun fromWire(value: String?): AppVisualTheme =
            entries.firstOrNull { it.wireValue == value } ?: SPOX_CYBER
    }
}

enum class ChatWallpaperPreset(
    val wireValue: String,
    val labelRu: String,
    val darkColors: List<Color>,
    val lightColors: List<Color>,
    val hasPatternGrid: Boolean = false
) {
    THEME_DEFAULT(
        wireValue = "theme_default",
        labelRu = "По теме",
        darkColors = emptyList(),
        lightColors = emptyList()
    ),
    AURORA_GLOW(
        wireValue = "aurora_glow",
        labelRu = "Сияние",
        darkColors = listOf(Color(0xFF071A2F), Color(0xFF0D2D3E), Color(0xFF131538)),
        lightColors = listOf(Color(0xFFE0F2FE), Color(0xFFD1FAE5), Color(0xFFEDE9FE))
    ),
    CYBER_GRID(
        wireValue = "cyber_grid",
        labelRu = "Сетка",
        darkColors = listOf(Color(0xFF090E18), Color(0xFF101C2E), Color(0xFF0B1320)),
        lightColors = listOf(Color(0xFFF1F5F9), Color(0xFFE2E8F0), Color(0xFFF8FAFC)),
        hasPatternGrid = true
    ),
    TWILIGHT_DUSK(
        wireValue = "twilight_dusk",
        labelRu = "Сумерки",
        darkColors = listOf(Color(0xFF1B102E), Color(0xFF2B1339), Color(0xFF140D22)),
        lightColors = listOf(Color(0xFFFCE7F3), Color(0xFFEDE9FE), Color(0xFFFFEDD5))
    ),
    DEEP_FOREST(
        wireValue = "deep_forest",
        labelRu = "Тайга",
        darkColors = listOf(Color(0xFF071612), Color(0xFF0C271F), Color(0xFF081915)),
        lightColors = listOf(Color(0xFFD1FAE5), Color(0xFFCCFBF1), Color(0xFFECFDF5))
    ),
    WARM_DESERT(
        wireValue = "warm_desert",
        labelRu = "Дюны",
        darkColors = listOf(Color(0xFF1C100C), Color(0xFF2D1912), Color(0xFF170D0A)),
        lightColors = listOf(Color(0xFFFFEDD5), Color(0xFFFEF3C7), Color(0xFFFEE2E2))
    ),
    CUSTOM_IMAGE(
        wireValue = "custom_image",
        labelRu = "Фото",
        darkColors = listOf(Color(0xFF0E1420), Color(0xFF152033)),
        lightColors = listOf(Color(0xFFE2E8F0), Color(0xFFF1F5F9))
    );

    companion object {
        fun fromWire(value: String?): ChatWallpaperPreset =
            entries.firstOrNull { it.wireValue == value } ?: THEME_DEFAULT
    }
}

enum class OutgoingBubbleStyle(
    val wireValue: String,
    val labelRu: String,
    val startColor: Color?,
    val endColor: Color?,
    val contentColor: Color?
) {
    THEME_AUTO(
        wireValue = "theme_auto",
        labelRu = "По теме",
        startColor = null,
        endColor = null,
        contentColor = null
    ),
    OCEAN_BLUE(
        wireValue = "ocean_blue",
        labelRu = "Сапфир",
        startColor = Color(0xFF1D4ED8),
        endColor = Color(0xFF0284C7),
        contentColor = Color(0xFFFFFFFF)
    ),
    NEON_TEAL(
        wireValue = "neon_teal",
        labelRu = "Бирюза",
        startColor = Color(0xFF0F766E),
        endColor = Color(0xFF0D9488),
        contentColor = Color(0xFFFFFFFF)
    ),
    ROYAL_VIOLET(
        wireValue = "royal_violet",
        labelRu = "Аметист",
        startColor = Color(0xFF6D28D9),
        endColor = Color(0xFF9333EA),
        contentColor = Color(0xFFFFFFFF)
    ),
    CRIMSON_ROSE(
        wireValue = "crimson_rose",
        labelRu = "Рубин",
        startColor = Color(0xFFBE123C),
        endColor = Color(0xFFE11D48),
        contentColor = Color(0xFFFFFFFF)
    ),
    AMBER_SUN(
        wireValue = "amber_sun",
        labelRu = "Янтарь",
        startColor = Color(0xFFB45309),
        endColor = Color(0xFFD97706),
        contentColor = Color(0xFFFFFFFF)
    ),
    EMERALD_MINT(
        wireValue = "emerald_mint",
        labelRu = "Изумруд",
        startColor = Color(0xFF047857),
        endColor = Color(0xFF059669),
        contentColor = Color(0xFFFFFFFF)
    ),
    GRAPHITE(
        wireValue = "graphite",
        labelRu = "Графит",
        startColor = Color(0xFF334155),
        endColor = Color(0xFF1E293B),
        contentColor = Color(0xFFF8FAFC)
    );

    companion object {
        fun fromWire(value: String?): OutgoingBubbleStyle =
            entries.firstOrNull { it.wireValue == value } ?: THEME_AUTO
    }
}

data class ChatAppearanceConfig(
    val themeMode: AppThemeMode = AppThemeMode.DARK,
    val visualTheme: AppVisualTheme = AppVisualTheme.SPOX_CYBER,
    val wallpaperPreset: ChatWallpaperPreset = ChatWallpaperPreset.THEME_DEFAULT,
    val customWallpaperPath: String = "",
    val customWallpaperVersion: Long = 0L,
    val outgoingBubbleStyle: OutgoingBubbleStyle = OutgoingBubbleStyle.THEME_AUTO,
    val showStories: Boolean = true,
    val showFolders: Boolean = true
)
