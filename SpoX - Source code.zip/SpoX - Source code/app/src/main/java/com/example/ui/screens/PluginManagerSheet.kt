package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.HelpOutline
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.plugins.BuiltInPlugins
import com.example.plugins.PluginCommandOutcome
import com.example.plugins.PluginStore
import com.example.plugins.PluginTestRunResult
import com.example.plugins.SpoXPlugin
import com.example.plugins.SpoxLuaEngine
import com.example.ui.theme.ApplyLiquidGlassWindowBlur
import com.example.ui.theme.isLiquidGlassActive
import com.example.ui.theme.liquidGlassDialogContainerColor
import com.example.ui.theme.liquidGlassSheetContainerColor
import com.example.ui.theme.liquidGlassSheetScrimColor
import com.example.ui.theme.liquidGlassSurface

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PluginManagerSheet(
    pluginStore: PluginStore,
    onShowMessage: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val plugins by pluginStore.plugins.collectAsStateWithLifecycle()
    val logs by pluginStore.logs.collectAsStateWithLifecycle()
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val scrollState = rememberScrollState()

    var pendingExportContent by remember { mutableStateOf<String?>(null) }

    val exportLuaLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("text/plain")
    ) { uri: Uri? ->
        val content = pendingExportContent
        pendingExportContent = null
        if (uri != null && content != null) {
            pluginStore.writeLuaToUri(uri, content)
                .onSuccess { onShowMessage("Файл .lua успешно сохранён") }
                .onFailure { err ->
                    onShowMessage(err.localizedMessage ?: "Не удалось сохранить .lua файл")
                }
        }
    }

    val importLuaLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            pluginStore.readLuaFromUri(uri)
                .onSuccess { rawSource ->
                    pluginStore.installOrUpdateFromSource(rawSource, enableAfterSave = true)
                        .onSuccess { saved ->
                            onShowMessage("Плагин «${saved.name}» установлен и включён")
                        }
                        .onFailure { err ->
                            onShowMessage("Ошибка плагина: ${err.localizedMessage ?: "неверный Lua"}")
                        }
                }
                .onFailure { err ->
                    onShowMessage(err.localizedMessage ?: "Не удалось прочитать файл")
                }
        }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = liquidGlassSheetContainerColor(),
        scrimColor = liquidGlassSheetScrimColor()
    ) {
        ApplyLiquidGlassWindowBlur()
        PluginManagerContent(
            plugins = plugins,
            recentLogs = logs,
            onTogglePlugin = { id, enabled ->
                pluginStore.setPluginEnabled(id, enabled)
            },
            onSavePluginSource = { source, overrideId ->
                pluginStore.installOrUpdateFromSource(
                    sourceCode = source,
                    overrideId = overrideId,
                    enableAfterSave = true
                ).onSuccess { saved ->
                    onShowMessage("Плагин «${saved.name}» сохранён")
                }.onFailure { err ->
                    onShowMessage("Ошибка Lua: ${err.localizedMessage ?: "проверьте код"}")
                }
            },
            onDeleteCustomPlugin = { id ->
                if (pluginStore.deleteCustomPlugin(id)) {
                    onShowMessage("Пользовательский плагин удалён")
                }
            },
            onResetBuiltInPlugin = { id ->
                if (pluginStore.resetBuiltInPlugin(id)) {
                    onShowMessage("Встроенный плагин восстановлен")
                }
            },
            onDownloadTemplate = {
                pendingExportContent = BuiltInPlugins.SPOX_PLUGIN_TEMPLATE_LUA
                exportLuaLauncher.launch(BuiltInPlugins.TEMPLATE_FILE_NAME)
            },
            onExportPluginLua = { fileName, source ->
                pendingExportContent = source
                exportLuaLauncher.launch(fileName)
            },
            onRequestImportLua = {
                importLuaLauncher.launch(arrayOf("*/*"))
            },
            onShowMessage = onShowMessage,
            onClearLogs = { pluginStore.clearLogs() },
            onDismiss = onDismiss,
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(scrollState)
                .navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 8.dp)
                .testTag("plugin_manager_sheet")
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PluginManagerContent(
    plugins: List<SpoXPlugin>,
    recentLogs: List<String> = emptyList(),
    onTogglePlugin: (String, Boolean) -> Unit,
    onSavePluginSource: (sourceCode: String, overrideId: String?) -> Result<SpoXPlugin>,
    onDeleteCustomPlugin: (String) -> Unit,
    onResetBuiltInPlugin: (String) -> Unit,
    onDownloadTemplate: () -> Unit,
    onExportPluginLua: (suggestedFileName: String, sourceCode: String) -> Unit,
    onRequestImportLua: () -> Unit,
    onShowMessage: (String) -> Unit = {},
    onClearLogs: () -> Unit = {},
    onDismiss: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val glassActive = isLiquidGlassActive()
    val enabledCount = remember(plugins) { plugins.count { it.enabled } }

    var editingTarget by remember { mutableStateOf<Pair<String?, String>?>(null) }
    var showTemplatePreview by remember { mutableStateOf(false) }
    var showApiHelp by remember { mutableStateOf(false) }

    Column(
        modifier = modifier,
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Header
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            Surface(
                shape = CircleShape,
                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.14f),
                modifier = Modifier.size(46.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Filled.Extension,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Плагины SpoX",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Язык: SpoX Lua (.lua) • Вкл: $enabledCount из ${plugins.size}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            OutlinedButton(
                onClick = { showApiHelp = true },
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .heightIn(min = 48.dp)
                    .testTag("plugins_api_help_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.HelpOutline,
                    contentDescription = "Справка по API Lua",
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text("API")
            }
        }

        // Sandbox & Language Info + Template Download Card
        val heroShape = RoundedCornerShape(20.dp)
        Surface(
            shape = heroShape,
            color = if (glassActive) Color.Transparent else MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.28f),
            border = if (glassActive) null else BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.36f)),
            modifier = Modifier
                .fillMaxWidth()
                .then(
                    if (glassActive) {
                        Modifier.liquidGlassSurface(
                            shape = heroShape,
                            tintColor = MaterialTheme.colorScheme.primaryContainer,
                            isHighlighted = true
                        )
                    } else Modifier
                )
                .testTag("plugin_template_card")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.Security,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = "Шаблон плагина на Lua и импорт",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold
                    )
                }
                Text(
                    text = "Плагины пишутся на языке Lua и выполняются в изолированной песочнице. Скачайте готовый шаблон .lua, отредактируйте его или создайте свой плагин прямо в приложении.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Button(
                    onClick = onDownloadTemplate,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("download_plugin_template_button")
                ) {
                    Icon(Icons.Filled.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Скачать шаблон (${BuiltInPlugins.TEMPLATE_FILE_NAME})")
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            editingTarget = null to BuiltInPlugins.SPOX_PLUGIN_TEMPLATE_LUA
                        },
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .weight(1f)
                            .heightIn(min = 48.dp)
                            .testTag("create_from_template_button")
                    ) {
                        Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(17.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Создать в Lua", maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    OutlinedButton(
                        onClick = onRequestImportLua,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .weight(1f)
                            .heightIn(min = 48.dp)
                            .testTag("import_plugin_button")
                    ) {
                        Icon(Icons.Filled.FolderOpen, contentDescription = null, modifier = Modifier.size(17.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Загрузить .lua", maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }

                TextButton(
                    onClick = { showTemplatePreview = true },
                    modifier = Modifier
                        .align(Alignment.End)
                        .heightIn(min = 48.dp)
                        .testTag("preview_template_button")
                ) {
                    Icon(Icons.Filled.Visibility, contentDescription = null, modifier = Modifier.size(17.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Просмотреть код шаблона")
                }
            }
        }

        Text(
            text = "Установленные плагины (${plugins.size})",
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold
        )

        plugins.forEach { plugin ->
            PluginItemCard(
                plugin = plugin,
                onToggle = { enabled -> onTogglePlugin(plugin.id, enabled) },
                onEditAndTest = { editingTarget = plugin.id to plugin.sourceCode },
                onExport = {
                    val safeName = "${plugin.id}.lua"
                    onExportPluginLua(safeName, plugin.sourceCode)
                },
                onDelete = { onDeleteCustomPlugin(plugin.id) },
                onResetBuiltIn = { onResetBuiltInPlugin(plugin.id) }
            )
        }

        if (recentLogs.isNotEmpty()) {
            val logShape = RoundedCornerShape(16.dp)
            Surface(
                shape = logShape,
                color = if (glassActive) Color.Transparent else MaterialTheme.colorScheme.surfaceContainerLow,
                border = if (glassActive) null else BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                modifier = Modifier
                    .fillMaxWidth()
                    .then(if (glassActive) Modifier.liquidGlassSurface(shape = logShape) else Modifier)
                    .testTag("plugin_logs_card")
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Журнал плагинов",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.SemiBold
                        )
                        TextButton(
                            onClick = onClearLogs,
                            modifier = Modifier.heightIn(min = 48.dp)
                        ) {
                            Text("Очистить")
                        }
                    }
                    recentLogs.take(6).forEach { entry ->
                        Text(
                            text = entry,
                            style = MaterialTheme.typography.bodySmall,
                            fontFamily = FontFamily.Monospace,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        if (onDismiss != null) {
            Button(
                onClick = onDismiss,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("plugins_done_button")
            ) {
                Text("Готово")
            }
        }

        Spacer(modifier = Modifier.height(6.dp))
    }

    editingTarget?.let { (overrideId, initialSource) ->
        PluginEditorDialog(
            initialSource = initialSource,
            isNewCustom = overrideId == null,
            onSave = { updatedSource ->
                val res = onSavePluginSource(updatedSource, overrideId)
                if (res.isSuccess) {
                    editingTarget = null
                }
                res
            },
            onExport = { source ->
                val meta = SpoxLuaEngine.extractMetadata(source, fallbackId = overrideId).getOrNull()
                val fileName = "${meta?.id ?: "custom_plugin"}.lua"
                onExportPluginLua(fileName, source)
            },
            onDismiss = { editingTarget = null }
        )
    }

    if (showTemplatePreview) {
        PluginTemplatePreviewDialog(
            templateCode = BuiltInPlugins.SPOX_PLUGIN_TEMPLATE_LUA,
            onDownload = {
                showTemplatePreview = false
                onDownloadTemplate()
            },
            onUseInEditor = {
                showTemplatePreview = false
                editingTarget = null to BuiltInPlugins.SPOX_PLUGIN_TEMPLATE_LUA
            },
            onCopied = { onShowMessage("Шаблон скопирован в буфер обмена") },
            onDismiss = { showTemplatePreview = false }
        )
    }

    if (showApiHelp) {
        PluginApiHelpDialog(
            onDownloadTemplate = {
                showApiHelp = false
                onDownloadTemplate()
            },
            onDismiss = { showApiHelp = false }
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun PluginItemCard(
    plugin: SpoXPlugin,
    onToggle: (Boolean) -> Unit,
    onEditAndTest: () -> Unit,
    onExport: () -> Unit,
    onDelete: () -> Unit,
    onResetBuiltIn: () -> Unit
) {
    val glassActive = isLiquidGlassActive()
    val cardShape = RoundedCornerShape(18.dp)

    Surface(
        shape = cardShape,
        color = if (glassActive) Color.Transparent else MaterialTheme.colorScheme.surfaceContainer,
        border = if (glassActive) null else BorderStroke(
            width = 1.dp,
            color = if (plugin.enabled) MaterialTheme.colorScheme.primary.copy(alpha = 0.42f)
            else MaterialTheme.colorScheme.outlineVariant
        ),
        modifier = Modifier
            .fillMaxWidth()
            .then(
                if (glassActive) {
                    Modifier.liquidGlassSurface(
                        shape = cardShape,
                        isHighlighted = plugin.enabled
                    )
                } else Modifier
            )
            .testTag("plugin_card_${plugin.id}")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Surface(
                    shape = CircleShape,
                    color = if (plugin.enabled) MaterialTheme.colorScheme.primary.copy(alpha = 0.16f)
                    else MaterialTheme.colorScheme.surfaceContainerHigh,
                    modifier = Modifier.size(40.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = if (plugin.isBuiltIn) Icons.Filled.Extension else Icons.Filled.Code,
                            contentDescription = null,
                            tint = if (plugin.enabled) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = plugin.name,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f, fill = false)
                        )
                        Surface(
                            shape = RoundedCornerShape(50),
                            color = MaterialTheme.colorScheme.secondaryContainer
                        ) {
                            Text(
                                text = "v${plugin.version}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSecondaryContainer,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                    Text(
                        text = buildString {
                            append(if (plugin.isBuiltIn) "Встроенный" else "Пользовательский")
                            append(" • ")
                            append(plugin.author)
                        },
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Switch(
                    checked = plugin.enabled,
                    onCheckedChange = onToggle,
                    modifier = Modifier.testTag("plugin_switch_${plugin.id}")
                )
            }

            if (plugin.description.isNotBlank()) {
                Text(
                    text = plugin.description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            if (plugin.commands.isNotEmpty()) {
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    plugin.commands.forEach { cmd ->
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)
                        ) {
                            Text(
                                text = cmd,
                                style = MaterialTheme.typography.labelSmall,
                                fontFamily = FontFamily.Monospace,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }
                }
            }

            if (!plugin.lastError.isNullOrBlank()) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.7f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Ошибка: ${plugin.lastError}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onErrorContainer,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.45f))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(
                    onClick = onEditAndTest,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .heightIn(min = 48.dp)
                        .testTag("plugin_edit_${plugin.id}")
                ) {
                    Icon(Icons.Filled.Code, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Код и тест")
                }

                OutlinedButton(
                    onClick = onExport,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .heightIn(min = 48.dp)
                        .testTag("plugin_export_${plugin.id}")
                ) {
                    Icon(Icons.Filled.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Экспорт .lua")
                }

                if (!plugin.isBuiltIn) {
                    TextButton(
                        onClick = onDelete,
                        modifier = Modifier
                            .heightIn(min = 48.dp)
                            .testTag("plugin_delete_${plugin.id}")
                    ) {
                        Icon(
                            Icons.Filled.DeleteOutline,
                            contentDescription = "Удалить плагин",
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(17.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Удалить", color = MaterialTheme.colorScheme.error)
                    }
                } else if (plugin.isModifiedBuiltIn) {
                    TextButton(
                        onClick = onResetBuiltIn,
                        modifier = Modifier
                            .heightIn(min = 48.dp)
                            .testTag("plugin_reset_${plugin.id}")
                    ) {
                        Icon(Icons.Filled.RestartAlt, contentDescription = "Сбросить код плагина", modifier = Modifier.size(17.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Сброс")
                    }
                }
            }
        }
    }
}

@Composable
private fun PluginEditorDialog(
    initialSource: String,
    isNewCustom: Boolean,
    onSave: (String) -> Result<SpoXPlugin>,
    onExport: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val glassActive = isLiquidGlassActive()
    val dialogShape = RoundedCornerShape(24.dp)
    var codeDraft by remember(initialSource) { mutableStateOf(initialSource) }
    val defaultSample = remember(initialSource) {
        val meta = SpoxLuaEngine.extractMetadata(initialSource).getOrNull()
        val firstCmd = meta?.commands?.firstOrNull()
        when (firstCmd) {
            "/calc" -> "/calc (12 + 8) * 3"
            "/roll" -> "/roll 50"
            "/hello" -> "/hello SpoX"
            "/hash" -> "/hash secret_message"
            else -> firstCmd?.let { "$it тест" } ?: "Привет :wave: -- проверка!"
        }
    }
    var sandboxInput by remember(defaultSample) { mutableStateOf(defaultSample) }
    var testResult by remember { mutableStateOf<PluginTestRunResult?>(null) }
    var saveError by remember { mutableStateOf<String?>(null) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            shape = dialogShape,
            color = if (glassActive) Color.Transparent else liquidGlassDialogContainerColor(),
            border = if (glassActive) null else BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 20.dp)
                .widthIn(max = 620.dp)
                .imePadding()
                .then(
                    if (glassActive) {
                        Modifier.liquidGlassSurface(
                            shape = dialogShape,
                            tintColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                            tintAlpha = 0.85f
                        )
                    } else Modifier
                )
                .testTag("plugin_editor_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = if (isNewCustom) "Новый плагин (SpoX Lua)" else "Редактор и песочница Lua",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )

                OutlinedTextField(
                    value = codeDraft,
                    onValueChange = {
                        codeDraft = it
                        saveError = null
                    },
                    label = { Text("Код плагина (.lua)") },
                    textStyle = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
                    minLines = 9,
                    maxLines = 15,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("plugin_code_editor_input")
                )

                if (!saveError.isNullOrBlank()) {
                    Text(
                        text = saveError!!,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error
                    )
                }

                // Sandbox test bar
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surfaceContainerLow,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "Проверка в песочнице",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.SemiBold
                        )
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            OutlinedTextField(
                                value = sandboxInput,
                                onValueChange = { sandboxInput = it },
                                label = { Text("Тестовая команда или текст") },
                                singleLine = true,
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("plugin_sandbox_input")
                            )
                            Button(
                                onClick = {
                                    testResult = SpoxLuaEngine.runSandboxTest(codeDraft, sandboxInput)
                                },
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .heightIn(min = 48.dp)
                                    .testTag("plugin_run_sandbox_button")
                            ) {
                                Icon(Icons.Filled.PlayArrow, contentDescription = "Запустить тест", modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Тест")
                            }
                        }

                        testResult?.let { res ->
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = if (res.success) {
                                    MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)
                                } else {
                                    MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.6f)
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("plugin_sandbox_result")
                            ) {
                                Column(
                                    modifier = Modifier.padding(10.dp),
                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    if (!res.success) {
                                        Text(
                                            text = res.errorMessage ?: "Ошибка",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onErrorContainer
                                        )
                                    } else {
                                        Text(
                                            text = "Метаданные: ${res.metadata?.name} v${res.metadata?.version}",
                                            style = MaterialTheme.typography.labelMedium,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                        when (val cmdRes = res.commandOutcome) {
                                            is PluginCommandOutcome.HandledSend -> Text(
                                                text = "on_command → отправка: ${cmdRes.text}",
                                                style = MaterialTheme.typography.bodySmall
                                            )
                                            is PluginCommandOutcome.HandledLocal -> Text(
                                                text = "on_command → локально: ${cmdRes.message}",
                                                style = MaterialTheme.typography.bodySmall
                                            )
                                            PluginCommandOutcome.NotHandled -> Unit
                                        }
                                        res.transformedSendText?.let { sendOut ->
                                            Text(
                                                text = "on_send_message: $sendOut",
                                                style = MaterialTheme.typography.bodySmall
                                            )
                                        }
                                        res.renderedDisplayText?.let { renderOut ->
                                            if (renderOut != sandboxInput) {
                                                Text(
                                                    text = "on_render_message: $renderOut",
                                                    style = MaterialTheme.typography.bodySmall
                                                )
                                            }
                                        }
                                        if (res.logs.isNotEmpty()) {
                                            Text(
                                                text = "Логи: ${res.logs.joinToString(" | ")}",
                                                style = MaterialTheme.typography.labelSmall,
                                                fontFamily = FontFamily.Monospace
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(
                        onClick = onDismiss,
                        modifier = Modifier.heightIn(min = 48.dp)
                    ) {
                        Text("Отмена")
                    }
                    OutlinedButton(
                        onClick = { onExport(codeDraft) },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .heightIn(min = 48.dp)
                            .testTag("plugin_editor_export_button")
                    ) {
                        Icon(Icons.Filled.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(".lua")
                    }
                    Spacer(modifier = Modifier.weight(1f))
                    Button(
                        onClick = {
                            onSave(codeDraft).onFailure { err ->
                                saveError = err.localizedMessage ?: "Ошибка синтаксиса Lua"
                            }
                        },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .heightIn(min = 48.dp)
                            .testTag("plugin_save_code_button")
                    ) {
                        Icon(Icons.Filled.Save, contentDescription = null, modifier = Modifier.size(17.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Сохранить")
                    }
                }
            }
        }
    }
}

@Composable
private fun PluginTemplatePreviewDialog(
    templateCode: String,
    onDownload: () -> Unit,
    onUseInEditor: () -> Unit,
    onCopied: () -> Unit,
    onDismiss: () -> Unit
) {
    val clipboard = LocalClipboardManager.current
    val glassActive = isLiquidGlassActive()
    val dialogShape = RoundedCornerShape(24.dp)

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            shape = dialogShape,
            color = if (glassActive) Color.Transparent else liquidGlassDialogContainerColor(),
            border = if (glassActive) null else BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 24.dp)
                .widthIn(max = 580.dp)
                .then(
                    if (glassActive) {
                        Modifier.liquidGlassSurface(
                            shape = dialogShape,
                            tintColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                            tintAlpha = 0.85f
                        )
                    } else Modifier
                )
                .testTag("plugin_template_preview_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "Шаблон ${BuiltInPlugins.TEMPLATE_FILE_NAME}",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surfaceContainerLow,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 320.dp)
                ) {
                    Text(
                        text = templateCode,
                        style = MaterialTheme.typography.bodySmall,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier
                            .verticalScroll(rememberScrollState())
                            .padding(12.dp)
                    )
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            clipboard.setText(AnnotatedString(templateCode))
                            onCopied()
                        },
                        modifier = Modifier.heightIn(min = 48.dp)
                    ) {
                        Icon(Icons.Filled.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Копировать")
                    }
                    OutlinedButton(
                        onClick = onUseInEditor,
                        modifier = Modifier.heightIn(min = 48.dp)
                    ) {
                        Icon(Icons.Filled.Code, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("В редактор")
                    }
                    Button(
                        onClick = onDownload,
                        modifier = Modifier.heightIn(min = 48.dp)
                    ) {
                        Icon(Icons.Filled.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Скачать .lua")
                    }
                }
                TextButton(
                    onClick = onDismiss,
                    modifier = Modifier
                        .align(Alignment.End)
                        .heightIn(min = 48.dp)
                ) {
                    Text("Закрыть")
                }
            }
        }
    }
}

@Composable
private fun PluginApiHelpDialog(
    onDownloadTemplate: () -> Unit,
    onDismiss: () -> Unit
) {
    val glassActive = isLiquidGlassActive()
    val dialogShape = RoundedCornerShape(24.dp)

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            shape = dialogShape,
            color = if (glassActive) Color.Transparent else liquidGlassDialogContainerColor(),
            border = if (glassActive) null else BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 24.dp)
                .widthIn(max = 560.dp)
                .then(
                    if (glassActive) {
                        Modifier.liquidGlassSurface(
                            shape = dialogShape,
                            tintColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                            tintAlpha = 0.85f
                        )
                    } else Modifier
                )
                .testTag("plugin_api_help_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "Документация SpoX Lua",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "1. Метаданные\nУкажите в начале файла таблицу plugin = { id, name, version, author, description, commands } или комментарии -- @name, -- @commands.\n\n" +
                        "2. Хуки мессенджера\n" +
                        "• on_command(ctx) — обработка /команд (ctx.command, ctx.args, ctx.chat_title, ctx.is_group). Возврат: { action = \"send\" | \"local\", text = \"...\" }.\n" +
                        "• on_send_message(ctx) — изменение текста перед шифрованием E2EE.\n" +
                        "• on_render_message(ctx) — форматирование текста при показе в пузыре чата.\n\n" +
                        "3. Встроенный модуль spox\n" +
                        "spox.log(msg), spox.notify(msg), spox.send(text), spox.upper/lower/trim/replace/split/contains/starts_with, spox.sha256_short(s), spox.app_version(), spox.now_ms(), spox.format_time(ms).\n\n" +
                        "4. Стандартный Lua\n" +
                        "Поддерживаются string, math, table, os.time/os.date, pairs/ipairs, pcall и замыкания.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(
                        onClick = onDownloadTemplate,
                        modifier = Modifier.heightIn(min = 48.dp)
                    ) {
                        Icon(Icons.Filled.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Скачать шаблон")
                    }
                    Button(
                        onClick = onDismiss,
                        modifier = Modifier.heightIn(min = 48.dp)
                    ) {
                        Text("Понятно")
                    }
                }
            }
        }
    }
}
