package com.example.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import com.example.data.model.AppThemeMode
import com.example.data.model.ChatAppearanceConfig
import com.example.data.model.ChatWallpaperPreset
import com.example.data.model.OutgoingBubbleStyle

import androidx.compose.ui.graphics.lerp
import com.example.ui.theme.LocalChatAppearance

data class ResolvedBubblePalette(
    val startColor: Color,
    val endColor: Color,
    val contentColor: Color,
    val borderColor: Color
)

@Composable
fun resolveOutgoingBubblePalette(style: OutgoingBubbleStyle): ResolvedBubblePalette {
    val appearance = LocalChatAppearance.current
    val isLiquidGlass = appearance.liquidGlassEnabled && !appearance.resourceSavingMode
    val isDark = when (appearance.themeMode) {
        AppThemeMode.DARK -> true
        AppThemeMode.LIGHT -> false
        AppThemeMode.SYSTEM -> isSystemInDarkTheme()
    }
    val primaryContainer = MaterialTheme.colorScheme.primaryContainer
    val secondaryContainer = MaterialTheme.colorScheme.secondaryContainer
    val onPrimaryContainer = MaterialTheme.colorScheme.onPrimaryContainer
    val primary = MaterialTheme.colorScheme.primary
    return remember(style, isLiquidGlass, isDark, primaryContainer, secondaryContainer, onPrimaryContainer, primary) {
        val rawStart = style.startColor ?: primaryContainer
        val rawEnd = style.endColor ?: secondaryContainer
        val start = if (isLiquidGlass) rawStart.copy(alpha = minOf(rawStart.alpha, 0.56f)) else rawStart
        val end = if (isLiquidGlass) rawEnd.copy(alpha = minOf(rawEnd.alpha, 0.44f)) else rawEnd
        val text = style.contentColor ?: onPrimaryContainer
        val border = when {
            isLiquidGlass && style == OutgoingBubbleStyle.THEME_AUTO ->
                lerp(Color.White, primary, if (isDark) 0.22f else 0.32f).copy(alpha = if (isDark) 0.48f else 0.78f)
            isLiquidGlass ->
                lerp(Color.White, rawEnd, 0.24f).copy(alpha = 0.62f)
            style == OutgoingBubbleStyle.THEME_AUTO -> primary.copy(alpha = 0.35f)
            else -> rawEnd.copy(alpha = 0.55f)
        }
        ResolvedBubblePalette(
            startColor = start,
            endColor = end,
            contentColor = text,
            borderColor = border
        )
    }
}

@Composable
fun ChatWallpaperBackground(
    appearance: ChatAppearanceConfig,
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit = {}
) {
    val isDark = when (appearance.themeMode) {
        AppThemeMode.DARK -> true
        AppThemeMode.LIGHT -> false
        AppThemeMode.SYSTEM -> isSystemInDarkTheme()
    }

    val preset = appearance.wallpaperPreset
    val isCustomPreset = preset == ChatWallpaperPreset.CUSTOM_IMAGE && appearance.customWallpaperPath.isNotBlank()
    val customBitmap by produceState<ImageBitmap?>(
        initialValue = if (isCustomPreset) {
            BitmapMemoryCache.getCachedWallpaper(appearance.customWallpaperPath, appearance.customWallpaperVersion)
        } else {
            null
        },
        key1 = preset,
        key2 = appearance.customWallpaperPath,
        key3 = appearance.customWallpaperVersion
    ) {
        value = if (isCustomPreset) {
            BitmapMemoryCache.decodeWallpaper(appearance.customWallpaperPath, appearance.customWallpaperVersion)
        } else {
            null
        }
    }

    val isResourceSaving = appearance.resourceSavingMode
    val isGlass = appearance.liquidGlassEnabled && !isResourceSaving
    val colors = if (isDark) preset.darkColors else preset.lightColors
    val gridColor = MaterialTheme.colorScheme.primary.copy(alpha = if (isDark) 0.10f else 0.08f)
    val accentGlow = MaterialTheme.colorScheme.secondary.copy(
        alpha = if (isDark) 0.14f else 0.10f
    )
    val verticalGradientBrush = remember(colors) {
        if (colors.size >= 2) Brush.verticalGradient(colors) else null
    }

    Box(modifier = modifier.background(MaterialTheme.colorScheme.background)) {
        when {
            customBitmap != null -> {
                Image(
                    bitmap = customBitmap!!,
                    contentDescription = "Фоновые обои чата",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            if (isDark) Color.Black.copy(alpha = 0.42f)
                            else Color.White.copy(alpha = 0.32f)
                        )
                )
            }

            verticalGradientBrush != null -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(verticalGradientBrush)
                )
            }
        }

        val primaryGlow = MaterialTheme.colorScheme.primary.copy(
            alpha = if (isDark) 0.11f else 0.08f
        )
        val tertiaryGlow = MaterialTheme.colorScheme.tertiary.copy(
            alpha = if (isGlass) (if (isDark) 0.08f else 0.06f) else 0f
        )
        if (customBitmap == null && !isResourceSaving) {
            if (isGlass && verticalGradientBrush == null) {
                com.example.ui.theme.LiquidGlassBackdrop(modifier = Modifier.fillMaxSize())
            }
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .drawWithCache {
                        val gridPath = if (preset.hasPatternGrid) {
                            Path().apply {
                                val step = 36.dp.toPx()
                                var x = 0f
                                while (x <= size.width) {
                                    moveTo(x, 0f)
                                    lineTo(x, size.height)
                                    x += step
                                }
                                var y = 0f
                                while (y <= size.height) {
                                    moveTo(0f, y)
                                    lineTo(size.width, y)
                                    y += step
                                }
                            }
                        } else {
                            null
                        }
                        val gridStroke = Stroke(width = 1.dp.toPx())
                        val glowCenter = Offset(size.width * 0.82f, size.height * 0.16f)
                        val glowRadius = (size.minDimension * 0.78f).coerceAtLeast(1f)
                        val midCenter = Offset(size.width * 0.52f, size.height * 0.48f)
                        val midRadius = (size.minDimension * 0.58f).coerceAtLeast(1f)
                        val bottomGlowCenter = Offset(size.width * 0.15f, size.height * 0.84f)
                        val bottomGlowRadius = (size.minDimension * 0.65f).coerceAtLeast(1f)
                        val glowBrush = Brush.radialGradient(
                            colors = listOf(accentGlow, Color.Transparent),
                            center = glowCenter,
                            radius = glowRadius
                        )
                        val midGlowBrush = Brush.radialGradient(
                            colors = listOf(tertiaryGlow, Color.Transparent),
                            center = midCenter,
                            radius = midRadius
                        )
                        val primaryGlowBrush = Brush.radialGradient(
                            colors = listOf(primaryGlow, Color.Transparent),
                            center = bottomGlowCenter,
                            radius = bottomGlowRadius
                        )

                        onDrawBehind {
                            if (gridPath != null) {
                                drawPath(path = gridPath, color = gridColor, style = gridStroke)
                            }
                            drawCircle(
                                brush = primaryGlowBrush,
                                radius = bottomGlowRadius,
                                center = bottomGlowCenter
                            )
                            if (isGlass) {
                                drawCircle(
                                    brush = midGlowBrush,
                                    radius = midRadius,
                                    center = midCenter
                                )
                            }
                            if (isGlass || preset == ChatWallpaperPreset.AURORA_GLOW || !preset.hasPatternGrid) {
                                drawCircle(
                                    brush = glowBrush,
                                    radius = glowRadius,
                                    center = glowCenter
                                )
                            }
                        }
                    }
            )
        }

        content()
    }
}
