package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.CallMade
import androidx.compose.material.icons.automirrored.filled.CallReceived
import androidx.compose.material.icons.filled.AddIcCall
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.PhoneInTalk
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.data.model.CallSession
import com.example.data.model.Conversation
import com.example.data.model.PublicUserProfile
import com.example.data.model.UserPresenceStatus
import com.example.ui.components.IncomingOrActiveCallBanner
import com.example.ui.components.UserAvatar
import com.example.ui.components.smoothAppear
import com.example.ui.theme.ApplyLiquidGlassWindowBlur
import com.example.ui.theme.LocalPresenceColors
import com.example.ui.theme.isLiquidGlassActive
import com.example.ui.theme.liquidGlassSheetContainerColor
import com.example.ui.theme.liquidGlassSheetScrimColor
import com.example.ui.theme.liquidGlassSurface
import com.example.util.TimeFormatters
import com.google.firebase.Timestamp

private enum class CallsFilter(val label: String) {
    ALL("Все"),
    INCOMING("Входящие"),
    OUTGOING("Исходящие"),
    VIDEO("Видео")
}

@Composable
fun CallsTabContent(
    currentUserId: String,
    activeCalls: List<CallSession>,
    callHistory: List<CallSession>,
    conversations: List<Conversation>,
    directoryUsers: List<PublicUserProfile>,
    chatPeersMap: Map<String, PublicUserProfile>,
    presenceNowMs: Long,
    isBusy: Boolean,
    topPadding: Dp,
    bottomPadding: Dp,
    horizontalPadding: Dp,
    smoothAppearance: Boolean,
    onJoinCall: (CallSession) -> Unit,
    onDeclineCall: (CallSession) -> Unit,
    onStartCallWithConversation: (Conversation, String) -> Unit,
    onStartCallWithPeer: (PublicUserProfile, String) -> Unit,
    onOpenStartCallSheet: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isGlass = isLiquidGlassActive()
    var activeFilter by rememberSaveable { mutableStateOf(CallsFilter.ALL) }

    val conversationsById = remember(conversations) {
        conversations.associateBy { it.id }
    }

    val filteredHistory = remember(callHistory, activeFilter, currentUserId) {
        callHistory.filter { call ->
            when (activeFilter) {
                CallsFilter.ALL -> true
                CallsFilter.INCOMING -> call.callerId != currentUserId
                CallsFilter.OUTGOING -> call.callerId == currentUserId
                CallsFilter.VIDEO -> call.callType == "video"
            }
        }
    }

    val presenceBucket = presenceNowMs / 30_000L
    val quickContacts = remember(directoryUsers, currentUserId, presenceBucket) {
        directoryUsers
            .filter { it.userId != currentUserId && it.userId.isNotBlank() }
            .sortedWith(
                compareBy<PublicUserProfile> {
                    when (it.presenceStatus(presenceNowMs)) {
                        UserPresenceStatus.ONLINE -> 0
                        UserPresenceStatus.RECENTLY -> 1
                        UserPresenceStatus.OFFLINE -> 2
                    }
                }.thenBy { it.displayName.lowercase() }
            )
            .take(8)
    }

    LazyColumn(
        contentPadding = PaddingValues(
            start = horizontalPadding,
            end = horizontalPadding,
            top = topPadding,
            bottom = bottomPadding
        ),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = modifier
            .fillMaxSize()
            .testTag("calls_tab_content")
    ) {
        item(key = "calls_header_filters") {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .smoothAppear(
                        enabled = smoothAppearance,
                        key = "calls_hdr",
                        initialTranslationYDp = -8f,
                        durationMillis = 220
                    ),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Звонки",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (callHistory.isEmpty()) {
                                "Защищённые аудио и видеозвонки E2EE"
                            } else {
                                "История вызовов (${callHistory.size})"
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    if (quickContacts.isNotEmpty() || conversations.any { !it.isSavedMessages(currentUserId) }) {
                        Surface(
                            onClick = onOpenStartCallSheet,
                            shape = RoundedCornerShape(14.dp),
                            color = if (isGlass) Color.Transparent else MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f),
                            border = if (isGlass) null else BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.35f)),
                            modifier = Modifier
                                .defaultMinSize(minHeight = 48.dp)
                                .then(
                                    if (isGlass) {
                                        Modifier.liquidGlassSurface(
                                            shape = RoundedCornerShape(14.dp),
                                            tintColor = MaterialTheme.colorScheme.primaryContainer,
                                            isHighlighted = true
                                        )
                                    } else Modifier
                                )
                                .testTag("calls_header_new_call_button")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.AddIcCall,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(18.dp)
                                )
                                Text(
                                    text = "Позвонить",
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                            }
                        }
                    }
                }

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(CallsFilter.entries, key = { it.name }) { filter ->
                        FilterChip(
                            selected = activeFilter == filter,
                            onClick = { activeFilter = filter },
                            label = { Text(filter.label) },
                            modifier = Modifier
                                .defaultMinSize(minHeight = 40.dp)
                                .testTag("calls_filter_${filter.name.lowercase()}")
                        )
                    }
                }
            }
        }

        if (activeCalls.isNotEmpty()) {
            item(key = "active_calls_section_title") {
                Text(
                    text = "Активные вызовы (${activeCalls.size})",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(top = 2.dp)
                )
            }
            items(activeCalls, key = { "live_${it.id}" }) { liveCall ->
                IncomingOrActiveCallBanner(
                    call = liveCall,
                    currentUserId = currentUserId,
                    onAcceptOrJoin = { onJoinCall(liveCall) },
                    onDecline = { onDeclineCall(liveCall) }
                )
            }
        }

        if (filteredHistory.isEmpty() && activeCalls.isEmpty()) {
            item(key = "calls_empty_state") {
                val emptyShape = RoundedCornerShape(22.dp)
                Surface(
                    shape = emptyShape,
                    color = if (isGlass) Color.Transparent else MaterialTheme.colorScheme.surfaceContainerLow,
                    border = if (isGlass) null else BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp)
                        .then(if (isGlass) Modifier.liquidGlassSurface(shape = emptyShape) else Modifier)
                        .testTag("calls_empty_state")
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.primaryContainer,
                            modifier = Modifier.size(62.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Filled.PhoneInTalk,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                    modifier = Modifier.size(30.dp)
                                )
                            }
                        }
                        Text(
                            text = if (activeFilter == CallsFilter.ALL) {
                                "Пока нет истории звонков"
                            } else {
                                "Нет звонков по фильтру «${activeFilter.label}»"
                            },
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "Выберите контакт ниже или нажмите «Начать звонок» для голосового или видеозвонка.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Button(
                            onClick = onOpenStartCallSheet,
                            enabled = !isBusy,
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .defaultMinSize(minHeight = 48.dp)
                                .testTag("calls_empty_start_button")
                        ) {
                            Icon(Icons.Filled.AddIcCall, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Начать звонок")
                        }
                    }
                }
            }
        } else if (filteredHistory.isNotEmpty()) {
            item(key = "history_section_title") {
                Text(
                    text = "Недавние",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
            itemsIndexed(filteredHistory, key = { _, call -> "history_${call.id}" }) { index, call ->
                val linkedConv = conversationsById[call.conversationId]
                val peerUid = remember(call, currentUserId) {
                    if (call.isGroupCall) null
                    else if (call.callerId != currentUserId && call.callerId.isNotBlank()) call.callerId
                    else call.memberUids.firstOrNull { it != currentUserId }
                }
                val peerProfile = peerUid?.let { chatPeersMap[it] }
                val resolvedTitle = remember(call, peerProfile, linkedConv, currentUserId) {
                    when {
                        call.isGroupCall -> linkedConv?.title?.ifBlank { null }
                            ?: call.conversationTitle.ifBlank { "Групповой звонок" }
                        peerProfile != null && peerProfile.displayName.isNotBlank() -> peerProfile.displayName
                        call.callerId != currentUserId && call.callerName.isNotBlank() -> call.callerName
                        call.conversationTitle.isNotBlank() -> call.conversationTitle
                        else -> "Собеседник"
                    }
                }
                val isLive = call.status == "ringing" || call.status == "active"

                CallHistoryCard(
                    call = call,
                    title = resolvedTitle,
                    peerProfile = peerProfile,
                    currentUserId = currentUserId,
                    presenceNowMs = presenceNowMs,
                    enabled = !isBusy,
                    canCallback = isLive || linkedConv != null || peerProfile != null,
                    onCardClick = {
                        if (isLive) {
                            onJoinCall(call)
                        } else if (linkedConv != null) {
                            onStartCallWithConversation(linkedConv, call.callType)
                        } else if (peerProfile != null) {
                            onStartCallWithPeer(peerProfile, call.callType)
                        } else {
                            onOpenStartCallSheet()
                        }
                    },
                    onAudioCallClick = {
                        if (isLive && call.callType == "audio") {
                            onJoinCall(call)
                        } else if (linkedConv != null) {
                            onStartCallWithConversation(linkedConv, "audio")
                        } else if (peerProfile != null) {
                            onStartCallWithPeer(peerProfile, "audio")
                        } else {
                            onOpenStartCallSheet()
                        }
                    },
                    onVideoCallClick = {
                        if (isLive && call.callType == "video") {
                            onJoinCall(call)
                        } else if (linkedConv != null) {
                            onStartCallWithConversation(linkedConv, "video")
                        } else if (peerProfile != null) {
                            onStartCallWithPeer(peerProfile, "video")
                        } else {
                            onOpenStartCallSheet()
                        }
                    },
                    modifier = Modifier.smoothAppear(
                        enabled = smoothAppearance,
                        key = "call_hist_${call.id}",
                        delayMillis = index.coerceAtMost(6) * 20,
                        initialTranslationYDp = 10f,
                        durationMillis = 220
                    )
                )
            }
        }

        if (quickContacts.isNotEmpty()) {
            item(key = "quick_call_contacts_title") {
                Text(
                    text = "Быстрый звонок контактам",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(top = 6.dp)
                )
            }
            itemsIndexed(quickContacts, key = { _, person -> "quick_call_${person.userId}" }) { index, person ->
                QuickCallPeerCard(
                    peer = person,
                    presenceNowMs = presenceNowMs,
                    enabled = !isBusy,
                    onAudioCall = { onStartCallWithPeer(person, "audio") },
                    onVideoCall = { onStartCallWithPeer(person, "video") },
                    modifier = Modifier.smoothAppear(
                        enabled = smoothAppearance,
                        key = "quick_peer_${person.userId}",
                        delayMillis = index.coerceAtMost(5) * 18,
                        initialTranslationYDp = 10f,
                        durationMillis = 210
                    )
                )
            }
        }
    }
}

@Composable
private fun CallHistoryCard(
    call: CallSession,
    title: String,
    peerProfile: PublicUserProfile?,
    currentUserId: String,
    presenceNowMs: Long,
    enabled: Boolean,
    canCallback: Boolean,
    onCardClick: () -> Unit,
    onAudioCallClick: () -> Unit,
    onVideoCallClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isGlass = isLiquidGlassActive()
    val cardShape = RoundedCornerShape(18.dp)
    val isOutgoing = call.callerId == currentUserId
    val isVideo = call.callType == "video"
    val isLive = call.status == "ringing" || call.status == "active"

    val statusText = remember(call.status, call.createdAt, isOutgoing, isVideo) {
        val kind = if (isVideo) "Видео" else "Аудио"
        val dir = if (isOutgoing) "Исходящий" else "Входящий"
        val timeStr = formatCallTimestamp(call.updatedAt ?: call.createdAt)
        when (call.status) {
            "active" -> "$kind • Идёт сейчас"
            "ringing" -> if (isOutgoing) "$kind • Вызов..." else "$kind • Входящий вызов"
            else -> if (timeStr.isNotBlank()) "$dir ($kind) • $timeStr" else "$dir ($kind) • Завершён"
        }
    }

    Surface(
        shape = cardShape,
        color = if (isGlass) {
            Color.Transparent
        } else if (isLive) {
            MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.32f)
        } else {
            MaterialTheme.colorScheme.surfaceContainerLow
        },
        border = if (isGlass) null else BorderStroke(
            width = 1.dp,
            color = if (isLive) {
                MaterialTheme.colorScheme.primary.copy(alpha = 0.45f)
            } else {
                MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.7f)
            }
        ),
        modifier = modifier
            .fillMaxWidth()
            .then(
                if (isGlass) {
                    Modifier.liquidGlassSurface(
                        shape = cardShape,
                        tintColor = if (isLive) MaterialTheme.colorScheme.primaryContainer else null,
                        isHighlighted = isLive
                    )
                } else Modifier
            )
            .clip(cardShape)
            .clickable(enabled = enabled && canCallback, onClick = onCardClick)
            .testTag("call_history_card_${call.id}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (call.isGroupCall) {
                Surface(
                    shape = CircleShape,
                    color = MaterialTheme.colorScheme.secondaryContainer,
                    modifier = Modifier.size(46.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Filled.Groups,
                            contentDescription = title,
                            tint = MaterialTheme.colorScheme.onSecondaryContainer,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }
            } else {
                Box(contentAlignment = Alignment.BottomEnd) {
                    UserAvatar(
                        name = title,
                        avatarBase64 = peerProfile?.avatarBase64.orEmpty(),
                        colorIndex = (peerProfile?.avatarColorIndex ?: 0L).toInt(),
                        size = 46.dp
                    )
                    if (peerProfile != null && peerProfile.presenceStatus(presenceNowMs) == UserPresenceStatus.ONLINE) {
                        PresenceDotOverlay()
                    }
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(2.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    Icon(
                        imageVector = if (isOutgoing) {
                            Icons.AutoMirrored.Filled.CallMade
                        } else {
                            Icons.AutoMirrored.Filled.CallReceived
                        },
                        contentDescription = null,
                        tint = if (isLive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        text = statusText,
                        style = MaterialTheme.typography.bodySmall,
                        color = if (isLive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            IconButton(
                onClick = onAudioCallClick,
                enabled = enabled && canCallback,
                modifier = Modifier
                    .defaultMinSize(minWidth = 48.dp, minHeight = 48.dp)
                    .testTag("call_history_audio_${call.id}")
            ) {
                Icon(
                    imageVector = Icons.Filled.Call,
                    contentDescription = "Аудиозвонок: $title",
                    tint = MaterialTheme.colorScheme.primary
                )
            }
            IconButton(
                onClick = onVideoCallClick,
                enabled = enabled && canCallback,
                modifier = Modifier
                    .defaultMinSize(minWidth = 48.dp, minHeight = 48.dp)
                    .testTag("call_history_video_${call.id}")
            ) {
                Icon(
                    imageVector = Icons.Filled.Videocam,
                    contentDescription = "Видеозвонок: $title",
                    tint = MaterialTheme.colorScheme.secondary
                )
            }
        }
    }
}

@Composable
private fun QuickCallPeerCard(
    peer: PublicUserProfile,
    presenceNowMs: Long,
    enabled: Boolean,
    onAudioCall: () -> Unit,
    onVideoCall: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isGlass = isLiquidGlassActive()
    val cardShape = RoundedCornerShape(18.dp)
    val presence = peer.presenceStatus(presenceNowMs)
    val presenceLabel = when (presence) {
        UserPresenceStatus.ONLINE -> "В сети"
        UserPresenceStatus.RECENTLY -> "Был(а) недавно"
        UserPresenceStatus.OFFLINE -> if (peer.handle.isNotBlank()) "@${peer.handle.removePrefix("@")}" else "Не в сети"
    }

    Surface(
        shape = cardShape,
        color = if (isGlass) Color.Transparent else MaterialTheme.colorScheme.surfaceContainerLow,
        border = if (isGlass) null else BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.65f)),
        modifier = modifier
            .fillMaxWidth()
            .then(if (isGlass) Modifier.liquidGlassSurface(shape = cardShape) else Modifier)
            .clip(cardShape)
            .clickable(enabled = enabled, onClick = onAudioCall)
            .testTag("quick_call_peer_${peer.userId}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(contentAlignment = Alignment.BottomEnd) {
                UserAvatar(
                    name = peer.displayName,
                    avatarBase64 = peer.avatarBase64,
                    colorIndex = peer.avatarColorIndex.toInt(),
                    size = 44.dp
                )
                if (presence == UserPresenceStatus.ONLINE) {
                    PresenceDotOverlay()
                }
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = peer.displayName.ifBlank { "Пользователь" },
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = presenceLabel,
                    style = MaterialTheme.typography.bodySmall,
                    color = if (presence == UserPresenceStatus.ONLINE) {
                        MaterialTheme.colorScheme.primary
                    } else {
                        MaterialTheme.colorScheme.onSurfaceVariant
                    },
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            IconButton(
                onClick = onAudioCall,
                enabled = enabled,
                modifier = Modifier
                    .defaultMinSize(minWidth = 48.dp, minHeight = 48.dp)
                    .testTag("quick_call_audio_${peer.userId}")
            ) {
                Icon(
                    imageVector = Icons.Filled.Call,
                    contentDescription = "Позвонить ${peer.displayName}",
                    tint = MaterialTheme.colorScheme.primary
                )
            }
            IconButton(
                onClick = onVideoCall,
                enabled = enabled,
                modifier = Modifier
                    .defaultMinSize(minWidth = 48.dp, minHeight = 48.dp)
                    .testTag("quick_call_video_${peer.userId}")
            ) {
                Icon(
                    imageVector = Icons.Filled.Videocam,
                    contentDescription = "Видеозвонок ${peer.displayName}",
                    tint = MaterialTheme.colorScheme.secondary
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StartCallPickerSheet(
    currentUserId: String,
    conversations: List<Conversation>,
    directoryUsers: List<PublicUserProfile>,
    presenceNowMs: Long,
    isBusy: Boolean,
    onStartCallWithConversation: (Conversation, String) -> Unit,
    onStartCallWithPeer: (PublicUserProfile, String) -> Unit,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var query by remember { mutableStateOf("") }
    val trimmed = query.trim()

    val groupConvs = remember(conversations, trimmed) {
        conversations.filter { conv ->
            conv.isGroup && (trimmed.isEmpty() || conv.title.contains(trimmed, ignoreCase = true))
        }
    }

    val peers = remember(directoryUsers, currentUserId, trimmed, presenceNowMs) {
        val clean = trimmed.removePrefix("@")
        directoryUsers
            .filter { user ->
                user.userId != currentUserId &&
                    user.userId.isNotBlank() &&
                    (trimmed.isEmpty() ||
                        user.displayName.contains(trimmed, ignoreCase = true) ||
                        user.handle.removePrefix("@").contains(clean, ignoreCase = true))
            }
            .sortedWith(
                compareBy<PublicUserProfile> {
                    when (it.presenceStatus(presenceNowMs)) {
                        UserPresenceStatus.ONLINE -> 0
                        UserPresenceStatus.RECENTLY -> 1
                        UserPresenceStatus.OFFLINE -> 2
                    }
                }.thenBy { it.displayName.lowercase() }
            )
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = liquidGlassSheetContainerColor(),
        scrimColor = liquidGlassSheetScrimColor()
    ) {
        ApplyLiquidGlassWindowBlur()
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 8.dp)
                .testTag("start_call_picker_sheet"),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                text = "Новый звонок",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Выберите контакт или группу для аудио- или видеозвонка",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                placeholder = { Text("Поиск контакта или группы...") },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                trailingIcon = {
                    if (query.isNotEmpty()) {
                        IconButton(onClick = { query = "" }) {
                            Icon(Icons.Filled.Close, contentDescription = "Очистить")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("start_call_search_input")
            )

            if (peers.isEmpty() && groupConvs.isEmpty()) {
                Text(
                    text = if (trimmed.isEmpty()) {
                        "Нет доступных контактов или групп для вызова."
                    } else {
                        "По запросу «$trimmed» никого не найдено."
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(vertical = 18.dp)
                )
            } else {
                LazyColumn(
                    modifier = Modifier.height(340.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (groupConvs.isNotEmpty()) {
                        item(key = "sheet_groups_hdr") {
                            Text(
                                text = "Группы (${groupConvs.size})",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        items(groupConvs, key = { "grp_${it.id}" }) { conv ->
                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = MaterialTheme.colorScheme.surfaceContainerLow,
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 12.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Surface(
                                        shape = CircleShape,
                                        color = MaterialTheme.colorScheme.secondaryContainer,
                                        modifier = Modifier.size(40.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon(
                                                imageVector = Icons.Filled.Groups,
                                                contentDescription = null,
                                                tint = MaterialTheme.colorScheme.onSecondaryContainer
                                            )
                                        }
                                    }
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Text(
                                        text = conv.title.ifBlank { "Групповой чат" },
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.SemiBold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.weight(1f)
                                    )
                                    IconButton(
                                        onClick = {
                                            onDismiss()
                                            onStartCallWithConversation(conv, "audio")
                                        },
                                        enabled = !isBusy,
                                        modifier = Modifier.defaultMinSize(minWidth = 48.dp, minHeight = 48.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Filled.Call,
                                            contentDescription = "Аудиозвонок в группу",
                                            tint = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                    IconButton(
                                        onClick = {
                                            onDismiss()
                                            onStartCallWithConversation(conv, "video")
                                        },
                                        enabled = !isBusy,
                                        modifier = Modifier.defaultMinSize(minWidth = 48.dp, minHeight = 48.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Filled.Videocam,
                                            contentDescription = "Видеозвонок в группу",
                                            tint = MaterialTheme.colorScheme.secondary
                                        )
                                    }
                                }
                            }
                        }
                    }

                    if (peers.isNotEmpty()) {
                        item(key = "sheet_peers_hdr") {
                            Text(
                                text = "Люди (${peers.size})",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        items(peers, key = { "peer_${it.userId}" }) { peer ->
                            QuickCallPeerCard(
                                peer = peer,
                                presenceNowMs = presenceNowMs,
                                enabled = !isBusy,
                                onAudioCall = {
                                    onDismiss()
                                    onStartCallWithPeer(peer, "audio")
                                },
                                onVideoCall = {
                                    onDismiss()
                                    onStartCallWithPeer(peer, "video")
                                }
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))
        }
    }
}

@Composable
private fun PresenceDotOverlay() {
    val dotColor = LocalPresenceColors.current.online
    Box(
        modifier = Modifier
            .size(12.dp)
            .clip(CircleShape)
            .background(dotColor)
            .border(2.dp, MaterialTheme.colorScheme.surface, CircleShape)
    )
}

private fun formatCallTimestamp(timestamp: Timestamp?): String =
    TimeFormatters.formatCallTimestamp(timestamp)
