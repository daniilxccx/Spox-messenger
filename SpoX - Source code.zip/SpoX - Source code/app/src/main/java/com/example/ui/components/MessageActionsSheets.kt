package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Forward
import androidx.compose.material.icons.automirrored.filled.Reply
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkAdd
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.data.model.Conversation
import com.example.data.model.DecryptedContent
import com.example.data.model.DecryptedMessageItem
import com.example.data.model.ForwardOriginInfo
import com.example.data.model.PublicUserProfile
import com.example.data.model.ReplyQuoteInfo

@Composable
fun SavedMessagesAvatar(
    size: Dp = 50.dp,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = CircleShape,
        color = Color.Transparent,
        border = BorderStroke(1.2.dp, Color.White.copy(alpha = 0.25f)),
        shadowElevation = 2.dp,
        modifier = modifier.size(size)
    ) {
        Box(
            modifier = Modifier
                .size(size)
                .clip(CircleShape)
                .background(
                    Brush.linearGradient(
                        listOf(
                            MaterialTheme.colorScheme.primary,
                            MaterialTheme.colorScheme.secondary,
                            MaterialTheme.colorScheme.tertiary
                        )
                    )
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Filled.Bookmark,
                contentDescription = "Избранное",
                tint = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.size(size * 0.50f)
            )
        }
    }
}

@Composable
fun ReplyComposerPreviewBar(
    replyTo: ReplyQuoteInfo,
    onCancel: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.94f),
        shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp),
        modifier = modifier
            .fillMaxWidth()
            .testTag("reply_composer_bar")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 14.dp, end = 6.dp, top = 8.dp, bottom = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                shape = CircleShape,
                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.14f),
                modifier = Modifier.size(30.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Reply,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.width(10.dp))
            Box(
                modifier = Modifier
                    .width(3.dp)
                    .height(34.dp)
                    .clip(RoundedCornerShape(50))
                    .background(MaterialTheme.colorScheme.primary)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = replyTo.senderName,
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = replyTo.previewText,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            IconButton(
                onClick = onCancel,
                modifier = Modifier
                    .size(48.dp)
                    .testTag("cancel_reply_button")
            ) {
                Icon(
                    imageVector = Icons.Filled.Close,
                    contentDescription = "Отменить ответ",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
fun MessageQuoteBlock(
    replyTo: ReplyQuoteInfo,
    isMine: Boolean,
    accentColor: Color,
    textColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val bgColor = if (isMine) {
        textColor.copy(alpha = 0.13f)
    } else {
        MaterialTheme.colorScheme.primary.copy(alpha = 0.10f)
    }
    val barColor = if (isMine) textColor.copy(alpha = 0.88f) else accentColor
    Surface(
        shape = RoundedCornerShape(11.dp),
        color = bgColor,
        border = BorderStroke(0.5.dp, barColor.copy(alpha = 0.25f)),
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("reply_quote_block")
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 9.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .width(3.dp)
                    .height(28.dp)
                    .clip(RoundedCornerShape(50))
                    .background(barColor)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = replyTo.senderName,
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = barColor,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = replyTo.previewText,
                    style = MaterialTheme.typography.bodySmall,
                    color = textColor.copy(alpha = 0.88f),
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
fun ForwardedHeaderLabel(
    origin: ForwardOriginInfo,
    accentColor: Color,
    textColor: Color,
    modifier: Modifier = Modifier
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = modifier.testTag("forwarded_header_label")
    ) {
        Icon(
            imageVector = Icons.AutoMirrored.Filled.Forward,
            contentDescription = null,
            tint = accentColor,
            modifier = Modifier.size(13.dp)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = "Переслано от ${origin.originalSenderName}",
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.SemiBold,
            color = textColor.copy(alpha = 0.85f),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MessageActionsSheet(
    item: DecryptedMessageItem,
    isMine: Boolean,
    isSavedChat: Boolean,
    onDismiss: () -> Unit,
    onReply: () -> Unit,
    onForwardToSaved: () -> Unit,
    onForwardToChat: () -> Unit,
    onCopyText: ((String) -> Unit)?,
    onDelete: () -> Unit
) {
    val previewSummary = remember(item) {
        when (val c = item.content) {
            is DecryptedContent.Text -> c.text
            is DecryptedContent.Voice -> "Голосовое сообщение (${formatDurationMillis(c.durationMs)})"
            is DecryptedContent.FileAttachment -> if (c.isImage) "Фото: ${c.fileName}" else "Файл: ${c.fileName}"
            else -> "Сообщение"
        }
    }
    val copyableText = (item.content as? DecryptedContent.Text)?.text

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = MaterialTheme.colorScheme.surfaceContainerHigh,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
                    Text(
                        text = if (isMine) "Ваше сообщение" else item.senderName.ifBlank { "Собеседник" },
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = previewSummary,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            ActionRowCard(
                icon = Icons.AutoMirrored.Filled.Reply,
                title = "Ответить",
                subtitle = "Ответить с цитатой на это сообщение",
                tint = MaterialTheme.colorScheme.primary,
                onClick = {
                    onDismiss()
                    onReply()
                },
                modifier = Modifier.testTag("action_reply_message")
            )

            if (!isSavedChat) {
                ActionRowCard(
                    icon = Icons.Filled.BookmarkAdd,
                    title = "Переслать в «Избранное»",
                    subtitle = "Сохранить в ваш личный зашифрованный чат",
                    tint = MaterialTheme.colorScheme.tertiary,
                    onClick = {
                        onDismiss()
                        onForwardToSaved()
                    },
                    modifier = Modifier.testTag("action_forward_to_saved")
                )
            }

            ActionRowCard(
                icon = Icons.AutoMirrored.Filled.Forward,
                title = "Переслать...",
                subtitle = "Выбрать другой чат или собеседника",
                tint = MaterialTheme.colorScheme.secondary,
                onClick = {
                    onDismiss()
                    onForwardToChat()
                },
                modifier = Modifier.testTag("action_forward_to_chat")
            )

            if (copyableText != null && onCopyText != null) {
                ActionRowCard(
                    icon = Icons.Filled.ContentCopy,
                    title = "Скопировать текст",
                    subtitle = null,
                    tint = MaterialTheme.colorScheme.onSurface,
                    onClick = {
                        onDismiss()
                        onCopyText(copyableText)
                    },
                    modifier = Modifier.testTag("action_copy_message")
                )
            }

            if (isMine) {
                ActionRowCard(
                    icon = Icons.Filled.Delete,
                    title = "Удалить сообщение",
                    subtitle = "Заменить на метку удаления у всех",
                    tint = MaterialTheme.colorScheme.error,
                    onClick = {
                        onDismiss()
                        onDelete()
                    },
                    modifier = Modifier.testTag("action_delete_message")
                )
            }

            Spacer(modifier = Modifier.height(10.dp))
        }
    }
}

@Composable
private fun ActionRowCard(
    icon: ImageVector,
    title: String,
    subtitle: String?,
    tint: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surfaceContainer,
        modifier = modifier
            .fillMaxWidth()
            .defaultMinSize(minHeight = 48.dp)
            .clickable(onClick = onClick)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = tint,
                modifier = Modifier.size(22.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall,
                    color = if (tint == MaterialTheme.colorScheme.error) tint else MaterialTheme.colorScheme.onSurface
                )
                if (!subtitle.isNullOrBlank()) {
                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ForwardTargetSheet(
    conversations: List<Conversation>,
    directoryUsers: List<PublicUserProfile>,
    currentUserId: String,
    isForwarding: Boolean,
    resolveTitle: (Conversation) -> String,
    resolveDirectPeer: (Conversation) -> PublicUserProfile?,
    onDismiss: () -> Unit,
    onSelectSaved: () -> Unit,
    onSelectConversation: (Conversation, String) -> Unit,
    onSelectUser: (PublicUserProfile) -> Unit
) {
    var query by remember { mutableStateOf("") }
    val trimmed = query.trim()

    val regularConversations = remember(conversations, trimmed, currentUserId) {
        conversations
            .filter { !it.isSavedMessages(currentUserId) }
            .filter { conv ->
                if (trimmed.isEmpty()) true
                else resolveTitle(conv).contains(trimmed, ignoreCase = true)
            }
    }

    val existingDirectPeerUids = remember(conversations, currentUserId) {
        conversations
            .filter { !it.isGroup && !it.isSavedMessages(currentUserId) }
            .mapNotNull { conv -> conv.memberUids.firstOrNull { it != currentUserId } }
            .toSet()
    }

    val extraUsers = remember(directoryUsers, existingDirectPeerUids, trimmed, currentUserId) {
        directoryUsers
            .filter { it.userId != currentUserId && it.userId !in existingDirectPeerUids }
            .filter { user ->
                if (trimmed.isEmpty()) true
                else user.displayName.contains(trimmed, ignoreCase = true) ||
                    user.handle.contains(trimmed, ignoreCase = true)
            }
    }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Переслать сообщение",
                        style = MaterialTheme.typography.titleLarge
                    )
                    Text(
                        text = "Выберите «Избранное», чат или собеседника",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                if (isForwarding) {
                    CircularProgressIndicator(modifier = Modifier.size(22.dp), strokeWidth = 2.dp)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                placeholder = { Text("Поиск чата или человека...") },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                trailingIcon = {
                    if (query.isNotEmpty()) {
                        IconButton(onClick = { query = "" }) {
                            Icon(Icons.Filled.Close, contentDescription = "Очистить")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("forward_search_input")
            )

            Spacer(modifier = Modifier.height(12.dp))

            val showSaved = trimmed.isEmpty() ||
                "избранное".contains(trimmed, ignoreCase = true) ||
                "saved".contains(trimmed, ignoreCase = true)

            LazyColumn(
                modifier = Modifier.height(340.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (showSaved) {
                    item(key = "forward_saved") {
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.4f)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .defaultMinSize(minHeight = 48.dp)
                                .clickable(enabled = !isForwarding, onClick = onSelectSaved)
                                .testTag("forward_target_saved")
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                SavedMessagesAvatar(size = 42.dp)
                                Spacer(modifier = Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "Избранное",
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "Личное зашифрованное хранилище",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.Forward,
                                    contentDescription = "Переслать в Избранное",
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }
                }

                if (regularConversations.isNotEmpty()) {
                    item(key = "hdr_chats") {
                        Text(
                            text = "Ваши чаты",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                    items(regularConversations, key = { "conv_${it.id}" }) { conv ->
                        val title = resolveTitle(conv)
                        val peer = resolveDirectPeer(conv)
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = MaterialTheme.colorScheme.surfaceContainer,
                            modifier = Modifier
                                .fillMaxWidth()
                                .defaultMinSize(minHeight = 48.dp)
                                .clickable(enabled = !isForwarding) {
                                    onSelectConversation(conv, title)
                                }
                                .testTag("forward_target_conv_${conv.id}")
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                UserAvatar(
                                    name = title,
                                    avatarBase64 = if (conv.isGroup) "" else peer?.avatarBase64.orEmpty(),
                                    colorIndex = peer?.avatarColorIndex?.toInt() ?: kotlin.math.abs(title.hashCode()),
                                    isGroup = conv.isGroup,
                                    size = 38.dp
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        if (conv.isGroup) {
                                            Icon(
                                                imageVector = Icons.Filled.Groups,
                                                contentDescription = null,
                                                tint = MaterialTheme.colorScheme.tertiary,
                                                modifier = Modifier.size(15.dp)
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                        }
                                        Text(
                                            text = title,
                                            style = MaterialTheme.typography.titleSmall,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                    Text(
                                        text = if (conv.isGroup) "Группа • ${conv.memberUids.size} уч." else "Личный чат E2EE",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }

                if (extraUsers.isNotEmpty()) {
                    item(key = "hdr_users") {
                        HorizontalDivider(modifier = Modifier.padding(vertical = 2.dp))
                        Text(
                            text = "Люди в SpoX",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                    items(extraUsers, key = { "usr_${it.userId}" }) { user ->
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = MaterialTheme.colorScheme.surfaceContainer,
                            modifier = Modifier
                                .fillMaxWidth()
                                .defaultMinSize(minHeight = 48.dp)
                                .clickable(enabled = !isForwarding) {
                                    onSelectUser(user)
                                }
                                .testTag("forward_target_user_${user.userId}")
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                UserAvatar(
                                    name = user.displayName,
                                    avatarBase64 = user.avatarBase64,
                                    colorIndex = user.avatarColorIndex.toInt(),
                                    size = 38.dp
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = user.displayName,
                                        style = MaterialTheme.typography.titleSmall,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    if (user.handle.isNotBlank()) {
                                        Text(
                                            text = user.handle,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(10.dp))
        }
    }
}
