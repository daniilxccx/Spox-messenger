package com.example.data.repository

import android.content.Context
import android.util.Log
import com.example.R
import com.google.firebase.Firebase
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class ActiveFirebaseSession(
    val appName: String,
    val app: FirebaseApp,
    val auth: FirebaseAuth
)

/**
 * Maintains isolated FirebaseApp sessions per saved SpoX account (up to MAX_ACCOUNTS slots)
 * so switching between previously signed-in profiles does not sign out existing sessions or
 * force the user to re-pick their Google account every time.
 */
object FirebaseSessionManager {

    private const val TAG = "FirebaseSessionManager"
    private const val PREFS_NAME = "spox_active_session"
    private const val KEY_ACTIVE_APP_NAME = "active_app_name"

    const val DEFAULT_SESSION_NAME: String = FirebaseApp.DEFAULT_APP_NAME
    private val SLOT_NAMES: List<String> = listOf(
        DEFAULT_SESSION_NAME,
        "spox_acc_1",
        "spox_acc_2",
        "spox_acc_3",
        "spox_acc_4"
    )

    private val _activeSession = MutableStateFlow<ActiveFirebaseSession?>(null)
    val activeSession: StateFlow<ActiveFirebaseSession?> = _activeSession.asStateFlow()

    @Synchronized
    fun ensureInitialized(
        context: Context,
        savedAccounts: List<SavedAccount> = emptyList()
    ): ActiveFirebaseSession? {
        val appContext = context.applicationContext
        val defaultApp = ensureDefaultApp(appContext) ?: return null

        val persistedAppName = readPersistedActiveAppName(appContext)
        val initialApp = getOrCreateApp(appContext, persistedAppName) ?: defaultApp

        syncSavedAccountAppsLocked(appContext, savedAccounts)

        val current = _activeSession.value
        if (current != null && current.appName == initialApp.name) {
            return current
        }

        val session = ActiveFirebaseSession(
            appName = initialApp.name,
            app = initialApp,
            auth = FirebaseAuth.getInstance(initialApp)
        )
        _activeSession.value = session
        return session
    }

    fun observeActiveSession(context: Context): StateFlow<ActiveFirebaseSession?> {
        ensureInitialized(context)
        return activeSession
    }

    @Synchronized
    fun syncSavedAccountApps(context: Context, savedAccounts: List<SavedAccount>) {
        val appContext = context.applicationContext
        if (ensureDefaultApp(appContext) == null) return
        syncSavedAccountAppsLocked(appContext, savedAccounts)
    }

    private fun syncSavedAccountAppsLocked(context: Context, savedAccounts: List<SavedAccount>) {
        val namesToWarm = linkedSetOf<String>().apply {
            addAll(SLOT_NAMES)
            savedAccounts.forEach { acc ->
                if (acc.sessionAppName.isNotBlank()) add(acc.sessionAppName)
            }
        }
        namesToWarm.forEach { name ->
            getOrCreateApp(context, name)
        }
    }

    fun getOrCreateApp(context: Context, appName: String): FirebaseApp? {
        val appContext = context.applicationContext
        val defaultApp = ensureDefaultApp(appContext) ?: return null
        val normalized = appName.trim()
        if (normalized.isBlank() || normalized == DEFAULT_SESSION_NAME) {
            return defaultApp
        }
        val existing = runCatching {
            FirebaseApp.getApps(appContext).firstOrNull { it.name == normalized }
        }.getOrNull()
        if (existing != null) return existing

        return runCatching {
            FirebaseApp.initializeApp(appContext, defaultApp.options, normalized)
        }.onFailure { err ->
            Log.w(TAG, "Failed to initialize named FirebaseApp $normalized: ${err.message}")
        }.getOrNull()
    }

    @Synchronized
    fun findLiveAppForAccount(context: Context, account: SavedAccount): FirebaseApp? {
        val appContext = context.applicationContext
        if (account.uid.isBlank()) return null
        if (ensureDefaultApp(appContext) == null) return null

        val candidateNames = linkedSetOf<String>().apply {
            if (account.sessionAppName.isNotBlank()) add(account.sessionAppName)
            addAll(SLOT_NAMES)
        }

        for (slotName in candidateNames) {
            val app = getOrCreateApp(appContext, slotName) ?: continue
            val currentUser = runCatching { FirebaseAuth.getInstance(app).currentUser }.getOrNull()
            if (currentUser != null && currentUser.uid == account.uid) {
                return app
            }
        }
        return null
    }

    fun hasLiveSessionForAccount(context: Context, account: SavedAccount): Boolean {
        return findLiveAppForAccount(context, account) != null
    }

    @Synchronized
    fun activateApp(context: Context, appName: String): ActiveFirebaseSession? {
        val appContext = context.applicationContext
        val app = getOrCreateApp(appContext, appName) ?: return null
        persistActiveAppName(appContext, app.name)
        val session = ActiveFirebaseSession(
            appName = app.name,
            app = app,
            auth = FirebaseAuth.getInstance(app)
        )
        _activeSession.value = session
        return session
    }

    @Synchronized
    fun tryInstantSwitch(context: Context, account: SavedAccount): Boolean {
        val liveApp = findLiveAppForAccount(context, account) ?: return false
        return activateApp(context, liveApp.name) != null
    }

    @Synchronized
    fun resolveTargetAppForGoogleEmail(
        context: Context,
        googleEmail: String,
        savedAccounts: List<SavedAccount>
    ): FirebaseApp? {
        val appContext = context.applicationContext
        val defaultApp = ensureDefaultApp(appContext) ?: return null
        syncSavedAccountAppsLocked(appContext, savedAccounts)

        val trimmedEmail = googleEmail.trim()
        if (trimmedEmail.isNotBlank()) {
            val matchingSaved = savedAccounts.firstOrNull {
                it.email.equals(trimmedEmail, ignoreCase = true) && it.sessionAppName.isNotBlank()
            }
            if (matchingSaved != null) {
                getOrCreateApp(appContext, matchingSaved.sessionAppName)?.let { return it }
            }

            for (slotName in SLOT_NAMES) {
                val app = getOrCreateApp(appContext, slotName) ?: continue
                val existingEmail = runCatching { FirebaseAuth.getInstance(app).currentUser?.email }.getOrNull()
                if (!existingEmail.isNullOrBlank() && existingEmail.equals(trimmedEmail, ignoreCase = true)) {
                    return app
                }
            }
        }

        val claimedByOtherAccounts = savedAccounts
            .filter { acc ->
                acc.sessionAppName.isNotBlank() &&
                    (trimmedEmail.isBlank() || !acc.email.equals(trimmedEmail, ignoreCase = true))
            }
            .map { it.sessionAppName }
            .toSet()

        // Prefer a completely unclaimed, signed-out slot so other saved accounts keep their sessions.
        for (slotName in SLOT_NAMES) {
            if (slotName in claimedByOtherAccounts) continue
            val app = getOrCreateApp(appContext, slotName) ?: continue
            val user = runCatching { FirebaseAuth.getInstance(app).currentUser }.getOrNull()
            if (user == null) {
                return app
            }
        }

        // Next, any slot whose FirebaseAuth is signed out.
        for (slotName in SLOT_NAMES) {
            val app = getOrCreateApp(appContext, slotName) ?: continue
            val user = runCatching { FirebaseAuth.getInstance(app).currentUser }.getOrNull()
            if (user == null) {
                return app
            }
        }

        return defaultApp
    }

    @Synchronized
    fun clearAccountSession(context: Context, account: SavedAccount) {
        val appContext = context.applicationContext
        if (account.uid.isBlank()) return
        if (ensureDefaultApp(appContext) == null) return

        val candidateNames = linkedSetOf<String>().apply {
            if (account.sessionAppName.isNotBlank()) add(account.sessionAppName)
            addAll(SLOT_NAMES)
        }
        for (slotName in candidateNames) {
            val app = getOrCreateApp(appContext, slotName) ?: continue
            val auth = runCatching { FirebaseAuth.getInstance(app) }.getOrNull() ?: continue
            if (auth.currentUser?.uid == account.uid) {
                runCatching { auth.signOut() }
            }
        }
    }

    fun getActiveApp(context: Context): FirebaseApp? {
        return ensureInitialized(context)?.app
    }

    fun getActiveAuth(context: Context): FirebaseAuth? {
        return ensureInitialized(context)?.auth
    }

    fun activeAuthOrDefault(): FirebaseAuth {
        return _activeSession.value?.auth ?: Firebase.auth
    }

    fun getFirestore(context: Context, app: FirebaseApp): FirebaseFirestore? {
        val appContext = context.applicationContext
        return runCatching {
            val dbId = appContext.getString(R.string.firestore_database_id)
            FirebaseFirestore.getInstance(app, dbId)
        }.onFailure { err ->
            Log.e(TAG, "Firestore initialization failed for ${app.name}", err)
        }.getOrNull()
    }

    fun getActiveFirestore(context: Context): FirebaseFirestore? {
        val app = getActiveApp(context) ?: return null
        return getFirestore(context, app)
    }

    private fun ensureDefaultApp(appContext: Context): FirebaseApp? {
        return runCatching {
            val existing = FirebaseApp.getApps(appContext).firstOrNull { it.name == DEFAULT_SESSION_NAME }
            existing ?: FirebaseApp.initializeApp(appContext) ?: FirebaseApp.getInstance()
        }.onFailure { err ->
            Log.e(TAG, "Default FirebaseApp initialization failed", err)
        }.getOrNull()
    }

    private fun readPersistedActiveAppName(appContext: Context): String {
        val prefs = appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getString(KEY_ACTIVE_APP_NAME, DEFAULT_SESSION_NAME)
            ?.takeIf { it.isNotBlank() }
            ?: DEFAULT_SESSION_NAME
    }

    private fun persistActiveAppName(appContext: Context, appName: String) {
        appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_ACTIVE_APP_NAME, appName)
            .apply()
    }
}
