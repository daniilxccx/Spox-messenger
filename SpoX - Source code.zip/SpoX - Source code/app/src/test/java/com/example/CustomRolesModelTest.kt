package com.example

import com.example.data.model.CustomRolePalette
import com.example.data.model.CustomRolePermission
import com.example.data.model.CustomRoleRecord
import com.example.data.model.ModerationStatus
import com.example.data.model.PublicUserProfile
import com.example.data.model.UserPrivateProfile
import com.example.data.model.UserRole
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class CustomRolesModelTest {

    @Test
    fun `developer has all permissions regardless of custom role`() {
        val dev = UserPrivateProfile(
            userId = "dev_1",
            role = UserRole.DEVELOPER.wireValue,
            moderationStatus = ModerationStatus.ACTIVE.wireValue,
            customRolePermissions = emptyList()
        )
        assertEquals(CustomRolePermission.entries.toSet(), dev.effectivePermissions())
        assertTrue(dev.hasPermission(CustomRolePermission.MODERATE_BAN))
        assertTrue(dev.hasPermission(CustomRolePermission.ISSUE_TESTER_CODES))
    }

    @Test
    fun `banned user loses all permissions even with custom role or developer flag`() {
        val bannedMod = UserPrivateProfile(
            userId = "mod_1",
            role = UserRole.USER.wireValue,
            moderationStatus = ModerationStatus.BANNED.wireValue,
            customRoleId = "role_mod",
            customRoleName = "Модератор",
            customRoleBadge = "MOD",
            customRolePermissions = listOf("view_moderation", "moderate_mute")
        )
        assertTrue(bannedMod.effectivePermissions().isEmpty())
        assertFalse(bannedMod.hasPermission(CustomRolePermission.VIEW_MODERATION))
        assertFalse(bannedMod.hasPermission(CustomRolePermission.MODERATE_MUTE))
    }

    @Test
    fun `regular user receives only permissions granted by custom role`() {
        val moderator = UserPrivateProfile(
            userId = "u_mod",
            role = UserRole.TESTER.wireValue,
            moderationStatus = ModerationStatus.ACTIVE.wireValue,
            customRoleId = "role_support",
            customRoleName = "Саппорт",
            customRoleBadge = "SUP",
            customRoleColorHex = CustomRolePalette.PRESET_COLORS.first(),
            customRolePermissions = listOf("view_moderation", "moderate_mute", "unknown_ignored")
        )
        assertTrue(moderator.hasCustomRole())
        assertTrue(moderator.hasPermission(CustomRolePermission.VIEW_MODERATION))
        assertTrue(moderator.hasPermission(CustomRolePermission.MODERATE_MUTE))
        assertFalse(moderator.hasPermission(CustomRolePermission.MODERATE_BAN))
        assertFalse(moderator.hasPermission(CustomRolePermission.ISSUE_TESTER_CODES))
    }

    @Test
    fun `custom role record parses valid permissions and resolves id`() {
        val record = CustomRoleRecord(
            id = "doc_abc",
            roleId = "",
            name = "Хранитель чатов",
            badgeText = "GUARD",
            colorHex = "#00D2A8",
            permissions = listOf("manage_groups", "priority_badge", "invalid_key")
        )
        assertEquals("doc_abc", record.resolvedId())
        assertEquals(
            setOf(CustomRolePermission.MANAGE_GROUPS, CustomRolePermission.PRIORITY_BADGE),
            record.parsedPermissions()
        )

        val pub = PublicUserProfile(
            userId = "u_1",
            customRoleId = "doc_abc",
            customRoleName = "Хранитель чатов",
            customRoleBadge = "GUARD",
            customRoleColorHex = "#00D2A8",
            customRolePermissions = listOf("manage_groups", "priority_badge")
        )
        assertTrue(pub.hasCustomRole())
        assertEquals(
            setOf(CustomRolePermission.MANAGE_GROUPS, CustomRolePermission.PRIORITY_BADGE),
            pub.effectivePermissions()
        )
    }
}
